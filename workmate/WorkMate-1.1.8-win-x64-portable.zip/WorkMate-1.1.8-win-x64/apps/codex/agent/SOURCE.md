# Prompt source

- Repository: https://github.com/openai/codex
- Commit: `25f4940d4affcf8c60f96ffec5e3752e1f590b8a`
- Primary source: `codex-rs/core/gpt-5.2-codex_prompt.md`
- License: Apache-2.0
- Retrieved: 2026-11-09

- Runtime source snapshot: `agent/upstream.md` (verbatim upstream prompt)

## Adaptation

`agent/core.md` retains the latest upstream Codex working method, editing
constraints, dirty-worktree safety, review behavior, frontend-task guidance,
and response-delivery rules. Runtime-only CLI identity and unavailable tool
details are adapted to WorkMate. WorkMate's runtime contract owns tools,
permissions, sandboxing, filesystem safety, reminders, and artifact delivery.
No upstream executable code is bundled.
