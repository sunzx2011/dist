WorkMate 1.1.8 · Windows 免安装版（x64）
=====================================================

怎么用
------
1. 把整个文件夹解压到任意位置（不要只解出 WorkMate.exe，assets/ 与 apps/ 要跟着）。
2. 双击 WorkMate.exe 即可。不写注册表、不装服务、不建开始菜单项。
3. 卸载 = 直接删掉这个文件夹。

系统要求
--------
* Windows 10 1803+ / Windows 11（x64）
* WebView2 运行时：Windows 11 自带；Windows 10 一般随 Edge 已装。
  如果双击后提示缺少 WebView2，装一次微软官方 Evergreen Runtime 即可：
  https://developer.microsoft.com/microsoft-edge/webview2/
* 本开发包未做代码签名，首次运行可能被 SmartScreen 拦：点「更多信息」→「仍要运行」。

数据放在哪
----------
默认 %USERPROFILE%\.workmate（会话、模型配置、专家、日志都在这里）。
想让它完全绿色（数据跟着程序走），启动前设一个环境变量：

    set WORKMATE_CONFIG_DIR=%CD%\data
    WorkMate.exe

（也可以只设 WORKBUDDY_CONFIG_DIR / CODEBUDDY_CONFIG_DIR，作用相同。）

Computer Use
------------
本主包不包含 Computer Use。Computer Use 是独立的可选扩展，不影响 WorkMate 的其他功能。
需要时请单独解压 WorkMate Computer Use 扩展到下面任一位置：

    %USERPROFILE%\.workmate\extensions
    %USERPROFILE%\.workmate\extensions\computer-use
    WorkMate.exe 同级的 ComputerUse 目录

扩展安装后重新打开 WorkMate，再到“设置 → 智能体 → 电脑操控”启用。

如果这台机器连 exe 都不允许运行（AppLocker / WDAC / Smart App Control）
--------------------------------------------------------------------
那就不在这台机器上跑任何东西。在另一台你能控制的机器（Mac / 内网服务器）上：

    node scripts/workmate-web.mjs --host 0.0.0.0 --port 8787 --ui ui/dist

它会打印一个带 token 的地址（形如 http://192.168.1.20:8787/?token=XXXX），
在受限机器上用 Edge / Chrome 打开即可。注意：这个端口等于「远程执行 shell」的入口，
只在自己内网开。
