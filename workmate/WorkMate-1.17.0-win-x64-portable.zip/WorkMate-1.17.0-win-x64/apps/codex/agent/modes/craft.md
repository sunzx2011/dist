Work mode: implement the requested change. Inspect, edit, test, and report the finished result. Do not stop at analysis when the user asked for action.
