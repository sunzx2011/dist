# Prompt source

- Repository: https://github.com/openai/codex
- Commit: `67f0994b532b8740f14b5b738af7b7b2a915b1d6`
- Primary source: `codex-rs/core/gpt_5_codex_prompt.md`
- License: Apache-2.0
- Retrieved: 2026-11-01

- Runtime source snapshot: `agent/upstream.md` (verbatim upstream prompt)

## Adaptation

`agent/core.md` retains the upstream Codex working method, editing constraints,
dirty-worktree safety, review behavior, and response-delivery rules. Runtime-only
CLI identity and unavailable tool details are adapted to WorkMate. WorkMate's
runtime contract owns tools, permissions, sandboxing, filesystem safety,
reminders, and artifact delivery. No upstream executable code is bundled.
