# Buddy App packages

Each subdirectory is an independently removable Buddy App package.

Required files:

- `app.json` — package manifest (`kind: "buddy-app"`)
- `home/categories.json` — homepage tabs, scenes and quick prompts
- `prompts/system.md` — app identity and boundaries
- `prompts/modes/*.md` — per-mode prompts
- `icon.png` or `icon.svg`

Optional capability files:

- `workflow/plan.schema.json`
- `workflow/evidence.schema.json`

Optional package-local Agent Profile:

- `app.json` → `"agent": { "profile": "agent/profile.json" }`
- `agent/profile.json` — core prompt, optional mode prompts, source metadata,
  and `tools` / `skills` policies
- `agent/core.md` and optional `agent/modes/*.md`
- `agent/SOURCE.md` plus upstream license/notice files

Agent Profiles are isolated to their app package. Paths are relative to that
package and cannot reference another app or resolve through a symlink outside
the package. Runtime `core.md` files retain the documented upstream core rules;
tool- or provider-specific details are adapted to WorkMate's runtime contract.
The profile is frozen into a conversation when it is created; changing an app
affects new conversations only.

The host scans this directory through the generic Buddy App registry. Core does
not contain app-id branches. Deleting a package directory removes the app from
the app switcher; its data under a target project's `.workmate/workflow/`
directory is intentionally left untouched.
