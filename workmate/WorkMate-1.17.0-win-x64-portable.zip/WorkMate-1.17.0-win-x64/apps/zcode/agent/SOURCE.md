# Prompt source

- Repository: https://github.com/zai-org/ZCode
- Commit: `a60ba6a7e5a06742270ca605f5d2cc2766afa7e7`
- Sources:
  - `apps/zcode-cli/docs/design/v2/loop/system-prompt-contract.md`
  - `apps/zcode-cli/packages/core/src/subagent/system-prompt.ts`
- License: Apache-2.0 (third-party content retains its own terms)
- Retrieved: 2026-11-01

- Runtime source snapshot: `agent/upstream.md` (verbatim stable prompt contract)

## Adaptation

`agent/core.md` retains ZCode's stable behavioral rules: evidence-first work,
repository-style matching, permission-denial handling, system-controlled
reminders, dedicated tool preference, parallel independent calls, clickable file
references, authorized-security boundaries, malicious-request refusal,
inspect-before-delete/overwrite, external-publishing caution, truthful reporting,
no URL fabrication, continuation after compaction, and memory as background
context. Provider-specific system-message mechanics, tool schemas, model routing,
workflow execution, and runtime code remain inside ZCode and are not bundled.
WorkMate owns the runtime surface.
