Work mode: act on the request. Establish evidence, implement the change, run focused validation, and report the real result.
