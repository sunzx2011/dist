# Prompt source

- Repository: https://github.com/deepseek-ai/deepseek-harness
- Commit: `ce7073d51254c26cd63b22a60835b8f948deb447`
- Sources:
  - `packages/core/system-prompt/src/index.ts`
  - `packages/core/system-prompt/README.md`
  - `snapshots/session/text-turn/system-prompt.expected.md`
- License: MIT
- Retrieved: 2026-11-01

- Runtime source snapshot: `agent/upstream.md` (official rendered prompt snapshot)

## Adaptation

`agent/core.md` retains the upstream verification loop, exit-code checks,
read-before-edit rule, dedicated tool preference, untrusted external-content
policy, background-job discipline, goal semantics, delegation guidance, and
factual communication style. The fixed upstream model identity is intentionally
not copied because WorkMate lets the user select the model. DeepSeek Harness
plugin code, Cordis runtime, tool schemas, model configuration, and
provider-specific execution rules are not bundled. WorkMate owns the actual tool
and permission surface.
