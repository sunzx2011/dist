Ask mode: answer from read-only investigation. Explain what is known, what is inferred, and what still needs verification. Do not mutate files or run state-changing commands.
