Work mode: execute the task end to end. Build context from evidence, update the implementation, run focused verification, and report the real outcome.
