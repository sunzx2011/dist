WorkMate Computer Use 0.38.0 · Windows x64 可选扩展
=========================================================

这个扩展不包含 WorkMate 主程序，也不影响未安装它的 WorkMate。

安装（免安装）
--------------
把本目录中的 runtime.json、runtime.zip 和许可证文件放到下面任一位置：

1. 用户扩展根目录（推荐，升级主包后仍保留；解压后保留本版本目录即可）：

    %USERPROFILE%\.workmate\extensions

2. WorkMate.exe 同级的 ComputerUse 目录：

    <WorkMate 解压目录>\ComputerUse

也可以直接把本目录改名为 computer-use 后放到用户扩展根目录。扩展需要保持
runtime.json 与 runtime.zip 同级。放好后重新打开 WorkMate，
进入“设置 → 智能体 → 电脑操控”，即可看到并启用 Computer Use。

不安装时
--------
WorkMate 的对话、文件、专家、技能、定时任务等功能不受影响；只有 Computer Use
开关会显示“扩展未安装”。

自检（不会点击应用）
--------------------
    powershell -NoProfile -ExecutionPolicy Bypass -File .\check-computer-use.ps1 -RuntimeZip .\runtime.zip

开发版可加 -AllowUnsigned；正式公司的扩展包必须同时通过 CompanyName 和 Authenticode
校验。
