﻿param(
  [string]$RuntimeZip = "",
  [switch]$AllowUnsigned
)

$ErrorActionPreference = "Stop"
$repo = Split-Path -Parent $PSScriptRoot
if ([string]::IsNullOrWhiteSpace($RuntimeZip)) {
  $RuntimeZip = Join-Path $repo "src-tauri/resources/computer-use/win32-x64/runtime.zip"
}
if (-not (Test-Path -LiteralPath $RuntimeZip -PathType Leaf)) {
  throw "Computer Use runtime archive not found: $RuntimeZip"
}

$markerPath = Join-Path (Split-Path -Parent $RuntimeZip) "runtime.json"
if (Test-Path -LiteralPath $markerPath -PathType Leaf) {
  $marker = Get-Content -LiteralPath $markerPath -Raw | ConvertFrom-Json
  if ($marker.provider -ne "cua-driver") { throw "runtime marker is not Cua Driver" }
  if ($marker.companyName -ne "平安科技深圳有限公司") { throw "runtime marker CompanyName is incorrect" }
  if ($marker.version -ne "0.38.0") { throw "runtime marker version is not 0.38.0" }
  if ($marker.license -ne "MIT") { throw "runtime marker license is not MIT" }
  if (-not $AllowUnsigned -and $marker.signed -ne $true) { throw "runtime marker says the package is unsigned" }
  $archiveHash = (Get-FileHash -LiteralPath $RuntimeZip -Algorithm SHA256).Hash.ToLowerInvariant()
  if ($marker.archiveSha256 -and $archiveHash -ne $marker.archiveSha256.ToLowerInvariant()) {
    throw "runtime archive SHA-256 does not match marker"
  }
}

$temp = Join-Path ([IO.Path]::GetTempPath()) ("workmate-cua-check-" + [Guid]::NewGuid().ToString("N"))
try {
  Expand-Archive -LiteralPath $RuntimeZip -DestinationPath $temp -Force
  $required = @(
    "cua-driver.exe",
    "cua-driver-uia.exe",
    "LICENSE-CUA-DRIVER.txt",
    "THIRD_PARTY_NOTICES-CUA-DRIVER.txt"
  )
  foreach ($relative in $required) {
    $path = Join-Path $temp $relative
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) {
      throw "Missing Cua Driver runtime file: $path"
    }
  }

  $driver = Join-Path $temp "cua-driver.exe"
  $helper = Join-Path $temp "cua-driver-uia.exe"
  foreach ($exe in @($driver, $helper)) {
    $versionInfo = (Get-Item -LiteralPath $exe).VersionInfo
    if ($versionInfo.CompanyName -ne "平安科技深圳有限公司") {
      throw "CompanyName mismatch: ${exe}: $($versionInfo.CompanyName)"
    }
    if ($versionInfo.ProductName -ne "WorkMate Computer Use Driver") {
      throw "ProductName mismatch: ${exe}: $($versionInfo.ProductName)"
    }
    if ($versionInfo.ProductVersion -notlike "0.38.0*" -or $versionInfo.FileVersion -notlike "0.38.0*") {
      throw "Version mismatch: ${exe}: product=$($versionInfo.ProductVersion), file=$($versionInfo.FileVersion)"
    }
    $signature = Get-AuthenticodeSignature -LiteralPath $exe
    if (-not $AllowUnsigned -and $signature.Status -ne [System.Management.Automation.SignatureStatus]::Valid) {
      throw "Invalid Authenticode signature: ${exe}: $($signature.StatusMessage)"
    }
    if (-not $AllowUnsigned -and $signature.SignerCertificate.Subject -notlike "*平安科技深圳有限公司*") {
      throw "Signer subject mismatch: ${exe}: $($signature.SignerCertificate.Subject)"
    }
    Write-Host "$(Split-Path -Leaf $exe): company=$($versionInfo.CompanyName), version=$($versionInfo.ProductVersion), signature=$($signature.Status)"
  }

  $driverVersion = (& $driver --version 2>&1 | Out-String).Trim()
  if ($LASTEXITCODE -ne 0) { throw "cua-driver.exe --version failed" }
  Write-Host "Cua Driver: $driverVersion"
  $tools = (& $driver list-tools 2>&1 | Out-String)
  if ($LASTEXITCODE -ne 0) { throw "cua-driver.exe list-tools failed" }
  foreach ($name in @("list_apps", "get_window_state", "click", "type_text", "verify_state", "run_steps")) {
    if ($tools -notmatch [regex]::Escape($name)) { throw "Cua Driver does not advertise required tool: $name" }
  }
  Write-Host "Cua Driver tool surface: OK"
  Write-Host "Windows Computer Use runtime check passed: $RuntimeZip"
} finally {
  if (Test-Path -LiteralPath $temp) { Remove-Item -LiteralPath $temp -Recurse -Force }
}
