# Agent Browser Runtime

- agent-browser 0.43.0: Apache-2.0, https://github.com/vercel-labs/agent-browser/releases/download/v0.43.0/agent-browser-win32-x64.exe
- WorkMate Windows runtime hardening: windows-runtime-hardening-v1
  - DevToolsActivePort handoff fix (upstream issue #1710)
  - per-session daemon spawn lock and startup cleanup (upstream PR #2648)
- Browser: system Microsoft Edge (not redistributed with WorkMate)
