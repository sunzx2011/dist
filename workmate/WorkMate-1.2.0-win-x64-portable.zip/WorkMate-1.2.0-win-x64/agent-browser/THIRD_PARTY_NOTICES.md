# Agent Browser Runtime

- agent-browser 0.43.0: Apache-2.0, https://github.com/vercel-labs/agent-browser/releases/download/v0.43.0/agent-browser-win32-x64.exe
- WorkMate Windows patch: devtools-active-port-handoff-v1 (upstream issue #1710)
- Browser: system Microsoft Edge (not redistributed with WorkMate)
