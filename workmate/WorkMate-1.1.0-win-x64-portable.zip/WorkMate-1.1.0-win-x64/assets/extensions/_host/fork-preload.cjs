var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// ../../node_modules/.pnpm/minimalistic-assert@1.0.1/node_modules/minimalistic-assert/index.js
var require_minimalistic_assert = __commonJS({
  "../../node_modules/.pnpm/minimalistic-assert@1.0.1/node_modules/minimalistic-assert/index.js"(exports2, module2) {
    module2.exports = assert;
    function assert(val, msg) {
      if (!val)
        throw new Error(msg || "Assertion failed");
    }
    assert.equal = function assertEqual(l, r, msg) {
      if (l != r)
        throw new Error(msg || "Assertion failed: " + l + " != " + r);
    };
  }
});

// ../../node_modules/.pnpm/inherits@2.0.4/node_modules/inherits/inherits_browser.js
var require_inherits_browser = __commonJS({
  "../../node_modules/.pnpm/inherits@2.0.4/node_modules/inherits/inherits_browser.js"(exports2, module2) {
    if (typeof Object.create === "function") {
      module2.exports = function inherits(ctor, superCtor) {
        if (superCtor) {
          ctor.super_ = superCtor;
          ctor.prototype = Object.create(superCtor.prototype, {
            constructor: {
              value: ctor,
              enumerable: false,
              writable: true,
              configurable: true
            }
          });
        }
      };
    } else {
      module2.exports = function inherits(ctor, superCtor) {
        if (superCtor) {
          ctor.super_ = superCtor;
          var TempCtor = function() {
          };
          TempCtor.prototype = superCtor.prototype;
          ctor.prototype = new TempCtor();
          ctor.prototype.constructor = ctor;
        }
      };
    }
  }
});

// ../../node_modules/.pnpm/inherits@2.0.4/node_modules/inherits/inherits.js
var require_inherits = __commonJS({
  "../../node_modules/.pnpm/inherits@2.0.4/node_modules/inherits/inherits.js"(exports2, module2) {
    try {
      util = require("util");
      if (typeof util.inherits !== "function")
        throw "";
      module2.exports = util.inherits;
    } catch (e) {
      module2.exports = require_inherits_browser();
    }
    var util;
  }
});

// ../../node_modules/.pnpm/hash.js@1.1.7/node_modules/hash.js/lib/hash/utils.js
var require_utils = __commonJS({
  "../../node_modules/.pnpm/hash.js@1.1.7/node_modules/hash.js/lib/hash/utils.js"(exports2) {
    "use strict";
    var assert = require_minimalistic_assert();
    var inherits = require_inherits();
    exports2.inherits = inherits;
    function isSurrogatePair(msg, i) {
      if ((msg.charCodeAt(i) & 64512) !== 55296) {
        return false;
      }
      if (i < 0 || i + 1 >= msg.length) {
        return false;
      }
      return (msg.charCodeAt(i + 1) & 64512) === 56320;
    }
    function toArray(msg, enc) {
      if (Array.isArray(msg))
        return msg.slice();
      if (!msg)
        return [];
      var res = [];
      if (typeof msg === "string") {
        if (!enc) {
          var p = 0;
          for (var i = 0; i < msg.length; i++) {
            var c = msg.charCodeAt(i);
            if (c < 128) {
              res[p++] = c;
            } else if (c < 2048) {
              res[p++] = c >> 6 | 192;
              res[p++] = c & 63 | 128;
            } else if (isSurrogatePair(msg, i)) {
              c = 65536 + ((c & 1023) << 10) + (msg.charCodeAt(++i) & 1023);
              res[p++] = c >> 18 | 240;
              res[p++] = c >> 12 & 63 | 128;
              res[p++] = c >> 6 & 63 | 128;
              res[p++] = c & 63 | 128;
            } else {
              res[p++] = c >> 12 | 224;
              res[p++] = c >> 6 & 63 | 128;
              res[p++] = c & 63 | 128;
            }
          }
        } else if (enc === "hex") {
          msg = msg.replace(/[^a-z0-9]+/ig, "");
          if (msg.length % 2 !== 0)
            msg = "0" + msg;
          for (i = 0; i < msg.length; i += 2)
            res.push(parseInt(msg[i] + msg[i + 1], 16));
        }
      } else {
        for (i = 0; i < msg.length; i++)
          res[i] = msg[i] | 0;
      }
      return res;
    }
    exports2.toArray = toArray;
    function toHex(msg) {
      var res = "";
      for (var i = 0; i < msg.length; i++)
        res += zero2(msg[i].toString(16));
      return res;
    }
    exports2.toHex = toHex;
    function htonl(w) {
      var res = w >>> 24 | w >>> 8 & 65280 | w << 8 & 16711680 | (w & 255) << 24;
      return res >>> 0;
    }
    exports2.htonl = htonl;
    function toHex32(msg, endian) {
      var res = "";
      for (var i = 0; i < msg.length; i++) {
        var w = msg[i];
        if (endian === "little")
          w = htonl(w);
        res += zero8(w.toString(16));
      }
      return res;
    }
    exports2.toHex32 = toHex32;
    function zero2(word) {
      if (word.length === 1)
        return "0" + word;
      else
        return word;
    }
    exports2.zero2 = zero2;
    function zero8(word) {
      if (word.length === 7)
        return "0" + word;
      else if (word.length === 6)
        return "00" + word;
      else if (word.length === 5)
        return "000" + word;
      else if (word.length === 4)
        return "0000" + word;
      else if (word.length === 3)
        return "00000" + word;
      else if (word.length === 2)
        return "000000" + word;
      else if (word.length === 1)
        return "0000000" + word;
      else
        return word;
    }
    exports2.zero8 = zero8;
    function join32(msg, start, end, endian) {
      var len = end - start;
      assert(len % 4 === 0);
      var res = new Array(len / 4);
      for (var i = 0, k = start; i < res.length; i++, k += 4) {
        var w;
        if (endian === "big")
          w = msg[k] << 24 | msg[k + 1] << 16 | msg[k + 2] << 8 | msg[k + 3];
        else
          w = msg[k + 3] << 24 | msg[k + 2] << 16 | msg[k + 1] << 8 | msg[k];
        res[i] = w >>> 0;
      }
      return res;
    }
    exports2.join32 = join32;
    function split32(msg, endian) {
      var res = new Array(msg.length * 4);
      for (var i = 0, k = 0; i < msg.length; i++, k += 4) {
        var m = msg[i];
        if (endian === "big") {
          res[k] = m >>> 24;
          res[k + 1] = m >>> 16 & 255;
          res[k + 2] = m >>> 8 & 255;
          res[k + 3] = m & 255;
        } else {
          res[k + 3] = m >>> 24;
          res[k + 2] = m >>> 16 & 255;
          res[k + 1] = m >>> 8 & 255;
          res[k] = m & 255;
        }
      }
      return res;
    }
    exports2.split32 = split32;
    function rotr32(w, b) {
      return w >>> b | w << 32 - b;
    }
    exports2.rotr32 = rotr32;
    function rotl32(w, b) {
      return w << b | w >>> 32 - b;
    }
    exports2.rotl32 = rotl32;
    function sum32(a, b) {
      return a + b >>> 0;
    }
    exports2.sum32 = sum32;
    function sum32_3(a, b, c) {
      return a + b + c >>> 0;
    }
    exports2.sum32_3 = sum32_3;
    function sum32_4(a, b, c, d) {
      return a + b + c + d >>> 0;
    }
    exports2.sum32_4 = sum32_4;
    function sum32_5(a, b, c, d, e) {
      return a + b + c + d + e >>> 0;
    }
    exports2.sum32_5 = sum32_5;
    function sum64(buf, pos, ah, al) {
      var bh = buf[pos];
      var bl = buf[pos + 1];
      var lo = al + bl >>> 0;
      var hi = (lo < al ? 1 : 0) + ah + bh;
      buf[pos] = hi >>> 0;
      buf[pos + 1] = lo;
    }
    exports2.sum64 = sum64;
    function sum64_hi(ah, al, bh, bl) {
      var lo = al + bl >>> 0;
      var hi = (lo < al ? 1 : 0) + ah + bh;
      return hi >>> 0;
    }
    exports2.sum64_hi = sum64_hi;
    function sum64_lo(ah, al, bh, bl) {
      var lo = al + bl;
      return lo >>> 0;
    }
    exports2.sum64_lo = sum64_lo;
    function sum64_4_hi(ah, al, bh, bl, ch, cl, dh, dl) {
      var carry = 0;
      var lo = al;
      lo = lo + bl >>> 0;
      carry += lo < al ? 1 : 0;
      lo = lo + cl >>> 0;
      carry += lo < cl ? 1 : 0;
      lo = lo + dl >>> 0;
      carry += lo < dl ? 1 : 0;
      var hi = ah + bh + ch + dh + carry;
      return hi >>> 0;
    }
    exports2.sum64_4_hi = sum64_4_hi;
    function sum64_4_lo(ah, al, bh, bl, ch, cl, dh, dl) {
      var lo = al + bl + cl + dl;
      return lo >>> 0;
    }
    exports2.sum64_4_lo = sum64_4_lo;
    function sum64_5_hi(ah, al, bh, bl, ch, cl, dh, dl, eh, el) {
      var carry = 0;
      var lo = al;
      lo = lo + bl >>> 0;
      carry += lo < al ? 1 : 0;
      lo = lo + cl >>> 0;
      carry += lo < cl ? 1 : 0;
      lo = lo + dl >>> 0;
      carry += lo < dl ? 1 : 0;
      lo = lo + el >>> 0;
      carry += lo < el ? 1 : 0;
      var hi = ah + bh + ch + dh + eh + carry;
      return hi >>> 0;
    }
    exports2.sum64_5_hi = sum64_5_hi;
    function sum64_5_lo(ah, al, bh, bl, ch, cl, dh, dl, eh, el) {
      var lo = al + bl + cl + dl + el;
      return lo >>> 0;
    }
    exports2.sum64_5_lo = sum64_5_lo;
    function rotr64_hi(ah, al, num) {
      var r = al << 32 - num | ah >>> num;
      return r >>> 0;
    }
    exports2.rotr64_hi = rotr64_hi;
    function rotr64_lo(ah, al, num) {
      var r = ah << 32 - num | al >>> num;
      return r >>> 0;
    }
    exports2.rotr64_lo = rotr64_lo;
    function shr64_hi(ah, al, num) {
      return ah >>> num;
    }
    exports2.shr64_hi = shr64_hi;
    function shr64_lo(ah, al, num) {
      var r = ah << 32 - num | al >>> num;
      return r >>> 0;
    }
    exports2.shr64_lo = shr64_lo;
  }
});

// ../../node_modules/.pnpm/hash.js@1.1.7/node_modules/hash.js/lib/hash/common.js
var require_common = __commonJS({
  "../../node_modules/.pnpm/hash.js@1.1.7/node_modules/hash.js/lib/hash/common.js"(exports2) {
    "use strict";
    var utils = require_utils();
    var assert = require_minimalistic_assert();
    function BlockHash() {
      this.pending = null;
      this.pendingTotal = 0;
      this.blockSize = this.constructor.blockSize;
      this.outSize = this.constructor.outSize;
      this.hmacStrength = this.constructor.hmacStrength;
      this.padLength = this.constructor.padLength / 8;
      this.endian = "big";
      this._delta8 = this.blockSize / 8;
      this._delta32 = this.blockSize / 32;
    }
    exports2.BlockHash = BlockHash;
    BlockHash.prototype.update = function update(msg, enc) {
      msg = utils.toArray(msg, enc);
      if (!this.pending)
        this.pending = msg;
      else
        this.pending = this.pending.concat(msg);
      this.pendingTotal += msg.length;
      if (this.pending.length >= this._delta8) {
        msg = this.pending;
        var r = msg.length % this._delta8;
        this.pending = msg.slice(msg.length - r, msg.length);
        if (this.pending.length === 0)
          this.pending = null;
        msg = utils.join32(msg, 0, msg.length - r, this.endian);
        for (var i = 0; i < msg.length; i += this._delta32)
          this._update(msg, i, i + this._delta32);
      }
      return this;
    };
    BlockHash.prototype.digest = function digest(enc) {
      this.update(this._pad());
      assert(this.pending === null);
      return this._digest(enc);
    };
    BlockHash.prototype._pad = function pad() {
      var len = this.pendingTotal;
      var bytes = this._delta8;
      var k = bytes - (len + this.padLength) % bytes;
      var res = new Array(k + this.padLength);
      res[0] = 128;
      for (var i = 1; i < k; i++)
        res[i] = 0;
      len <<= 3;
      if (this.endian === "big") {
        for (var t = 8; t < this.padLength; t++)
          res[i++] = 0;
        res[i++] = 0;
        res[i++] = 0;
        res[i++] = 0;
        res[i++] = 0;
        res[i++] = len >>> 24 & 255;
        res[i++] = len >>> 16 & 255;
        res[i++] = len >>> 8 & 255;
        res[i++] = len & 255;
      } else {
        res[i++] = len & 255;
        res[i++] = len >>> 8 & 255;
        res[i++] = len >>> 16 & 255;
        res[i++] = len >>> 24 & 255;
        res[i++] = 0;
        res[i++] = 0;
        res[i++] = 0;
        res[i++] = 0;
        for (t = 8; t < this.padLength; t++)
          res[i++] = 0;
      }
      return res;
    };
  }
});

// ../../node_modules/.pnpm/hash.js@1.1.7/node_modules/hash.js/lib/hash/sha/common.js
var require_common2 = __commonJS({
  "../../node_modules/.pnpm/hash.js@1.1.7/node_modules/hash.js/lib/hash/sha/common.js"(exports2) {
    "use strict";
    var utils = require_utils();
    var rotr32 = utils.rotr32;
    function ft_1(s, x, y, z) {
      if (s === 0)
        return ch32(x, y, z);
      if (s === 1 || s === 3)
        return p32(x, y, z);
      if (s === 2)
        return maj32(x, y, z);
    }
    exports2.ft_1 = ft_1;
    function ch32(x, y, z) {
      return x & y ^ ~x & z;
    }
    exports2.ch32 = ch32;
    function maj32(x, y, z) {
      return x & y ^ x & z ^ y & z;
    }
    exports2.maj32 = maj32;
    function p32(x, y, z) {
      return x ^ y ^ z;
    }
    exports2.p32 = p32;
    function s0_256(x) {
      return rotr32(x, 2) ^ rotr32(x, 13) ^ rotr32(x, 22);
    }
    exports2.s0_256 = s0_256;
    function s1_256(x) {
      return rotr32(x, 6) ^ rotr32(x, 11) ^ rotr32(x, 25);
    }
    exports2.s1_256 = s1_256;
    function g0_256(x) {
      return rotr32(x, 7) ^ rotr32(x, 18) ^ x >>> 3;
    }
    exports2.g0_256 = g0_256;
    function g1_256(x) {
      return rotr32(x, 17) ^ rotr32(x, 19) ^ x >>> 10;
    }
    exports2.g1_256 = g1_256;
  }
});

// ../../node_modules/.pnpm/hash.js@1.1.7/node_modules/hash.js/lib/hash/sha/1.js
var require__ = __commonJS({
  "../../node_modules/.pnpm/hash.js@1.1.7/node_modules/hash.js/lib/hash/sha/1.js"(exports2, module2) {
    "use strict";
    var utils = require_utils();
    var common = require_common();
    var shaCommon = require_common2();
    var rotl32 = utils.rotl32;
    var sum32 = utils.sum32;
    var sum32_5 = utils.sum32_5;
    var ft_1 = shaCommon.ft_1;
    var BlockHash = common.BlockHash;
    var sha1_K = [
      1518500249,
      1859775393,
      2400959708,
      3395469782
    ];
    function SHA1() {
      if (!(this instanceof SHA1))
        return new SHA1();
      BlockHash.call(this);
      this.h = [
        1732584193,
        4023233417,
        2562383102,
        271733878,
        3285377520
      ];
      this.W = new Array(80);
    }
    utils.inherits(SHA1, BlockHash);
    module2.exports = SHA1;
    SHA1.blockSize = 512;
    SHA1.outSize = 160;
    SHA1.hmacStrength = 80;
    SHA1.padLength = 64;
    SHA1.prototype._update = function _update(msg, start) {
      var W = this.W;
      for (var i = 0; i < 16; i++)
        W[i] = msg[start + i];
      for (; i < W.length; i++)
        W[i] = rotl32(W[i - 3] ^ W[i - 8] ^ W[i - 14] ^ W[i - 16], 1);
      var a = this.h[0];
      var b = this.h[1];
      var c = this.h[2];
      var d = this.h[3];
      var e = this.h[4];
      for (i = 0; i < W.length; i++) {
        var s = ~~(i / 20);
        var t = sum32_5(rotl32(a, 5), ft_1(s, b, c, d), e, W[i], sha1_K[s]);
        e = d;
        d = c;
        c = rotl32(b, 30);
        b = a;
        a = t;
      }
      this.h[0] = sum32(this.h[0], a);
      this.h[1] = sum32(this.h[1], b);
      this.h[2] = sum32(this.h[2], c);
      this.h[3] = sum32(this.h[3], d);
      this.h[4] = sum32(this.h[4], e);
    };
    SHA1.prototype._digest = function digest(enc) {
      if (enc === "hex")
        return utils.toHex32(this.h, "big");
      else
        return utils.split32(this.h, "big");
    };
  }
});

// ../../node_modules/.pnpm/hash.js@1.1.7/node_modules/hash.js/lib/hash/sha/256.js
var require__2 = __commonJS({
  "../../node_modules/.pnpm/hash.js@1.1.7/node_modules/hash.js/lib/hash/sha/256.js"(exports2, module2) {
    "use strict";
    var utils = require_utils();
    var common = require_common();
    var shaCommon = require_common2();
    var assert = require_minimalistic_assert();
    var sum32 = utils.sum32;
    var sum32_4 = utils.sum32_4;
    var sum32_5 = utils.sum32_5;
    var ch32 = shaCommon.ch32;
    var maj32 = shaCommon.maj32;
    var s0_256 = shaCommon.s0_256;
    var s1_256 = shaCommon.s1_256;
    var g0_256 = shaCommon.g0_256;
    var g1_256 = shaCommon.g1_256;
    var BlockHash = common.BlockHash;
    var sha256_K = [
      1116352408,
      1899447441,
      3049323471,
      3921009573,
      961987163,
      1508970993,
      2453635748,
      2870763221,
      3624381080,
      310598401,
      607225278,
      1426881987,
      1925078388,
      2162078206,
      2614888103,
      3248222580,
      3835390401,
      4022224774,
      264347078,
      604807628,
      770255983,
      1249150122,
      1555081692,
      1996064986,
      2554220882,
      2821834349,
      2952996808,
      3210313671,
      3336571891,
      3584528711,
      113926993,
      338241895,
      666307205,
      773529912,
      1294757372,
      1396182291,
      1695183700,
      1986661051,
      2177026350,
      2456956037,
      2730485921,
      2820302411,
      3259730800,
      3345764771,
      3516065817,
      3600352804,
      4094571909,
      275423344,
      430227734,
      506948616,
      659060556,
      883997877,
      958139571,
      1322822218,
      1537002063,
      1747873779,
      1955562222,
      2024104815,
      2227730452,
      2361852424,
      2428436474,
      2756734187,
      3204031479,
      3329325298
    ];
    function SHA256() {
      if (!(this instanceof SHA256))
        return new SHA256();
      BlockHash.call(this);
      this.h = [
        1779033703,
        3144134277,
        1013904242,
        2773480762,
        1359893119,
        2600822924,
        528734635,
        1541459225
      ];
      this.k = sha256_K;
      this.W = new Array(64);
    }
    utils.inherits(SHA256, BlockHash);
    module2.exports = SHA256;
    SHA256.blockSize = 512;
    SHA256.outSize = 256;
    SHA256.hmacStrength = 192;
    SHA256.padLength = 64;
    SHA256.prototype._update = function _update(msg, start) {
      var W = this.W;
      for (var i = 0; i < 16; i++)
        W[i] = msg[start + i];
      for (; i < W.length; i++)
        W[i] = sum32_4(g1_256(W[i - 2]), W[i - 7], g0_256(W[i - 15]), W[i - 16]);
      var a = this.h[0];
      var b = this.h[1];
      var c = this.h[2];
      var d = this.h[3];
      var e = this.h[4];
      var f = this.h[5];
      var g = this.h[6];
      var h = this.h[7];
      assert(this.k.length === W.length);
      for (i = 0; i < W.length; i++) {
        var T1 = sum32_5(h, s1_256(e), ch32(e, f, g), this.k[i], W[i]);
        var T2 = sum32(s0_256(a), maj32(a, b, c));
        h = g;
        g = f;
        f = e;
        e = sum32(d, T1);
        d = c;
        c = b;
        b = a;
        a = sum32(T1, T2);
      }
      this.h[0] = sum32(this.h[0], a);
      this.h[1] = sum32(this.h[1], b);
      this.h[2] = sum32(this.h[2], c);
      this.h[3] = sum32(this.h[3], d);
      this.h[4] = sum32(this.h[4], e);
      this.h[5] = sum32(this.h[5], f);
      this.h[6] = sum32(this.h[6], g);
      this.h[7] = sum32(this.h[7], h);
    };
    SHA256.prototype._digest = function digest(enc) {
      if (enc === "hex")
        return utils.toHex32(this.h, "big");
      else
        return utils.split32(this.h, "big");
    };
  }
});

// ../../node_modules/.pnpm/hash.js@1.1.7/node_modules/hash.js/lib/hash/sha/224.js
var require__3 = __commonJS({
  "../../node_modules/.pnpm/hash.js@1.1.7/node_modules/hash.js/lib/hash/sha/224.js"(exports2, module2) {
    "use strict";
    var utils = require_utils();
    var SHA256 = require__2();
    function SHA224() {
      if (!(this instanceof SHA224))
        return new SHA224();
      SHA256.call(this);
      this.h = [
        3238371032,
        914150663,
        812702999,
        4144912697,
        4290775857,
        1750603025,
        1694076839,
        3204075428
      ];
    }
    utils.inherits(SHA224, SHA256);
    module2.exports = SHA224;
    SHA224.blockSize = 512;
    SHA224.outSize = 224;
    SHA224.hmacStrength = 192;
    SHA224.padLength = 64;
    SHA224.prototype._digest = function digest(enc) {
      if (enc === "hex")
        return utils.toHex32(this.h.slice(0, 7), "big");
      else
        return utils.split32(this.h.slice(0, 7), "big");
    };
  }
});

// ../../node_modules/.pnpm/hash.js@1.1.7/node_modules/hash.js/lib/hash/sha/512.js
var require__4 = __commonJS({
  "../../node_modules/.pnpm/hash.js@1.1.7/node_modules/hash.js/lib/hash/sha/512.js"(exports2, module2) {
    "use strict";
    var utils = require_utils();
    var common = require_common();
    var assert = require_minimalistic_assert();
    var rotr64_hi = utils.rotr64_hi;
    var rotr64_lo = utils.rotr64_lo;
    var shr64_hi = utils.shr64_hi;
    var shr64_lo = utils.shr64_lo;
    var sum64 = utils.sum64;
    var sum64_hi = utils.sum64_hi;
    var sum64_lo = utils.sum64_lo;
    var sum64_4_hi = utils.sum64_4_hi;
    var sum64_4_lo = utils.sum64_4_lo;
    var sum64_5_hi = utils.sum64_5_hi;
    var sum64_5_lo = utils.sum64_5_lo;
    var BlockHash = common.BlockHash;
    var sha512_K = [
      1116352408,
      3609767458,
      1899447441,
      602891725,
      3049323471,
      3964484399,
      3921009573,
      2173295548,
      961987163,
      4081628472,
      1508970993,
      3053834265,
      2453635748,
      2937671579,
      2870763221,
      3664609560,
      3624381080,
      2734883394,
      310598401,
      1164996542,
      607225278,
      1323610764,
      1426881987,
      3590304994,
      1925078388,
      4068182383,
      2162078206,
      991336113,
      2614888103,
      633803317,
      3248222580,
      3479774868,
      3835390401,
      2666613458,
      4022224774,
      944711139,
      264347078,
      2341262773,
      604807628,
      2007800933,
      770255983,
      1495990901,
      1249150122,
      1856431235,
      1555081692,
      3175218132,
      1996064986,
      2198950837,
      2554220882,
      3999719339,
      2821834349,
      766784016,
      2952996808,
      2566594879,
      3210313671,
      3203337956,
      3336571891,
      1034457026,
      3584528711,
      2466948901,
      113926993,
      3758326383,
      338241895,
      168717936,
      666307205,
      1188179964,
      773529912,
      1546045734,
      1294757372,
      1522805485,
      1396182291,
      2643833823,
      1695183700,
      2343527390,
      1986661051,
      1014477480,
      2177026350,
      1206759142,
      2456956037,
      344077627,
      2730485921,
      1290863460,
      2820302411,
      3158454273,
      3259730800,
      3505952657,
      3345764771,
      106217008,
      3516065817,
      3606008344,
      3600352804,
      1432725776,
      4094571909,
      1467031594,
      275423344,
      851169720,
      430227734,
      3100823752,
      506948616,
      1363258195,
      659060556,
      3750685593,
      883997877,
      3785050280,
      958139571,
      3318307427,
      1322822218,
      3812723403,
      1537002063,
      2003034995,
      1747873779,
      3602036899,
      1955562222,
      1575990012,
      2024104815,
      1125592928,
      2227730452,
      2716904306,
      2361852424,
      442776044,
      2428436474,
      593698344,
      2756734187,
      3733110249,
      3204031479,
      2999351573,
      3329325298,
      3815920427,
      3391569614,
      3928383900,
      3515267271,
      566280711,
      3940187606,
      3454069534,
      4118630271,
      4000239992,
      116418474,
      1914138554,
      174292421,
      2731055270,
      289380356,
      3203993006,
      460393269,
      320620315,
      685471733,
      587496836,
      852142971,
      1086792851,
      1017036298,
      365543100,
      1126000580,
      2618297676,
      1288033470,
      3409855158,
      1501505948,
      4234509866,
      1607167915,
      987167468,
      1816402316,
      1246189591
    ];
    function SHA512() {
      if (!(this instanceof SHA512))
        return new SHA512();
      BlockHash.call(this);
      this.h = [
        1779033703,
        4089235720,
        3144134277,
        2227873595,
        1013904242,
        4271175723,
        2773480762,
        1595750129,
        1359893119,
        2917565137,
        2600822924,
        725511199,
        528734635,
        4215389547,
        1541459225,
        327033209
      ];
      this.k = sha512_K;
      this.W = new Array(160);
    }
    utils.inherits(SHA512, BlockHash);
    module2.exports = SHA512;
    SHA512.blockSize = 1024;
    SHA512.outSize = 512;
    SHA512.hmacStrength = 192;
    SHA512.padLength = 128;
    SHA512.prototype._prepareBlock = function _prepareBlock(msg, start) {
      var W = this.W;
      for (var i = 0; i < 32; i++)
        W[i] = msg[start + i];
      for (; i < W.length; i += 2) {
        var c0_hi = g1_512_hi(W[i - 4], W[i - 3]);
        var c0_lo = g1_512_lo(W[i - 4], W[i - 3]);
        var c1_hi = W[i - 14];
        var c1_lo = W[i - 13];
        var c2_hi = g0_512_hi(W[i - 30], W[i - 29]);
        var c2_lo = g0_512_lo(W[i - 30], W[i - 29]);
        var c3_hi = W[i - 32];
        var c3_lo = W[i - 31];
        W[i] = sum64_4_hi(
          c0_hi,
          c0_lo,
          c1_hi,
          c1_lo,
          c2_hi,
          c2_lo,
          c3_hi,
          c3_lo
        );
        W[i + 1] = sum64_4_lo(
          c0_hi,
          c0_lo,
          c1_hi,
          c1_lo,
          c2_hi,
          c2_lo,
          c3_hi,
          c3_lo
        );
      }
    };
    SHA512.prototype._update = function _update(msg, start) {
      this._prepareBlock(msg, start);
      var W = this.W;
      var ah = this.h[0];
      var al = this.h[1];
      var bh = this.h[2];
      var bl = this.h[3];
      var ch = this.h[4];
      var cl = this.h[5];
      var dh = this.h[6];
      var dl = this.h[7];
      var eh = this.h[8];
      var el = this.h[9];
      var fh = this.h[10];
      var fl = this.h[11];
      var gh = this.h[12];
      var gl = this.h[13];
      var hh = this.h[14];
      var hl = this.h[15];
      assert(this.k.length === W.length);
      for (var i = 0; i < W.length; i += 2) {
        var c0_hi = hh;
        var c0_lo = hl;
        var c1_hi = s1_512_hi(eh, el);
        var c1_lo = s1_512_lo(eh, el);
        var c2_hi = ch64_hi(eh, el, fh, fl, gh, gl);
        var c2_lo = ch64_lo(eh, el, fh, fl, gh, gl);
        var c3_hi = this.k[i];
        var c3_lo = this.k[i + 1];
        var c4_hi = W[i];
        var c4_lo = W[i + 1];
        var T1_hi = sum64_5_hi(
          c0_hi,
          c0_lo,
          c1_hi,
          c1_lo,
          c2_hi,
          c2_lo,
          c3_hi,
          c3_lo,
          c4_hi,
          c4_lo
        );
        var T1_lo = sum64_5_lo(
          c0_hi,
          c0_lo,
          c1_hi,
          c1_lo,
          c2_hi,
          c2_lo,
          c3_hi,
          c3_lo,
          c4_hi,
          c4_lo
        );
        c0_hi = s0_512_hi(ah, al);
        c0_lo = s0_512_lo(ah, al);
        c1_hi = maj64_hi(ah, al, bh, bl, ch, cl);
        c1_lo = maj64_lo(ah, al, bh, bl, ch, cl);
        var T2_hi = sum64_hi(c0_hi, c0_lo, c1_hi, c1_lo);
        var T2_lo = sum64_lo(c0_hi, c0_lo, c1_hi, c1_lo);
        hh = gh;
        hl = gl;
        gh = fh;
        gl = fl;
        fh = eh;
        fl = el;
        eh = sum64_hi(dh, dl, T1_hi, T1_lo);
        el = sum64_lo(dl, dl, T1_hi, T1_lo);
        dh = ch;
        dl = cl;
        ch = bh;
        cl = bl;
        bh = ah;
        bl = al;
        ah = sum64_hi(T1_hi, T1_lo, T2_hi, T2_lo);
        al = sum64_lo(T1_hi, T1_lo, T2_hi, T2_lo);
      }
      sum64(this.h, 0, ah, al);
      sum64(this.h, 2, bh, bl);
      sum64(this.h, 4, ch, cl);
      sum64(this.h, 6, dh, dl);
      sum64(this.h, 8, eh, el);
      sum64(this.h, 10, fh, fl);
      sum64(this.h, 12, gh, gl);
      sum64(this.h, 14, hh, hl);
    };
    SHA512.prototype._digest = function digest(enc) {
      if (enc === "hex")
        return utils.toHex32(this.h, "big");
      else
        return utils.split32(this.h, "big");
    };
    function ch64_hi(xh, xl, yh, yl, zh) {
      var r = xh & yh ^ ~xh & zh;
      if (r < 0)
        r += 4294967296;
      return r;
    }
    function ch64_lo(xh, xl, yh, yl, zh, zl) {
      var r = xl & yl ^ ~xl & zl;
      if (r < 0)
        r += 4294967296;
      return r;
    }
    function maj64_hi(xh, xl, yh, yl, zh) {
      var r = xh & yh ^ xh & zh ^ yh & zh;
      if (r < 0)
        r += 4294967296;
      return r;
    }
    function maj64_lo(xh, xl, yh, yl, zh, zl) {
      var r = xl & yl ^ xl & zl ^ yl & zl;
      if (r < 0)
        r += 4294967296;
      return r;
    }
    function s0_512_hi(xh, xl) {
      var c0_hi = rotr64_hi(xh, xl, 28);
      var c1_hi = rotr64_hi(xl, xh, 2);
      var c2_hi = rotr64_hi(xl, xh, 7);
      var r = c0_hi ^ c1_hi ^ c2_hi;
      if (r < 0)
        r += 4294967296;
      return r;
    }
    function s0_512_lo(xh, xl) {
      var c0_lo = rotr64_lo(xh, xl, 28);
      var c1_lo = rotr64_lo(xl, xh, 2);
      var c2_lo = rotr64_lo(xl, xh, 7);
      var r = c0_lo ^ c1_lo ^ c2_lo;
      if (r < 0)
        r += 4294967296;
      return r;
    }
    function s1_512_hi(xh, xl) {
      var c0_hi = rotr64_hi(xh, xl, 14);
      var c1_hi = rotr64_hi(xh, xl, 18);
      var c2_hi = rotr64_hi(xl, xh, 9);
      var r = c0_hi ^ c1_hi ^ c2_hi;
      if (r < 0)
        r += 4294967296;
      return r;
    }
    function s1_512_lo(xh, xl) {
      var c0_lo = rotr64_lo(xh, xl, 14);
      var c1_lo = rotr64_lo(xh, xl, 18);
      var c2_lo = rotr64_lo(xl, xh, 9);
      var r = c0_lo ^ c1_lo ^ c2_lo;
      if (r < 0)
        r += 4294967296;
      return r;
    }
    function g0_512_hi(xh, xl) {
      var c0_hi = rotr64_hi(xh, xl, 1);
      var c1_hi = rotr64_hi(xh, xl, 8);
      var c2_hi = shr64_hi(xh, xl, 7);
      var r = c0_hi ^ c1_hi ^ c2_hi;
      if (r < 0)
        r += 4294967296;
      return r;
    }
    function g0_512_lo(xh, xl) {
      var c0_lo = rotr64_lo(xh, xl, 1);
      var c1_lo = rotr64_lo(xh, xl, 8);
      var c2_lo = shr64_lo(xh, xl, 7);
      var r = c0_lo ^ c1_lo ^ c2_lo;
      if (r < 0)
        r += 4294967296;
      return r;
    }
    function g1_512_hi(xh, xl) {
      var c0_hi = rotr64_hi(xh, xl, 19);
      var c1_hi = rotr64_hi(xl, xh, 29);
      var c2_hi = shr64_hi(xh, xl, 6);
      var r = c0_hi ^ c1_hi ^ c2_hi;
      if (r < 0)
        r += 4294967296;
      return r;
    }
    function g1_512_lo(xh, xl) {
      var c0_lo = rotr64_lo(xh, xl, 19);
      var c1_lo = rotr64_lo(xl, xh, 29);
      var c2_lo = shr64_lo(xh, xl, 6);
      var r = c0_lo ^ c1_lo ^ c2_lo;
      if (r < 0)
        r += 4294967296;
      return r;
    }
  }
});

// ../../node_modules/.pnpm/hash.js@1.1.7/node_modules/hash.js/lib/hash/sha/384.js
var require__5 = __commonJS({
  "../../node_modules/.pnpm/hash.js@1.1.7/node_modules/hash.js/lib/hash/sha/384.js"(exports2, module2) {
    "use strict";
    var utils = require_utils();
    var SHA512 = require__4();
    function SHA384() {
      if (!(this instanceof SHA384))
        return new SHA384();
      SHA512.call(this);
      this.h = [
        3418070365,
        3238371032,
        1654270250,
        914150663,
        2438529370,
        812702999,
        355462360,
        4144912697,
        1731405415,
        4290775857,
        2394180231,
        1750603025,
        3675008525,
        1694076839,
        1203062813,
        3204075428
      ];
    }
    utils.inherits(SHA384, SHA512);
    module2.exports = SHA384;
    SHA384.blockSize = 1024;
    SHA384.outSize = 384;
    SHA384.hmacStrength = 192;
    SHA384.padLength = 128;
    SHA384.prototype._digest = function digest(enc) {
      if (enc === "hex")
        return utils.toHex32(this.h.slice(0, 12), "big");
      else
        return utils.split32(this.h.slice(0, 12), "big");
    };
  }
});

// ../../node_modules/.pnpm/hash.js@1.1.7/node_modules/hash.js/lib/hash/sha.js
var require_sha = __commonJS({
  "../../node_modules/.pnpm/hash.js@1.1.7/node_modules/hash.js/lib/hash/sha.js"(exports2) {
    "use strict";
    exports2.sha1 = require__();
    exports2.sha224 = require__3();
    exports2.sha256 = require__2();
    exports2.sha384 = require__5();
    exports2.sha512 = require__4();
  }
});

// ../../node_modules/.pnpm/hash.js@1.1.7/node_modules/hash.js/lib/hash/ripemd.js
var require_ripemd = __commonJS({
  "../../node_modules/.pnpm/hash.js@1.1.7/node_modules/hash.js/lib/hash/ripemd.js"(exports2) {
    "use strict";
    var utils = require_utils();
    var common = require_common();
    var rotl32 = utils.rotl32;
    var sum32 = utils.sum32;
    var sum32_3 = utils.sum32_3;
    var sum32_4 = utils.sum32_4;
    var BlockHash = common.BlockHash;
    function RIPEMD160() {
      if (!(this instanceof RIPEMD160))
        return new RIPEMD160();
      BlockHash.call(this);
      this.h = [1732584193, 4023233417, 2562383102, 271733878, 3285377520];
      this.endian = "little";
    }
    utils.inherits(RIPEMD160, BlockHash);
    exports2.ripemd160 = RIPEMD160;
    RIPEMD160.blockSize = 512;
    RIPEMD160.outSize = 160;
    RIPEMD160.hmacStrength = 192;
    RIPEMD160.padLength = 64;
    RIPEMD160.prototype._update = function update(msg, start) {
      var A = this.h[0];
      var B = this.h[1];
      var C = this.h[2];
      var D = this.h[3];
      var E = this.h[4];
      var Ah = A;
      var Bh = B;
      var Ch = C;
      var Dh = D;
      var Eh = E;
      for (var j = 0; j < 80; j++) {
        var T = sum32(
          rotl32(
            sum32_4(A, f(j, B, C, D), msg[r[j] + start], K(j)),
            s[j]
          ),
          E
        );
        A = E;
        E = D;
        D = rotl32(C, 10);
        C = B;
        B = T;
        T = sum32(
          rotl32(
            sum32_4(Ah, f(79 - j, Bh, Ch, Dh), msg[rh[j] + start], Kh(j)),
            sh[j]
          ),
          Eh
        );
        Ah = Eh;
        Eh = Dh;
        Dh = rotl32(Ch, 10);
        Ch = Bh;
        Bh = T;
      }
      T = sum32_3(this.h[1], C, Dh);
      this.h[1] = sum32_3(this.h[2], D, Eh);
      this.h[2] = sum32_3(this.h[3], E, Ah);
      this.h[3] = sum32_3(this.h[4], A, Bh);
      this.h[4] = sum32_3(this.h[0], B, Ch);
      this.h[0] = T;
    };
    RIPEMD160.prototype._digest = function digest(enc) {
      if (enc === "hex")
        return utils.toHex32(this.h, "little");
      else
        return utils.split32(this.h, "little");
    };
    function f(j, x, y, z) {
      if (j <= 15)
        return x ^ y ^ z;
      else if (j <= 31)
        return x & y | ~x & z;
      else if (j <= 47)
        return (x | ~y) ^ z;
      else if (j <= 63)
        return x & z | y & ~z;
      else
        return x ^ (y | ~z);
    }
    function K(j) {
      if (j <= 15)
        return 0;
      else if (j <= 31)
        return 1518500249;
      else if (j <= 47)
        return 1859775393;
      else if (j <= 63)
        return 2400959708;
      else
        return 2840853838;
    }
    function Kh(j) {
      if (j <= 15)
        return 1352829926;
      else if (j <= 31)
        return 1548603684;
      else if (j <= 47)
        return 1836072691;
      else if (j <= 63)
        return 2053994217;
      else
        return 0;
    }
    var r = [
      0,
      1,
      2,
      3,
      4,
      5,
      6,
      7,
      8,
      9,
      10,
      11,
      12,
      13,
      14,
      15,
      7,
      4,
      13,
      1,
      10,
      6,
      15,
      3,
      12,
      0,
      9,
      5,
      2,
      14,
      11,
      8,
      3,
      10,
      14,
      4,
      9,
      15,
      8,
      1,
      2,
      7,
      0,
      6,
      13,
      11,
      5,
      12,
      1,
      9,
      11,
      10,
      0,
      8,
      12,
      4,
      13,
      3,
      7,
      15,
      14,
      5,
      6,
      2,
      4,
      0,
      5,
      9,
      7,
      12,
      2,
      10,
      14,
      1,
      3,
      8,
      11,
      6,
      15,
      13
    ];
    var rh = [
      5,
      14,
      7,
      0,
      9,
      2,
      11,
      4,
      13,
      6,
      15,
      8,
      1,
      10,
      3,
      12,
      6,
      11,
      3,
      7,
      0,
      13,
      5,
      10,
      14,
      15,
      8,
      12,
      4,
      9,
      1,
      2,
      15,
      5,
      1,
      3,
      7,
      14,
      6,
      9,
      11,
      8,
      12,
      2,
      10,
      0,
      4,
      13,
      8,
      6,
      4,
      1,
      3,
      11,
      15,
      0,
      5,
      12,
      2,
      13,
      9,
      7,
      10,
      14,
      12,
      15,
      10,
      4,
      1,
      5,
      8,
      7,
      6,
      2,
      13,
      14,
      0,
      3,
      9,
      11
    ];
    var s = [
      11,
      14,
      15,
      12,
      5,
      8,
      7,
      9,
      11,
      13,
      14,
      15,
      6,
      7,
      9,
      8,
      7,
      6,
      8,
      13,
      11,
      9,
      7,
      15,
      7,
      12,
      15,
      9,
      11,
      7,
      13,
      12,
      11,
      13,
      6,
      7,
      14,
      9,
      13,
      15,
      14,
      8,
      13,
      6,
      5,
      12,
      7,
      5,
      11,
      12,
      14,
      15,
      14,
      15,
      9,
      8,
      9,
      14,
      5,
      6,
      8,
      6,
      5,
      12,
      9,
      15,
      5,
      11,
      6,
      8,
      13,
      12,
      5,
      12,
      13,
      14,
      11,
      8,
      5,
      6
    ];
    var sh = [
      8,
      9,
      9,
      11,
      13,
      15,
      15,
      5,
      7,
      7,
      8,
      11,
      14,
      14,
      12,
      6,
      9,
      13,
      15,
      7,
      12,
      8,
      9,
      11,
      7,
      7,
      12,
      7,
      6,
      15,
      13,
      11,
      9,
      7,
      15,
      11,
      8,
      6,
      6,
      14,
      12,
      13,
      5,
      14,
      13,
      13,
      7,
      5,
      15,
      5,
      8,
      11,
      14,
      14,
      6,
      14,
      6,
      9,
      12,
      9,
      12,
      5,
      15,
      8,
      8,
      5,
      12,
      9,
      12,
      5,
      14,
      6,
      8,
      13,
      6,
      5,
      15,
      13,
      11,
      11
    ];
  }
});

// ../../node_modules/.pnpm/hash.js@1.1.7/node_modules/hash.js/lib/hash/hmac.js
var require_hmac = __commonJS({
  "../../node_modules/.pnpm/hash.js@1.1.7/node_modules/hash.js/lib/hash/hmac.js"(exports2, module2) {
    "use strict";
    var utils = require_utils();
    var assert = require_minimalistic_assert();
    function Hmac(hash, key, enc) {
      if (!(this instanceof Hmac))
        return new Hmac(hash, key, enc);
      this.Hash = hash;
      this.blockSize = hash.blockSize / 8;
      this.outSize = hash.outSize / 8;
      this.inner = null;
      this.outer = null;
      this._init(utils.toArray(key, enc));
    }
    module2.exports = Hmac;
    Hmac.prototype._init = function init(key) {
      if (key.length > this.blockSize)
        key = new this.Hash().update(key).digest();
      assert(key.length <= this.blockSize);
      for (var i = key.length; i < this.blockSize; i++)
        key.push(0);
      for (i = 0; i < key.length; i++)
        key[i] ^= 54;
      this.inner = new this.Hash().update(key);
      for (i = 0; i < key.length; i++)
        key[i] ^= 106;
      this.outer = new this.Hash().update(key);
    };
    Hmac.prototype.update = function update(msg, enc) {
      this.inner.update(msg, enc);
      return this;
    };
    Hmac.prototype.digest = function digest(enc) {
      this.outer.update(this.inner.digest());
      return this.outer.digest(enc);
    };
  }
});

// ../../node_modules/.pnpm/hash.js@1.1.7/node_modules/hash.js/lib/hash.js
var require_hash = __commonJS({
  "../../node_modules/.pnpm/hash.js@1.1.7/node_modules/hash.js/lib/hash.js"(exports2) {
    var hash = exports2;
    hash.utils = require_utils();
    hash.common = require_common();
    hash.sha = require_sha();
    hash.ripemd = require_ripemd();
    hash.hmac = require_hmac();
    hash.sha1 = hash.sha.sha1;
    hash.sha256 = hash.sha.sha256;
    hash.sha224 = hash.sha.sha224;
    hash.sha384 = hash.sha.sha384;
    hash.sha512 = hash.sha.sha512;
    hash.ripemd160 = hash.ripemd.ripemd160;
  }
});

// ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/internal/constants.js
var require_constants = __commonJS({
  "../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/internal/constants.js"(exports2, module2) {
    "use strict";
    var SEMVER_SPEC_VERSION = "2.0.0";
    var MAX_LENGTH = 256;
    var MAX_SAFE_INTEGER = Number.MAX_SAFE_INTEGER || /* istanbul ignore next */
    9007199254740991;
    var MAX_SAFE_COMPONENT_LENGTH = 16;
    var MAX_SAFE_BUILD_LENGTH = MAX_LENGTH - 6;
    var RELEASE_TYPES = [
      "major",
      "premajor",
      "minor",
      "preminor",
      "patch",
      "prepatch",
      "prerelease"
    ];
    module2.exports = {
      MAX_LENGTH,
      MAX_SAFE_COMPONENT_LENGTH,
      MAX_SAFE_BUILD_LENGTH,
      MAX_SAFE_INTEGER,
      RELEASE_TYPES,
      SEMVER_SPEC_VERSION,
      FLAG_INCLUDE_PRERELEASE: 1,
      FLAG_LOOSE: 2
    };
  }
});

// ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/internal/debug.js
var require_debug = __commonJS({
  "../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/internal/debug.js"(exports2, module2) {
    "use strict";
    var debug = typeof process === "object" && process.env && process.env.NODE_DEBUG && /\bsemver\b/i.test(process.env.NODE_DEBUG) ? (...args) => console.error("SEMVER", ...args) : () => {
    };
    module2.exports = debug;
  }
});

// ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/internal/re.js
var require_re = __commonJS({
  "../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/internal/re.js"(exports2, module2) {
    "use strict";
    var {
      MAX_SAFE_COMPONENT_LENGTH,
      MAX_SAFE_BUILD_LENGTH,
      MAX_LENGTH
    } = require_constants();
    var debug = require_debug();
    exports2 = module2.exports = {};
    var re = exports2.re = [];
    var safeRe = exports2.safeRe = [];
    var src = exports2.src = [];
    var safeSrc = exports2.safeSrc = [];
    var t = exports2.t = {};
    var R = 0;
    var LETTERDASHNUMBER = "[a-zA-Z0-9-]";
    var safeRegexReplacements = [
      ["\\s", 1],
      ["\\d", MAX_LENGTH],
      [LETTERDASHNUMBER, MAX_SAFE_BUILD_LENGTH]
    ];
    var makeSafeRegex = (value) => {
      for (const [token, max] of safeRegexReplacements) {
        value = value.split(`${token}*`).join(`${token}{0,${max}}`).split(`${token}+`).join(`${token}{1,${max}}`);
      }
      return value;
    };
    var createToken = (name, value, isGlobal) => {
      const safe = makeSafeRegex(value);
      const index = R++;
      debug(name, index, value);
      t[name] = index;
      src[index] = value;
      safeSrc[index] = safe;
      re[index] = new RegExp(value, isGlobal ? "g" : void 0);
      safeRe[index] = new RegExp(safe, isGlobal ? "g" : void 0);
    };
    createToken("NUMERICIDENTIFIER", "0|[1-9]\\d*");
    createToken("NUMERICIDENTIFIERLOOSE", "\\d+");
    createToken("NONNUMERICIDENTIFIER", `\\d*[a-zA-Z-]${LETTERDASHNUMBER}*`);
    createToken("MAINVERSION", `(${src[t.NUMERICIDENTIFIER]})\\.(${src[t.NUMERICIDENTIFIER]})\\.(${src[t.NUMERICIDENTIFIER]})`);
    createToken("MAINVERSIONLOOSE", `(${src[t.NUMERICIDENTIFIERLOOSE]})\\.(${src[t.NUMERICIDENTIFIERLOOSE]})\\.(${src[t.NUMERICIDENTIFIERLOOSE]})`);
    createToken("PRERELEASEIDENTIFIER", `(?:${src[t.NONNUMERICIDENTIFIER]}|${src[t.NUMERICIDENTIFIER]})`);
    createToken("PRERELEASEIDENTIFIERLOOSE", `(?:${src[t.NONNUMERICIDENTIFIER]}|${src[t.NUMERICIDENTIFIERLOOSE]})`);
    createToken("PRERELEASE", `(?:-(${src[t.PRERELEASEIDENTIFIER]}(?:\\.${src[t.PRERELEASEIDENTIFIER]})*))`);
    createToken("PRERELEASELOOSE", `(?:-?(${src[t.PRERELEASEIDENTIFIERLOOSE]}(?:\\.${src[t.PRERELEASEIDENTIFIERLOOSE]})*))`);
    createToken("BUILDIDENTIFIER", `${LETTERDASHNUMBER}+`);
    createToken("BUILD", `(?:\\+(${src[t.BUILDIDENTIFIER]}(?:\\.${src[t.BUILDIDENTIFIER]})*))`);
    createToken("FULLPLAIN", `v?${src[t.MAINVERSION]}${src[t.PRERELEASE]}?${src[t.BUILD]}?`);
    createToken("FULL", `^${src[t.FULLPLAIN]}$`);
    createToken("LOOSEPLAIN", `[v=\\s]*${src[t.MAINVERSIONLOOSE]}${src[t.PRERELEASELOOSE]}?${src[t.BUILD]}?`);
    createToken("LOOSE", `^${src[t.LOOSEPLAIN]}$`);
    createToken("GTLT", "((?:<|>)?=?)");
    createToken("XRANGEIDENTIFIERLOOSE", `${src[t.NUMERICIDENTIFIERLOOSE]}|x|X|\\*`);
    createToken("XRANGEIDENTIFIER", `${src[t.NUMERICIDENTIFIER]}|x|X|\\*`);
    createToken("XRANGEPLAIN", `[v=\\s]*(${src[t.XRANGEIDENTIFIER]})(?:\\.(${src[t.XRANGEIDENTIFIER]})(?:\\.(${src[t.XRANGEIDENTIFIER]})(?:${src[t.PRERELEASE]})?${src[t.BUILD]}?)?)?`);
    createToken("XRANGEPLAINLOOSE", `[v=\\s]*(${src[t.XRANGEIDENTIFIERLOOSE]})(?:\\.(${src[t.XRANGEIDENTIFIERLOOSE]})(?:\\.(${src[t.XRANGEIDENTIFIERLOOSE]})(?:${src[t.PRERELEASELOOSE]})?${src[t.BUILD]}?)?)?`);
    createToken("XRANGE", `^${src[t.GTLT]}\\s*${src[t.XRANGEPLAIN]}$`);
    createToken("XRANGELOOSE", `^${src[t.GTLT]}\\s*${src[t.XRANGEPLAINLOOSE]}$`);
    createToken("COERCEPLAIN", `${"(^|[^\\d])(\\d{1,"}${MAX_SAFE_COMPONENT_LENGTH}})(?:\\.(\\d{1,${MAX_SAFE_COMPONENT_LENGTH}}))?(?:\\.(\\d{1,${MAX_SAFE_COMPONENT_LENGTH}}))?`);
    createToken("COERCE", `${src[t.COERCEPLAIN]}(?:$|[^\\d])`);
    createToken("COERCEFULL", src[t.COERCEPLAIN] + `(?:${src[t.PRERELEASE]})?(?:${src[t.BUILD]})?(?:$|[^\\d])`);
    createToken("COERCERTL", src[t.COERCE], true);
    createToken("COERCERTLFULL", src[t.COERCEFULL], true);
    createToken("LONETILDE", "(?:~>?)");
    createToken("TILDETRIM", `(\\s*)${src[t.LONETILDE]}\\s+`, true);
    exports2.tildeTrimReplace = "$1~";
    createToken("TILDE", `^${src[t.LONETILDE]}${src[t.XRANGEPLAIN]}$`);
    createToken("TILDELOOSE", `^${src[t.LONETILDE]}${src[t.XRANGEPLAINLOOSE]}$`);
    createToken("LONECARET", "(?:\\^)");
    createToken("CARETTRIM", `(\\s*)${src[t.LONECARET]}\\s+`, true);
    exports2.caretTrimReplace = "$1^";
    createToken("CARET", `^${src[t.LONECARET]}${src[t.XRANGEPLAIN]}$`);
    createToken("CARETLOOSE", `^${src[t.LONECARET]}${src[t.XRANGEPLAINLOOSE]}$`);
    createToken("COMPARATORLOOSE", `^${src[t.GTLT]}\\s*(${src[t.LOOSEPLAIN]})$|^$`);
    createToken("COMPARATOR", `^${src[t.GTLT]}\\s*(${src[t.FULLPLAIN]})$|^$`);
    createToken("COMPARATORTRIM", `(\\s*)${src[t.GTLT]}\\s*(${src[t.LOOSEPLAIN]}|${src[t.XRANGEPLAIN]})`, true);
    exports2.comparatorTrimReplace = "$1$2$3";
    createToken("HYPHENRANGE", `^\\s*(${src[t.XRANGEPLAIN]})\\s+-\\s+(${src[t.XRANGEPLAIN]})\\s*$`);
    createToken("HYPHENRANGELOOSE", `^\\s*(${src[t.XRANGEPLAINLOOSE]})\\s+-\\s+(${src[t.XRANGEPLAINLOOSE]})\\s*$`);
    createToken("STAR", "(<|>)?=?\\s*\\*");
    createToken("GTE0", "^\\s*>=\\s*0\\.0\\.0\\s*$");
    createToken("GTE0PRE", "^\\s*>=\\s*0\\.0\\.0-0\\s*$");
  }
});

// ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/internal/parse-options.js
var require_parse_options = __commonJS({
  "../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/internal/parse-options.js"(exports2, module2) {
    "use strict";
    var looseOption = Object.freeze({ loose: true });
    var emptyOpts = Object.freeze({});
    var parseOptions = (options) => {
      if (!options) {
        return emptyOpts;
      }
      if (typeof options !== "object") {
        return looseOption;
      }
      return options;
    };
    module2.exports = parseOptions;
  }
});

// ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/internal/identifiers.js
var require_identifiers = __commonJS({
  "../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/internal/identifiers.js"(exports2, module2) {
    "use strict";
    var numeric = /^[0-9]+$/;
    var compareIdentifiers = (a, b) => {
      if (typeof a === "number" && typeof b === "number") {
        return a === b ? 0 : a < b ? -1 : 1;
      }
      const anum = numeric.test(a);
      const bnum = numeric.test(b);
      if (anum && bnum) {
        a = +a;
        b = +b;
      }
      return a === b ? 0 : anum && !bnum ? -1 : bnum && !anum ? 1 : a < b ? -1 : 1;
    };
    var rcompareIdentifiers = (a, b) => compareIdentifiers(b, a);
    module2.exports = {
      compareIdentifiers,
      rcompareIdentifiers
    };
  }
});

// ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/classes/semver.js
var require_semver = __commonJS({
  "../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/classes/semver.js"(exports2, module2) {
    "use strict";
    var debug = require_debug();
    var { MAX_LENGTH, MAX_SAFE_INTEGER } = require_constants();
    var { safeRe: re, t } = require_re();
    var parseOptions = require_parse_options();
    var { compareIdentifiers } = require_identifiers();
    var isPrereleaseIdentifier = (prerelease, identifier) => {
      const identifiers = identifier.split(".");
      if (identifiers.length > prerelease.length) {
        return false;
      }
      for (let i = 0; i < identifiers.length; i++) {
        if (compareIdentifiers(prerelease[i], identifiers[i]) !== 0) {
          return false;
        }
      }
      return true;
    };
    var SemVer = class _SemVer {
      constructor(version, options) {
        options = parseOptions(options);
        if (version instanceof _SemVer) {
          if (version.loose === !!options.loose && version.includePrerelease === !!options.includePrerelease) {
            return version;
          } else {
            version = version.version;
          }
        } else if (typeof version !== "string") {
          throw new TypeError(`Invalid version. Must be a string. Got type "${typeof version}".`);
        }
        if (version.length > MAX_LENGTH) {
          throw new TypeError(
            `version is longer than ${MAX_LENGTH} characters`
          );
        }
        debug("SemVer", version, options);
        this.options = options;
        this.loose = !!options.loose;
        this.includePrerelease = !!options.includePrerelease;
        const m = version.trim().match(options.loose ? re[t.LOOSE] : re[t.FULL]);
        if (!m) {
          throw new TypeError(`Invalid Version: ${version}`);
        }
        this.raw = version;
        this.major = +m[1];
        this.minor = +m[2];
        this.patch = +m[3];
        if (this.major > MAX_SAFE_INTEGER || this.major < 0) {
          throw new TypeError("Invalid major version");
        }
        if (this.minor > MAX_SAFE_INTEGER || this.minor < 0) {
          throw new TypeError("Invalid minor version");
        }
        if (this.patch > MAX_SAFE_INTEGER || this.patch < 0) {
          throw new TypeError("Invalid patch version");
        }
        if (!m[4]) {
          this.prerelease = [];
        } else {
          this.prerelease = m[4].split(".").map((id) => {
            if (/^[0-9]+$/.test(id)) {
              const num = +id;
              if (num >= 0 && num < MAX_SAFE_INTEGER) {
                return num;
              }
            }
            return id;
          });
        }
        this.build = m[5] ? m[5].split(".") : [];
        this.format();
      }
      format() {
        this.version = `${this.major}.${this.minor}.${this.patch}`;
        if (this.prerelease.length) {
          this.version += `-${this.prerelease.join(".")}`;
        }
        return this.version;
      }
      toString() {
        return this.version;
      }
      compare(other) {
        debug("SemVer.compare", this.version, this.options, other);
        if (!(other instanceof _SemVer)) {
          if (typeof other === "string" && other === this.version) {
            return 0;
          }
          other = new _SemVer(other, this.options);
        }
        if (other.version === this.version) {
          return 0;
        }
        return this.compareMain(other) || this.comparePre(other);
      }
      compareMain(other) {
        if (!(other instanceof _SemVer)) {
          other = new _SemVer(other, this.options);
        }
        if (this.major < other.major) {
          return -1;
        }
        if (this.major > other.major) {
          return 1;
        }
        if (this.minor < other.minor) {
          return -1;
        }
        if (this.minor > other.minor) {
          return 1;
        }
        if (this.patch < other.patch) {
          return -1;
        }
        if (this.patch > other.patch) {
          return 1;
        }
        return 0;
      }
      comparePre(other) {
        if (!(other instanceof _SemVer)) {
          other = new _SemVer(other, this.options);
        }
        if (this.prerelease.length && !other.prerelease.length) {
          return -1;
        } else if (!this.prerelease.length && other.prerelease.length) {
          return 1;
        } else if (!this.prerelease.length && !other.prerelease.length) {
          return 0;
        }
        let i = 0;
        do {
          const a = this.prerelease[i];
          const b = other.prerelease[i];
          debug("prerelease compare", i, a, b);
          if (a === void 0 && b === void 0) {
            return 0;
          } else if (b === void 0) {
            return 1;
          } else if (a === void 0) {
            return -1;
          } else if (a === b) {
            continue;
          } else {
            return compareIdentifiers(a, b);
          }
        } while (++i);
      }
      compareBuild(other) {
        if (!(other instanceof _SemVer)) {
          other = new _SemVer(other, this.options);
        }
        let i = 0;
        do {
          const a = this.build[i];
          const b = other.build[i];
          debug("build compare", i, a, b);
          if (a === void 0 && b === void 0) {
            return 0;
          } else if (b === void 0) {
            return 1;
          } else if (a === void 0) {
            return -1;
          } else if (a === b) {
            continue;
          } else {
            return compareIdentifiers(a, b);
          }
        } while (++i);
      }
      // preminor will bump the version up to the next minor release, and immediately
      // down to pre-release. premajor and prepatch work the same way.
      inc(release, identifier, identifierBase) {
        if (release.startsWith("pre")) {
          if (!identifier && identifierBase === false) {
            throw new Error("invalid increment argument: identifier is empty");
          }
          if (identifier) {
            const match = `-${identifier}`.match(this.options.loose ? re[t.PRERELEASELOOSE] : re[t.PRERELEASE]);
            if (!match || match[1] !== identifier) {
              throw new Error(`invalid identifier: ${identifier}`);
            }
          }
        }
        switch (release) {
          case "premajor":
            this.prerelease.length = 0;
            this.patch = 0;
            this.minor = 0;
            this.major++;
            this.inc("pre", identifier, identifierBase);
            break;
          case "preminor":
            this.prerelease.length = 0;
            this.patch = 0;
            this.minor++;
            this.inc("pre", identifier, identifierBase);
            break;
          case "prepatch":
            this.prerelease.length = 0;
            this.inc("patch", identifier, identifierBase);
            this.inc("pre", identifier, identifierBase);
            break;
          case "prerelease":
            if (this.prerelease.length === 0) {
              this.inc("patch", identifier, identifierBase);
            }
            this.inc("pre", identifier, identifierBase);
            break;
          case "release":
            if (this.prerelease.length === 0) {
              throw new Error(`version ${this.raw} is not a prerelease`);
            }
            this.prerelease.length = 0;
            break;
          case "major":
            if (this.minor !== 0 || this.patch !== 0 || this.prerelease.length === 0) {
              this.major++;
            }
            this.minor = 0;
            this.patch = 0;
            this.prerelease = [];
            break;
          case "minor":
            if (this.patch !== 0 || this.prerelease.length === 0) {
              this.minor++;
            }
            this.patch = 0;
            this.prerelease = [];
            break;
          case "patch":
            if (this.prerelease.length === 0) {
              this.patch++;
            }
            this.prerelease = [];
            break;
          case "pre": {
            const base = Number(identifierBase) ? 1 : 0;
            if (this.prerelease.length === 0) {
              this.prerelease = [base];
            } else {
              let i = this.prerelease.length;
              while (--i >= 0) {
                if (typeof this.prerelease[i] === "number") {
                  this.prerelease[i]++;
                  i = -2;
                }
              }
              if (i === -1) {
                if (identifier === this.prerelease.join(".") && identifierBase === false) {
                  throw new Error("invalid increment argument: identifier already exists");
                }
                this.prerelease.push(base);
              }
            }
            if (identifier) {
              let prerelease = [identifier, base];
              if (identifierBase === false) {
                prerelease = [identifier];
              }
              if (isPrereleaseIdentifier(this.prerelease, identifier)) {
                const prereleaseBase = this.prerelease[identifier.split(".").length];
                if (isNaN(prereleaseBase)) {
                  this.prerelease = prerelease;
                }
              } else {
                this.prerelease = prerelease;
              }
            }
            break;
          }
          default:
            throw new Error(`invalid increment argument: ${release}`);
        }
        this.raw = this.format();
        if (this.build.length) {
          this.raw += `+${this.build.join(".")}`;
        }
        return this;
      }
    };
    module2.exports = SemVer;
  }
});

// ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/parse.js
var require_parse = __commonJS({
  "../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/parse.js"(exports2, module2) {
    "use strict";
    var SemVer = require_semver();
    var parse = (version, options, throwErrors = false) => {
      if (version instanceof SemVer) {
        return version;
      }
      try {
        return new SemVer(version, options);
      } catch (er) {
        if (!throwErrors) {
          return null;
        }
        throw er;
      }
    };
    module2.exports = parse;
  }
});

// ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/valid.js
var require_valid = __commonJS({
  "../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/valid.js"(exports2, module2) {
    "use strict";
    var parse = require_parse();
    var valid = (version, options) => {
      const v = parse(version, options);
      return v ? v.version : null;
    };
    module2.exports = valid;
  }
});

// ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/clean.js
var require_clean = __commonJS({
  "../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/clean.js"(exports2, module2) {
    "use strict";
    var parse = require_parse();
    var clean = (version, options) => {
      const s = parse(version.trim().replace(/^[=v]+/, ""), options);
      return s ? s.version : null;
    };
    module2.exports = clean;
  }
});

// ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/inc.js
var require_inc = __commonJS({
  "../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/inc.js"(exports2, module2) {
    "use strict";
    var SemVer = require_semver();
    var inc = (version, release, options, identifier, identifierBase) => {
      if (typeof options === "string") {
        identifierBase = identifier;
        identifier = options;
        options = void 0;
      }
      try {
        return new SemVer(
          version instanceof SemVer ? version.version : version,
          options
        ).inc(release, identifier, identifierBase).version;
      } catch (er) {
        return null;
      }
    };
    module2.exports = inc;
  }
});

// ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/diff.js
var require_diff = __commonJS({
  "../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/diff.js"(exports2, module2) {
    "use strict";
    var parse = require_parse();
    var diff = (version1, version2) => {
      const v1 = parse(version1, null, true);
      const v2 = parse(version2, null, true);
      const comparison = v1.compare(v2);
      if (comparison === 0) {
        return null;
      }
      const v1Higher = comparison > 0;
      const highVersion = v1Higher ? v1 : v2;
      const lowVersion = v1Higher ? v2 : v1;
      const highHasPre = !!highVersion.prerelease.length;
      const lowHasPre = !!lowVersion.prerelease.length;
      if (lowHasPre && !highHasPre) {
        if (!lowVersion.patch && !lowVersion.minor) {
          return "major";
        }
        if (lowVersion.compareMain(highVersion) === 0) {
          if (lowVersion.minor && !lowVersion.patch) {
            return "minor";
          }
          return "patch";
        }
      }
      const prefix = highHasPre ? "pre" : "";
      if (v1.major !== v2.major) {
        return prefix + "major";
      }
      if (v1.minor !== v2.minor) {
        return prefix + "minor";
      }
      if (v1.patch !== v2.patch) {
        return prefix + "patch";
      }
      return "prerelease";
    };
    module2.exports = diff;
  }
});

// ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/major.js
var require_major = __commonJS({
  "../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/major.js"(exports2, module2) {
    "use strict";
    var SemVer = require_semver();
    var major = (a, loose) => new SemVer(a, loose).major;
    module2.exports = major;
  }
});

// ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/minor.js
var require_minor = __commonJS({
  "../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/minor.js"(exports2, module2) {
    "use strict";
    var SemVer = require_semver();
    var minor = (a, loose) => new SemVer(a, loose).minor;
    module2.exports = minor;
  }
});

// ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/patch.js
var require_patch = __commonJS({
  "../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/patch.js"(exports2, module2) {
    "use strict";
    var SemVer = require_semver();
    var patch = (a, loose) => new SemVer(a, loose).patch;
    module2.exports = patch;
  }
});

// ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/prerelease.js
var require_prerelease = __commonJS({
  "../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/prerelease.js"(exports2, module2) {
    "use strict";
    var parse = require_parse();
    var prerelease = (version, options) => {
      const parsed = parse(version, options);
      return parsed && parsed.prerelease.length ? parsed.prerelease : null;
    };
    module2.exports = prerelease;
  }
});

// ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/compare.js
var require_compare = __commonJS({
  "../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/compare.js"(exports2, module2) {
    "use strict";
    var SemVer = require_semver();
    var compare = (a, b, loose) => new SemVer(a, loose).compare(new SemVer(b, loose));
    module2.exports = compare;
  }
});

// ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/rcompare.js
var require_rcompare = __commonJS({
  "../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/rcompare.js"(exports2, module2) {
    "use strict";
    var compare = require_compare();
    var rcompare = (a, b, loose) => compare(b, a, loose);
    module2.exports = rcompare;
  }
});

// ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/compare-loose.js
var require_compare_loose = __commonJS({
  "../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/compare-loose.js"(exports2, module2) {
    "use strict";
    var compare = require_compare();
    var compareLoose = (a, b) => compare(a, b, true);
    module2.exports = compareLoose;
  }
});

// ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/compare-build.js
var require_compare_build = __commonJS({
  "../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/compare-build.js"(exports2, module2) {
    "use strict";
    var SemVer = require_semver();
    var compareBuild = (a, b, loose) => {
      const versionA = new SemVer(a, loose);
      const versionB = new SemVer(b, loose);
      return versionA.compare(versionB) || versionA.compareBuild(versionB);
    };
    module2.exports = compareBuild;
  }
});

// ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/sort.js
var require_sort = __commonJS({
  "../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/sort.js"(exports2, module2) {
    "use strict";
    var compareBuild = require_compare_build();
    var sort = (list, loose) => list.sort((a, b) => compareBuild(a, b, loose));
    module2.exports = sort;
  }
});

// ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/rsort.js
var require_rsort = __commonJS({
  "../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/rsort.js"(exports2, module2) {
    "use strict";
    var compareBuild = require_compare_build();
    var rsort = (list, loose) => list.sort((a, b) => compareBuild(b, a, loose));
    module2.exports = rsort;
  }
});

// ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/gt.js
var require_gt = __commonJS({
  "../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/gt.js"(exports2, module2) {
    "use strict";
    var compare = require_compare();
    var gt = (a, b, loose) => compare(a, b, loose) > 0;
    module2.exports = gt;
  }
});

// ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/lt.js
var require_lt = __commonJS({
  "../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/lt.js"(exports2, module2) {
    "use strict";
    var compare = require_compare();
    var lt = (a, b, loose) => compare(a, b, loose) < 0;
    module2.exports = lt;
  }
});

// ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/eq.js
var require_eq = __commonJS({
  "../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/eq.js"(exports2, module2) {
    "use strict";
    var compare = require_compare();
    var eq = (a, b, loose) => compare(a, b, loose) === 0;
    module2.exports = eq;
  }
});

// ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/neq.js
var require_neq = __commonJS({
  "../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/neq.js"(exports2, module2) {
    "use strict";
    var compare = require_compare();
    var neq = (a, b, loose) => compare(a, b, loose) !== 0;
    module2.exports = neq;
  }
});

// ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/gte.js
var require_gte = __commonJS({
  "../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/gte.js"(exports2, module2) {
    "use strict";
    var compare = require_compare();
    var gte = (a, b, loose) => compare(a, b, loose) >= 0;
    module2.exports = gte;
  }
});

// ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/lte.js
var require_lte = __commonJS({
  "../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/lte.js"(exports2, module2) {
    "use strict";
    var compare = require_compare();
    var lte = (a, b, loose) => compare(a, b, loose) <= 0;
    module2.exports = lte;
  }
});

// ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/cmp.js
var require_cmp = __commonJS({
  "../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/cmp.js"(exports2, module2) {
    "use strict";
    var eq = require_eq();
    var neq = require_neq();
    var gt = require_gt();
    var gte = require_gte();
    var lt = require_lt();
    var lte = require_lte();
    var cmp = (a, op, b, loose) => {
      switch (op) {
        case "===":
          if (typeof a === "object") {
            a = a.version;
          }
          if (typeof b === "object") {
            b = b.version;
          }
          return a === b;
        case "!==":
          if (typeof a === "object") {
            a = a.version;
          }
          if (typeof b === "object") {
            b = b.version;
          }
          return a !== b;
        case "":
        case "=":
        case "==":
          return eq(a, b, loose);
        case "!=":
          return neq(a, b, loose);
        case ">":
          return gt(a, b, loose);
        case ">=":
          return gte(a, b, loose);
        case "<":
          return lt(a, b, loose);
        case "<=":
          return lte(a, b, loose);
        default:
          throw new TypeError(`Invalid operator: ${op}`);
      }
    };
    module2.exports = cmp;
  }
});

// ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/coerce.js
var require_coerce = __commonJS({
  "../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/coerce.js"(exports2, module2) {
    "use strict";
    var SemVer = require_semver();
    var parse = require_parse();
    var { safeRe: re, t } = require_re();
    var coerce = (version, options) => {
      if (version instanceof SemVer) {
        return version;
      }
      if (typeof version === "number") {
        version = String(version);
      }
      if (typeof version !== "string") {
        return null;
      }
      options = options || {};
      let match = null;
      if (!options.rtl) {
        match = version.match(options.includePrerelease ? re[t.COERCEFULL] : re[t.COERCE]);
      } else {
        const coerceRtlRegex = options.includePrerelease ? re[t.COERCERTLFULL] : re[t.COERCERTL];
        let next;
        while ((next = coerceRtlRegex.exec(version)) && (!match || match.index + match[0].length !== version.length)) {
          if (!match || next.index + next[0].length !== match.index + match[0].length) {
            match = next;
          }
          coerceRtlRegex.lastIndex = next.index + next[1].length + next[2].length;
        }
        coerceRtlRegex.lastIndex = -1;
      }
      if (match === null) {
        return null;
      }
      const major = match[2];
      const minor = match[3] || "0";
      const patch = match[4] || "0";
      const prerelease = options.includePrerelease && match[5] ? `-${match[5]}` : "";
      const build = options.includePrerelease && match[6] ? `+${match[6]}` : "";
      return parse(`${major}.${minor}.${patch}${prerelease}${build}`, options);
    };
    module2.exports = coerce;
  }
});

// ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/truncate.js
var require_truncate = __commonJS({
  "../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/truncate.js"(exports2, module2) {
    "use strict";
    var parse = require_parse();
    var constants = require_constants();
    var SemVer = require_semver();
    var truncate = (version, truncation, options) => {
      if (!constants.RELEASE_TYPES.includes(truncation)) {
        return null;
      }
      const clonedVersion = cloneInputVersion(version, options);
      return clonedVersion && doTruncation(clonedVersion, truncation);
    };
    var cloneInputVersion = (version, options) => {
      const versionStringToParse = version instanceof SemVer ? version.version : version;
      return parse(versionStringToParse, options);
    };
    var doTruncation = (version, truncation) => {
      if (isPrerelease(truncation)) {
        return version.version;
      }
      version.prerelease = [];
      switch (truncation) {
        case "major":
          version.minor = 0;
          version.patch = 0;
          break;
        case "minor":
          version.patch = 0;
          break;
      }
      return version.format();
    };
    var isPrerelease = (type) => {
      return type.startsWith("pre");
    };
    module2.exports = truncate;
  }
});

// ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/internal/lrucache.js
var require_lrucache = __commonJS({
  "../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/internal/lrucache.js"(exports2, module2) {
    "use strict";
    var LRUCache = class {
      constructor() {
        this.max = 1e3;
        this.map = /* @__PURE__ */ new Map();
      }
      get(key) {
        const value = this.map.get(key);
        if (value === void 0) {
          return void 0;
        } else {
          this.map.delete(key);
          this.map.set(key, value);
          return value;
        }
      }
      delete(key) {
        return this.map.delete(key);
      }
      set(key, value) {
        const deleted = this.delete(key);
        if (!deleted && value !== void 0) {
          if (this.map.size >= this.max) {
            const firstKey = this.map.keys().next().value;
            this.delete(firstKey);
          }
          this.map.set(key, value);
        }
        return this;
      }
    };
    module2.exports = LRUCache;
  }
});

// ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/classes/range.js
var require_range = __commonJS({
  "../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/classes/range.js"(exports2, module2) {
    "use strict";
    var SPACE_CHARACTERS = /\s+/g;
    var Range = class _Range {
      constructor(range, options) {
        options = parseOptions(options);
        if (range instanceof _Range) {
          if (range.loose === !!options.loose && range.includePrerelease === !!options.includePrerelease) {
            return range;
          } else {
            return new _Range(range.raw, options);
          }
        }
        if (range instanceof Comparator) {
          this.raw = range.value;
          this.set = [[range]];
          this.formatted = void 0;
          return this;
        }
        this.options = options;
        this.loose = !!options.loose;
        this.includePrerelease = !!options.includePrerelease;
        this.raw = range.trim().replace(SPACE_CHARACTERS, " ");
        this.set = this.raw.split("||").map((r) => this.parseRange(r.trim())).filter((c) => c.length);
        if (!this.set.length) {
          throw new TypeError(`Invalid SemVer Range: ${this.raw}`);
        }
        if (this.set.length > 1) {
          const first = this.set[0];
          this.set = this.set.filter((c) => !isNullSet(c[0]));
          if (this.set.length === 0) {
            this.set = [first];
          } else if (this.set.length > 1) {
            for (const c of this.set) {
              if (c.length === 1 && isAny(c[0])) {
                this.set = [c];
                break;
              }
            }
          }
        }
        this.formatted = void 0;
      }
      get range() {
        if (this.formatted === void 0) {
          this.formatted = "";
          for (let i = 0; i < this.set.length; i++) {
            if (i > 0) {
              this.formatted += "||";
            }
            const comps = this.set[i];
            for (let k = 0; k < comps.length; k++) {
              if (k > 0) {
                this.formatted += " ";
              }
              this.formatted += comps[k].toString().trim();
            }
          }
        }
        return this.formatted;
      }
      format() {
        return this.range;
      }
      toString() {
        return this.range;
      }
      parseRange(range) {
        range = range.replace(BUILDSTRIPRE, "");
        const memoOpts = (this.options.includePrerelease && FLAG_INCLUDE_PRERELEASE) | (this.options.loose && FLAG_LOOSE);
        const memoKey = memoOpts + ":" + range;
        const cached = cache.get(memoKey);
        if (cached) {
          return cached;
        }
        const loose = this.options.loose;
        const hr = loose ? re[t.HYPHENRANGELOOSE] : re[t.HYPHENRANGE];
        range = range.replace(hr, hyphenReplace(this.options.includePrerelease));
        debug("hyphen replace", range);
        range = range.replace(re[t.COMPARATORTRIM], comparatorTrimReplace);
        debug("comparator trim", range);
        range = range.replace(re[t.TILDETRIM], tildeTrimReplace);
        debug("tilde trim", range);
        range = range.replace(re[t.CARETTRIM], caretTrimReplace);
        debug("caret trim", range);
        let rangeList = range.split(" ").map((comp) => parseComparator(comp, this.options)).join(" ").split(/\s+/).map((comp) => replaceGTE0(comp, this.options));
        if (loose) {
          rangeList = rangeList.filter((comp) => {
            debug("loose invalid filter", comp, this.options);
            return !!comp.match(re[t.COMPARATORLOOSE]);
          });
        }
        debug("range list", rangeList);
        const rangeMap = /* @__PURE__ */ new Map();
        const comparators = rangeList.map((comp) => new Comparator(comp, this.options));
        for (const comp of comparators) {
          if (isNullSet(comp)) {
            return [comp];
          }
          rangeMap.set(comp.value, comp);
        }
        if (rangeMap.size > 1 && rangeMap.has("")) {
          rangeMap.delete("");
        }
        const result = [...rangeMap.values()];
        cache.set(memoKey, result);
        return result;
      }
      intersects(range, options) {
        if (!(range instanceof _Range)) {
          throw new TypeError("a Range is required");
        }
        return this.set.some((thisComparators) => {
          return isSatisfiable(thisComparators, options) && range.set.some((rangeComparators) => {
            return isSatisfiable(rangeComparators, options) && thisComparators.every((thisComparator) => {
              return rangeComparators.every((rangeComparator) => {
                return thisComparator.intersects(rangeComparator, options);
              });
            });
          });
        });
      }
      // if ANY of the sets match ALL of its comparators, then pass
      test(version) {
        if (!version) {
          return false;
        }
        if (typeof version === "string") {
          try {
            version = new SemVer(version, this.options);
          } catch (er) {
            return false;
          }
        }
        for (let i = 0; i < this.set.length; i++) {
          if (testSet(this.set[i], version, this.options)) {
            return true;
          }
        }
        return false;
      }
    };
    module2.exports = Range;
    var LRU = require_lrucache();
    var cache = new LRU();
    var parseOptions = require_parse_options();
    var Comparator = require_comparator();
    var debug = require_debug();
    var SemVer = require_semver();
    var {
      safeRe: re,
      src,
      t,
      comparatorTrimReplace,
      tildeTrimReplace,
      caretTrimReplace
    } = require_re();
    var { FLAG_INCLUDE_PRERELEASE, FLAG_LOOSE } = require_constants();
    var BUILDSTRIPRE = new RegExp(src[t.BUILD], "g");
    var isNullSet = (c) => c.value === "<0.0.0-0";
    var isAny = (c) => c.value === "";
    var isSatisfiable = (comparators, options) => {
      let result = true;
      const remainingComparators = comparators.slice();
      let testComparator = remainingComparators.pop();
      while (result && remainingComparators.length) {
        result = remainingComparators.every((otherComparator) => {
          return testComparator.intersects(otherComparator, options);
        });
        testComparator = remainingComparators.pop();
      }
      return result;
    };
    var parseComparator = (comp, options) => {
      comp = comp.replace(re[t.BUILD], "");
      debug("comp", comp, options);
      comp = replaceCarets(comp, options);
      debug("caret", comp);
      comp = replaceTildes(comp, options);
      debug("tildes", comp);
      comp = replaceXRanges(comp, options);
      debug("xrange", comp);
      comp = replaceStars(comp, options);
      debug("stars", comp);
      return comp;
    };
    var isX = (id) => !id || id.toLowerCase() === "x" || id === "*";
    var invalidXRangeOrder = (M, m, p) => isX(M) && !isX(m) || isX(m) && p && !isX(p);
    var replaceTildes = (comp, options) => {
      return comp.trim().split(/\s+/).map((c) => replaceTilde(c, options)).join(" ");
    };
    var replaceTilde = (comp, options) => {
      const r = options.loose ? re[t.TILDELOOSE] : re[t.TILDE];
      const z = options.includePrerelease ? "-0" : "";
      return comp.replace(r, (_, M, m, p, pr) => {
        debug("tilde", comp, _, M, m, p, pr);
        let ret;
        if (isX(M)) {
          ret = "";
        } else if (isX(m)) {
          ret = `>=${M}.0.0${z} <${+M + 1}.0.0-0`;
        } else if (isX(p)) {
          ret = `>=${M}.${m}.0${z} <${M}.${+m + 1}.0-0`;
        } else if (pr) {
          debug("replaceTilde pr", pr);
          ret = `>=${M}.${m}.${p}-${pr} <${M}.${+m + 1}.0-0`;
        } else {
          ret = `>=${M}.${m}.${p} <${M}.${+m + 1}.0-0`;
        }
        debug("tilde return", ret);
        return ret;
      });
    };
    var replaceCarets = (comp, options) => {
      return comp.trim().split(/\s+/).map((c) => replaceCaret(c, options)).join(" ");
    };
    var replaceCaret = (comp, options) => {
      debug("caret", comp, options);
      const r = options.loose ? re[t.CARETLOOSE] : re[t.CARET];
      const z = options.includePrerelease ? "-0" : "";
      return comp.replace(r, (_, M, m, p, pr) => {
        debug("caret", comp, _, M, m, p, pr);
        let ret;
        if (isX(M)) {
          ret = "";
        } else if (isX(m)) {
          ret = `>=${M}.0.0${z} <${+M + 1}.0.0-0`;
        } else if (isX(p)) {
          if (M === "0") {
            ret = `>=${M}.${m}.0${z} <${M}.${+m + 1}.0-0`;
          } else {
            ret = `>=${M}.${m}.0${z} <${+M + 1}.0.0-0`;
          }
        } else if (pr) {
          debug("replaceCaret pr", pr);
          if (M === "0") {
            if (m === "0") {
              ret = `>=${M}.${m}.${p}-${pr} <${M}.${m}.${+p + 1}-0`;
            } else {
              ret = `>=${M}.${m}.${p}-${pr} <${M}.${+m + 1}.0-0`;
            }
          } else {
            ret = `>=${M}.${m}.${p}-${pr} <${+M + 1}.0.0-0`;
          }
        } else {
          debug("no pr");
          if (M === "0") {
            if (m === "0") {
              ret = `>=${M}.${m}.${p} <${M}.${m}.${+p + 1}-0`;
            } else {
              ret = `>=${M}.${m}.${p} <${M}.${+m + 1}.0-0`;
            }
          } else {
            ret = `>=${M}.${m}.${p} <${+M + 1}.0.0-0`;
          }
        }
        debug("caret return", ret);
        return ret;
      });
    };
    var replaceXRanges = (comp, options) => {
      debug("replaceXRanges", comp, options);
      return comp.split(/\s+/).map((c) => replaceXRange(c, options)).join(" ");
    };
    var replaceXRange = (comp, options) => {
      comp = comp.trim();
      const r = options.loose ? re[t.XRANGELOOSE] : re[t.XRANGE];
      return comp.replace(r, (ret, gtlt, M, m, p, pr) => {
        debug("xRange", comp, ret, gtlt, M, m, p, pr);
        if (invalidXRangeOrder(M, m, p)) {
          return comp;
        }
        const xM = isX(M);
        const xm = xM || isX(m);
        const xp = xm || isX(p);
        const anyX = xp;
        if (gtlt === "=" && anyX) {
          gtlt = "";
        }
        pr = options.includePrerelease ? "-0" : "";
        if (xM) {
          if (gtlt === ">" || gtlt === "<") {
            ret = "<0.0.0-0";
          } else {
            ret = "*";
          }
        } else if (gtlt && anyX) {
          if (xm) {
            m = 0;
          }
          p = 0;
          if (gtlt === ">") {
            gtlt = ">=";
            if (xm) {
              M = +M + 1;
              m = 0;
              p = 0;
            } else {
              m = +m + 1;
              p = 0;
            }
          } else if (gtlt === "<=") {
            gtlt = "<";
            if (xm) {
              M = +M + 1;
            } else {
              m = +m + 1;
            }
          }
          if (gtlt === "<") {
            pr = "-0";
          }
          ret = `${gtlt + M}.${m}.${p}${pr}`;
        } else if (xm) {
          ret = `>=${M}.0.0${pr} <${+M + 1}.0.0-0`;
        } else if (xp) {
          ret = `>=${M}.${m}.0${pr} <${M}.${+m + 1}.0-0`;
        }
        debug("xRange return", ret);
        return ret;
      });
    };
    var replaceStars = (comp, options) => {
      debug("replaceStars", comp, options);
      return comp.trim().replace(re[t.STAR], "");
    };
    var replaceGTE0 = (comp, options) => {
      debug("replaceGTE0", comp, options);
      return comp.trim().replace(re[options.includePrerelease ? t.GTE0PRE : t.GTE0], "");
    };
    var hyphenReplace = (incPr) => ($0, from, fM, fm, fp, fpr, fb, to, tM, tm, tp, tpr) => {
      if (isX(fM)) {
        from = "";
      } else if (isX(fm)) {
        from = `>=${fM}.0.0${incPr ? "-0" : ""}`;
      } else if (isX(fp)) {
        from = `>=${fM}.${fm}.0${incPr ? "-0" : ""}`;
      } else if (fpr) {
        from = `>=${from}`;
      } else {
        from = `>=${from}${incPr ? "-0" : ""}`;
      }
      if (isX(tM)) {
        to = "";
      } else if (isX(tm)) {
        to = `<${+tM + 1}.0.0-0`;
      } else if (isX(tp)) {
        to = `<${tM}.${+tm + 1}.0-0`;
      } else if (tpr) {
        to = `<=${tM}.${tm}.${tp}-${tpr}`;
      } else if (incPr) {
        to = `<${tM}.${tm}.${+tp + 1}-0`;
      } else {
        to = `<=${to}`;
      }
      return `${from} ${to}`.trim();
    };
    var testSet = (set, version, options) => {
      for (let i = 0; i < set.length; i++) {
        if (!set[i].test(version)) {
          return false;
        }
      }
      if (version.prerelease.length && !options.includePrerelease) {
        for (let i = 0; i < set.length; i++) {
          debug(set[i].semver);
          if (set[i].semver === Comparator.ANY) {
            continue;
          }
          if (set[i].semver.prerelease.length > 0) {
            const allowed = set[i].semver;
            if (allowed.major === version.major && allowed.minor === version.minor && allowed.patch === version.patch) {
              return true;
            }
          }
        }
        return false;
      }
      return true;
    };
  }
});

// ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/classes/comparator.js
var require_comparator = __commonJS({
  "../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/classes/comparator.js"(exports2, module2) {
    "use strict";
    var ANY = Symbol("SemVer ANY");
    var Comparator = class _Comparator {
      static get ANY() {
        return ANY;
      }
      constructor(comp, options) {
        options = parseOptions(options);
        if (comp instanceof _Comparator) {
          if (comp.loose === !!options.loose) {
            return comp;
          } else {
            comp = comp.value;
          }
        }
        comp = comp.trim().split(/\s+/).join(" ");
        debug("comparator", comp, options);
        this.options = options;
        this.loose = !!options.loose;
        this.parse(comp);
        if (this.semver === ANY) {
          this.value = "";
        } else {
          this.value = this.operator + this.semver.version;
        }
        debug("comp", this);
      }
      parse(comp) {
        const r = this.options.loose ? re[t.COMPARATORLOOSE] : re[t.COMPARATOR];
        const m = comp.match(r);
        if (!m) {
          throw new TypeError(`Invalid comparator: ${comp}`);
        }
        this.operator = m[1] !== void 0 ? m[1] : "";
        if (this.operator === "=") {
          this.operator = "";
        }
        if (!m[2]) {
          this.semver = ANY;
        } else {
          this.semver = new SemVer(m[2], this.options.loose);
        }
      }
      toString() {
        return this.value;
      }
      test(version) {
        debug("Comparator.test", version, this.options.loose);
        if (this.semver === ANY || version === ANY) {
          return true;
        }
        if (typeof version === "string") {
          try {
            version = new SemVer(version, this.options);
          } catch (er) {
            return false;
          }
        }
        return cmp(version, this.operator, this.semver, this.options);
      }
      intersects(comp, options) {
        if (!(comp instanceof _Comparator)) {
          throw new TypeError("a Comparator is required");
        }
        if (this.operator === "") {
          if (this.value === "") {
            return true;
          }
          return new Range(comp.value, options).test(this.value);
        } else if (comp.operator === "") {
          if (comp.value === "") {
            return true;
          }
          return new Range(this.value, options).test(comp.semver);
        }
        options = parseOptions(options);
        if (options.includePrerelease && (this.value === "<0.0.0-0" || comp.value === "<0.0.0-0")) {
          return false;
        }
        if (!options.includePrerelease && (this.value.startsWith("<0.0.0") || comp.value.startsWith("<0.0.0"))) {
          return false;
        }
        if (this.operator.startsWith(">") && comp.operator.startsWith(">")) {
          return true;
        }
        if (this.operator.startsWith("<") && comp.operator.startsWith("<")) {
          return true;
        }
        if (this.semver.version === comp.semver.version && this.operator.includes("=") && comp.operator.includes("=")) {
          return true;
        }
        if (cmp(this.semver, "<", comp.semver, options) && this.operator.startsWith(">") && comp.operator.startsWith("<")) {
          return true;
        }
        if (cmp(this.semver, ">", comp.semver, options) && this.operator.startsWith("<") && comp.operator.startsWith(">")) {
          return true;
        }
        return false;
      }
    };
    module2.exports = Comparator;
    var parseOptions = require_parse_options();
    var { safeRe: re, t } = require_re();
    var cmp = require_cmp();
    var debug = require_debug();
    var SemVer = require_semver();
    var Range = require_range();
  }
});

// ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/satisfies.js
var require_satisfies = __commonJS({
  "../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/satisfies.js"(exports2, module2) {
    "use strict";
    var Range = require_range();
    var satisfies = (version, range, options) => {
      try {
        range = new Range(range, options);
      } catch (er) {
        return false;
      }
      return range.test(version);
    };
    module2.exports = satisfies;
  }
});

// ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/ranges/to-comparators.js
var require_to_comparators = __commonJS({
  "../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/ranges/to-comparators.js"(exports2, module2) {
    "use strict";
    var Range = require_range();
    var toComparators = (range, options) => new Range(range, options).set.map((comp) => comp.map((c) => c.value).join(" ").trim().split(" "));
    module2.exports = toComparators;
  }
});

// ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/ranges/max-satisfying.js
var require_max_satisfying = __commonJS({
  "../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/ranges/max-satisfying.js"(exports2, module2) {
    "use strict";
    var SemVer = require_semver();
    var Range = require_range();
    var maxSatisfying = (versions, range, options) => {
      let max = null;
      let maxSV = null;
      let rangeObj = null;
      try {
        rangeObj = new Range(range, options);
      } catch (er) {
        return null;
      }
      versions.forEach((v) => {
        if (rangeObj.test(v)) {
          if (!max || maxSV.compare(v) === -1) {
            max = v;
            maxSV = new SemVer(max, options);
          }
        }
      });
      return max;
    };
    module2.exports = maxSatisfying;
  }
});

// ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/ranges/min-satisfying.js
var require_min_satisfying = __commonJS({
  "../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/ranges/min-satisfying.js"(exports2, module2) {
    "use strict";
    var SemVer = require_semver();
    var Range = require_range();
    var minSatisfying = (versions, range, options) => {
      let min = null;
      let minSV = null;
      let rangeObj = null;
      try {
        rangeObj = new Range(range, options);
      } catch (er) {
        return null;
      }
      versions.forEach((v) => {
        if (rangeObj.test(v)) {
          if (!min || minSV.compare(v) === 1) {
            min = v;
            minSV = new SemVer(min, options);
          }
        }
      });
      return min;
    };
    module2.exports = minSatisfying;
  }
});

// ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/ranges/min-version.js
var require_min_version = __commonJS({
  "../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/ranges/min-version.js"(exports2, module2) {
    "use strict";
    var SemVer = require_semver();
    var Range = require_range();
    var gt = require_gt();
    var minVersion = (range, loose) => {
      range = new Range(range, loose);
      let minver = new SemVer("0.0.0");
      if (range.test(minver)) {
        return minver;
      }
      minver = new SemVer("0.0.0-0");
      if (range.test(minver)) {
        return minver;
      }
      minver = null;
      for (let i = 0; i < range.set.length; ++i) {
        const comparators = range.set[i];
        let setMin = null;
        comparators.forEach((comparator) => {
          const compver = new SemVer(comparator.semver.version);
          switch (comparator.operator) {
            case ">":
              if (compver.prerelease.length === 0) {
                compver.patch++;
              } else {
                compver.prerelease.push(0);
              }
              compver.raw = compver.format();
            case "":
            case ">=":
              if (!setMin || gt(compver, setMin)) {
                setMin = compver;
              }
              break;
            case "<":
            case "<=":
              break;
            default:
              throw new Error(`Unexpected operation: ${comparator.operator}`);
          }
        });
        if (setMin && (!minver || gt(minver, setMin))) {
          minver = setMin;
        }
      }
      if (minver && range.test(minver)) {
        return minver;
      }
      return null;
    };
    module2.exports = minVersion;
  }
});

// ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/ranges/valid.js
var require_valid2 = __commonJS({
  "../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/ranges/valid.js"(exports2, module2) {
    "use strict";
    var Range = require_range();
    var validRange = (range, options) => {
      try {
        return new Range(range, options).range || "*";
      } catch (er) {
        return null;
      }
    };
    module2.exports = validRange;
  }
});

// ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/ranges/outside.js
var require_outside = __commonJS({
  "../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/ranges/outside.js"(exports2, module2) {
    "use strict";
    var SemVer = require_semver();
    var Comparator = require_comparator();
    var { ANY } = Comparator;
    var Range = require_range();
    var satisfies = require_satisfies();
    var gt = require_gt();
    var lt = require_lt();
    var lte = require_lte();
    var gte = require_gte();
    var outside = (version, range, hilo, options) => {
      version = new SemVer(version, options);
      range = new Range(range, options);
      let gtfn, ltefn, ltfn, comp, ecomp;
      switch (hilo) {
        case ">":
          gtfn = gt;
          ltefn = lte;
          ltfn = lt;
          comp = ">";
          ecomp = ">=";
          break;
        case "<":
          gtfn = lt;
          ltefn = gte;
          ltfn = gt;
          comp = "<";
          ecomp = "<=";
          break;
        default:
          throw new TypeError('Must provide a hilo val of "<" or ">"');
      }
      if (satisfies(version, range, options)) {
        return false;
      }
      for (let i = 0; i < range.set.length; ++i) {
        const comparators = range.set[i];
        let high = null;
        let low = null;
        comparators.forEach((comparator) => {
          if (comparator.semver === ANY) {
            comparator = new Comparator(">=0.0.0");
          }
          high = high || comparator;
          low = low || comparator;
          if (gtfn(comparator.semver, high.semver, options)) {
            high = comparator;
          } else if (ltfn(comparator.semver, low.semver, options)) {
            low = comparator;
          }
        });
        if (high.operator === comp || high.operator === ecomp) {
          return false;
        }
        if ((!low.operator || low.operator === comp) && ltefn(version, low.semver)) {
          return false;
        } else if (low.operator === ecomp && ltfn(version, low.semver)) {
          return false;
        }
      }
      return true;
    };
    module2.exports = outside;
  }
});

// ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/ranges/gtr.js
var require_gtr = __commonJS({
  "../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/ranges/gtr.js"(exports2, module2) {
    "use strict";
    var outside = require_outside();
    var gtr = (version, range, options) => outside(version, range, ">", options);
    module2.exports = gtr;
  }
});

// ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/ranges/ltr.js
var require_ltr = __commonJS({
  "../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/ranges/ltr.js"(exports2, module2) {
    "use strict";
    var outside = require_outside();
    var ltr = (version, range, options) => outside(version, range, "<", options);
    module2.exports = ltr;
  }
});

// ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/ranges/intersects.js
var require_intersects = __commonJS({
  "../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/ranges/intersects.js"(exports2, module2) {
    "use strict";
    var Range = require_range();
    var intersects = (r1, r2, options) => {
      r1 = new Range(r1, options);
      r2 = new Range(r2, options);
      return r1.intersects(r2, options);
    };
    module2.exports = intersects;
  }
});

// ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/ranges/simplify.js
var require_simplify = __commonJS({
  "../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/ranges/simplify.js"(exports2, module2) {
    "use strict";
    var satisfies = require_satisfies();
    var compare = require_compare();
    module2.exports = (versions, range, options) => {
      const set = [];
      let first = null;
      let prev = null;
      const v = versions.sort((a, b) => compare(a, b, options));
      for (const version of v) {
        const included = satisfies(version, range, options);
        if (included) {
          prev = version;
          if (!first) {
            first = version;
          }
        } else {
          if (prev) {
            set.push([first, prev]);
          }
          prev = null;
          first = null;
        }
      }
      if (first) {
        set.push([first, null]);
      }
      const ranges = [];
      for (const [min, max] of set) {
        if (min === max) {
          ranges.push(min);
        } else if (!max && min === v[0]) {
          ranges.push("*");
        } else if (!max) {
          ranges.push(`>=${min}`);
        } else if (min === v[0]) {
          ranges.push(`<=${max}`);
        } else {
          ranges.push(`${min} - ${max}`);
        }
      }
      const simplified = ranges.join(" || ");
      const original = typeof range.raw === "string" ? range.raw : String(range);
      return simplified.length < original.length ? simplified : range;
    };
  }
});

// ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/ranges/subset.js
var require_subset = __commonJS({
  "../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/ranges/subset.js"(exports2, module2) {
    "use strict";
    var Range = require_range();
    var Comparator = require_comparator();
    var { ANY } = Comparator;
    var satisfies = require_satisfies();
    var compare = require_compare();
    var subset = (sub, dom, options = {}) => {
      if (sub === dom) {
        return true;
      }
      sub = new Range(sub, options);
      dom = new Range(dom, options);
      let sawNonNull = false;
      OUTER:
        for (const simpleSub of sub.set) {
          for (const simpleDom of dom.set) {
            const isSub = simpleSubset(simpleSub, simpleDom, options);
            sawNonNull = sawNonNull || isSub !== null;
            if (isSub) {
              continue OUTER;
            }
          }
          if (sawNonNull) {
            return false;
          }
        }
      return true;
    };
    var minimumVersionWithPreRelease = [new Comparator(">=0.0.0-0")];
    var minimumVersion = [new Comparator(">=0.0.0")];
    var simpleSubset = (sub, dom, options) => {
      if (sub === dom) {
        return true;
      }
      if (sub.length === 1 && sub[0].semver === ANY) {
        if (dom.length === 1 && dom[0].semver === ANY) {
          return true;
        } else if (options.includePrerelease) {
          sub = minimumVersionWithPreRelease;
        } else {
          sub = minimumVersion;
        }
      }
      if (dom.length === 1 && dom[0].semver === ANY) {
        if (options.includePrerelease) {
          return true;
        } else {
          dom = minimumVersion;
        }
      }
      const eqSet = /* @__PURE__ */ new Set();
      let gt, lt;
      for (const c of sub) {
        if (c.operator === ">" || c.operator === ">=") {
          gt = higherGT(gt, c, options);
        } else if (c.operator === "<" || c.operator === "<=") {
          lt = lowerLT(lt, c, options);
        } else {
          eqSet.add(c.semver);
        }
      }
      if (eqSet.size > 1) {
        return null;
      }
      let gtltComp;
      if (gt && lt) {
        gtltComp = compare(gt.semver, lt.semver, options);
        if (gtltComp > 0) {
          return null;
        } else if (gtltComp === 0 && (gt.operator !== ">=" || lt.operator !== "<=")) {
          return null;
        }
      }
      for (const eq of eqSet) {
        if (gt && !satisfies(eq, String(gt), options)) {
          return null;
        }
        if (lt && !satisfies(eq, String(lt), options)) {
          return null;
        }
        for (const c of dom) {
          if (!satisfies(eq, String(c), options)) {
            return false;
          }
        }
        return true;
      }
      let higher, lower;
      let hasDomLT, hasDomGT;
      let needDomLTPre = lt && !options.includePrerelease && lt.semver.prerelease.length ? lt.semver : false;
      let needDomGTPre = gt && !options.includePrerelease && gt.semver.prerelease.length ? gt.semver : false;
      if (needDomLTPre && needDomLTPre.prerelease.length === 1 && lt.operator === "<" && needDomLTPre.prerelease[0] === 0) {
        needDomLTPre = false;
      }
      for (const c of dom) {
        hasDomGT = hasDomGT || c.operator === ">" || c.operator === ">=";
        hasDomLT = hasDomLT || c.operator === "<" || c.operator === "<=";
        if (gt) {
          if (needDomGTPre) {
            if (c.semver.prerelease && c.semver.prerelease.length && c.semver.major === needDomGTPre.major && c.semver.minor === needDomGTPre.minor && c.semver.patch === needDomGTPre.patch) {
              needDomGTPre = false;
            }
          }
          if (c.operator === ">" || c.operator === ">=") {
            higher = higherGT(gt, c, options);
            if (higher === c && higher !== gt) {
              return false;
            }
          } else if (gt.operator === ">=" && !c.test(gt.semver)) {
            return false;
          }
        }
        if (lt) {
          if (needDomLTPre) {
            if (c.semver.prerelease && c.semver.prerelease.length && c.semver.major === needDomLTPre.major && c.semver.minor === needDomLTPre.minor && c.semver.patch === needDomLTPre.patch) {
              needDomLTPre = false;
            }
          }
          if (c.operator === "<" || c.operator === "<=") {
            lower = lowerLT(lt, c, options);
            if (lower === c && lower !== lt) {
              return false;
            }
          } else if (lt.operator === "<=" && !c.test(lt.semver)) {
            return false;
          }
        }
        if (!c.operator && (lt || gt) && gtltComp !== 0) {
          return false;
        }
      }
      if (gt && hasDomLT && !lt && gtltComp !== 0) {
        return false;
      }
      if (lt && hasDomGT && !gt && gtltComp !== 0) {
        return false;
      }
      if (needDomGTPre || needDomLTPre) {
        return false;
      }
      return true;
    };
    var higherGT = (a, b, options) => {
      if (!a) {
        return b;
      }
      const comp = compare(a.semver, b.semver, options);
      return comp > 0 ? a : comp < 0 ? b : b.operator === ">" && a.operator === ">=" ? b : a;
    };
    var lowerLT = (a, b, options) => {
      if (!a) {
        return b;
      }
      const comp = compare(a.semver, b.semver, options);
      return comp < 0 ? a : comp > 0 ? b : b.operator === "<" && a.operator === "<=" ? b : a;
    };
    module2.exports = subset;
  }
});

// ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/index.js
var require_semver2 = __commonJS({
  "../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/index.js"(exports2, module2) {
    "use strict";
    var internalRe = require_re();
    var constants = require_constants();
    var SemVer = require_semver();
    var identifiers = require_identifiers();
    var parse = require_parse();
    var valid = require_valid();
    var clean = require_clean();
    var inc = require_inc();
    var diff = require_diff();
    var major = require_major();
    var minor = require_minor();
    var patch = require_patch();
    var prerelease = require_prerelease();
    var compare = require_compare();
    var rcompare = require_rcompare();
    var compareLoose = require_compare_loose();
    var compareBuild = require_compare_build();
    var sort = require_sort();
    var rsort = require_rsort();
    var gt = require_gt();
    var lt = require_lt();
    var eq = require_eq();
    var neq = require_neq();
    var gte = require_gte();
    var lte = require_lte();
    var cmp = require_cmp();
    var coerce = require_coerce();
    var truncate = require_truncate();
    var Comparator = require_comparator();
    var Range = require_range();
    var satisfies = require_satisfies();
    var toComparators = require_to_comparators();
    var maxSatisfying = require_max_satisfying();
    var minSatisfying = require_min_satisfying();
    var minVersion = require_min_version();
    var validRange = require_valid2();
    var outside = require_outside();
    var gtr = require_gtr();
    var ltr = require_ltr();
    var intersects = require_intersects();
    var simplifyRange = require_simplify();
    var subset = require_subset();
    module2.exports = {
      parse,
      valid,
      clean,
      inc,
      diff,
      major,
      minor,
      patch,
      prerelease,
      compare,
      rcompare,
      compareLoose,
      compareBuild,
      sort,
      rsort,
      gt,
      lt,
      eq,
      neq,
      gte,
      lte,
      cmp,
      coerce,
      truncate,
      Comparator,
      Range,
      satisfies,
      toComparators,
      maxSatisfying,
      minSatisfying,
      minVersion,
      validRange,
      outside,
      gtr,
      ltr,
      intersects,
      simplifyRange,
      subset,
      SemVer,
      re: internalRe.re,
      src: internalRe.src,
      tokens: internalRe.t,
      SEMVER_SPEC_VERSION: constants.SEMVER_SPEC_VERSION,
      RELEASE_TYPES: constants.RELEASE_TYPES,
      compareIdentifiers: identifiers.compareIdentifiers,
      rcompareIdentifiers: identifiers.rcompareIdentifiers
    };
  }
});

// ../workbuddy-core/src/infra/bus/bus.ts
var WBBus = class {
  handlers = /* @__PURE__ */ new Map();
  wildcardHandlers = /* @__PURE__ */ new Set();
  /** 订阅事件，返回取消函数 */
  on(event, handler) {
    let set = this.handlers.get(event);
    if (!set) {
      set = /* @__PURE__ */ new Set();
      this.handlers.set(event, set);
    }
    set.add(handler);
    return () => {
      set.delete(handler);
      if (set.size === 0) {
        this.handlers.delete(event);
      }
    };
  }
  /** 取消订阅（需传入与 on 相同的 handler 引用） */
  off(event, handler) {
    const set = this.handlers.get(event);
    if (!set) {
      return;
    }
    set.delete(handler);
    if (set.size === 0) {
      this.handlers.delete(event);
    }
  }
  /** 派发事件。单个 handler 抛错不影响其他订阅者。 */
  emit(event, payload) {
    const set = this.handlers.get(event);
    if (set && set.size > 0) {
      for (const handler of [...set]) {
        try {
          handler(payload);
        } catch {
        }
      }
    }
    if (this.wildcardHandlers.size > 0) {
      for (const wh of [...this.wildcardHandlers]) {
        try {
          wh(event, payload);
        } catch {
        }
      }
    }
  }
  /**
   * 全量监听所有事件（通配符订阅）。
   * 典型用途：IPC 转发器 —— 主进程 bus 上挂一个 onAny，把所有事件推到 renderer。
   */
  onAny(handler) {
    this.wildcardHandlers.add(handler);
    return () => {
      this.wildcardHandlers.delete(handler);
    };
  }
  /** 清空某事件的全部订阅，不传 event 则清空所有（含 wildcard） */
  clear(event) {
    if (event === void 0) {
      this.handlers.clear();
      this.wildcardHandlers.clear();
    } else {
      this.handlers.delete(event);
    }
  }
};
var instance = null;
function getBus() {
  if (!instance) {
    instance = new WBBus();
  }
  return instance;
}

// ../workbuddy-core/src/wb/boundary/error-envelope.ts
var AXIOS_BODY_MAX_BYTES = 4 * 1024;
function serializeBridgeError(error) {
  const err = error;
  let axiosEnvelope;
  if (err?.response || err?.config || err?.isAxiosError) {
    axiosEnvelope = {};
    if (err.response) {
      axiosEnvelope.response = {
        ...err.response.status !== void 0 ? { status: err.response.status } : {},
        ...err.response.statusText ? { statusText: err.response.statusText } : {},
        ...err.response.data !== void 0 ? { data: clampAxiosBody(err.response.data) } : {}
      };
    }
    if (err.config) {
      axiosEnvelope.config = {
        ...err.config.url ? { url: err.config.url } : {},
        ...err.config.method ? { method: err.config.method } : {}
      };
    }
    if (err.code) {
      axiosEnvelope.code = err.code;
    }
  }
  return {
    __wbError: true,
    message: err?.message ?? String(error),
    ...err?.code ? { code: err.code } : {},
    ...err?.bizCode !== void 0 ? { bizCode: err.bizCode } : {},
    ...err?.source ? { source: err.source } : {},
    ...err?.httpStatus !== void 0 ? { httpStatus: err.httpStatus } : {},
    // axios response.status 也顺手挂到顶层 httpStatus（如果业务没显式设 httpStatus 的话）
    // —— 方便按 `err.httpStatus` 直接判定，无需深入 err.response
    ...err?.httpStatus === void 0 && err?.response?.status !== void 0 ? { httpStatus: err.response.status } : {},
    ...err?.data !== void 0 ? { data: err.data } : {},
    ...axiosEnvelope ? { axios: axiosEnvelope } : {}
  };
}
function clampAxiosBody(body) {
  try {
    const s = typeof body === "string" ? body : JSON.stringify(body);
    if (typeof s !== "string") {
      return "(unserializable body)";
    }
    if (Buffer.byteLength(s, "utf-8") <= AXIOS_BODY_MAX_BYTES) {
      return typeof body === "string" ? s : body;
    }
    const truncated = s.slice(0, AXIOS_BODY_MAX_BYTES);
    return `${truncated}...(truncated ${s.length - AXIOS_BODY_MAX_BYTES} chars)`;
  } catch {
    return "(unserializable body)";
  }
}
function isSerializedBridgeError(value) {
  return value !== null && typeof value === "object" && value.__wbError === true;
}
function deserializeResult(result) {
  if (!isSerializedBridgeError(result)) {
    return result;
  }
  const { message, code, bizCode, source, httpStatus, data, axios } = result;
  const err = new Error(message);
  err.name = "WBError";
  if (code) {
    err.code = code;
  }
  if (bizCode !== void 0) {
    err.bizCode = bizCode;
  }
  if (source) {
    err.source = source;
  }
  if (httpStatus !== void 0) {
    err.httpStatus = httpStatus;
  }
  if (data !== void 0) {
    err.data = data;
  }
  if (axios) {
    if (axios.response) {
      err.response = { ...axios.response };
    }
    if (axios.config) {
      err.config = { ...axios.config };
    }
    if (axios.code && !err.code) {
      err.code = axios.code;
    }
    err.isAxiosError = true;
  }
  throw err;
}

// ../workbuddy-core/src/conversations/common/core/conversation-event-types.ts
var ConversationAutomationEvent = {
  Completed: "automationCompleted" /* AutomationCompleted */,
  Failed: "automationFailed" /* AutomationFailed */,
  Cancelled: "automationCancelled" /* AutomationCancelled */,
  TimedOut: "automationTimedOut" /* AutomationTimedOut */
};

// ../workbuddy-core/src/conversations/common/core/conversation-support-types.ts
var REQUEST_HISTORY_PAGE_BYTE_LENGTH = 5 * 1024 * 1024;

// ../workbuddy-core/src/conversations/common/buddy-snapshot.ts
var hashJs = __toESM(require_hash());
var BUDDY_APP_SNAPSHOT_MAX_JSON_LENGTH = 512 * 1024;
var BUDDY_SESSION_BINDING_MAX_JSON_LENGTH = 128 * 1024;

// ../workbuddy-core/src/conversations/common/event-names.ts
var WB_CONVERSATION_STATE_CHANGE = "wb:conversation:stateChange";
var WB_CONVERSATION_INFO_CHANGE = "wb:conversation:infoChange";
var WB_CONVERSATION_PERMISSION = "wb:conversation:permission";
var WB_CONVERSATION_PLUGIN_RECOMMENDATION_CHANGED = "wb:conversation:pluginRecommendationChanged";
var WB_CONVERSATION_CLOUD_SERVICE_CONFIRMATION_CHANGED = "wb:conversation:cloudServiceConfirmationChanged";
var WB_CONVERSATION_WARNING = "wb:conversation:warning";
var WB_CONVERSATION_PREPARE_STATUS = "wb:conversation:prepareStatus";
var WB_CONVERSATION_MCP_STARTUP_STATUS = "wb:conversation:mcpStartupStatus";
var WB_CONVERSATION_HISTORY_LOADED = "wb:conversation:historyLoaded";
var WB_CONVERSATION_CREDIT_CHANGED = "wb:conversation:creditChanged";
var WB_CONVERSATION_CONTEXT_USAGE_CHANGED = "wb:conversation:contextUsageChanged";
var WB_CONVERSATION_ESTIMATED_COST_CHANGED = "wb:conversation:estimatedCostChanged";
var WB_CONVERSATION_QUEUE_UPDATE = "wb:conversation:queueUpdate";
var WB_CONVERSATION_CAPACITY_QUEUE_UPDATE = "wb:conversation:capacityQueueUpdate";
var WB_CONVERSATION_ARTIFACT_UPDATE = "wb:conversation:artifactUpdate";
var WB_CONVERSATION_COMMANDS_UPDATE = "wb:conversation:commandsUpdate";
var WB_CONVERSATION_MODE_CHANGE = "wb:conversation:modeChange";
var WB_CONVERSATION_CONFIG_UPDATE = "wb:conversation:configUpdate";
var WB_CONVERSATION_MODEL_CHANGE = "wb:conversation:modelChange";
var WB_CONVERSATION_TIMELINE_EVENT = "wb:conversation:timelineEvent";
var WB_CONVERSATION_MODES_UPDATE = "wb:conversation:modesUpdate";
var WB_CONVERSATION_PLAN_UPDATE = "wb:conversation:planUpdate";
var WB_CONVERSATION_CHILD_AGENT_EVENT = "wb:conversation:childAgentEvent";

// ../workbuddy-core/src/conversations/common/core/model/conversation-prompt-operations.ts
var AUTOMATION_TERMINAL_EVENTS = new Set(Object.values(ConversationAutomationEvent));

// ../workbuddy-core/src/conversations/wb/wire-descriptor.ts
var METHOD_BINDS = [
  { key: "sendPrompt", mode: "async", bridgeAuto: true },
  { key: "runPrompt", mode: "async", bridgeAuto: true },
  { key: "clear", mode: "async", bridgeAuto: true },
  { key: "compact", mode: "async", bridgeAuto: true },
  { key: "requests", mode: "async", bridgeAuto: true },
  { key: "requestEntries", mode: "async", bridgeAuto: true },
  { key: "getBackgroundTerminals", mode: "async", bridgeAuto: true },
  { key: "userPrompts", mode: "async", bridgeAuto: true },
  { key: "inputHistory", mode: "async", bridgeAuto: true },
  { key: "updateEstimatedCost", mode: "async", bridgeAuto: true },
  { key: "loadToolDetail", mode: "async", bridgeAuto: true },
  { key: "artifacts", mode: "async", bridgeAuto: false },
  { key: "files", mode: "async", bridgeAuto: false },
  { key: "searchFiles", mode: "async", bridgeAuto: true },
  { key: "changes", mode: "async", bridgeAuto: false },
  { key: "changeManifests", mode: "async", bridgeAuto: false },
  { key: "changeDetail", mode: "async", bridgeAuto: false },
  { key: "cancel", mode: "async", bridgeAuto: true },
  { key: "cancelBackgroundTask", mode: "async", bridgeAuto: true },
  { key: "getCapacityQueueState", mode: "async", bridgeAuto: true },
  { key: "cancelCapacityQueue", mode: "async", bridgeAuto: true },
  { key: "resend", mode: "async", bridgeAuto: true },
  { key: "rewind", mode: "async", bridgeAuto: true },
  { key: "checkpointRead", mode: "async", bridgeAuto: true },
  { key: "getPendingInfo", mode: "async", bridgeAuto: true },
  { key: "getCloudServiceConfirmation", mode: "async", bridgeAuto: true },
  { key: "getPluginRecommendation", mode: "async", bridgeAuto: true },
  { key: "rename", mode: "async", bridgeAuto: true },
  { key: "preload", mode: "fireAndForget", onReject: "silent", bridgeAuto: false },
  { key: "ensureRuntime", mode: "fireAndForget", onReject: "silent", bridgeAuto: false },
  { key: "releaseRuntimeHold", mode: "fireAndForget", onReject: "silent", bridgeAuto: false },
  // async（非 fireAndForget）：UI 点击用量圆环后要用返回的 Promise 收 loading 态。
  { key: "refreshContextUsage", mode: "async", bridgeAuto: true },
  { key: "resolvePending", mode: "syncVoid", onReject: "warn", bridgeAuto: true },
  { key: "rejectPending", mode: "syncVoid", onReject: "warn", bridgeAuto: true },
  { key: "log", mode: "fireAndForget", onReject: "silent", bridgeAuto: true },
  { key: "markExcludeLaunchSpecServers", mode: "async", bridgeAuto: true }
];
var WIRE_ONLY_METHOD_KEYS = [
  "dispose",
  "queueItems",
  "queuePause",
  "queueResume",
  "queueDelete",
  "queueMove",
  "queueSendNow",
  "registerClientTools",
  "unregisterClientTools",
  "fileArtifacts",
  "fileFiles",
  "fileChanges",
  "childAgentSnapshots",
  "childAgentRequests",
  "childAgentLoadToolDetail",
  "configSetMode",
  "configSetModel",
  "configSetConnectors",
  "configSetPermissionMode",
  "configSetSandboxMode",
  "configSetThoughtLevel",
  "configSetPreMessageCompactPct",
  "configSetContextWindow",
  "configSetExpert",
  "configSetExpertId"
];
function eventBind(busEvent) {
  return { busEvent };
}
var INSTANCE_EVENT_BINDS = {
  ["stateChange" /* StateChange */]: {
    bind: eventBind(WB_CONVERSATION_STATE_CHANGE),
    map: (p) => p.promptResponseMeta ? [
      p.from,
      p.to,
      p.finalState,
      p.terminalError,
      p.interruption,
      p.promptResponseMeta
    ] : p.interruption ? [p.from, p.to, p.finalState, p.terminalError, p.interruption] : [p.from, p.to, p.finalState, p.terminalError]
  },
  ["infoChange" /* InfoChange */]: {
    bind: eventBind(WB_CONVERSATION_INFO_CHANGE),
    map: (p) => [p.info]
  },
  ["capacityQueueUpdate" /* CapacityQueueUpdate */]: {
    bind: eventBind(WB_CONVERSATION_CAPACITY_QUEUE_UPDATE),
    map: (p) => [p]
  },
  ["artifactUpdate" /* ArtifactUpdate */]: {
    bind: eventBind(WB_CONVERSATION_ARTIFACT_UPDATE),
    map: (_p) => []
  },
  ["warning" /* Warning */]: {
    bind: eventBind(WB_CONVERSATION_WARNING),
    map: (p) => [p.info]
  },
  ["prepareStatus" /* PrepareStatus */]: {
    bind: eventBind(WB_CONVERSATION_PREPARE_STATUS),
    map: (p) => [p.status]
  },
  ["mcpStartupStatus" /* McpStartupStatus */]: {
    bind: eventBind(WB_CONVERSATION_MCP_STARTUP_STATUS),
    map: (p) => [p.status]
  },
  ["pendingRequest" /* PendingRequest */]: {
    bind: eventBind(WB_CONVERSATION_PERMISSION),
    map: (p) => [p.permission]
  },
  ["pluginRecommendationChanged" /* PluginRecommendationChanged */]: {
    bind: eventBind(
      WB_CONVERSATION_PLUGIN_RECOMMENDATION_CHANGED
    ),
    map: (p) => [p.recommendation]
  },
  ["cloudServiceConfirmationChanged" /* CloudServiceConfirmationChanged */]: {
    bind: eventBind(
      WB_CONVERSATION_CLOUD_SERVICE_CONFIRMATION_CHANGED
    ),
    map: (p) => [p.confirmation]
  },
  ["historyLoaded" /* HistoryLoaded */]: {
    bind: eventBind(WB_CONVERSATION_HISTORY_LOADED),
    map: (_p) => []
  },
  ["creditChanged" /* CreditChanged */]: {
    bind: eventBind(WB_CONVERSATION_CREDIT_CHANGED),
    map: (p) => [{ requestId: p.requestId, cost: p.cost }]
  },
  ["contextUsageChanged" /* ContextUsageChanged */]: {
    bind: eventBind(WB_CONVERSATION_CONTEXT_USAGE_CHANGED),
    map: (p) => [{
      totalTokens: p.totalTokens,
      contextWindow: p.contextWindow,
      ...p.byCategory ? { byCategory: p.byCategory } : {}
    }]
  },
  ["estimatedCostChanged" /* EstimatedCostChanged */]: {
    bind: eventBind(WB_CONVERSATION_ESTIMATED_COST_CHANGED),
    map: (p) => [{ requestId: p.requestId, estimatedCost: p.estimatedCost }]
  },
  ["commandsUpdate" /* CommandsUpdate */]: {
    bind: eventBind(WB_CONVERSATION_COMMANDS_UPDATE),
    map: (p) => [p]
  },
  ["modeChange" /* ModeChange */]: {
    bind: eventBind(WB_CONVERSATION_MODE_CHANGE),
    map: (p) => [p]
  },
  ["configUpdate" /* ConfigUpdate */]: {
    bind: eventBind(WB_CONVERSATION_CONFIG_UPDATE),
    map: (p) => [p]
  },
  ["modelChange" /* ModelChange */]: {
    bind: eventBind(WB_CONVERSATION_MODEL_CHANGE),
    map: (p) => [p]
  },
  ["timelineEvent" /* TimelineEvent */]: {
    bind: eventBind(WB_CONVERSATION_TIMELINE_EVENT),
    map: (p) => [p]
  },
  ["modesUpdate" /* ModesUpdate */]: {
    bind: eventBind(WB_CONVERSATION_MODES_UPDATE),
    map: (p) => [p]
  },
  ["planUpdate" /* PlanUpdate */]: {
    bind: eventBind(WB_CONVERSATION_PLAN_UPDATE),
    map: (p) => [p]
  }
};
var INSTANCE_SPECIAL_EVENTS = [
  "requestUpdate" /* RequestUpdate */,
  "queueUpdate" /* QueueUpdate */,
  "requestsChanged" /* RequestsChanged */,
  "extensionMethod" /* ExtensionMethod */,
  // 由 attachConversationPromptOperations 基于 RequestsChanged 在各进程本地派生，
  // 不增加重复的 wire bus。
  "automationCompleted" /* AutomationCompleted */,
  "automationFailed" /* AutomationFailed */,
  "automationCancelled" /* AutomationCancelled */,
  "automationTimedOut" /* AutomationTimedOut */
];
var COLLECTION_EVENT_BINDS = {
  ["agentTeamChanged" /* AgentTeamChanged */]: {
    bind: eventBind(WB_CONVERSATION_CHILD_AGENT_EVENT),
    map: (p) => [p.conversationId, p.event]
  },
  ["stateChanged" /* StateChanged */]: {
    bind: eventBind(WB_CONVERSATION_STATE_CHANGE),
    map: (p) => [p.conversationId, p.from, p.to]
  },
  ["infoChanged" /* InfoChanged */]: {
    bind: eventBind(WB_CONVERSATION_INFO_CHANGE),
    map: (p) => [p.conversationId, p.info]
  },
  ["queueUpdated" /* QueueUpdated */]: {
    bind: eventBind(WB_CONVERSATION_QUEUE_UPDATE),
    map: (p) => [p.conversationId]
  },
  ["artifactUpdated" /* ArtifactUpdated */]: {
    bind: eventBind(WB_CONVERSATION_ARTIFACT_UPDATE),
    map: (p) => [p.conversationId]
  },
  ["warning" /* Warning */]: {
    bind: eventBind(WB_CONVERSATION_WARNING),
    map: (p) => [p.conversationId, p.info]
  }
};
var COLLECTION_SPECIAL_EVENTS = [
  "listChange" /* ListChange */,
  "requestUpdated" /* RequestUpdated */
];

// ../workbuddy-core/src/conversations/wb/service.ts
var BRIDGE_FORWARD_KEYS = [
  ...METHOD_BINDS.map((bind) => bind.key).filter((key) => key !== "rename"),
  ...WIRE_ONLY_METHOD_KEYS
];

// ../workbuddy-core/src/wb/boundary/transport/protocol.ts
var WB_BRIDGE_SUBSCRIBE_EVENT_CHANNEL = "wb:$bridge:subscribeEvent";
var WB_BRIDGE_UNSUBSCRIBE_EVENT_CHANNEL = "wb:$bridge:unsubscribeEvent";

// ../workbuddy-core/src/wb/guest/proxy.ts
var DEFAULT_LIST_THROTTLE_MS = 300;
function readListThrottleMs() {
  if (typeof process === "undefined") {
    return DEFAULT_LIST_THROTTLE_MS;
  }
  const raw = process.env?.WB_GUEST_LIST_THROTTLE_MS;
  if (raw === void 0) {
    return DEFAULT_LIST_THROTTLE_MS;
  }
  const parsed = Number(raw);
  if (!Number.isFinite(parsed) || parsed < 0) {
    return DEFAULT_LIST_THROTTLE_MS;
  }
  return Math.floor(parsed);
}
var LIST_THROTTLE_MS = readListThrottleMs();
function serializeListArgs(args) {
  try {
    return JSON.stringify(args);
  } catch {
    return void 0;
  }
}
function resolveInvokeContext(options) {
  const subject = options?.subject ?? (options?.callerId ? { moduleId: options.callerId, type: "module", scopes: [] } : void 0);
  if (!subject) {
    return void 0;
  }
  return { callerId: subject.moduleId, subject };
}
function createGuestProxy(namespace, invoke, options) {
  return _proxy(namespace, invoke, resolveInvokeContext(options), options?.cacheListResults !== false);
}
function createGuestWb(invoke, options) {
  const bus = getBus();
  let subscribeAttached = false;
  const signal = options?.signal;
  const localReleases = /* @__PURE__ */ new Set();
  function ensureSubscribed() {
    if (signal?.aborted || subscribeAttached || !options?.subscribe) {
      return;
    }
    subscribeAttached = true;
    options.subscribe((event, payload) => {
      if (!signal?.aborted) {
        bus.emit(event, payload);
      }
    });
  }
  const invokeContext = resolveInvokeContext(options);
  const eventHandlers = /* @__PURE__ */ new Map();
  const off = (event, handler) => {
    bus.off(event, handler);
    const handlers = eventHandlers.get(event);
    if (!handlers?.delete(handler) || handlers.size > 0) {
      return;
    }
    eventHandlers.delete(event);
    invoke(WB_BRIDGE_UNSUBSCRIBE_EVENT_CHANNEL, invokeContext, event).catch(() => void 0);
  };
  const on = (event, handler) => {
    ensureSubscribed();
    if (signal?.aborted) {
      return () => void 0;
    }
    if (!options?.subscribe) {
      return trackRelease(bus.on(event, handler));
    }
    bus.on(event, handler);
    let handlers = eventHandlers.get(event);
    if (!handlers) {
      handlers = /* @__PURE__ */ new Set();
      eventHandlers.set(event, handlers);
      invoke(WB_BRIDGE_SUBSCRIBE_EVENT_CHANNEL, invokeContext, event).catch(() => void 0);
    }
    handlers.add(handler);
    return () => off(event, handler);
  };
  function trackRelease(release) {
    const tracked = () => {
      if (!localReleases.delete(tracked)) {
        return;
      }
      release();
    };
    localReleases.add(tracked);
    return tracked;
  }
  signal?.addEventListener("abort", () => {
    for (const [event, handlers] of eventHandlers) {
      for (const handler of handlers) {
        off(event, handler);
      }
    }
    for (const release of localReleases) {
      release();
    }
  }, { once: true });
  return new Proxy({}, {
    get(_target, prop) {
      if (typeof prop !== "string") {
        return void 0;
      }
      if (prop === "then" || prop === "toJSON") {
        return void 0;
      }
      if (prop === "on") {
        return on;
      }
      if (prop === "off") {
        return off;
      }
      if (prop === "onAny") {
        ensureSubscribed();
        return (handler) => signal?.aborted ? () => void 0 : trackRelease(bus.onAny(handler));
      }
      if (prop === "invoke") {
        return (channel, ...args) => invoke(channel, invokeContext, ...args);
      }
      if (options?.namespaces && Object.prototype.hasOwnProperty.call(options.namespaces, prop)) {
        return options.namespaces[prop];
      }
      return createGuestProxy(prop, invoke, options);
    }
  });
}
function _proxy(path, invoke, context, cacheListResults) {
  const children = /* @__PURE__ */ new Map();
  const listCache = /* @__PURE__ */ new Map();
  const proxy = new Proxy(() => {
  }, {
    get(_target, prop) {
      if (prop === "then") {
        return void 0;
      }
      if (prop === "toJSON") {
        return void 0;
      }
      if (typeof prop !== "string") {
        return void 0;
      }
      if (prop === "bind") {
        return (_thisArg, ...boundArgs) => (...callArgs) => Reflect.apply(proxy, void 0, [...boundArgs, ...callArgs]);
      }
      if (prop === "call") {
        return (_thisArg, ...args) => Reflect.apply(proxy, void 0, args);
      }
      if (prop === "apply") {
        return (_thisArg, args) => Reflect.apply(proxy, void 0, args ?? []);
      }
      const cached = children.get(prop);
      if (cached !== void 0) {
        return cached;
      }
      const child = _proxy(`${path}.${prop}`, invoke, context, cacheListResults);
      children.set(prop, child);
      return child;
    },
    apply(_target, _thisArg, args) {
      const lastDot = path.lastIndexOf(".");
      const channel = `wb:${path.slice(0, lastDot)}:${path.slice(lastDot + 1)}`;
      const isListCall = cacheListResults && LIST_THROTTLE_MS > 0 && (path === "list" || path.endsWith(".list"));
      if (isListCall) {
        const key = serializeListArgs(args);
        if (key !== void 0) {
          const cached = listCache.get(key);
          if (cached) {
            const now = Date.now();
            if (cached.fulfilledAt === void 0) {
              console.log(`[wb-list-cache] HIT-INFLIGHT channel=${channel} keyLen=${key.length}`);
              return cached.promise;
            }
            if (now - cached.fulfilledAt < LIST_THROTTLE_MS) {
              console.log(`[wb-list-cache] HIT-FRESH channel=${channel} ageMs=${now - cached.fulfilledAt} keyLen=${key.length}`);
              return cached.promise;
            }
            listCache.delete(key);
          }
          console.log(`[wb-list-cache] MISS channel=${channel} keyLen=${key.length}`);
          const promise = invoke(channel, context, ...args).then(deserializeResult);
          const entry = { promise };
          listCache.set(key, entry);
          promise.then(
            () => {
              if (listCache.get(key) === entry) {
                entry.fulfilledAt = Date.now();
                const timer = setTimeout(() => {
                  if (listCache.get(key) === entry) {
                    listCache.delete(key);
                  }
                }, LIST_THROTTLE_MS);
                timer?.unref?.();
              }
            },
            () => {
              if (listCache.get(key) === entry) {
                listCache.delete(key);
              }
              console.log(`[wb-list-cache] REJECT channel=${channel} keyLen=${key.length}`);
            }
          );
          return promise;
        }
        console.log(`[wb-list-cache] SKIP-UNCACHEABLE channel=${channel} (args not JSON-serializable)`);
      }
      return invoke(channel, context, ...args).then(deserializeResult);
    }
  });
  return proxy;
}

// ../workbuddy-core/src/wb/core/namespace-manifest.ts
var BUILT_IN_NAMESPACES = ["telemetry", "http", "feedback"];
var CORE_NAMESPACES = [
  "storage",
  "config",
  "account",
  "openAuth",
  "skills",
  "experts",
  "automations",
  "workspaces",
  "models",
  "notifications",
  "ops",
  "connectors",
  "conversations",
  "artifacts",
  "search",
  "changes",
  "intentRecognition",
  "imChannels",
  "metrics",
  "netdrive",
  "inspirationCode",
  "cloud"
];
var DESKTOP_ONLY_NAMESPACES = [
  "paths",
  "shell",
  "mcp",
  "buddyApps"
];
var PLATFORM_MANIFEST = {
  /** Web 端必挂载的 namespace（跨平台核心） */
  web: CORE_NAMESPACES,
  /** Desktop 端必挂载的 namespace（跨平台核心 + Desktop 独有） */
  desktop: [...CORE_NAMESPACES, ...DESKTOP_ONLY_NAMESPACES]
};
var ALL_NAMESPACES = [...CORE_NAMESPACES, ...DESKTOP_ONLY_NAMESPACES, ...BUILT_IN_NAMESPACES];

// ../workbuddy-core/src/domains/skills/common/skill-cloud-sync-merge-engine.ts
var import_semver = __toESM(require_semver2());

// src/bridge/transport-process.ts
function transportClosed(error, delivery) {
  return Object.assign(new Error(error.message, { cause: error }), {
    code: "EXTENSION_TRANSPORT_CLOSED",
    data: { delivery }
  });
}
function createRpcSide(opts) {
  const { onMessage, label } = opts;
  const requestHandlers = /* @__PURE__ */ new Map();
  let anyHandler;
  let eventHandler;
  let requestCounter = 0;
  const pending = /* @__PURE__ */ new Map();
  let closed;
  let acceptingRequests = true;
  let detach = () => void 0;
  let detachClose = () => void 0;
  function close(error = new Error(`[${label}] disposed`)) {
    if (closed) {
      return;
    }
    closed = error;
    detach();
    detachClose();
    for (const request of pending.values()) {
      request.reject(transportClosed(error, request.delivery));
    }
    pending.clear();
    requestHandlers.clear();
    anyHandler = void 0;
    eventHandler = void 0;
  }
  function send(message) {
    if (closed) {
      return;
    }
    if (!opts.isConnected()) {
      failConnection(new Error(`[${label}] disconnected`));
      return;
    }
    try {
      const request = message.type === "invoke:request" && message.requestId ? pending.get(message.requestId) : void 0;
      if (request) {
        request.delivery = "unknown";
      }
      opts.send(message, (error) => {
        if (error) {
          failConnection(error);
        }
      });
    } catch (error) {
      try {
        JSON.stringify(message);
      } catch {
        throw new Error(`[${label}] IPC message is not JSON serializable`);
      }
      failConnection(error instanceof Error ? error : new Error(String(error)));
    }
  }
  function failConnection(error) {
    close(error);
    try {
      opts.disconnect();
    } catch {
    }
  }
  const listener = async (raw) => {
    if (closed) {
      return;
    }
    if (!isWireMessage(raw)) {
      return;
    }
    const msg = raw;
    if (msg.type === "invoke:request" && msg.channel && msg.requestId) {
      if (!acceptingRequests) {
        send({
          type: "invoke:response",
          requestId: msg.requestId,
          error: serializeBridgeError(new Error(`[${label}] shutting down`))
        });
        return;
      }
      const perChannelHandler = requestHandlers.get(msg.channel);
      if (!perChannelHandler && !anyHandler) {
        send({
          type: "invoke:response",
          requestId: msg.requestId,
          error: serializeBridgeError(new Error(
            `[${label}] no handler for channel: ${msg.channel}`
          ))
        });
        return;
      }
      try {
        const rawArgs = msg.args ?? [];
        const [context, ...userArgs] = rawArgs;
        const result = perChannelHandler ? await perChannelHandler(context, ...userArgs) : await anyHandler(msg.channel, context, ...userArgs);
        send({ type: "invoke:response", requestId: msg.requestId, result });
      } catch (err) {
        send({
          type: "invoke:response",
          requestId: msg.requestId,
          error: serializeBridgeError(err)
        });
      }
      return;
    }
    if (msg.type === "invoke:response" && msg.requestId) {
      const p = pending.get(msg.requestId);
      if (!p) {
        return;
      }
      pending.delete(msg.requestId);
      if (msg.error !== void 0) {
        try {
          if (isSerializedBridgeError(msg.error)) {
            deserializeResult(msg.error);
          } else {
            throw new Error(String(msg.error));
          }
        } catch (err) {
          p.reject(err);
        }
      } else {
        p.resolve(msg.result);
      }
      return;
    }
    if (msg.type === "event" && msg.event) {
      eventHandler?.(msg.event, msg.payload);
    }
  };
  detach = onMessage(listener);
  detachClose = opts.onClose((error) => close(error ?? new Error(`[${label}] disconnected`)));
  function invoke(channel, context, ...args) {
    if (closed) {
      return Promise.reject(transportClosed(closed, "not-sent"));
    }
    return new Promise((resolve, reject) => {
      const requestId = `${label}_req_${++requestCounter}`;
      pending.set(requestId, { resolve, reject, delivery: "not-sent" });
      try {
        send({
          type: "invoke:request",
          requestId,
          channel,
          args: [context, ...args]
        });
      } catch (err) {
        pending.delete(requestId);
        reject(err instanceof Error ? err : new Error(String(err)));
      }
    });
  }
  return {
    stopAcceptingRequests() {
      acceptingRequests = false;
    },
    handle(channel, handler) {
      requestHandlers.set(channel, handler);
    },
    /**
     * 挂通配 handler —— 供 bridge-host 做 catch-all 前缀路由（wb.invoke 逃生舱）。
     * per-channel 精确匹配优先，miss 才走通配。多次调用后一次覆盖前一次。
     */
    handleAny(handler) {
      anyHandler = handler;
    },
    broadcast(event, payload) {
      send({ type: "event", event, payload });
    },
    invoke,
    on(handler) {
      eventHandler = handler;
    },
    dispose: close
  };
}
function createProcessClientTransport() {
  return createRpcSide({
    label: "ProcessClientTransport",
    isConnected: () => !!process.connected && !!process.send,
    send: (msg, callback) => {
      process.send(msg, callback);
    },
    disconnect: () => {
      if (process.connected) {
        process.disconnect?.();
      }
    },
    onClose: (listener) => {
      process.on("disconnect", listener);
      return () => process.off("disconnect", listener);
    },
    onMessage: (listener) => {
      process.on("message", listener);
      return () => process.off("message", listener);
    }
  });
}
function isWireMessage(msg) {
  return msg !== null && typeof msg === "object" && "type" in msg && typeof msg.type === "string";
}

// src/runtime/core/process-env.ts
function createProcessEnv() {
  const transport = createProcessClientTransport();
  const shutdownHooks = [];
  let shutdownTriggered = false;
  const runShutdown = async () => {
    if (shutdownTriggered) {
      return;
    }
    shutdownTriggered = true;
    for (const fn of shutdownHooks) {
      try {
        await fn();
      } catch (err) {
        console.error("[ProcessEnv] shutdown hook error:", err);
      }
    }
  };
  const noop = () => {
  };
  process.on("SIGTERM", () => {
    runShutdown().then(noop, noop);
  });
  process.once("disconnect", () => {
    runShutdown().then(noop, noop);
  });
  const extensionId = process.env.WB_EXTENSION_ID ?? "<unknown>";
  let readySent = false;
  return {
    kind: "process",
    transport,
    onShutdown(fn) {
      shutdownHooks.push(fn);
    },
    signalReady() {
      if (readySent) {
        return;
      }
      readySent = true;
      if (typeof process.send === "function") {
        try {
          process.send({
            type: "wb-extension-ready",
            extensionId,
            pid: process.pid
          });
        } catch (err) {
          console.error(`[Extension:${extensionId}] send ready signal failed:`, err);
        }
      }
    },
    terminate() {
      process.exit(0);
    }
  };
}

// src/runtime/core/run-extension.ts
async function runExtension(opts) {
  const { extensionId, env, activate } = opts;
  const { transport } = env;
  const invokeFn = transport.invoke ?? (async () => {
    throw new Error(`[Extension:${extensionId}] transport.invoke not ready`);
  });
  const subscribeFn = transport.on ?? (() => {
  });
  const wb = createGuestWb(invokeFn, {
    subscribe: subscribeFn
  });
  let userDispose;
  let shutdownStarted = false;
  const doShutdown = async () => {
    if (shutdownStarted) {
      return;
    }
    shutdownStarted = true;
    try {
      await userDispose?.();
    } catch (err) {
      console.error(`[Extension:${extensionId}] dispose error:`, err);
    }
    try {
      transport.dispose?.();
    } catch (err) {
      console.error(`[Extension:${extensionId}] transport dispose error:`, err);
    }
    try {
      env.terminate();
    } catch (err) {
      console.error(`[Extension:${extensionId}] env.terminate error:`, err);
    }
  };
  env.onShutdown(doShutdown);
  try {
    const result = await activate(wb);
    if (result && typeof result === "object") {
      const { methods, dispose } = result;
      userDispose = dispose;
      if (methods) {
        for (const channel of Object.keys(methods)) {
          const fn = methods[channel];
          transport.handle(channel, async (...args) => fn(...args));
        }
        console.log(
          `[Extension:${extensionId}] registered methods: [${Object.keys(methods).join(", ")}]`
        );
      }
    }
  } catch (err) {
    console.error(`[Extension:${extensionId}] activate failed:`, err);
    try {
      env.terminate();
    } catch {
    }
    throw err;
  }
  try {
    env.signalReady();
  } catch (err) {
    console.error(`[Extension:${extensionId}] signalReady failed:`, err);
  }
  return {
    dispose: doShutdown
  };
}

// src/runtime/preload/fork-preload.ts
function resolveActivate(mod) {
  if (!mod || typeof mod !== "object") {
    return void 0;
  }
  const m = mod;
  if (typeof m.activate === "function") {
    return m.activate;
  }
  const def = m.default;
  if (def && typeof def === "object" && typeof def.activate === "function") {
    return def.activate;
  }
  if (typeof def === "function") {
    return def;
  }
  return void 0;
}
async function main() {
  const extensionId = process.env.WB_EXTENSION_ID ?? "<unknown>";
  const userEntry = process.argv[2];
  if (!userEntry) {
    console.error(`[fork-preload:${extensionId}] user entry path missing (argv[2])`);
    process.exit(1);
  }
  const userModule = require(userEntry);
  const activate = resolveActivate(userModule);
  if (!activate) {
    console.log(
      `[fork-preload:${extensionId}] no 'activate' export; assuming legacy bootstrap() side-effect`
    );
    return;
  }
  const env = createProcessEnv();
  await runExtension({ extensionId, env, activate });
}
main().catch((err) => {
  console.error(
    `[fork-preload:${process.env.WB_EXTENSION_ID ?? "<unknown>"}] fatal:`,
    err instanceof Error ? err.stack ?? err.message : err
  );
  process.exit(1);
});
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzLy5wbnBtL21pbmltYWxpc3RpYy1hc3NlcnRAMS4wLjEvbm9kZV9tb2R1bGVzL21pbmltYWxpc3RpYy1hc3NlcnQvaW5kZXguanMiLCAiLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzLy5wbnBtL2luaGVyaXRzQDIuMC40L25vZGVfbW9kdWxlcy9pbmhlcml0cy9pbmhlcml0c19icm93c2VyLmpzIiwgIi4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy8ucG5wbS9pbmhlcml0c0AyLjAuNC9ub2RlX21vZHVsZXMvaW5oZXJpdHMvaW5oZXJpdHMuanMiLCAiLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzLy5wbnBtL2hhc2guanNAMS4xLjcvbm9kZV9tb2R1bGVzL2hhc2guanMvbGliL2hhc2gvdXRpbHMuanMiLCAiLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzLy5wbnBtL2hhc2guanNAMS4xLjcvbm9kZV9tb2R1bGVzL2hhc2guanMvbGliL2hhc2gvY29tbW9uLmpzIiwgIi4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy8ucG5wbS9oYXNoLmpzQDEuMS43L25vZGVfbW9kdWxlcy9oYXNoLmpzL2xpYi9oYXNoL3NoYS9jb21tb24uanMiLCAiLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzLy5wbnBtL2hhc2guanNAMS4xLjcvbm9kZV9tb2R1bGVzL2hhc2guanMvbGliL2hhc2gvc2hhLzEuanMiLCAiLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzLy5wbnBtL2hhc2guanNAMS4xLjcvbm9kZV9tb2R1bGVzL2hhc2guanMvbGliL2hhc2gvc2hhLzI1Ni5qcyIsICIuLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvLnBucG0vaGFzaC5qc0AxLjEuNy9ub2RlX21vZHVsZXMvaGFzaC5qcy9saWIvaGFzaC9zaGEvMjI0LmpzIiwgIi4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy8ucG5wbS9oYXNoLmpzQDEuMS43L25vZGVfbW9kdWxlcy9oYXNoLmpzL2xpYi9oYXNoL3NoYS81MTIuanMiLCAiLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzLy5wbnBtL2hhc2guanNAMS4xLjcvbm9kZV9tb2R1bGVzL2hhc2guanMvbGliL2hhc2gvc2hhLzM4NC5qcyIsICIuLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvLnBucG0vaGFzaC5qc0AxLjEuNy9ub2RlX21vZHVsZXMvaGFzaC5qcy9saWIvaGFzaC9zaGEuanMiLCAiLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzLy5wbnBtL2hhc2guanNAMS4xLjcvbm9kZV9tb2R1bGVzL2hhc2guanMvbGliL2hhc2gvcmlwZW1kLmpzIiwgIi4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy8ucG5wbS9oYXNoLmpzQDEuMS43L25vZGVfbW9kdWxlcy9oYXNoLmpzL2xpYi9oYXNoL2htYWMuanMiLCAiLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzLy5wbnBtL2hhc2guanNAMS4xLjcvbm9kZV9tb2R1bGVzL2hhc2guanMvbGliL2hhc2guanMiLCAiLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzLy5wbnBtL3NlbXZlckA3LjguNS9ub2RlX21vZHVsZXMvc2VtdmVyL2ludGVybmFsL2NvbnN0YW50cy5qcyIsICIuLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvLnBucG0vc2VtdmVyQDcuOC41L25vZGVfbW9kdWxlcy9zZW12ZXIvaW50ZXJuYWwvZGVidWcuanMiLCAiLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzLy5wbnBtL3NlbXZlckA3LjguNS9ub2RlX21vZHVsZXMvc2VtdmVyL2ludGVybmFsL3JlLmpzIiwgIi4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy8ucG5wbS9zZW12ZXJANy44LjUvbm9kZV9tb2R1bGVzL3NlbXZlci9pbnRlcm5hbC9wYXJzZS1vcHRpb25zLmpzIiwgIi4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy8ucG5wbS9zZW12ZXJANy44LjUvbm9kZV9tb2R1bGVzL3NlbXZlci9pbnRlcm5hbC9pZGVudGlmaWVycy5qcyIsICIuLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvLnBucG0vc2VtdmVyQDcuOC41L25vZGVfbW9kdWxlcy9zZW12ZXIvY2xhc3Nlcy9zZW12ZXIuanMiLCAiLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzLy5wbnBtL3NlbXZlckA3LjguNS9ub2RlX21vZHVsZXMvc2VtdmVyL2Z1bmN0aW9ucy9wYXJzZS5qcyIsICIuLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvLnBucG0vc2VtdmVyQDcuOC41L25vZGVfbW9kdWxlcy9zZW12ZXIvZnVuY3Rpb25zL3ZhbGlkLmpzIiwgIi4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy8ucG5wbS9zZW12ZXJANy44LjUvbm9kZV9tb2R1bGVzL3NlbXZlci9mdW5jdGlvbnMvY2xlYW4uanMiLCAiLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzLy5wbnBtL3NlbXZlckA3LjguNS9ub2RlX21vZHVsZXMvc2VtdmVyL2Z1bmN0aW9ucy9pbmMuanMiLCAiLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzLy5wbnBtL3NlbXZlckA3LjguNS9ub2RlX21vZHVsZXMvc2VtdmVyL2Z1bmN0aW9ucy9kaWZmLmpzIiwgIi4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy8ucG5wbS9zZW12ZXJANy44LjUvbm9kZV9tb2R1bGVzL3NlbXZlci9mdW5jdGlvbnMvbWFqb3IuanMiLCAiLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzLy5wbnBtL3NlbXZlckA3LjguNS9ub2RlX21vZHVsZXMvc2VtdmVyL2Z1bmN0aW9ucy9taW5vci5qcyIsICIuLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvLnBucG0vc2VtdmVyQDcuOC41L25vZGVfbW9kdWxlcy9zZW12ZXIvZnVuY3Rpb25zL3BhdGNoLmpzIiwgIi4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy8ucG5wbS9zZW12ZXJANy44LjUvbm9kZV9tb2R1bGVzL3NlbXZlci9mdW5jdGlvbnMvcHJlcmVsZWFzZS5qcyIsICIuLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvLnBucG0vc2VtdmVyQDcuOC41L25vZGVfbW9kdWxlcy9zZW12ZXIvZnVuY3Rpb25zL2NvbXBhcmUuanMiLCAiLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzLy5wbnBtL3NlbXZlckA3LjguNS9ub2RlX21vZHVsZXMvc2VtdmVyL2Z1bmN0aW9ucy9yY29tcGFyZS5qcyIsICIuLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvLnBucG0vc2VtdmVyQDcuOC41L25vZGVfbW9kdWxlcy9zZW12ZXIvZnVuY3Rpb25zL2NvbXBhcmUtbG9vc2UuanMiLCAiLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzLy5wbnBtL3NlbXZlckA3LjguNS9ub2RlX21vZHVsZXMvc2VtdmVyL2Z1bmN0aW9ucy9jb21wYXJlLWJ1aWxkLmpzIiwgIi4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy8ucG5wbS9zZW12ZXJANy44LjUvbm9kZV9tb2R1bGVzL3NlbXZlci9mdW5jdGlvbnMvc29ydC5qcyIsICIuLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvLnBucG0vc2VtdmVyQDcuOC41L25vZGVfbW9kdWxlcy9zZW12ZXIvZnVuY3Rpb25zL3Jzb3J0LmpzIiwgIi4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy8ucG5wbS9zZW12ZXJANy44LjUvbm9kZV9tb2R1bGVzL3NlbXZlci9mdW5jdGlvbnMvZ3QuanMiLCAiLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzLy5wbnBtL3NlbXZlckA3LjguNS9ub2RlX21vZHVsZXMvc2VtdmVyL2Z1bmN0aW9ucy9sdC5qcyIsICIuLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvLnBucG0vc2VtdmVyQDcuOC41L25vZGVfbW9kdWxlcy9zZW12ZXIvZnVuY3Rpb25zL2VxLmpzIiwgIi4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy8ucG5wbS9zZW12ZXJANy44LjUvbm9kZV9tb2R1bGVzL3NlbXZlci9mdW5jdGlvbnMvbmVxLmpzIiwgIi4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy8ucG5wbS9zZW12ZXJANy44LjUvbm9kZV9tb2R1bGVzL3NlbXZlci9mdW5jdGlvbnMvZ3RlLmpzIiwgIi4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy8ucG5wbS9zZW12ZXJANy44LjUvbm9kZV9tb2R1bGVzL3NlbXZlci9mdW5jdGlvbnMvbHRlLmpzIiwgIi4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy8ucG5wbS9zZW12ZXJANy44LjUvbm9kZV9tb2R1bGVzL3NlbXZlci9mdW5jdGlvbnMvY21wLmpzIiwgIi4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy8ucG5wbS9zZW12ZXJANy44LjUvbm9kZV9tb2R1bGVzL3NlbXZlci9mdW5jdGlvbnMvY29lcmNlLmpzIiwgIi4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy8ucG5wbS9zZW12ZXJANy44LjUvbm9kZV9tb2R1bGVzL3NlbXZlci9mdW5jdGlvbnMvdHJ1bmNhdGUuanMiLCAiLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzLy5wbnBtL3NlbXZlckA3LjguNS9ub2RlX21vZHVsZXMvc2VtdmVyL2ludGVybmFsL2xydWNhY2hlLmpzIiwgIi4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy8ucG5wbS9zZW12ZXJANy44LjUvbm9kZV9tb2R1bGVzL3NlbXZlci9jbGFzc2VzL3JhbmdlLmpzIiwgIi4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy8ucG5wbS9zZW12ZXJANy44LjUvbm9kZV9tb2R1bGVzL3NlbXZlci9jbGFzc2VzL2NvbXBhcmF0b3IuanMiLCAiLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzLy5wbnBtL3NlbXZlckA3LjguNS9ub2RlX21vZHVsZXMvc2VtdmVyL2Z1bmN0aW9ucy9zYXRpc2ZpZXMuanMiLCAiLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzLy5wbnBtL3NlbXZlckA3LjguNS9ub2RlX21vZHVsZXMvc2VtdmVyL3Jhbmdlcy90by1jb21wYXJhdG9ycy5qcyIsICIuLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvLnBucG0vc2VtdmVyQDcuOC41L25vZGVfbW9kdWxlcy9zZW12ZXIvcmFuZ2VzL21heC1zYXRpc2Z5aW5nLmpzIiwgIi4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy8ucG5wbS9zZW12ZXJANy44LjUvbm9kZV9tb2R1bGVzL3NlbXZlci9yYW5nZXMvbWluLXNhdGlzZnlpbmcuanMiLCAiLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzLy5wbnBtL3NlbXZlckA3LjguNS9ub2RlX21vZHVsZXMvc2VtdmVyL3Jhbmdlcy9taW4tdmVyc2lvbi5qcyIsICIuLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvLnBucG0vc2VtdmVyQDcuOC41L25vZGVfbW9kdWxlcy9zZW12ZXIvcmFuZ2VzL3ZhbGlkLmpzIiwgIi4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy8ucG5wbS9zZW12ZXJANy44LjUvbm9kZV9tb2R1bGVzL3NlbXZlci9yYW5nZXMvb3V0c2lkZS5qcyIsICIuLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvLnBucG0vc2VtdmVyQDcuOC41L25vZGVfbW9kdWxlcy9zZW12ZXIvcmFuZ2VzL2d0ci5qcyIsICIuLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvLnBucG0vc2VtdmVyQDcuOC41L25vZGVfbW9kdWxlcy9zZW12ZXIvcmFuZ2VzL2x0ci5qcyIsICIuLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvLnBucG0vc2VtdmVyQDcuOC41L25vZGVfbW9kdWxlcy9zZW12ZXIvcmFuZ2VzL2ludGVyc2VjdHMuanMiLCAiLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzLy5wbnBtL3NlbXZlckA3LjguNS9ub2RlX21vZHVsZXMvc2VtdmVyL3Jhbmdlcy9zaW1wbGlmeS5qcyIsICIuLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvLnBucG0vc2VtdmVyQDcuOC41L25vZGVfbW9kdWxlcy9zZW12ZXIvcmFuZ2VzL3N1YnNldC5qcyIsICIuLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvLnBucG0vc2VtdmVyQDcuOC41L25vZGVfbW9kdWxlcy9zZW12ZXIvaW5kZXguanMiLCAiLi4vLi4vLi4vLi4vd29ya2J1ZGR5LWNvcmUvc3JjL2luZnJhL2J1cy9idXMudHMiLCAiLi4vLi4vLi4vLi4vd29ya2J1ZGR5LWNvcmUvc3JjL3diL2JvdW5kYXJ5L2Vycm9yLWVudmVsb3BlLnRzIiwgIi4uLy4uLy4uLy4uL3dvcmtidWRkeS1jb3JlL3NyYy9jb252ZXJzYXRpb25zL2NvbW1vbi9jb3JlL2NvbnZlcnNhdGlvbi1ldmVudC10eXBlcy50cyIsICIuLi8uLi8uLi8uLi93b3JrYnVkZHktY29yZS9zcmMvY29udmVyc2F0aW9ucy9jb21tb24vY29yZS9jb252ZXJzYXRpb24tc3VwcG9ydC10eXBlcy50cyIsICIuLi8uLi8uLi8uLi93b3JrYnVkZHktY29yZS9zcmMvY29udmVyc2F0aW9ucy9jb21tb24vYnVkZHktc25hcHNob3QudHMiLCAiLi4vLi4vLi4vLi4vd29ya2J1ZGR5LWNvcmUvc3JjL2NvbnZlcnNhdGlvbnMvY29tbW9uL2V2ZW50LW5hbWVzLnRzIiwgIi4uLy4uLy4uLy4uL3dvcmtidWRkeS1jb3JlL3NyYy9jb252ZXJzYXRpb25zL2NvbW1vbi9jb3JlL21vZGVsL2NvbnZlcnNhdGlvbi1wcm9tcHQtb3BlcmF0aW9ucy50cyIsICIuLi8uLi8uLi8uLi93b3JrYnVkZHktY29yZS9zcmMvY29udmVyc2F0aW9ucy93Yi93aXJlLWRlc2NyaXB0b3IudHMiLCAiLi4vLi4vLi4vLi4vd29ya2J1ZGR5LWNvcmUvc3JjL2NvbnZlcnNhdGlvbnMvd2Ivc2VydmljZS50cyIsICIuLi8uLi8uLi8uLi93b3JrYnVkZHktY29yZS9zcmMvd2IvYm91bmRhcnkvdHJhbnNwb3J0L3Byb3RvY29sLnRzIiwgIi4uLy4uLy4uLy4uL3dvcmtidWRkeS1jb3JlL3NyYy93Yi9ndWVzdC9wcm94eS50cyIsICIuLi8uLi8uLi8uLi93b3JrYnVkZHktY29yZS9zcmMvd2IvY29yZS9uYW1lc3BhY2UtbWFuaWZlc3QudHMiLCAiLi4vLi4vLi4vLi4vd29ya2J1ZGR5LWNvcmUvc3JjL2RvbWFpbnMvc2tpbGxzL2NvbW1vbi9za2lsbC1jbG91ZC1zeW5jLW1lcmdlLWVuZ2luZS50cyIsICIuLi8uLi8uLi9zcmMvYnJpZGdlL3RyYW5zcG9ydC1wcm9jZXNzLnRzIiwgIi4uLy4uLy4uL3NyYy9ydW50aW1lL2NvcmUvcHJvY2Vzcy1lbnYudHMiLCAiLi4vLi4vLi4vc3JjL3J1bnRpbWUvY29yZS9ydW4tZXh0ZW5zaW9uLnRzIiwgIi4uLy4uLy4uL3NyYy9ydW50aW1lL3ByZWxvYWQvZm9yay1wcmVsb2FkLnRzIl0sCiAgInNvdXJjZXNDb250ZW50IjogWyJtb2R1bGUuZXhwb3J0cyA9IGFzc2VydDtcblxuZnVuY3Rpb24gYXNzZXJ0KHZhbCwgbXNnKSB7XG4gIGlmICghdmFsKVxuICAgIHRocm93IG5ldyBFcnJvcihtc2cgfHwgJ0Fzc2VydGlvbiBmYWlsZWQnKTtcbn1cblxuYXNzZXJ0LmVxdWFsID0gZnVuY3Rpb24gYXNzZXJ0RXF1YWwobCwgciwgbXNnKSB7XG4gIGlmIChsICE9IHIpXG4gICAgdGhyb3cgbmV3IEVycm9yKG1zZyB8fCAoJ0Fzc2VydGlvbiBmYWlsZWQ6ICcgKyBsICsgJyAhPSAnICsgcikpO1xufTtcbiIsICJpZiAodHlwZW9mIE9iamVjdC5jcmVhdGUgPT09ICdmdW5jdGlvbicpIHtcbiAgLy8gaW1wbGVtZW50YXRpb24gZnJvbSBzdGFuZGFyZCBub2RlLmpzICd1dGlsJyBtb2R1bGVcbiAgbW9kdWxlLmV4cG9ydHMgPSBmdW5jdGlvbiBpbmhlcml0cyhjdG9yLCBzdXBlckN0b3IpIHtcbiAgICBpZiAoc3VwZXJDdG9yKSB7XG4gICAgICBjdG9yLnN1cGVyXyA9IHN1cGVyQ3RvclxuICAgICAgY3Rvci5wcm90b3R5cGUgPSBPYmplY3QuY3JlYXRlKHN1cGVyQ3Rvci5wcm90b3R5cGUsIHtcbiAgICAgICAgY29uc3RydWN0b3I6IHtcbiAgICAgICAgICB2YWx1ZTogY3RvcixcbiAgICAgICAgICBlbnVtZXJhYmxlOiBmYWxzZSxcbiAgICAgICAgICB3cml0YWJsZTogdHJ1ZSxcbiAgICAgICAgICBjb25maWd1cmFibGU6IHRydWVcbiAgICAgICAgfVxuICAgICAgfSlcbiAgICB9XG4gIH07XG59IGVsc2Uge1xuICAvLyBvbGQgc2Nob29sIHNoaW0gZm9yIG9sZCBicm93c2Vyc1xuICBtb2R1bGUuZXhwb3J0cyA9IGZ1bmN0aW9uIGluaGVyaXRzKGN0b3IsIHN1cGVyQ3Rvcikge1xuICAgIGlmIChzdXBlckN0b3IpIHtcbiAgICAgIGN0b3Iuc3VwZXJfID0gc3VwZXJDdG9yXG4gICAgICB2YXIgVGVtcEN0b3IgPSBmdW5jdGlvbiAoKSB7fVxuICAgICAgVGVtcEN0b3IucHJvdG90eXBlID0gc3VwZXJDdG9yLnByb3RvdHlwZVxuICAgICAgY3Rvci5wcm90b3R5cGUgPSBuZXcgVGVtcEN0b3IoKVxuICAgICAgY3Rvci5wcm90b3R5cGUuY29uc3RydWN0b3IgPSBjdG9yXG4gICAgfVxuICB9XG59XG4iLCAidHJ5IHtcbiAgdmFyIHV0aWwgPSByZXF1aXJlKCd1dGlsJyk7XG4gIC8qIGlzdGFuYnVsIGlnbm9yZSBuZXh0ICovXG4gIGlmICh0eXBlb2YgdXRpbC5pbmhlcml0cyAhPT0gJ2Z1bmN0aW9uJykgdGhyb3cgJyc7XG4gIG1vZHVsZS5leHBvcnRzID0gdXRpbC5pbmhlcml0cztcbn0gY2F0Y2ggKGUpIHtcbiAgLyogaXN0YW5idWwgaWdub3JlIG5leHQgKi9cbiAgbW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKCcuL2luaGVyaXRzX2Jyb3dzZXIuanMnKTtcbn1cbiIsICIndXNlIHN0cmljdCc7XG5cbnZhciBhc3NlcnQgPSByZXF1aXJlKCdtaW5pbWFsaXN0aWMtYXNzZXJ0Jyk7XG52YXIgaW5oZXJpdHMgPSByZXF1aXJlKCdpbmhlcml0cycpO1xuXG5leHBvcnRzLmluaGVyaXRzID0gaW5oZXJpdHM7XG5cbmZ1bmN0aW9uIGlzU3Vycm9nYXRlUGFpcihtc2csIGkpIHtcbiAgaWYgKChtc2cuY2hhckNvZGVBdChpKSAmIDB4RkMwMCkgIT09IDB4RDgwMCkge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICBpZiAoaSA8IDAgfHwgaSArIDEgPj0gbXNnLmxlbmd0aCkge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICByZXR1cm4gKG1zZy5jaGFyQ29kZUF0KGkgKyAxKSAmIDB4RkMwMCkgPT09IDB4REMwMDtcbn1cblxuZnVuY3Rpb24gdG9BcnJheShtc2csIGVuYykge1xuICBpZiAoQXJyYXkuaXNBcnJheShtc2cpKVxuICAgIHJldHVybiBtc2cuc2xpY2UoKTtcbiAgaWYgKCFtc2cpXG4gICAgcmV0dXJuIFtdO1xuICB2YXIgcmVzID0gW107XG4gIGlmICh0eXBlb2YgbXNnID09PSAnc3RyaW5nJykge1xuICAgIGlmICghZW5jKSB7XG4gICAgICAvLyBJbnNwaXJlZCBieSBzdHJpbmdUb1V0ZjhCeXRlQXJyYXkoKSBpbiBjbG9zdXJlLWxpYnJhcnkgYnkgR29vZ2xlXG4gICAgICAvLyBodHRwczovL2dpdGh1Yi5jb20vZ29vZ2xlL2Nsb3N1cmUtbGlicmFyeS9ibG9iLzg1OThkODcyNDJhZjU5YWFjMjMzMjcwNzQyYzg5ODRlMmIyYmRiZTAvY2xvc3VyZS9nb29nL2NyeXB0L2NyeXB0LmpzI0wxMTctTDE0M1xuICAgICAgLy8gQXBhY2hlIExpY2Vuc2UgMi4wXG4gICAgICAvLyBodHRwczovL2dpdGh1Yi5jb20vZ29vZ2xlL2Nsb3N1cmUtbGlicmFyeS9ibG9iL21hc3Rlci9MSUNFTlNFXG4gICAgICB2YXIgcCA9IDA7XG4gICAgICBmb3IgKHZhciBpID0gMDsgaSA8IG1zZy5sZW5ndGg7IGkrKykge1xuICAgICAgICB2YXIgYyA9IG1zZy5jaGFyQ29kZUF0KGkpO1xuICAgICAgICBpZiAoYyA8IDEyOCkge1xuICAgICAgICAgIHJlc1twKytdID0gYztcbiAgICAgICAgfSBlbHNlIGlmIChjIDwgMjA0OCkge1xuICAgICAgICAgIHJlc1twKytdID0gKGMgPj4gNikgfCAxOTI7XG4gICAgICAgICAgcmVzW3ArK10gPSAoYyAmIDYzKSB8IDEyODtcbiAgICAgICAgfSBlbHNlIGlmIChpc1N1cnJvZ2F0ZVBhaXIobXNnLCBpKSkge1xuICAgICAgICAgIGMgPSAweDEwMDAwICsgKChjICYgMHgwM0ZGKSA8PCAxMCkgKyAobXNnLmNoYXJDb2RlQXQoKytpKSAmIDB4MDNGRik7XG4gICAgICAgICAgcmVzW3ArK10gPSAoYyA+PiAxOCkgfCAyNDA7XG4gICAgICAgICAgcmVzW3ArK10gPSAoKGMgPj4gMTIpICYgNjMpIHwgMTI4O1xuICAgICAgICAgIHJlc1twKytdID0gKChjID4+IDYpICYgNjMpIHwgMTI4O1xuICAgICAgICAgIHJlc1twKytdID0gKGMgJiA2MykgfCAxMjg7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgcmVzW3ArK10gPSAoYyA+PiAxMikgfCAyMjQ7XG4gICAgICAgICAgcmVzW3ArK10gPSAoKGMgPj4gNikgJiA2MykgfCAxMjg7XG4gICAgICAgICAgcmVzW3ArK10gPSAoYyAmIDYzKSB8IDEyODtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0gZWxzZSBpZiAoZW5jID09PSAnaGV4Jykge1xuICAgICAgbXNnID0gbXNnLnJlcGxhY2UoL1teYS16MC05XSsvaWcsICcnKTtcbiAgICAgIGlmIChtc2cubGVuZ3RoICUgMiAhPT0gMClcbiAgICAgICAgbXNnID0gJzAnICsgbXNnO1xuICAgICAgZm9yIChpID0gMDsgaSA8IG1zZy5sZW5ndGg7IGkgKz0gMilcbiAgICAgICAgcmVzLnB1c2gocGFyc2VJbnQobXNnW2ldICsgbXNnW2kgKyAxXSwgMTYpKTtcbiAgICB9XG4gIH0gZWxzZSB7XG4gICAgZm9yIChpID0gMDsgaSA8IG1zZy5sZW5ndGg7IGkrKylcbiAgICAgIHJlc1tpXSA9IG1zZ1tpXSB8IDA7XG4gIH1cbiAgcmV0dXJuIHJlcztcbn1cbmV4cG9ydHMudG9BcnJheSA9IHRvQXJyYXk7XG5cbmZ1bmN0aW9uIHRvSGV4KG1zZykge1xuICB2YXIgcmVzID0gJyc7XG4gIGZvciAodmFyIGkgPSAwOyBpIDwgbXNnLmxlbmd0aDsgaSsrKVxuICAgIHJlcyArPSB6ZXJvMihtc2dbaV0udG9TdHJpbmcoMTYpKTtcbiAgcmV0dXJuIHJlcztcbn1cbmV4cG9ydHMudG9IZXggPSB0b0hleDtcblxuZnVuY3Rpb24gaHRvbmwodykge1xuICB2YXIgcmVzID0gKHcgPj4+IDI0KSB8XG4gICAgICAgICAgICAoKHcgPj4+IDgpICYgMHhmZjAwKSB8XG4gICAgICAgICAgICAoKHcgPDwgOCkgJiAweGZmMDAwMCkgfFxuICAgICAgICAgICAgKCh3ICYgMHhmZikgPDwgMjQpO1xuICByZXR1cm4gcmVzID4+PiAwO1xufVxuZXhwb3J0cy5odG9ubCA9IGh0b25sO1xuXG5mdW5jdGlvbiB0b0hleDMyKG1zZywgZW5kaWFuKSB7XG4gIHZhciByZXMgPSAnJztcbiAgZm9yICh2YXIgaSA9IDA7IGkgPCBtc2cubGVuZ3RoOyBpKyspIHtcbiAgICB2YXIgdyA9IG1zZ1tpXTtcbiAgICBpZiAoZW5kaWFuID09PSAnbGl0dGxlJylcbiAgICAgIHcgPSBodG9ubCh3KTtcbiAgICByZXMgKz0gemVybzgody50b1N0cmluZygxNikpO1xuICB9XG4gIHJldHVybiByZXM7XG59XG5leHBvcnRzLnRvSGV4MzIgPSB0b0hleDMyO1xuXG5mdW5jdGlvbiB6ZXJvMih3b3JkKSB7XG4gIGlmICh3b3JkLmxlbmd0aCA9PT0gMSlcbiAgICByZXR1cm4gJzAnICsgd29yZDtcbiAgZWxzZVxuICAgIHJldHVybiB3b3JkO1xufVxuZXhwb3J0cy56ZXJvMiA9IHplcm8yO1xuXG5mdW5jdGlvbiB6ZXJvOCh3b3JkKSB7XG4gIGlmICh3b3JkLmxlbmd0aCA9PT0gNylcbiAgICByZXR1cm4gJzAnICsgd29yZDtcbiAgZWxzZSBpZiAod29yZC5sZW5ndGggPT09IDYpXG4gICAgcmV0dXJuICcwMCcgKyB3b3JkO1xuICBlbHNlIGlmICh3b3JkLmxlbmd0aCA9PT0gNSlcbiAgICByZXR1cm4gJzAwMCcgKyB3b3JkO1xuICBlbHNlIGlmICh3b3JkLmxlbmd0aCA9PT0gNClcbiAgICByZXR1cm4gJzAwMDAnICsgd29yZDtcbiAgZWxzZSBpZiAod29yZC5sZW5ndGggPT09IDMpXG4gICAgcmV0dXJuICcwMDAwMCcgKyB3b3JkO1xuICBlbHNlIGlmICh3b3JkLmxlbmd0aCA9PT0gMilcbiAgICByZXR1cm4gJzAwMDAwMCcgKyB3b3JkO1xuICBlbHNlIGlmICh3b3JkLmxlbmd0aCA9PT0gMSlcbiAgICByZXR1cm4gJzAwMDAwMDAnICsgd29yZDtcbiAgZWxzZVxuICAgIHJldHVybiB3b3JkO1xufVxuZXhwb3J0cy56ZXJvOCA9IHplcm84O1xuXG5mdW5jdGlvbiBqb2luMzIobXNnLCBzdGFydCwgZW5kLCBlbmRpYW4pIHtcbiAgdmFyIGxlbiA9IGVuZCAtIHN0YXJ0O1xuICBhc3NlcnQobGVuICUgNCA9PT0gMCk7XG4gIHZhciByZXMgPSBuZXcgQXJyYXkobGVuIC8gNCk7XG4gIGZvciAodmFyIGkgPSAwLCBrID0gc3RhcnQ7IGkgPCByZXMubGVuZ3RoOyBpKyssIGsgKz0gNCkge1xuICAgIHZhciB3O1xuICAgIGlmIChlbmRpYW4gPT09ICdiaWcnKVxuICAgICAgdyA9IChtc2dba10gPDwgMjQpIHwgKG1zZ1trICsgMV0gPDwgMTYpIHwgKG1zZ1trICsgMl0gPDwgOCkgfCBtc2dbayArIDNdO1xuICAgIGVsc2VcbiAgICAgIHcgPSAobXNnW2sgKyAzXSA8PCAyNCkgfCAobXNnW2sgKyAyXSA8PCAxNikgfCAobXNnW2sgKyAxXSA8PCA4KSB8IG1zZ1trXTtcbiAgICByZXNbaV0gPSB3ID4+PiAwO1xuICB9XG4gIHJldHVybiByZXM7XG59XG5leHBvcnRzLmpvaW4zMiA9IGpvaW4zMjtcblxuZnVuY3Rpb24gc3BsaXQzMihtc2csIGVuZGlhbikge1xuICB2YXIgcmVzID0gbmV3IEFycmF5KG1zZy5sZW5ndGggKiA0KTtcbiAgZm9yICh2YXIgaSA9IDAsIGsgPSAwOyBpIDwgbXNnLmxlbmd0aDsgaSsrLCBrICs9IDQpIHtcbiAgICB2YXIgbSA9IG1zZ1tpXTtcbiAgICBpZiAoZW5kaWFuID09PSAnYmlnJykge1xuICAgICAgcmVzW2tdID0gbSA+Pj4gMjQ7XG4gICAgICByZXNbayArIDFdID0gKG0gPj4+IDE2KSAmIDB4ZmY7XG4gICAgICByZXNbayArIDJdID0gKG0gPj4+IDgpICYgMHhmZjtcbiAgICAgIHJlc1trICsgM10gPSBtICYgMHhmZjtcbiAgICB9IGVsc2Uge1xuICAgICAgcmVzW2sgKyAzXSA9IG0gPj4+IDI0O1xuICAgICAgcmVzW2sgKyAyXSA9IChtID4+PiAxNikgJiAweGZmO1xuICAgICAgcmVzW2sgKyAxXSA9IChtID4+PiA4KSAmIDB4ZmY7XG4gICAgICByZXNba10gPSBtICYgMHhmZjtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIHJlcztcbn1cbmV4cG9ydHMuc3BsaXQzMiA9IHNwbGl0MzI7XG5cbmZ1bmN0aW9uIHJvdHIzMih3LCBiKSB7XG4gIHJldHVybiAodyA+Pj4gYikgfCAodyA8PCAoMzIgLSBiKSk7XG59XG5leHBvcnRzLnJvdHIzMiA9IHJvdHIzMjtcblxuZnVuY3Rpb24gcm90bDMyKHcsIGIpIHtcbiAgcmV0dXJuICh3IDw8IGIpIHwgKHcgPj4+ICgzMiAtIGIpKTtcbn1cbmV4cG9ydHMucm90bDMyID0gcm90bDMyO1xuXG5mdW5jdGlvbiBzdW0zMihhLCBiKSB7XG4gIHJldHVybiAoYSArIGIpID4+PiAwO1xufVxuZXhwb3J0cy5zdW0zMiA9IHN1bTMyO1xuXG5mdW5jdGlvbiBzdW0zMl8zKGEsIGIsIGMpIHtcbiAgcmV0dXJuIChhICsgYiArIGMpID4+PiAwO1xufVxuZXhwb3J0cy5zdW0zMl8zID0gc3VtMzJfMztcblxuZnVuY3Rpb24gc3VtMzJfNChhLCBiLCBjLCBkKSB7XG4gIHJldHVybiAoYSArIGIgKyBjICsgZCkgPj4+IDA7XG59XG5leHBvcnRzLnN1bTMyXzQgPSBzdW0zMl80O1xuXG5mdW5jdGlvbiBzdW0zMl81KGEsIGIsIGMsIGQsIGUpIHtcbiAgcmV0dXJuIChhICsgYiArIGMgKyBkICsgZSkgPj4+IDA7XG59XG5leHBvcnRzLnN1bTMyXzUgPSBzdW0zMl81O1xuXG5mdW5jdGlvbiBzdW02NChidWYsIHBvcywgYWgsIGFsKSB7XG4gIHZhciBiaCA9IGJ1Zltwb3NdO1xuICB2YXIgYmwgPSBidWZbcG9zICsgMV07XG5cbiAgdmFyIGxvID0gKGFsICsgYmwpID4+PiAwO1xuICB2YXIgaGkgPSAobG8gPCBhbCA/IDEgOiAwKSArIGFoICsgYmg7XG4gIGJ1Zltwb3NdID0gaGkgPj4+IDA7XG4gIGJ1Zltwb3MgKyAxXSA9IGxvO1xufVxuZXhwb3J0cy5zdW02NCA9IHN1bTY0O1xuXG5mdW5jdGlvbiBzdW02NF9oaShhaCwgYWwsIGJoLCBibCkge1xuICB2YXIgbG8gPSAoYWwgKyBibCkgPj4+IDA7XG4gIHZhciBoaSA9IChsbyA8IGFsID8gMSA6IDApICsgYWggKyBiaDtcbiAgcmV0dXJuIGhpID4+PiAwO1xufVxuZXhwb3J0cy5zdW02NF9oaSA9IHN1bTY0X2hpO1xuXG5mdW5jdGlvbiBzdW02NF9sbyhhaCwgYWwsIGJoLCBibCkge1xuICB2YXIgbG8gPSBhbCArIGJsO1xuICByZXR1cm4gbG8gPj4+IDA7XG59XG5leHBvcnRzLnN1bTY0X2xvID0gc3VtNjRfbG87XG5cbmZ1bmN0aW9uIHN1bTY0XzRfaGkoYWgsIGFsLCBiaCwgYmwsIGNoLCBjbCwgZGgsIGRsKSB7XG4gIHZhciBjYXJyeSA9IDA7XG4gIHZhciBsbyA9IGFsO1xuICBsbyA9IChsbyArIGJsKSA+Pj4gMDtcbiAgY2FycnkgKz0gbG8gPCBhbCA/IDEgOiAwO1xuICBsbyA9IChsbyArIGNsKSA+Pj4gMDtcbiAgY2FycnkgKz0gbG8gPCBjbCA/IDEgOiAwO1xuICBsbyA9IChsbyArIGRsKSA+Pj4gMDtcbiAgY2FycnkgKz0gbG8gPCBkbCA/IDEgOiAwO1xuXG4gIHZhciBoaSA9IGFoICsgYmggKyBjaCArIGRoICsgY2Fycnk7XG4gIHJldHVybiBoaSA+Pj4gMDtcbn1cbmV4cG9ydHMuc3VtNjRfNF9oaSA9IHN1bTY0XzRfaGk7XG5cbmZ1bmN0aW9uIHN1bTY0XzRfbG8oYWgsIGFsLCBiaCwgYmwsIGNoLCBjbCwgZGgsIGRsKSB7XG4gIHZhciBsbyA9IGFsICsgYmwgKyBjbCArIGRsO1xuICByZXR1cm4gbG8gPj4+IDA7XG59XG5leHBvcnRzLnN1bTY0XzRfbG8gPSBzdW02NF80X2xvO1xuXG5mdW5jdGlvbiBzdW02NF81X2hpKGFoLCBhbCwgYmgsIGJsLCBjaCwgY2wsIGRoLCBkbCwgZWgsIGVsKSB7XG4gIHZhciBjYXJyeSA9IDA7XG4gIHZhciBsbyA9IGFsO1xuICBsbyA9IChsbyArIGJsKSA+Pj4gMDtcbiAgY2FycnkgKz0gbG8gPCBhbCA/IDEgOiAwO1xuICBsbyA9IChsbyArIGNsKSA+Pj4gMDtcbiAgY2FycnkgKz0gbG8gPCBjbCA/IDEgOiAwO1xuICBsbyA9IChsbyArIGRsKSA+Pj4gMDtcbiAgY2FycnkgKz0gbG8gPCBkbCA/IDEgOiAwO1xuICBsbyA9IChsbyArIGVsKSA+Pj4gMDtcbiAgY2FycnkgKz0gbG8gPCBlbCA/IDEgOiAwO1xuXG4gIHZhciBoaSA9IGFoICsgYmggKyBjaCArIGRoICsgZWggKyBjYXJyeTtcbiAgcmV0dXJuIGhpID4+PiAwO1xufVxuZXhwb3J0cy5zdW02NF81X2hpID0gc3VtNjRfNV9oaTtcblxuZnVuY3Rpb24gc3VtNjRfNV9sbyhhaCwgYWwsIGJoLCBibCwgY2gsIGNsLCBkaCwgZGwsIGVoLCBlbCkge1xuICB2YXIgbG8gPSBhbCArIGJsICsgY2wgKyBkbCArIGVsO1xuXG4gIHJldHVybiBsbyA+Pj4gMDtcbn1cbmV4cG9ydHMuc3VtNjRfNV9sbyA9IHN1bTY0XzVfbG87XG5cbmZ1bmN0aW9uIHJvdHI2NF9oaShhaCwgYWwsIG51bSkge1xuICB2YXIgciA9IChhbCA8PCAoMzIgLSBudW0pKSB8IChhaCA+Pj4gbnVtKTtcbiAgcmV0dXJuIHIgPj4+IDA7XG59XG5leHBvcnRzLnJvdHI2NF9oaSA9IHJvdHI2NF9oaTtcblxuZnVuY3Rpb24gcm90cjY0X2xvKGFoLCBhbCwgbnVtKSB7XG4gIHZhciByID0gKGFoIDw8ICgzMiAtIG51bSkpIHwgKGFsID4+PiBudW0pO1xuICByZXR1cm4gciA+Pj4gMDtcbn1cbmV4cG9ydHMucm90cjY0X2xvID0gcm90cjY0X2xvO1xuXG5mdW5jdGlvbiBzaHI2NF9oaShhaCwgYWwsIG51bSkge1xuICByZXR1cm4gYWggPj4+IG51bTtcbn1cbmV4cG9ydHMuc2hyNjRfaGkgPSBzaHI2NF9oaTtcblxuZnVuY3Rpb24gc2hyNjRfbG8oYWgsIGFsLCBudW0pIHtcbiAgdmFyIHIgPSAoYWggPDwgKDMyIC0gbnVtKSkgfCAoYWwgPj4+IG51bSk7XG4gIHJldHVybiByID4+PiAwO1xufVxuZXhwb3J0cy5zaHI2NF9sbyA9IHNocjY0X2xvO1xuIiwgIid1c2Ugc3RyaWN0JztcblxudmFyIHV0aWxzID0gcmVxdWlyZSgnLi91dGlscycpO1xudmFyIGFzc2VydCA9IHJlcXVpcmUoJ21pbmltYWxpc3RpYy1hc3NlcnQnKTtcblxuZnVuY3Rpb24gQmxvY2tIYXNoKCkge1xuICB0aGlzLnBlbmRpbmcgPSBudWxsO1xuICB0aGlzLnBlbmRpbmdUb3RhbCA9IDA7XG4gIHRoaXMuYmxvY2tTaXplID0gdGhpcy5jb25zdHJ1Y3Rvci5ibG9ja1NpemU7XG4gIHRoaXMub3V0U2l6ZSA9IHRoaXMuY29uc3RydWN0b3Iub3V0U2l6ZTtcbiAgdGhpcy5obWFjU3RyZW5ndGggPSB0aGlzLmNvbnN0cnVjdG9yLmhtYWNTdHJlbmd0aDtcbiAgdGhpcy5wYWRMZW5ndGggPSB0aGlzLmNvbnN0cnVjdG9yLnBhZExlbmd0aCAvIDg7XG4gIHRoaXMuZW5kaWFuID0gJ2JpZyc7XG5cbiAgdGhpcy5fZGVsdGE4ID0gdGhpcy5ibG9ja1NpemUgLyA4O1xuICB0aGlzLl9kZWx0YTMyID0gdGhpcy5ibG9ja1NpemUgLyAzMjtcbn1cbmV4cG9ydHMuQmxvY2tIYXNoID0gQmxvY2tIYXNoO1xuXG5CbG9ja0hhc2gucHJvdG90eXBlLnVwZGF0ZSA9IGZ1bmN0aW9uIHVwZGF0ZShtc2csIGVuYykge1xuICAvLyBDb252ZXJ0IG1lc3NhZ2UgdG8gYXJyYXksIHBhZCBpdCwgYW5kIGpvaW4gaW50byAzMmJpdCBibG9ja3NcbiAgbXNnID0gdXRpbHMudG9BcnJheShtc2csIGVuYyk7XG4gIGlmICghdGhpcy5wZW5kaW5nKVxuICAgIHRoaXMucGVuZGluZyA9IG1zZztcbiAgZWxzZVxuICAgIHRoaXMucGVuZGluZyA9IHRoaXMucGVuZGluZy5jb25jYXQobXNnKTtcbiAgdGhpcy5wZW5kaW5nVG90YWwgKz0gbXNnLmxlbmd0aDtcblxuICAvLyBFbm91Z2ggZGF0YSwgdHJ5IHVwZGF0aW5nXG4gIGlmICh0aGlzLnBlbmRpbmcubGVuZ3RoID49IHRoaXMuX2RlbHRhOCkge1xuICAgIG1zZyA9IHRoaXMucGVuZGluZztcblxuICAgIC8vIFByb2Nlc3MgcGVuZGluZyBkYXRhIGluIGJsb2Nrc1xuICAgIHZhciByID0gbXNnLmxlbmd0aCAlIHRoaXMuX2RlbHRhODtcbiAgICB0aGlzLnBlbmRpbmcgPSBtc2cuc2xpY2UobXNnLmxlbmd0aCAtIHIsIG1zZy5sZW5ndGgpO1xuICAgIGlmICh0aGlzLnBlbmRpbmcubGVuZ3RoID09PSAwKVxuICAgICAgdGhpcy5wZW5kaW5nID0gbnVsbDtcblxuICAgIG1zZyA9IHV0aWxzLmpvaW4zMihtc2csIDAsIG1zZy5sZW5ndGggLSByLCB0aGlzLmVuZGlhbik7XG4gICAgZm9yICh2YXIgaSA9IDA7IGkgPCBtc2cubGVuZ3RoOyBpICs9IHRoaXMuX2RlbHRhMzIpXG4gICAgICB0aGlzLl91cGRhdGUobXNnLCBpLCBpICsgdGhpcy5fZGVsdGEzMik7XG4gIH1cblxuICByZXR1cm4gdGhpcztcbn07XG5cbkJsb2NrSGFzaC5wcm90b3R5cGUuZGlnZXN0ID0gZnVuY3Rpb24gZGlnZXN0KGVuYykge1xuICB0aGlzLnVwZGF0ZSh0aGlzLl9wYWQoKSk7XG4gIGFzc2VydCh0aGlzLnBlbmRpbmcgPT09IG51bGwpO1xuXG4gIHJldHVybiB0aGlzLl9kaWdlc3QoZW5jKTtcbn07XG5cbkJsb2NrSGFzaC5wcm90b3R5cGUuX3BhZCA9IGZ1bmN0aW9uIHBhZCgpIHtcbiAgdmFyIGxlbiA9IHRoaXMucGVuZGluZ1RvdGFsO1xuICB2YXIgYnl0ZXMgPSB0aGlzLl9kZWx0YTg7XG4gIHZhciBrID0gYnl0ZXMgLSAoKGxlbiArIHRoaXMucGFkTGVuZ3RoKSAlIGJ5dGVzKTtcbiAgdmFyIHJlcyA9IG5ldyBBcnJheShrICsgdGhpcy5wYWRMZW5ndGgpO1xuICByZXNbMF0gPSAweDgwO1xuICBmb3IgKHZhciBpID0gMTsgaSA8IGs7IGkrKylcbiAgICByZXNbaV0gPSAwO1xuXG4gIC8vIEFwcGVuZCBsZW5ndGhcbiAgbGVuIDw8PSAzO1xuICBpZiAodGhpcy5lbmRpYW4gPT09ICdiaWcnKSB7XG4gICAgZm9yICh2YXIgdCA9IDg7IHQgPCB0aGlzLnBhZExlbmd0aDsgdCsrKVxuICAgICAgcmVzW2krK10gPSAwO1xuXG4gICAgcmVzW2krK10gPSAwO1xuICAgIHJlc1tpKytdID0gMDtcbiAgICByZXNbaSsrXSA9IDA7XG4gICAgcmVzW2krK10gPSAwO1xuICAgIHJlc1tpKytdID0gKGxlbiA+Pj4gMjQpICYgMHhmZjtcbiAgICByZXNbaSsrXSA9IChsZW4gPj4+IDE2KSAmIDB4ZmY7XG4gICAgcmVzW2krK10gPSAobGVuID4+PiA4KSAmIDB4ZmY7XG4gICAgcmVzW2krK10gPSBsZW4gJiAweGZmO1xuICB9IGVsc2Uge1xuICAgIHJlc1tpKytdID0gbGVuICYgMHhmZjtcbiAgICByZXNbaSsrXSA9IChsZW4gPj4+IDgpICYgMHhmZjtcbiAgICByZXNbaSsrXSA9IChsZW4gPj4+IDE2KSAmIDB4ZmY7XG4gICAgcmVzW2krK10gPSAobGVuID4+PiAyNCkgJiAweGZmO1xuICAgIHJlc1tpKytdID0gMDtcbiAgICByZXNbaSsrXSA9IDA7XG4gICAgcmVzW2krK10gPSAwO1xuICAgIHJlc1tpKytdID0gMDtcblxuICAgIGZvciAodCA9IDg7IHQgPCB0aGlzLnBhZExlbmd0aDsgdCsrKVxuICAgICAgcmVzW2krK10gPSAwO1xuICB9XG5cbiAgcmV0dXJuIHJlcztcbn07XG4iLCAiJ3VzZSBzdHJpY3QnO1xuXG52YXIgdXRpbHMgPSByZXF1aXJlKCcuLi91dGlscycpO1xudmFyIHJvdHIzMiA9IHV0aWxzLnJvdHIzMjtcblxuZnVuY3Rpb24gZnRfMShzLCB4LCB5LCB6KSB7XG4gIGlmIChzID09PSAwKVxuICAgIHJldHVybiBjaDMyKHgsIHksIHopO1xuICBpZiAocyA9PT0gMSB8fCBzID09PSAzKVxuICAgIHJldHVybiBwMzIoeCwgeSwgeik7XG4gIGlmIChzID09PSAyKVxuICAgIHJldHVybiBtYWozMih4LCB5LCB6KTtcbn1cbmV4cG9ydHMuZnRfMSA9IGZ0XzE7XG5cbmZ1bmN0aW9uIGNoMzIoeCwgeSwgeikge1xuICByZXR1cm4gKHggJiB5KSBeICgofngpICYgeik7XG59XG5leHBvcnRzLmNoMzIgPSBjaDMyO1xuXG5mdW5jdGlvbiBtYWozMih4LCB5LCB6KSB7XG4gIHJldHVybiAoeCAmIHkpIF4gKHggJiB6KSBeICh5ICYgeik7XG59XG5leHBvcnRzLm1hajMyID0gbWFqMzI7XG5cbmZ1bmN0aW9uIHAzMih4LCB5LCB6KSB7XG4gIHJldHVybiB4IF4geSBeIHo7XG59XG5leHBvcnRzLnAzMiA9IHAzMjtcblxuZnVuY3Rpb24gczBfMjU2KHgpIHtcbiAgcmV0dXJuIHJvdHIzMih4LCAyKSBeIHJvdHIzMih4LCAxMykgXiByb3RyMzIoeCwgMjIpO1xufVxuZXhwb3J0cy5zMF8yNTYgPSBzMF8yNTY7XG5cbmZ1bmN0aW9uIHMxXzI1Nih4KSB7XG4gIHJldHVybiByb3RyMzIoeCwgNikgXiByb3RyMzIoeCwgMTEpIF4gcm90cjMyKHgsIDI1KTtcbn1cbmV4cG9ydHMuczFfMjU2ID0gczFfMjU2O1xuXG5mdW5jdGlvbiBnMF8yNTYoeCkge1xuICByZXR1cm4gcm90cjMyKHgsIDcpIF4gcm90cjMyKHgsIDE4KSBeICh4ID4+PiAzKTtcbn1cbmV4cG9ydHMuZzBfMjU2ID0gZzBfMjU2O1xuXG5mdW5jdGlvbiBnMV8yNTYoeCkge1xuICByZXR1cm4gcm90cjMyKHgsIDE3KSBeIHJvdHIzMih4LCAxOSkgXiAoeCA+Pj4gMTApO1xufVxuZXhwb3J0cy5nMV8yNTYgPSBnMV8yNTY7XG4iLCAiJ3VzZSBzdHJpY3QnO1xuXG52YXIgdXRpbHMgPSByZXF1aXJlKCcuLi91dGlscycpO1xudmFyIGNvbW1vbiA9IHJlcXVpcmUoJy4uL2NvbW1vbicpO1xudmFyIHNoYUNvbW1vbiA9IHJlcXVpcmUoJy4vY29tbW9uJyk7XG5cbnZhciByb3RsMzIgPSB1dGlscy5yb3RsMzI7XG52YXIgc3VtMzIgPSB1dGlscy5zdW0zMjtcbnZhciBzdW0zMl81ID0gdXRpbHMuc3VtMzJfNTtcbnZhciBmdF8xID0gc2hhQ29tbW9uLmZ0XzE7XG52YXIgQmxvY2tIYXNoID0gY29tbW9uLkJsb2NrSGFzaDtcblxudmFyIHNoYTFfSyA9IFtcbiAgMHg1QTgyNzk5OSwgMHg2RUQ5RUJBMSxcbiAgMHg4RjFCQkNEQywgMHhDQTYyQzFENlxuXTtcblxuZnVuY3Rpb24gU0hBMSgpIHtcbiAgaWYgKCEodGhpcyBpbnN0YW5jZW9mIFNIQTEpKVxuICAgIHJldHVybiBuZXcgU0hBMSgpO1xuXG4gIEJsb2NrSGFzaC5jYWxsKHRoaXMpO1xuICB0aGlzLmggPSBbXG4gICAgMHg2NzQ1MjMwMSwgMHhlZmNkYWI4OSwgMHg5OGJhZGNmZSxcbiAgICAweDEwMzI1NDc2LCAweGMzZDJlMWYwIF07XG4gIHRoaXMuVyA9IG5ldyBBcnJheSg4MCk7XG59XG5cbnV0aWxzLmluaGVyaXRzKFNIQTEsIEJsb2NrSGFzaCk7XG5tb2R1bGUuZXhwb3J0cyA9IFNIQTE7XG5cblNIQTEuYmxvY2tTaXplID0gNTEyO1xuU0hBMS5vdXRTaXplID0gMTYwO1xuU0hBMS5obWFjU3RyZW5ndGggPSA4MDtcblNIQTEucGFkTGVuZ3RoID0gNjQ7XG5cblNIQTEucHJvdG90eXBlLl91cGRhdGUgPSBmdW5jdGlvbiBfdXBkYXRlKG1zZywgc3RhcnQpIHtcbiAgdmFyIFcgPSB0aGlzLlc7XG5cbiAgZm9yICh2YXIgaSA9IDA7IGkgPCAxNjsgaSsrKVxuICAgIFdbaV0gPSBtc2dbc3RhcnQgKyBpXTtcblxuICBmb3IoOyBpIDwgVy5sZW5ndGg7IGkrKylcbiAgICBXW2ldID0gcm90bDMyKFdbaSAtIDNdIF4gV1tpIC0gOF0gXiBXW2kgLSAxNF0gXiBXW2kgLSAxNl0sIDEpO1xuXG4gIHZhciBhID0gdGhpcy5oWzBdO1xuICB2YXIgYiA9IHRoaXMuaFsxXTtcbiAgdmFyIGMgPSB0aGlzLmhbMl07XG4gIHZhciBkID0gdGhpcy5oWzNdO1xuICB2YXIgZSA9IHRoaXMuaFs0XTtcblxuICBmb3IgKGkgPSAwOyBpIDwgVy5sZW5ndGg7IGkrKykge1xuICAgIHZhciBzID0gfn4oaSAvIDIwKTtcbiAgICB2YXIgdCA9IHN1bTMyXzUocm90bDMyKGEsIDUpLCBmdF8xKHMsIGIsIGMsIGQpLCBlLCBXW2ldLCBzaGExX0tbc10pO1xuICAgIGUgPSBkO1xuICAgIGQgPSBjO1xuICAgIGMgPSByb3RsMzIoYiwgMzApO1xuICAgIGIgPSBhO1xuICAgIGEgPSB0O1xuICB9XG5cbiAgdGhpcy5oWzBdID0gc3VtMzIodGhpcy5oWzBdLCBhKTtcbiAgdGhpcy5oWzFdID0gc3VtMzIodGhpcy5oWzFdLCBiKTtcbiAgdGhpcy5oWzJdID0gc3VtMzIodGhpcy5oWzJdLCBjKTtcbiAgdGhpcy5oWzNdID0gc3VtMzIodGhpcy5oWzNdLCBkKTtcbiAgdGhpcy5oWzRdID0gc3VtMzIodGhpcy5oWzRdLCBlKTtcbn07XG5cblNIQTEucHJvdG90eXBlLl9kaWdlc3QgPSBmdW5jdGlvbiBkaWdlc3QoZW5jKSB7XG4gIGlmIChlbmMgPT09ICdoZXgnKVxuICAgIHJldHVybiB1dGlscy50b0hleDMyKHRoaXMuaCwgJ2JpZycpO1xuICBlbHNlXG4gICAgcmV0dXJuIHV0aWxzLnNwbGl0MzIodGhpcy5oLCAnYmlnJyk7XG59O1xuIiwgIid1c2Ugc3RyaWN0JztcblxudmFyIHV0aWxzID0gcmVxdWlyZSgnLi4vdXRpbHMnKTtcbnZhciBjb21tb24gPSByZXF1aXJlKCcuLi9jb21tb24nKTtcbnZhciBzaGFDb21tb24gPSByZXF1aXJlKCcuL2NvbW1vbicpO1xudmFyIGFzc2VydCA9IHJlcXVpcmUoJ21pbmltYWxpc3RpYy1hc3NlcnQnKTtcblxudmFyIHN1bTMyID0gdXRpbHMuc3VtMzI7XG52YXIgc3VtMzJfNCA9IHV0aWxzLnN1bTMyXzQ7XG52YXIgc3VtMzJfNSA9IHV0aWxzLnN1bTMyXzU7XG52YXIgY2gzMiA9IHNoYUNvbW1vbi5jaDMyO1xudmFyIG1hajMyID0gc2hhQ29tbW9uLm1hajMyO1xudmFyIHMwXzI1NiA9IHNoYUNvbW1vbi5zMF8yNTY7XG52YXIgczFfMjU2ID0gc2hhQ29tbW9uLnMxXzI1NjtcbnZhciBnMF8yNTYgPSBzaGFDb21tb24uZzBfMjU2O1xudmFyIGcxXzI1NiA9IHNoYUNvbW1vbi5nMV8yNTY7XG5cbnZhciBCbG9ja0hhc2ggPSBjb21tb24uQmxvY2tIYXNoO1xuXG52YXIgc2hhMjU2X0sgPSBbXG4gIDB4NDI4YTJmOTgsIDB4NzEzNzQ0OTEsIDB4YjVjMGZiY2YsIDB4ZTliNWRiYTUsXG4gIDB4Mzk1NmMyNWIsIDB4NTlmMTExZjEsIDB4OTIzZjgyYTQsIDB4YWIxYzVlZDUsXG4gIDB4ZDgwN2FhOTgsIDB4MTI4MzViMDEsIDB4MjQzMTg1YmUsIDB4NTUwYzdkYzMsXG4gIDB4NzJiZTVkNzQsIDB4ODBkZWIxZmUsIDB4OWJkYzA2YTcsIDB4YzE5YmYxNzQsXG4gIDB4ZTQ5YjY5YzEsIDB4ZWZiZTQ3ODYsIDB4MGZjMTlkYzYsIDB4MjQwY2ExY2MsXG4gIDB4MmRlOTJjNmYsIDB4NGE3NDg0YWEsIDB4NWNiMGE5ZGMsIDB4NzZmOTg4ZGEsXG4gIDB4OTgzZTUxNTIsIDB4YTgzMWM2NmQsIDB4YjAwMzI3YzgsIDB4YmY1OTdmYzcsXG4gIDB4YzZlMDBiZjMsIDB4ZDVhNzkxNDcsIDB4MDZjYTYzNTEsIDB4MTQyOTI5NjcsXG4gIDB4MjdiNzBhODUsIDB4MmUxYjIxMzgsIDB4NGQyYzZkZmMsIDB4NTMzODBkMTMsXG4gIDB4NjUwYTczNTQsIDB4NzY2YTBhYmIsIDB4ODFjMmM5MmUsIDB4OTI3MjJjODUsXG4gIDB4YTJiZmU4YTEsIDB4YTgxYTY2NGIsIDB4YzI0YjhiNzAsIDB4Yzc2YzUxYTMsXG4gIDB4ZDE5MmU4MTksIDB4ZDY5OTA2MjQsIDB4ZjQwZTM1ODUsIDB4MTA2YWEwNzAsXG4gIDB4MTlhNGMxMTYsIDB4MWUzNzZjMDgsIDB4Mjc0ODc3NGMsIDB4MzRiMGJjYjUsXG4gIDB4MzkxYzBjYjMsIDB4NGVkOGFhNGEsIDB4NWI5Y2NhNGYsIDB4NjgyZTZmZjMsXG4gIDB4NzQ4ZjgyZWUsIDB4NzhhNTYzNmYsIDB4ODRjODc4MTQsIDB4OGNjNzAyMDgsXG4gIDB4OTBiZWZmZmEsIDB4YTQ1MDZjZWIsIDB4YmVmOWEzZjcsIDB4YzY3MTc4ZjJcbl07XG5cbmZ1bmN0aW9uIFNIQTI1NigpIHtcbiAgaWYgKCEodGhpcyBpbnN0YW5jZW9mIFNIQTI1NikpXG4gICAgcmV0dXJuIG5ldyBTSEEyNTYoKTtcblxuICBCbG9ja0hhc2guY2FsbCh0aGlzKTtcbiAgdGhpcy5oID0gW1xuICAgIDB4NmEwOWU2NjcsIDB4YmI2N2FlODUsIDB4M2M2ZWYzNzIsIDB4YTU0ZmY1M2EsXG4gICAgMHg1MTBlNTI3ZiwgMHg5YjA1Njg4YywgMHgxZjgzZDlhYiwgMHg1YmUwY2QxOVxuICBdO1xuICB0aGlzLmsgPSBzaGEyNTZfSztcbiAgdGhpcy5XID0gbmV3IEFycmF5KDY0KTtcbn1cbnV0aWxzLmluaGVyaXRzKFNIQTI1NiwgQmxvY2tIYXNoKTtcbm1vZHVsZS5leHBvcnRzID0gU0hBMjU2O1xuXG5TSEEyNTYuYmxvY2tTaXplID0gNTEyO1xuU0hBMjU2Lm91dFNpemUgPSAyNTY7XG5TSEEyNTYuaG1hY1N0cmVuZ3RoID0gMTkyO1xuU0hBMjU2LnBhZExlbmd0aCA9IDY0O1xuXG5TSEEyNTYucHJvdG90eXBlLl91cGRhdGUgPSBmdW5jdGlvbiBfdXBkYXRlKG1zZywgc3RhcnQpIHtcbiAgdmFyIFcgPSB0aGlzLlc7XG5cbiAgZm9yICh2YXIgaSA9IDA7IGkgPCAxNjsgaSsrKVxuICAgIFdbaV0gPSBtc2dbc3RhcnQgKyBpXTtcbiAgZm9yICg7IGkgPCBXLmxlbmd0aDsgaSsrKVxuICAgIFdbaV0gPSBzdW0zMl80KGcxXzI1NihXW2kgLSAyXSksIFdbaSAtIDddLCBnMF8yNTYoV1tpIC0gMTVdKSwgV1tpIC0gMTZdKTtcblxuICB2YXIgYSA9IHRoaXMuaFswXTtcbiAgdmFyIGIgPSB0aGlzLmhbMV07XG4gIHZhciBjID0gdGhpcy5oWzJdO1xuICB2YXIgZCA9IHRoaXMuaFszXTtcbiAgdmFyIGUgPSB0aGlzLmhbNF07XG4gIHZhciBmID0gdGhpcy5oWzVdO1xuICB2YXIgZyA9IHRoaXMuaFs2XTtcbiAgdmFyIGggPSB0aGlzLmhbN107XG5cbiAgYXNzZXJ0KHRoaXMuay5sZW5ndGggPT09IFcubGVuZ3RoKTtcbiAgZm9yIChpID0gMDsgaSA8IFcubGVuZ3RoOyBpKyspIHtcbiAgICB2YXIgVDEgPSBzdW0zMl81KGgsIHMxXzI1NihlKSwgY2gzMihlLCBmLCBnKSwgdGhpcy5rW2ldLCBXW2ldKTtcbiAgICB2YXIgVDIgPSBzdW0zMihzMF8yNTYoYSksIG1hajMyKGEsIGIsIGMpKTtcbiAgICBoID0gZztcbiAgICBnID0gZjtcbiAgICBmID0gZTtcbiAgICBlID0gc3VtMzIoZCwgVDEpO1xuICAgIGQgPSBjO1xuICAgIGMgPSBiO1xuICAgIGIgPSBhO1xuICAgIGEgPSBzdW0zMihUMSwgVDIpO1xuICB9XG5cbiAgdGhpcy5oWzBdID0gc3VtMzIodGhpcy5oWzBdLCBhKTtcbiAgdGhpcy5oWzFdID0gc3VtMzIodGhpcy5oWzFdLCBiKTtcbiAgdGhpcy5oWzJdID0gc3VtMzIodGhpcy5oWzJdLCBjKTtcbiAgdGhpcy5oWzNdID0gc3VtMzIodGhpcy5oWzNdLCBkKTtcbiAgdGhpcy5oWzRdID0gc3VtMzIodGhpcy5oWzRdLCBlKTtcbiAgdGhpcy5oWzVdID0gc3VtMzIodGhpcy5oWzVdLCBmKTtcbiAgdGhpcy5oWzZdID0gc3VtMzIodGhpcy5oWzZdLCBnKTtcbiAgdGhpcy5oWzddID0gc3VtMzIodGhpcy5oWzddLCBoKTtcbn07XG5cblNIQTI1Ni5wcm90b3R5cGUuX2RpZ2VzdCA9IGZ1bmN0aW9uIGRpZ2VzdChlbmMpIHtcbiAgaWYgKGVuYyA9PT0gJ2hleCcpXG4gICAgcmV0dXJuIHV0aWxzLnRvSGV4MzIodGhpcy5oLCAnYmlnJyk7XG4gIGVsc2VcbiAgICByZXR1cm4gdXRpbHMuc3BsaXQzMih0aGlzLmgsICdiaWcnKTtcbn07XG4iLCAiJ3VzZSBzdHJpY3QnO1xuXG52YXIgdXRpbHMgPSByZXF1aXJlKCcuLi91dGlscycpO1xudmFyIFNIQTI1NiA9IHJlcXVpcmUoJy4vMjU2Jyk7XG5cbmZ1bmN0aW9uIFNIQTIyNCgpIHtcbiAgaWYgKCEodGhpcyBpbnN0YW5jZW9mIFNIQTIyNCkpXG4gICAgcmV0dXJuIG5ldyBTSEEyMjQoKTtcblxuICBTSEEyNTYuY2FsbCh0aGlzKTtcbiAgdGhpcy5oID0gW1xuICAgIDB4YzEwNTllZDgsIDB4MzY3Y2Q1MDcsIDB4MzA3MGRkMTcsIDB4ZjcwZTU5MzksXG4gICAgMHhmZmMwMGIzMSwgMHg2ODU4MTUxMSwgMHg2NGY5OGZhNywgMHhiZWZhNGZhNCBdO1xufVxudXRpbHMuaW5oZXJpdHMoU0hBMjI0LCBTSEEyNTYpO1xubW9kdWxlLmV4cG9ydHMgPSBTSEEyMjQ7XG5cblNIQTIyNC5ibG9ja1NpemUgPSA1MTI7XG5TSEEyMjQub3V0U2l6ZSA9IDIyNDtcblNIQTIyNC5obWFjU3RyZW5ndGggPSAxOTI7XG5TSEEyMjQucGFkTGVuZ3RoID0gNjQ7XG5cblNIQTIyNC5wcm90b3R5cGUuX2RpZ2VzdCA9IGZ1bmN0aW9uIGRpZ2VzdChlbmMpIHtcbiAgLy8gSnVzdCB0cnVuY2F0ZSBvdXRwdXRcbiAgaWYgKGVuYyA9PT0gJ2hleCcpXG4gICAgcmV0dXJuIHV0aWxzLnRvSGV4MzIodGhpcy5oLnNsaWNlKDAsIDcpLCAnYmlnJyk7XG4gIGVsc2VcbiAgICByZXR1cm4gdXRpbHMuc3BsaXQzMih0aGlzLmguc2xpY2UoMCwgNyksICdiaWcnKTtcbn07XG5cbiIsICIndXNlIHN0cmljdCc7XG5cbnZhciB1dGlscyA9IHJlcXVpcmUoJy4uL3V0aWxzJyk7XG52YXIgY29tbW9uID0gcmVxdWlyZSgnLi4vY29tbW9uJyk7XG52YXIgYXNzZXJ0ID0gcmVxdWlyZSgnbWluaW1hbGlzdGljLWFzc2VydCcpO1xuXG52YXIgcm90cjY0X2hpID0gdXRpbHMucm90cjY0X2hpO1xudmFyIHJvdHI2NF9sbyA9IHV0aWxzLnJvdHI2NF9sbztcbnZhciBzaHI2NF9oaSA9IHV0aWxzLnNocjY0X2hpO1xudmFyIHNocjY0X2xvID0gdXRpbHMuc2hyNjRfbG87XG52YXIgc3VtNjQgPSB1dGlscy5zdW02NDtcbnZhciBzdW02NF9oaSA9IHV0aWxzLnN1bTY0X2hpO1xudmFyIHN1bTY0X2xvID0gdXRpbHMuc3VtNjRfbG87XG52YXIgc3VtNjRfNF9oaSA9IHV0aWxzLnN1bTY0XzRfaGk7XG52YXIgc3VtNjRfNF9sbyA9IHV0aWxzLnN1bTY0XzRfbG87XG52YXIgc3VtNjRfNV9oaSA9IHV0aWxzLnN1bTY0XzVfaGk7XG52YXIgc3VtNjRfNV9sbyA9IHV0aWxzLnN1bTY0XzVfbG87XG5cbnZhciBCbG9ja0hhc2ggPSBjb21tb24uQmxvY2tIYXNoO1xuXG52YXIgc2hhNTEyX0sgPSBbXG4gIDB4NDI4YTJmOTgsIDB4ZDcyOGFlMjIsIDB4NzEzNzQ0OTEsIDB4MjNlZjY1Y2QsXG4gIDB4YjVjMGZiY2YsIDB4ZWM0ZDNiMmYsIDB4ZTliNWRiYTUsIDB4ODE4OWRiYmMsXG4gIDB4Mzk1NmMyNWIsIDB4ZjM0OGI1MzgsIDB4NTlmMTExZjEsIDB4YjYwNWQwMTksXG4gIDB4OTIzZjgyYTQsIDB4YWYxOTRmOWIsIDB4YWIxYzVlZDUsIDB4ZGE2ZDgxMTgsXG4gIDB4ZDgwN2FhOTgsIDB4YTMwMzAyNDIsIDB4MTI4MzViMDEsIDB4NDU3MDZmYmUsXG4gIDB4MjQzMTg1YmUsIDB4NGVlNGIyOGMsIDB4NTUwYzdkYzMsIDB4ZDVmZmI0ZTIsXG4gIDB4NzJiZTVkNzQsIDB4ZjI3Yjg5NmYsIDB4ODBkZWIxZmUsIDB4M2IxNjk2YjEsXG4gIDB4OWJkYzA2YTcsIDB4MjVjNzEyMzUsIDB4YzE5YmYxNzQsIDB4Y2Y2OTI2OTQsXG4gIDB4ZTQ5YjY5YzEsIDB4OWVmMTRhZDIsIDB4ZWZiZTQ3ODYsIDB4Mzg0ZjI1ZTMsXG4gIDB4MGZjMTlkYzYsIDB4OGI4Y2Q1YjUsIDB4MjQwY2ExY2MsIDB4NzdhYzljNjUsXG4gIDB4MmRlOTJjNmYsIDB4NTkyYjAyNzUsIDB4NGE3NDg0YWEsIDB4NmVhNmU0ODMsXG4gIDB4NWNiMGE5ZGMsIDB4YmQ0MWZiZDQsIDB4NzZmOTg4ZGEsIDB4ODMxMTUzYjUsXG4gIDB4OTgzZTUxNTIsIDB4ZWU2NmRmYWIsIDB4YTgzMWM2NmQsIDB4MmRiNDMyMTAsXG4gIDB4YjAwMzI3YzgsIDB4OThmYjIxM2YsIDB4YmY1OTdmYzcsIDB4YmVlZjBlZTQsXG4gIDB4YzZlMDBiZjMsIDB4M2RhODhmYzIsIDB4ZDVhNzkxNDcsIDB4OTMwYWE3MjUsXG4gIDB4MDZjYTYzNTEsIDB4ZTAwMzgyNmYsIDB4MTQyOTI5NjcsIDB4MGEwZTZlNzAsXG4gIDB4MjdiNzBhODUsIDB4NDZkMjJmZmMsIDB4MmUxYjIxMzgsIDB4NWMyNmM5MjYsXG4gIDB4NGQyYzZkZmMsIDB4NWFjNDJhZWQsIDB4NTMzODBkMTMsIDB4OWQ5NWIzZGYsXG4gIDB4NjUwYTczNTQsIDB4OGJhZjYzZGUsIDB4NzY2YTBhYmIsIDB4M2M3N2IyYTgsXG4gIDB4ODFjMmM5MmUsIDB4NDdlZGFlZTYsIDB4OTI3MjJjODUsIDB4MTQ4MjM1M2IsXG4gIDB4YTJiZmU4YTEsIDB4NGNmMTAzNjQsIDB4YTgxYTY2NGIsIDB4YmM0MjMwMDEsXG4gIDB4YzI0YjhiNzAsIDB4ZDBmODk3OTEsIDB4Yzc2YzUxYTMsIDB4MDY1NGJlMzAsXG4gIDB4ZDE5MmU4MTksIDB4ZDZlZjUyMTgsIDB4ZDY5OTA2MjQsIDB4NTU2NWE5MTAsXG4gIDB4ZjQwZTM1ODUsIDB4NTc3MTIwMmEsIDB4MTA2YWEwNzAsIDB4MzJiYmQxYjgsXG4gIDB4MTlhNGMxMTYsIDB4YjhkMmQwYzgsIDB4MWUzNzZjMDgsIDB4NTE0MWFiNTMsXG4gIDB4Mjc0ODc3NGMsIDB4ZGY4ZWViOTksIDB4MzRiMGJjYjUsIDB4ZTE5YjQ4YTgsXG4gIDB4MzkxYzBjYjMsIDB4YzVjOTVhNjMsIDB4NGVkOGFhNGEsIDB4ZTM0MThhY2IsXG4gIDB4NWI5Y2NhNGYsIDB4Nzc2M2UzNzMsIDB4NjgyZTZmZjMsIDB4ZDZiMmI4YTMsXG4gIDB4NzQ4ZjgyZWUsIDB4NWRlZmIyZmMsIDB4NzhhNTYzNmYsIDB4NDMxNzJmNjAsXG4gIDB4ODRjODc4MTQsIDB4YTFmMGFiNzIsIDB4OGNjNzAyMDgsIDB4MWE2NDM5ZWMsXG4gIDB4OTBiZWZmZmEsIDB4MjM2MzFlMjgsIDB4YTQ1MDZjZWIsIDB4ZGU4MmJkZTksXG4gIDB4YmVmOWEzZjcsIDB4YjJjNjc5MTUsIDB4YzY3MTc4ZjIsIDB4ZTM3MjUzMmIsXG4gIDB4Y2EyNzNlY2UsIDB4ZWEyNjYxOWMsIDB4ZDE4NmI4YzcsIDB4MjFjMGMyMDcsXG4gIDB4ZWFkYTdkZDYsIDB4Y2RlMGViMWUsIDB4ZjU3ZDRmN2YsIDB4ZWU2ZWQxNzgsXG4gIDB4MDZmMDY3YWEsIDB4NzIxNzZmYmEsIDB4MGE2MzdkYzUsIDB4YTJjODk4YTYsXG4gIDB4MTEzZjk4MDQsIDB4YmVmOTBkYWUsIDB4MWI3MTBiMzUsIDB4MTMxYzQ3MWIsXG4gIDB4MjhkYjc3ZjUsIDB4MjMwNDdkODQsIDB4MzJjYWFiN2IsIDB4NDBjNzI0OTMsXG4gIDB4M2M5ZWJlMGEsIDB4MTVjOWJlYmMsIDB4NDMxZDY3YzQsIDB4OWMxMDBkNGMsXG4gIDB4NGNjNWQ0YmUsIDB4Y2IzZTQyYjYsIDB4NTk3ZjI5OWMsIDB4ZmM2NTdlMmEsXG4gIDB4NWZjYjZmYWIsIDB4M2FkNmZhZWMsIDB4NmM0NDE5OGMsIDB4NGE0NzU4MTdcbl07XG5cbmZ1bmN0aW9uIFNIQTUxMigpIHtcbiAgaWYgKCEodGhpcyBpbnN0YW5jZW9mIFNIQTUxMikpXG4gICAgcmV0dXJuIG5ldyBTSEE1MTIoKTtcblxuICBCbG9ja0hhc2guY2FsbCh0aGlzKTtcbiAgdGhpcy5oID0gW1xuICAgIDB4NmEwOWU2NjcsIDB4ZjNiY2M5MDgsXG4gICAgMHhiYjY3YWU4NSwgMHg4NGNhYTczYixcbiAgICAweDNjNmVmMzcyLCAweGZlOTRmODJiLFxuICAgIDB4YTU0ZmY1M2EsIDB4NWYxZDM2ZjEsXG4gICAgMHg1MTBlNTI3ZiwgMHhhZGU2ODJkMSxcbiAgICAweDliMDU2ODhjLCAweDJiM2U2YzFmLFxuICAgIDB4MWY4M2Q5YWIsIDB4ZmI0MWJkNmIsXG4gICAgMHg1YmUwY2QxOSwgMHgxMzdlMjE3OSBdO1xuICB0aGlzLmsgPSBzaGE1MTJfSztcbiAgdGhpcy5XID0gbmV3IEFycmF5KDE2MCk7XG59XG51dGlscy5pbmhlcml0cyhTSEE1MTIsIEJsb2NrSGFzaCk7XG5tb2R1bGUuZXhwb3J0cyA9IFNIQTUxMjtcblxuU0hBNTEyLmJsb2NrU2l6ZSA9IDEwMjQ7XG5TSEE1MTIub3V0U2l6ZSA9IDUxMjtcblNIQTUxMi5obWFjU3RyZW5ndGggPSAxOTI7XG5TSEE1MTIucGFkTGVuZ3RoID0gMTI4O1xuXG5TSEE1MTIucHJvdG90eXBlLl9wcmVwYXJlQmxvY2sgPSBmdW5jdGlvbiBfcHJlcGFyZUJsb2NrKG1zZywgc3RhcnQpIHtcbiAgdmFyIFcgPSB0aGlzLlc7XG5cbiAgLy8gMzIgeCAzMmJpdCB3b3Jkc1xuICBmb3IgKHZhciBpID0gMDsgaSA8IDMyOyBpKyspXG4gICAgV1tpXSA9IG1zZ1tzdGFydCArIGldO1xuICBmb3IgKDsgaSA8IFcubGVuZ3RoOyBpICs9IDIpIHtcbiAgICB2YXIgYzBfaGkgPSBnMV81MTJfaGkoV1tpIC0gNF0sIFdbaSAtIDNdKTsgIC8vIGkgLSAyXG4gICAgdmFyIGMwX2xvID0gZzFfNTEyX2xvKFdbaSAtIDRdLCBXW2kgLSAzXSk7XG4gICAgdmFyIGMxX2hpID0gV1tpIC0gMTRdOyAgLy8gaSAtIDdcbiAgICB2YXIgYzFfbG8gPSBXW2kgLSAxM107XG4gICAgdmFyIGMyX2hpID0gZzBfNTEyX2hpKFdbaSAtIDMwXSwgV1tpIC0gMjldKTsgIC8vIGkgLSAxNVxuICAgIHZhciBjMl9sbyA9IGcwXzUxMl9sbyhXW2kgLSAzMF0sIFdbaSAtIDI5XSk7XG4gICAgdmFyIGMzX2hpID0gV1tpIC0gMzJdOyAgLy8gaSAtIDE2XG4gICAgdmFyIGMzX2xvID0gV1tpIC0gMzFdO1xuXG4gICAgV1tpXSA9IHN1bTY0XzRfaGkoXG4gICAgICBjMF9oaSwgYzBfbG8sXG4gICAgICBjMV9oaSwgYzFfbG8sXG4gICAgICBjMl9oaSwgYzJfbG8sXG4gICAgICBjM19oaSwgYzNfbG8pO1xuICAgIFdbaSArIDFdID0gc3VtNjRfNF9sbyhcbiAgICAgIGMwX2hpLCBjMF9sbyxcbiAgICAgIGMxX2hpLCBjMV9sbyxcbiAgICAgIGMyX2hpLCBjMl9sbyxcbiAgICAgIGMzX2hpLCBjM19sbyk7XG4gIH1cbn07XG5cblNIQTUxMi5wcm90b3R5cGUuX3VwZGF0ZSA9IGZ1bmN0aW9uIF91cGRhdGUobXNnLCBzdGFydCkge1xuICB0aGlzLl9wcmVwYXJlQmxvY2sobXNnLCBzdGFydCk7XG5cbiAgdmFyIFcgPSB0aGlzLlc7XG5cbiAgdmFyIGFoID0gdGhpcy5oWzBdO1xuICB2YXIgYWwgPSB0aGlzLmhbMV07XG4gIHZhciBiaCA9IHRoaXMuaFsyXTtcbiAgdmFyIGJsID0gdGhpcy5oWzNdO1xuICB2YXIgY2ggPSB0aGlzLmhbNF07XG4gIHZhciBjbCA9IHRoaXMuaFs1XTtcbiAgdmFyIGRoID0gdGhpcy5oWzZdO1xuICB2YXIgZGwgPSB0aGlzLmhbN107XG4gIHZhciBlaCA9IHRoaXMuaFs4XTtcbiAgdmFyIGVsID0gdGhpcy5oWzldO1xuICB2YXIgZmggPSB0aGlzLmhbMTBdO1xuICB2YXIgZmwgPSB0aGlzLmhbMTFdO1xuICB2YXIgZ2ggPSB0aGlzLmhbMTJdO1xuICB2YXIgZ2wgPSB0aGlzLmhbMTNdO1xuICB2YXIgaGggPSB0aGlzLmhbMTRdO1xuICB2YXIgaGwgPSB0aGlzLmhbMTVdO1xuXG4gIGFzc2VydCh0aGlzLmsubGVuZ3RoID09PSBXLmxlbmd0aCk7XG4gIGZvciAodmFyIGkgPSAwOyBpIDwgVy5sZW5ndGg7IGkgKz0gMikge1xuICAgIHZhciBjMF9oaSA9IGhoO1xuICAgIHZhciBjMF9sbyA9IGhsO1xuICAgIHZhciBjMV9oaSA9IHMxXzUxMl9oaShlaCwgZWwpO1xuICAgIHZhciBjMV9sbyA9IHMxXzUxMl9sbyhlaCwgZWwpO1xuICAgIHZhciBjMl9oaSA9IGNoNjRfaGkoZWgsIGVsLCBmaCwgZmwsIGdoLCBnbCk7XG4gICAgdmFyIGMyX2xvID0gY2g2NF9sbyhlaCwgZWwsIGZoLCBmbCwgZ2gsIGdsKTtcbiAgICB2YXIgYzNfaGkgPSB0aGlzLmtbaV07XG4gICAgdmFyIGMzX2xvID0gdGhpcy5rW2kgKyAxXTtcbiAgICB2YXIgYzRfaGkgPSBXW2ldO1xuICAgIHZhciBjNF9sbyA9IFdbaSArIDFdO1xuXG4gICAgdmFyIFQxX2hpID0gc3VtNjRfNV9oaShcbiAgICAgIGMwX2hpLCBjMF9sbyxcbiAgICAgIGMxX2hpLCBjMV9sbyxcbiAgICAgIGMyX2hpLCBjMl9sbyxcbiAgICAgIGMzX2hpLCBjM19sbyxcbiAgICAgIGM0X2hpLCBjNF9sbyk7XG4gICAgdmFyIFQxX2xvID0gc3VtNjRfNV9sbyhcbiAgICAgIGMwX2hpLCBjMF9sbyxcbiAgICAgIGMxX2hpLCBjMV9sbyxcbiAgICAgIGMyX2hpLCBjMl9sbyxcbiAgICAgIGMzX2hpLCBjM19sbyxcbiAgICAgIGM0X2hpLCBjNF9sbyk7XG5cbiAgICBjMF9oaSA9IHMwXzUxMl9oaShhaCwgYWwpO1xuICAgIGMwX2xvID0gczBfNTEyX2xvKGFoLCBhbCk7XG4gICAgYzFfaGkgPSBtYWo2NF9oaShhaCwgYWwsIGJoLCBibCwgY2gsIGNsKTtcbiAgICBjMV9sbyA9IG1hajY0X2xvKGFoLCBhbCwgYmgsIGJsLCBjaCwgY2wpO1xuXG4gICAgdmFyIFQyX2hpID0gc3VtNjRfaGkoYzBfaGksIGMwX2xvLCBjMV9oaSwgYzFfbG8pO1xuICAgIHZhciBUMl9sbyA9IHN1bTY0X2xvKGMwX2hpLCBjMF9sbywgYzFfaGksIGMxX2xvKTtcblxuICAgIGhoID0gZ2g7XG4gICAgaGwgPSBnbDtcblxuICAgIGdoID0gZmg7XG4gICAgZ2wgPSBmbDtcblxuICAgIGZoID0gZWg7XG4gICAgZmwgPSBlbDtcblxuICAgIGVoID0gc3VtNjRfaGkoZGgsIGRsLCBUMV9oaSwgVDFfbG8pO1xuICAgIGVsID0gc3VtNjRfbG8oZGwsIGRsLCBUMV9oaSwgVDFfbG8pO1xuXG4gICAgZGggPSBjaDtcbiAgICBkbCA9IGNsO1xuXG4gICAgY2ggPSBiaDtcbiAgICBjbCA9IGJsO1xuXG4gICAgYmggPSBhaDtcbiAgICBibCA9IGFsO1xuXG4gICAgYWggPSBzdW02NF9oaShUMV9oaSwgVDFfbG8sIFQyX2hpLCBUMl9sbyk7XG4gICAgYWwgPSBzdW02NF9sbyhUMV9oaSwgVDFfbG8sIFQyX2hpLCBUMl9sbyk7XG4gIH1cblxuICBzdW02NCh0aGlzLmgsIDAsIGFoLCBhbCk7XG4gIHN1bTY0KHRoaXMuaCwgMiwgYmgsIGJsKTtcbiAgc3VtNjQodGhpcy5oLCA0LCBjaCwgY2wpO1xuICBzdW02NCh0aGlzLmgsIDYsIGRoLCBkbCk7XG4gIHN1bTY0KHRoaXMuaCwgOCwgZWgsIGVsKTtcbiAgc3VtNjQodGhpcy5oLCAxMCwgZmgsIGZsKTtcbiAgc3VtNjQodGhpcy5oLCAxMiwgZ2gsIGdsKTtcbiAgc3VtNjQodGhpcy5oLCAxNCwgaGgsIGhsKTtcbn07XG5cblNIQTUxMi5wcm90b3R5cGUuX2RpZ2VzdCA9IGZ1bmN0aW9uIGRpZ2VzdChlbmMpIHtcbiAgaWYgKGVuYyA9PT0gJ2hleCcpXG4gICAgcmV0dXJuIHV0aWxzLnRvSGV4MzIodGhpcy5oLCAnYmlnJyk7XG4gIGVsc2VcbiAgICByZXR1cm4gdXRpbHMuc3BsaXQzMih0aGlzLmgsICdiaWcnKTtcbn07XG5cbmZ1bmN0aW9uIGNoNjRfaGkoeGgsIHhsLCB5aCwgeWwsIHpoKSB7XG4gIHZhciByID0gKHhoICYgeWgpIF4gKCh+eGgpICYgemgpO1xuICBpZiAociA8IDApXG4gICAgciArPSAweDEwMDAwMDAwMDtcbiAgcmV0dXJuIHI7XG59XG5cbmZ1bmN0aW9uIGNoNjRfbG8oeGgsIHhsLCB5aCwgeWwsIHpoLCB6bCkge1xuICB2YXIgciA9ICh4bCAmIHlsKSBeICgofnhsKSAmIHpsKTtcbiAgaWYgKHIgPCAwKVxuICAgIHIgKz0gMHgxMDAwMDAwMDA7XG4gIHJldHVybiByO1xufVxuXG5mdW5jdGlvbiBtYWo2NF9oaSh4aCwgeGwsIHloLCB5bCwgemgpIHtcbiAgdmFyIHIgPSAoeGggJiB5aCkgXiAoeGggJiB6aCkgXiAoeWggJiB6aCk7XG4gIGlmIChyIDwgMClcbiAgICByICs9IDB4MTAwMDAwMDAwO1xuICByZXR1cm4gcjtcbn1cblxuZnVuY3Rpb24gbWFqNjRfbG8oeGgsIHhsLCB5aCwgeWwsIHpoLCB6bCkge1xuICB2YXIgciA9ICh4bCAmIHlsKSBeICh4bCAmIHpsKSBeICh5bCAmIHpsKTtcbiAgaWYgKHIgPCAwKVxuICAgIHIgKz0gMHgxMDAwMDAwMDA7XG4gIHJldHVybiByO1xufVxuXG5mdW5jdGlvbiBzMF81MTJfaGkoeGgsIHhsKSB7XG4gIHZhciBjMF9oaSA9IHJvdHI2NF9oaSh4aCwgeGwsIDI4KTtcbiAgdmFyIGMxX2hpID0gcm90cjY0X2hpKHhsLCB4aCwgMik7ICAvLyAzNFxuICB2YXIgYzJfaGkgPSByb3RyNjRfaGkoeGwsIHhoLCA3KTsgIC8vIDM5XG5cbiAgdmFyIHIgPSBjMF9oaSBeIGMxX2hpIF4gYzJfaGk7XG4gIGlmIChyIDwgMClcbiAgICByICs9IDB4MTAwMDAwMDAwO1xuICByZXR1cm4gcjtcbn1cblxuZnVuY3Rpb24gczBfNTEyX2xvKHhoLCB4bCkge1xuICB2YXIgYzBfbG8gPSByb3RyNjRfbG8oeGgsIHhsLCAyOCk7XG4gIHZhciBjMV9sbyA9IHJvdHI2NF9sbyh4bCwgeGgsIDIpOyAgLy8gMzRcbiAgdmFyIGMyX2xvID0gcm90cjY0X2xvKHhsLCB4aCwgNyk7ICAvLyAzOVxuXG4gIHZhciByID0gYzBfbG8gXiBjMV9sbyBeIGMyX2xvO1xuICBpZiAociA8IDApXG4gICAgciArPSAweDEwMDAwMDAwMDtcbiAgcmV0dXJuIHI7XG59XG5cbmZ1bmN0aW9uIHMxXzUxMl9oaSh4aCwgeGwpIHtcbiAgdmFyIGMwX2hpID0gcm90cjY0X2hpKHhoLCB4bCwgMTQpO1xuICB2YXIgYzFfaGkgPSByb3RyNjRfaGkoeGgsIHhsLCAxOCk7XG4gIHZhciBjMl9oaSA9IHJvdHI2NF9oaSh4bCwgeGgsIDkpOyAgLy8gNDFcblxuICB2YXIgciA9IGMwX2hpIF4gYzFfaGkgXiBjMl9oaTtcbiAgaWYgKHIgPCAwKVxuICAgIHIgKz0gMHgxMDAwMDAwMDA7XG4gIHJldHVybiByO1xufVxuXG5mdW5jdGlvbiBzMV81MTJfbG8oeGgsIHhsKSB7XG4gIHZhciBjMF9sbyA9IHJvdHI2NF9sbyh4aCwgeGwsIDE0KTtcbiAgdmFyIGMxX2xvID0gcm90cjY0X2xvKHhoLCB4bCwgMTgpO1xuICB2YXIgYzJfbG8gPSByb3RyNjRfbG8oeGwsIHhoLCA5KTsgIC8vIDQxXG5cbiAgdmFyIHIgPSBjMF9sbyBeIGMxX2xvIF4gYzJfbG87XG4gIGlmIChyIDwgMClcbiAgICByICs9IDB4MTAwMDAwMDAwO1xuICByZXR1cm4gcjtcbn1cblxuZnVuY3Rpb24gZzBfNTEyX2hpKHhoLCB4bCkge1xuICB2YXIgYzBfaGkgPSByb3RyNjRfaGkoeGgsIHhsLCAxKTtcbiAgdmFyIGMxX2hpID0gcm90cjY0X2hpKHhoLCB4bCwgOCk7XG4gIHZhciBjMl9oaSA9IHNocjY0X2hpKHhoLCB4bCwgNyk7XG5cbiAgdmFyIHIgPSBjMF9oaSBeIGMxX2hpIF4gYzJfaGk7XG4gIGlmIChyIDwgMClcbiAgICByICs9IDB4MTAwMDAwMDAwO1xuICByZXR1cm4gcjtcbn1cblxuZnVuY3Rpb24gZzBfNTEyX2xvKHhoLCB4bCkge1xuICB2YXIgYzBfbG8gPSByb3RyNjRfbG8oeGgsIHhsLCAxKTtcbiAgdmFyIGMxX2xvID0gcm90cjY0X2xvKHhoLCB4bCwgOCk7XG4gIHZhciBjMl9sbyA9IHNocjY0X2xvKHhoLCB4bCwgNyk7XG5cbiAgdmFyIHIgPSBjMF9sbyBeIGMxX2xvIF4gYzJfbG87XG4gIGlmIChyIDwgMClcbiAgICByICs9IDB4MTAwMDAwMDAwO1xuICByZXR1cm4gcjtcbn1cblxuZnVuY3Rpb24gZzFfNTEyX2hpKHhoLCB4bCkge1xuICB2YXIgYzBfaGkgPSByb3RyNjRfaGkoeGgsIHhsLCAxOSk7XG4gIHZhciBjMV9oaSA9IHJvdHI2NF9oaSh4bCwgeGgsIDI5KTsgIC8vIDYxXG4gIHZhciBjMl9oaSA9IHNocjY0X2hpKHhoLCB4bCwgNik7XG5cbiAgdmFyIHIgPSBjMF9oaSBeIGMxX2hpIF4gYzJfaGk7XG4gIGlmIChyIDwgMClcbiAgICByICs9IDB4MTAwMDAwMDAwO1xuICByZXR1cm4gcjtcbn1cblxuZnVuY3Rpb24gZzFfNTEyX2xvKHhoLCB4bCkge1xuICB2YXIgYzBfbG8gPSByb3RyNjRfbG8oeGgsIHhsLCAxOSk7XG4gIHZhciBjMV9sbyA9IHJvdHI2NF9sbyh4bCwgeGgsIDI5KTsgIC8vIDYxXG4gIHZhciBjMl9sbyA9IHNocjY0X2xvKHhoLCB4bCwgNik7XG5cbiAgdmFyIHIgPSBjMF9sbyBeIGMxX2xvIF4gYzJfbG87XG4gIGlmIChyIDwgMClcbiAgICByICs9IDB4MTAwMDAwMDAwO1xuICByZXR1cm4gcjtcbn1cbiIsICIndXNlIHN0cmljdCc7XG5cbnZhciB1dGlscyA9IHJlcXVpcmUoJy4uL3V0aWxzJyk7XG5cbnZhciBTSEE1MTIgPSByZXF1aXJlKCcuLzUxMicpO1xuXG5mdW5jdGlvbiBTSEEzODQoKSB7XG4gIGlmICghKHRoaXMgaW5zdGFuY2VvZiBTSEEzODQpKVxuICAgIHJldHVybiBuZXcgU0hBMzg0KCk7XG5cbiAgU0hBNTEyLmNhbGwodGhpcyk7XG4gIHRoaXMuaCA9IFtcbiAgICAweGNiYmI5ZDVkLCAweGMxMDU5ZWQ4LFxuICAgIDB4NjI5YTI5MmEsIDB4MzY3Y2Q1MDcsXG4gICAgMHg5MTU5MDE1YSwgMHgzMDcwZGQxNyxcbiAgICAweDE1MmZlY2Q4LCAweGY3MGU1OTM5LFxuICAgIDB4NjczMzI2NjcsIDB4ZmZjMDBiMzEsXG4gICAgMHg4ZWI0NGE4NywgMHg2ODU4MTUxMSxcbiAgICAweGRiMGMyZTBkLCAweDY0Zjk4ZmE3LFxuICAgIDB4NDdiNTQ4MWQsIDB4YmVmYTRmYTQgXTtcbn1cbnV0aWxzLmluaGVyaXRzKFNIQTM4NCwgU0hBNTEyKTtcbm1vZHVsZS5leHBvcnRzID0gU0hBMzg0O1xuXG5TSEEzODQuYmxvY2tTaXplID0gMTAyNDtcblNIQTM4NC5vdXRTaXplID0gMzg0O1xuU0hBMzg0LmhtYWNTdHJlbmd0aCA9IDE5MjtcblNIQTM4NC5wYWRMZW5ndGggPSAxMjg7XG5cblNIQTM4NC5wcm90b3R5cGUuX2RpZ2VzdCA9IGZ1bmN0aW9uIGRpZ2VzdChlbmMpIHtcbiAgaWYgKGVuYyA9PT0gJ2hleCcpXG4gICAgcmV0dXJuIHV0aWxzLnRvSGV4MzIodGhpcy5oLnNsaWNlKDAsIDEyKSwgJ2JpZycpO1xuICBlbHNlXG4gICAgcmV0dXJuIHV0aWxzLnNwbGl0MzIodGhpcy5oLnNsaWNlKDAsIDEyKSwgJ2JpZycpO1xufTtcbiIsICIndXNlIHN0cmljdCc7XG5cbmV4cG9ydHMuc2hhMSA9IHJlcXVpcmUoJy4vc2hhLzEnKTtcbmV4cG9ydHMuc2hhMjI0ID0gcmVxdWlyZSgnLi9zaGEvMjI0Jyk7XG5leHBvcnRzLnNoYTI1NiA9IHJlcXVpcmUoJy4vc2hhLzI1NicpO1xuZXhwb3J0cy5zaGEzODQgPSByZXF1aXJlKCcuL3NoYS8zODQnKTtcbmV4cG9ydHMuc2hhNTEyID0gcmVxdWlyZSgnLi9zaGEvNTEyJyk7XG4iLCAiJ3VzZSBzdHJpY3QnO1xuXG52YXIgdXRpbHMgPSByZXF1aXJlKCcuL3V0aWxzJyk7XG52YXIgY29tbW9uID0gcmVxdWlyZSgnLi9jb21tb24nKTtcblxudmFyIHJvdGwzMiA9IHV0aWxzLnJvdGwzMjtcbnZhciBzdW0zMiA9IHV0aWxzLnN1bTMyO1xudmFyIHN1bTMyXzMgPSB1dGlscy5zdW0zMl8zO1xudmFyIHN1bTMyXzQgPSB1dGlscy5zdW0zMl80O1xudmFyIEJsb2NrSGFzaCA9IGNvbW1vbi5CbG9ja0hhc2g7XG5cbmZ1bmN0aW9uIFJJUEVNRDE2MCgpIHtcbiAgaWYgKCEodGhpcyBpbnN0YW5jZW9mIFJJUEVNRDE2MCkpXG4gICAgcmV0dXJuIG5ldyBSSVBFTUQxNjAoKTtcblxuICBCbG9ja0hhc2guY2FsbCh0aGlzKTtcblxuICB0aGlzLmggPSBbIDB4Njc0NTIzMDEsIDB4ZWZjZGFiODksIDB4OThiYWRjZmUsIDB4MTAzMjU0NzYsIDB4YzNkMmUxZjAgXTtcbiAgdGhpcy5lbmRpYW4gPSAnbGl0dGxlJztcbn1cbnV0aWxzLmluaGVyaXRzKFJJUEVNRDE2MCwgQmxvY2tIYXNoKTtcbmV4cG9ydHMucmlwZW1kMTYwID0gUklQRU1EMTYwO1xuXG5SSVBFTUQxNjAuYmxvY2tTaXplID0gNTEyO1xuUklQRU1EMTYwLm91dFNpemUgPSAxNjA7XG5SSVBFTUQxNjAuaG1hY1N0cmVuZ3RoID0gMTkyO1xuUklQRU1EMTYwLnBhZExlbmd0aCA9IDY0O1xuXG5SSVBFTUQxNjAucHJvdG90eXBlLl91cGRhdGUgPSBmdW5jdGlvbiB1cGRhdGUobXNnLCBzdGFydCkge1xuICB2YXIgQSA9IHRoaXMuaFswXTtcbiAgdmFyIEIgPSB0aGlzLmhbMV07XG4gIHZhciBDID0gdGhpcy5oWzJdO1xuICB2YXIgRCA9IHRoaXMuaFszXTtcbiAgdmFyIEUgPSB0aGlzLmhbNF07XG4gIHZhciBBaCA9IEE7XG4gIHZhciBCaCA9IEI7XG4gIHZhciBDaCA9IEM7XG4gIHZhciBEaCA9IEQ7XG4gIHZhciBFaCA9IEU7XG4gIGZvciAodmFyIGogPSAwOyBqIDwgODA7IGorKykge1xuICAgIHZhciBUID0gc3VtMzIoXG4gICAgICByb3RsMzIoXG4gICAgICAgIHN1bTMyXzQoQSwgZihqLCBCLCBDLCBEKSwgbXNnW3Jbal0gKyBzdGFydF0sIEsoaikpLFxuICAgICAgICBzW2pdKSxcbiAgICAgIEUpO1xuICAgIEEgPSBFO1xuICAgIEUgPSBEO1xuICAgIEQgPSByb3RsMzIoQywgMTApO1xuICAgIEMgPSBCO1xuICAgIEIgPSBUO1xuICAgIFQgPSBzdW0zMihcbiAgICAgIHJvdGwzMihcbiAgICAgICAgc3VtMzJfNChBaCwgZig3OSAtIGosIEJoLCBDaCwgRGgpLCBtc2dbcmhbal0gKyBzdGFydF0sIEtoKGopKSxcbiAgICAgICAgc2hbal0pLFxuICAgICAgRWgpO1xuICAgIEFoID0gRWg7XG4gICAgRWggPSBEaDtcbiAgICBEaCA9IHJvdGwzMihDaCwgMTApO1xuICAgIENoID0gQmg7XG4gICAgQmggPSBUO1xuICB9XG4gIFQgPSBzdW0zMl8zKHRoaXMuaFsxXSwgQywgRGgpO1xuICB0aGlzLmhbMV0gPSBzdW0zMl8zKHRoaXMuaFsyXSwgRCwgRWgpO1xuICB0aGlzLmhbMl0gPSBzdW0zMl8zKHRoaXMuaFszXSwgRSwgQWgpO1xuICB0aGlzLmhbM10gPSBzdW0zMl8zKHRoaXMuaFs0XSwgQSwgQmgpO1xuICB0aGlzLmhbNF0gPSBzdW0zMl8zKHRoaXMuaFswXSwgQiwgQ2gpO1xuICB0aGlzLmhbMF0gPSBUO1xufTtcblxuUklQRU1EMTYwLnByb3RvdHlwZS5fZGlnZXN0ID0gZnVuY3Rpb24gZGlnZXN0KGVuYykge1xuICBpZiAoZW5jID09PSAnaGV4JylcbiAgICByZXR1cm4gdXRpbHMudG9IZXgzMih0aGlzLmgsICdsaXR0bGUnKTtcbiAgZWxzZVxuICAgIHJldHVybiB1dGlscy5zcGxpdDMyKHRoaXMuaCwgJ2xpdHRsZScpO1xufTtcblxuZnVuY3Rpb24gZihqLCB4LCB5LCB6KSB7XG4gIGlmIChqIDw9IDE1KVxuICAgIHJldHVybiB4IF4geSBeIHo7XG4gIGVsc2UgaWYgKGogPD0gMzEpXG4gICAgcmV0dXJuICh4ICYgeSkgfCAoKH54KSAmIHopO1xuICBlbHNlIGlmIChqIDw9IDQ3KVxuICAgIHJldHVybiAoeCB8ICh+eSkpIF4gejtcbiAgZWxzZSBpZiAoaiA8PSA2MylcbiAgICByZXR1cm4gKHggJiB6KSB8ICh5ICYgKH56KSk7XG4gIGVsc2VcbiAgICByZXR1cm4geCBeICh5IHwgKH56KSk7XG59XG5cbmZ1bmN0aW9uIEsoaikge1xuICBpZiAoaiA8PSAxNSlcbiAgICByZXR1cm4gMHgwMDAwMDAwMDtcbiAgZWxzZSBpZiAoaiA8PSAzMSlcbiAgICByZXR1cm4gMHg1YTgyNzk5OTtcbiAgZWxzZSBpZiAoaiA8PSA0NylcbiAgICByZXR1cm4gMHg2ZWQ5ZWJhMTtcbiAgZWxzZSBpZiAoaiA8PSA2MylcbiAgICByZXR1cm4gMHg4ZjFiYmNkYztcbiAgZWxzZVxuICAgIHJldHVybiAweGE5NTNmZDRlO1xufVxuXG5mdW5jdGlvbiBLaChqKSB7XG4gIGlmIChqIDw9IDE1KVxuICAgIHJldHVybiAweDUwYTI4YmU2O1xuICBlbHNlIGlmIChqIDw9IDMxKVxuICAgIHJldHVybiAweDVjNGRkMTI0O1xuICBlbHNlIGlmIChqIDw9IDQ3KVxuICAgIHJldHVybiAweDZkNzAzZWYzO1xuICBlbHNlIGlmIChqIDw9IDYzKVxuICAgIHJldHVybiAweDdhNmQ3NmU5O1xuICBlbHNlXG4gICAgcmV0dXJuIDB4MDAwMDAwMDA7XG59XG5cbnZhciByID0gW1xuICAwLCAxLCAyLCAzLCA0LCA1LCA2LCA3LCA4LCA5LCAxMCwgMTEsIDEyLCAxMywgMTQsIDE1LFxuICA3LCA0LCAxMywgMSwgMTAsIDYsIDE1LCAzLCAxMiwgMCwgOSwgNSwgMiwgMTQsIDExLCA4LFxuICAzLCAxMCwgMTQsIDQsIDksIDE1LCA4LCAxLCAyLCA3LCAwLCA2LCAxMywgMTEsIDUsIDEyLFxuICAxLCA5LCAxMSwgMTAsIDAsIDgsIDEyLCA0LCAxMywgMywgNywgMTUsIDE0LCA1LCA2LCAyLFxuICA0LCAwLCA1LCA5LCA3LCAxMiwgMiwgMTAsIDE0LCAxLCAzLCA4LCAxMSwgNiwgMTUsIDEzXG5dO1xuXG52YXIgcmggPSBbXG4gIDUsIDE0LCA3LCAwLCA5LCAyLCAxMSwgNCwgMTMsIDYsIDE1LCA4LCAxLCAxMCwgMywgMTIsXG4gIDYsIDExLCAzLCA3LCAwLCAxMywgNSwgMTAsIDE0LCAxNSwgOCwgMTIsIDQsIDksIDEsIDIsXG4gIDE1LCA1LCAxLCAzLCA3LCAxNCwgNiwgOSwgMTEsIDgsIDEyLCAyLCAxMCwgMCwgNCwgMTMsXG4gIDgsIDYsIDQsIDEsIDMsIDExLCAxNSwgMCwgNSwgMTIsIDIsIDEzLCA5LCA3LCAxMCwgMTQsXG4gIDEyLCAxNSwgMTAsIDQsIDEsIDUsIDgsIDcsIDYsIDIsIDEzLCAxNCwgMCwgMywgOSwgMTFcbl07XG5cbnZhciBzID0gW1xuICAxMSwgMTQsIDE1LCAxMiwgNSwgOCwgNywgOSwgMTEsIDEzLCAxNCwgMTUsIDYsIDcsIDksIDgsXG4gIDcsIDYsIDgsIDEzLCAxMSwgOSwgNywgMTUsIDcsIDEyLCAxNSwgOSwgMTEsIDcsIDEzLCAxMixcbiAgMTEsIDEzLCA2LCA3LCAxNCwgOSwgMTMsIDE1LCAxNCwgOCwgMTMsIDYsIDUsIDEyLCA3LCA1LFxuICAxMSwgMTIsIDE0LCAxNSwgMTQsIDE1LCA5LCA4LCA5LCAxNCwgNSwgNiwgOCwgNiwgNSwgMTIsXG4gIDksIDE1LCA1LCAxMSwgNiwgOCwgMTMsIDEyLCA1LCAxMiwgMTMsIDE0LCAxMSwgOCwgNSwgNlxuXTtcblxudmFyIHNoID0gW1xuICA4LCA5LCA5LCAxMSwgMTMsIDE1LCAxNSwgNSwgNywgNywgOCwgMTEsIDE0LCAxNCwgMTIsIDYsXG4gIDksIDEzLCAxNSwgNywgMTIsIDgsIDksIDExLCA3LCA3LCAxMiwgNywgNiwgMTUsIDEzLCAxMSxcbiAgOSwgNywgMTUsIDExLCA4LCA2LCA2LCAxNCwgMTIsIDEzLCA1LCAxNCwgMTMsIDEzLCA3LCA1LFxuICAxNSwgNSwgOCwgMTEsIDE0LCAxNCwgNiwgMTQsIDYsIDksIDEyLCA5LCAxMiwgNSwgMTUsIDgsXG4gIDgsIDUsIDEyLCA5LCAxMiwgNSwgMTQsIDYsIDgsIDEzLCA2LCA1LCAxNSwgMTMsIDExLCAxMVxuXTtcbiIsICIndXNlIHN0cmljdCc7XG5cbnZhciB1dGlscyA9IHJlcXVpcmUoJy4vdXRpbHMnKTtcbnZhciBhc3NlcnQgPSByZXF1aXJlKCdtaW5pbWFsaXN0aWMtYXNzZXJ0Jyk7XG5cbmZ1bmN0aW9uIEhtYWMoaGFzaCwga2V5LCBlbmMpIHtcbiAgaWYgKCEodGhpcyBpbnN0YW5jZW9mIEhtYWMpKVxuICAgIHJldHVybiBuZXcgSG1hYyhoYXNoLCBrZXksIGVuYyk7XG4gIHRoaXMuSGFzaCA9IGhhc2g7XG4gIHRoaXMuYmxvY2tTaXplID0gaGFzaC5ibG9ja1NpemUgLyA4O1xuICB0aGlzLm91dFNpemUgPSBoYXNoLm91dFNpemUgLyA4O1xuICB0aGlzLmlubmVyID0gbnVsbDtcbiAgdGhpcy5vdXRlciA9IG51bGw7XG5cbiAgdGhpcy5faW5pdCh1dGlscy50b0FycmF5KGtleSwgZW5jKSk7XG59XG5tb2R1bGUuZXhwb3J0cyA9IEhtYWM7XG5cbkhtYWMucHJvdG90eXBlLl9pbml0ID0gZnVuY3Rpb24gaW5pdChrZXkpIHtcbiAgLy8gU2hvcnRlbiBrZXksIGlmIG5lZWRlZFxuICBpZiAoa2V5Lmxlbmd0aCA+IHRoaXMuYmxvY2tTaXplKVxuICAgIGtleSA9IG5ldyB0aGlzLkhhc2goKS51cGRhdGUoa2V5KS5kaWdlc3QoKTtcbiAgYXNzZXJ0KGtleS5sZW5ndGggPD0gdGhpcy5ibG9ja1NpemUpO1xuXG4gIC8vIEFkZCBwYWRkaW5nIHRvIGtleVxuICBmb3IgKHZhciBpID0ga2V5Lmxlbmd0aDsgaSA8IHRoaXMuYmxvY2tTaXplOyBpKyspXG4gICAga2V5LnB1c2goMCk7XG5cbiAgZm9yIChpID0gMDsgaSA8IGtleS5sZW5ndGg7IGkrKylcbiAgICBrZXlbaV0gXj0gMHgzNjtcbiAgdGhpcy5pbm5lciA9IG5ldyB0aGlzLkhhc2goKS51cGRhdGUoa2V5KTtcblxuICAvLyAweDM2IF4gMHg1YyA9IDB4NmFcbiAgZm9yIChpID0gMDsgaSA8IGtleS5sZW5ndGg7IGkrKylcbiAgICBrZXlbaV0gXj0gMHg2YTtcbiAgdGhpcy5vdXRlciA9IG5ldyB0aGlzLkhhc2goKS51cGRhdGUoa2V5KTtcbn07XG5cbkhtYWMucHJvdG90eXBlLnVwZGF0ZSA9IGZ1bmN0aW9uIHVwZGF0ZShtc2csIGVuYykge1xuICB0aGlzLmlubmVyLnVwZGF0ZShtc2csIGVuYyk7XG4gIHJldHVybiB0aGlzO1xufTtcblxuSG1hYy5wcm90b3R5cGUuZGlnZXN0ID0gZnVuY3Rpb24gZGlnZXN0KGVuYykge1xuICB0aGlzLm91dGVyLnVwZGF0ZSh0aGlzLmlubmVyLmRpZ2VzdCgpKTtcbiAgcmV0dXJuIHRoaXMub3V0ZXIuZGlnZXN0KGVuYyk7XG59O1xuIiwgInZhciBoYXNoID0gZXhwb3J0cztcblxuaGFzaC51dGlscyA9IHJlcXVpcmUoJy4vaGFzaC91dGlscycpO1xuaGFzaC5jb21tb24gPSByZXF1aXJlKCcuL2hhc2gvY29tbW9uJyk7XG5oYXNoLnNoYSA9IHJlcXVpcmUoJy4vaGFzaC9zaGEnKTtcbmhhc2gucmlwZW1kID0gcmVxdWlyZSgnLi9oYXNoL3JpcGVtZCcpO1xuaGFzaC5obWFjID0gcmVxdWlyZSgnLi9oYXNoL2htYWMnKTtcblxuLy8gUHJveHkgaGFzaCBmdW5jdGlvbnMgdG8gdGhlIG1haW4gb2JqZWN0XG5oYXNoLnNoYTEgPSBoYXNoLnNoYS5zaGExO1xuaGFzaC5zaGEyNTYgPSBoYXNoLnNoYS5zaGEyNTY7XG5oYXNoLnNoYTIyNCA9IGhhc2guc2hhLnNoYTIyNDtcbmhhc2guc2hhMzg0ID0gaGFzaC5zaGEuc2hhMzg0O1xuaGFzaC5zaGE1MTIgPSBoYXNoLnNoYS5zaGE1MTI7XG5oYXNoLnJpcGVtZDE2MCA9IGhhc2gucmlwZW1kLnJpcGVtZDE2MDtcbiIsICIndXNlIHN0cmljdCdcblxuLy8gTm90ZTogdGhpcyBpcyB0aGUgc2VtdmVyLm9yZyB2ZXJzaW9uIG9mIHRoZSBzcGVjIHRoYXQgaXQgaW1wbGVtZW50c1xuLy8gTm90IG5lY2Vzc2FyaWx5IHRoZSBwYWNrYWdlIHZlcnNpb24gb2YgdGhpcyBjb2RlLlxuY29uc3QgU0VNVkVSX1NQRUNfVkVSU0lPTiA9ICcyLjAuMCdcblxuY29uc3QgTUFYX0xFTkdUSCA9IDI1NlxuY29uc3QgTUFYX1NBRkVfSU5URUdFUiA9IE51bWJlci5NQVhfU0FGRV9JTlRFR0VSIHx8XG4vKiBpc3RhbmJ1bCBpZ25vcmUgbmV4dCAqLyA5MDA3MTk5MjU0NzQwOTkxXG5cbi8vIE1heCBzYWZlIHNlZ21lbnQgbGVuZ3RoIGZvciBjb2VyY2lvbi5cbmNvbnN0IE1BWF9TQUZFX0NPTVBPTkVOVF9MRU5HVEggPSAxNlxuXG4vLyBNYXggc2FmZSBsZW5ndGggZm9yIGEgYnVpbGQgaWRlbnRpZmllci4gVGhlIG1heCBsZW5ndGggbWludXMgNiBjaGFyYWN0ZXJzIGZvclxuLy8gdGhlIHNob3J0ZXN0IHZlcnNpb24gd2l0aCBhIGJ1aWxkIDAuMC4wK0JVSUxELlxuY29uc3QgTUFYX1NBRkVfQlVJTERfTEVOR1RIID0gTUFYX0xFTkdUSCAtIDZcblxuY29uc3QgUkVMRUFTRV9UWVBFUyA9IFtcbiAgJ21ham9yJyxcbiAgJ3ByZW1ham9yJyxcbiAgJ21pbm9yJyxcbiAgJ3ByZW1pbm9yJyxcbiAgJ3BhdGNoJyxcbiAgJ3ByZXBhdGNoJyxcbiAgJ3ByZXJlbGVhc2UnLFxuXVxuXG5tb2R1bGUuZXhwb3J0cyA9IHtcbiAgTUFYX0xFTkdUSCxcbiAgTUFYX1NBRkVfQ09NUE9ORU5UX0xFTkdUSCxcbiAgTUFYX1NBRkVfQlVJTERfTEVOR1RILFxuICBNQVhfU0FGRV9JTlRFR0VSLFxuICBSRUxFQVNFX1RZUEVTLFxuICBTRU1WRVJfU1BFQ19WRVJTSU9OLFxuICBGTEFHX0lOQ0xVREVfUFJFUkVMRUFTRTogMGIwMDEsXG4gIEZMQUdfTE9PU0U6IDBiMDEwLFxufVxuIiwgIid1c2Ugc3RyaWN0J1xuXG5jb25zdCBkZWJ1ZyA9IChcbiAgdHlwZW9mIHByb2Nlc3MgPT09ICdvYmplY3QnICYmXG4gIHByb2Nlc3MuZW52ICYmXG4gIHByb2Nlc3MuZW52Lk5PREVfREVCVUcgJiZcbiAgL1xcYnNlbXZlclxcYi9pLnRlc3QocHJvY2Vzcy5lbnYuTk9ERV9ERUJVRylcbikgPyAoLi4uYXJncykgPT4gY29uc29sZS5lcnJvcignU0VNVkVSJywgLi4uYXJncylcbiAgOiAoKSA9PiB7fVxuXG5tb2R1bGUuZXhwb3J0cyA9IGRlYnVnXG4iLCAiJ3VzZSBzdHJpY3QnXG5cbmNvbnN0IHtcbiAgTUFYX1NBRkVfQ09NUE9ORU5UX0xFTkdUSCxcbiAgTUFYX1NBRkVfQlVJTERfTEVOR1RILFxuICBNQVhfTEVOR1RILFxufSA9IHJlcXVpcmUoJy4vY29uc3RhbnRzJylcbmNvbnN0IGRlYnVnID0gcmVxdWlyZSgnLi9kZWJ1ZycpXG5leHBvcnRzID0gbW9kdWxlLmV4cG9ydHMgPSB7fVxuXG4vLyBUaGUgYWN0dWFsIHJlZ2V4cHMgZ28gb24gZXhwb3J0cy5yZVxuY29uc3QgcmUgPSBleHBvcnRzLnJlID0gW11cbmNvbnN0IHNhZmVSZSA9IGV4cG9ydHMuc2FmZVJlID0gW11cbmNvbnN0IHNyYyA9IGV4cG9ydHMuc3JjID0gW11cbmNvbnN0IHNhZmVTcmMgPSBleHBvcnRzLnNhZmVTcmMgPSBbXVxuY29uc3QgdCA9IGV4cG9ydHMudCA9IHt9XG5sZXQgUiA9IDBcblxuY29uc3QgTEVUVEVSREFTSE5VTUJFUiA9ICdbYS16QS1aMC05LV0nXG5cbi8vIFJlcGxhY2Ugc29tZSBncmVlZHkgcmVnZXggdG9rZW5zIHRvIHByZXZlbnQgcmVnZXggZG9zIGlzc3Vlcy4gVGhlc2UgcmVnZXggYXJlXG4vLyB1c2VkIGludGVybmFsbHkgdmlhIHRoZSBzYWZlUmUgb2JqZWN0IHNpbmNlIGFsbCBpbnB1dHMgaW4gdGhpcyBsaWJyYXJ5IGdldFxuLy8gbm9ybWFsaXplZCBmaXJzdCB0byB0cmltIGFuZCBjb2xsYXBzZSBhbGwgZXh0cmEgd2hpdGVzcGFjZS4gVGhlIG9yaWdpbmFsXG4vLyByZWdleGVzIGFyZSBleHBvcnRlZCBmb3IgdXNlcmxhbmQgY29uc3VtcHRpb24gYW5kIGxvd2VyIGxldmVsIHVzYWdlLiBBXG4vLyBmdXR1cmUgYnJlYWtpbmcgY2hhbmdlIGNvdWxkIGV4cG9ydCB0aGUgc2FmZXIgcmVnZXggb25seSB3aXRoIGEgbm90ZSB0aGF0XG4vLyBhbGwgaW5wdXQgc2hvdWxkIGhhdmUgZXh0cmEgd2hpdGVzcGFjZSByZW1vdmVkLlxuY29uc3Qgc2FmZVJlZ2V4UmVwbGFjZW1lbnRzID0gW1xuICBbJ1xcXFxzJywgMV0sXG4gIFsnXFxcXGQnLCBNQVhfTEVOR1RIXSxcbiAgW0xFVFRFUkRBU0hOVU1CRVIsIE1BWF9TQUZFX0JVSUxEX0xFTkdUSF0sXG5dXG5cbmNvbnN0IG1ha2VTYWZlUmVnZXggPSAodmFsdWUpID0+IHtcbiAgZm9yIChjb25zdCBbdG9rZW4sIG1heF0gb2Ygc2FmZVJlZ2V4UmVwbGFjZW1lbnRzKSB7XG4gICAgdmFsdWUgPSB2YWx1ZVxuICAgICAgLnNwbGl0KGAke3Rva2VufSpgKS5qb2luKGAke3Rva2VufXswLCR7bWF4fX1gKVxuICAgICAgLnNwbGl0KGAke3Rva2VufStgKS5qb2luKGAke3Rva2VufXsxLCR7bWF4fX1gKVxuICB9XG4gIHJldHVybiB2YWx1ZVxufVxuXG5jb25zdCBjcmVhdGVUb2tlbiA9IChuYW1lLCB2YWx1ZSwgaXNHbG9iYWwpID0+IHtcbiAgY29uc3Qgc2FmZSA9IG1ha2VTYWZlUmVnZXgodmFsdWUpXG4gIGNvbnN0IGluZGV4ID0gUisrXG4gIGRlYnVnKG5hbWUsIGluZGV4LCB2YWx1ZSlcbiAgdFtuYW1lXSA9IGluZGV4XG4gIHNyY1tpbmRleF0gPSB2YWx1ZVxuICBzYWZlU3JjW2luZGV4XSA9IHNhZmVcbiAgcmVbaW5kZXhdID0gbmV3IFJlZ0V4cCh2YWx1ZSwgaXNHbG9iYWwgPyAnZycgOiB1bmRlZmluZWQpXG4gIHNhZmVSZVtpbmRleF0gPSBuZXcgUmVnRXhwKHNhZmUsIGlzR2xvYmFsID8gJ2cnIDogdW5kZWZpbmVkKVxufVxuXG4vLyBUaGUgZm9sbG93aW5nIFJlZ3VsYXIgRXhwcmVzc2lvbnMgY2FuIGJlIHVzZWQgZm9yIHRva2VuaXppbmcsXG4vLyB2YWxpZGF0aW5nLCBhbmQgcGFyc2luZyBTZW1WZXIgdmVyc2lvbiBzdHJpbmdzLlxuXG4vLyAjIyBOdW1lcmljIElkZW50aWZpZXJcbi8vIEEgc2luZ2xlIGAwYCwgb3IgYSBub24temVybyBkaWdpdCBmb2xsb3dlZCBieSB6ZXJvIG9yIG1vcmUgZGlnaXRzLlxuXG5jcmVhdGVUb2tlbignTlVNRVJJQ0lERU5USUZJRVInLCAnMHxbMS05XVxcXFxkKicpXG5jcmVhdGVUb2tlbignTlVNRVJJQ0lERU5USUZJRVJMT09TRScsICdcXFxcZCsnKVxuXG4vLyAjIyBOb24tbnVtZXJpYyBJZGVudGlmaWVyXG4vLyBaZXJvIG9yIG1vcmUgZGlnaXRzLCBmb2xsb3dlZCBieSBhIGxldHRlciBvciBoeXBoZW4sIGFuZCB0aGVuIHplcm8gb3Jcbi8vIG1vcmUgbGV0dGVycywgZGlnaXRzLCBvciBoeXBoZW5zLlxuXG5jcmVhdGVUb2tlbignTk9OTlVNRVJJQ0lERU5USUZJRVInLCBgXFxcXGQqW2EtekEtWi1dJHtMRVRURVJEQVNITlVNQkVSfSpgKVxuXG4vLyAjIyBNYWluIFZlcnNpb25cbi8vIFRocmVlIGRvdC1zZXBhcmF0ZWQgbnVtZXJpYyBpZGVudGlmaWVycy5cblxuY3JlYXRlVG9rZW4oJ01BSU5WRVJTSU9OJywgYCgke3NyY1t0Lk5VTUVSSUNJREVOVElGSUVSXX0pXFxcXC5gICtcbiAgICAgICAgICAgICAgICAgICBgKCR7c3JjW3QuTlVNRVJJQ0lERU5USUZJRVJdfSlcXFxcLmAgK1xuICAgICAgICAgICAgICAgICAgIGAoJHtzcmNbdC5OVU1FUklDSURFTlRJRklFUl19KWApXG5cbmNyZWF0ZVRva2VuKCdNQUlOVkVSU0lPTkxPT1NFJywgYCgke3NyY1t0Lk5VTUVSSUNJREVOVElGSUVSTE9PU0VdfSlcXFxcLmAgK1xuICAgICAgICAgICAgICAgICAgICAgICAgYCgke3NyY1t0Lk5VTUVSSUNJREVOVElGSUVSTE9PU0VdfSlcXFxcLmAgK1xuICAgICAgICAgICAgICAgICAgICAgICAgYCgke3NyY1t0Lk5VTUVSSUNJREVOVElGSUVSTE9PU0VdfSlgKVxuXG4vLyAjIyBQcmUtcmVsZWFzZSBWZXJzaW9uIElkZW50aWZpZXJcbi8vIEEgbnVtZXJpYyBpZGVudGlmaWVyLCBvciBhIG5vbi1udW1lcmljIGlkZW50aWZpZXIuXG4vLyBOb24tbnVtZXJpYyBpZGVudGlmaWVycyBpbmNsdWRlIG51bWVyaWMgaWRlbnRpZmllcnMgYnV0IGNhbiBiZSBsb25nZXIuXG4vLyBUaGVyZWZvcmUgbm9uLW51bWVyaWMgaWRlbnRpZmllcnMgbXVzdCBnbyBmaXJzdC5cblxuY3JlYXRlVG9rZW4oJ1BSRVJFTEVBU0VJREVOVElGSUVSJywgYCg/OiR7c3JjW3QuTk9OTlVNRVJJQ0lERU5USUZJRVJdXG59fCR7c3JjW3QuTlVNRVJJQ0lERU5USUZJRVJdfSlgKVxuXG5jcmVhdGVUb2tlbignUFJFUkVMRUFTRUlERU5USUZJRVJMT09TRScsIGAoPzoke3NyY1t0Lk5PTk5VTUVSSUNJREVOVElGSUVSXVxufXwke3NyY1t0Lk5VTUVSSUNJREVOVElGSUVSTE9PU0VdfSlgKVxuXG4vLyAjIyBQcmUtcmVsZWFzZSBWZXJzaW9uXG4vLyBIeXBoZW4sIGZvbGxvd2VkIGJ5IG9uZSBvciBtb3JlIGRvdC1zZXBhcmF0ZWQgcHJlLXJlbGVhc2UgdmVyc2lvblxuLy8gaWRlbnRpZmllcnMuXG5cbmNyZWF0ZVRva2VuKCdQUkVSRUxFQVNFJywgYCg/Oi0oJHtzcmNbdC5QUkVSRUxFQVNFSURFTlRJRklFUl1cbn0oPzpcXFxcLiR7c3JjW3QuUFJFUkVMRUFTRUlERU5USUZJRVJdfSkqKSlgKVxuXG5jcmVhdGVUb2tlbignUFJFUkVMRUFTRUxPT1NFJywgYCg/Oi0/KCR7c3JjW3QuUFJFUkVMRUFTRUlERU5USUZJRVJMT09TRV1cbn0oPzpcXFxcLiR7c3JjW3QuUFJFUkVMRUFTRUlERU5USUZJRVJMT09TRV19KSopKWApXG5cbi8vICMjIEJ1aWxkIE1ldGFkYXRhIElkZW50aWZpZXJcbi8vIEFueSBjb21iaW5hdGlvbiBvZiBkaWdpdHMsIGxldHRlcnMsIG9yIGh5cGhlbnMuXG5cbmNyZWF0ZVRva2VuKCdCVUlMRElERU5USUZJRVInLCBgJHtMRVRURVJEQVNITlVNQkVSfStgKVxuXG4vLyAjIyBCdWlsZCBNZXRhZGF0YVxuLy8gUGx1cyBzaWduLCBmb2xsb3dlZCBieSBvbmUgb3IgbW9yZSBwZXJpb2Qtc2VwYXJhdGVkIGJ1aWxkIG1ldGFkYXRhXG4vLyBpZGVudGlmaWVycy5cblxuY3JlYXRlVG9rZW4oJ0JVSUxEJywgYCg/OlxcXFwrKCR7c3JjW3QuQlVJTERJREVOVElGSUVSXVxufSg/OlxcXFwuJHtzcmNbdC5CVUlMRElERU5USUZJRVJdfSkqKSlgKVxuXG4vLyAjIyBGdWxsIFZlcnNpb24gU3RyaW5nXG4vLyBBIG1haW4gdmVyc2lvbiwgZm9sbG93ZWQgb3B0aW9uYWxseSBieSBhIHByZS1yZWxlYXNlIHZlcnNpb24gYW5kXG4vLyBidWlsZCBtZXRhZGF0YS5cblxuLy8gTm90ZSB0aGF0IHRoZSBvbmx5IG1ham9yLCBtaW5vciwgcGF0Y2gsIGFuZCBwcmUtcmVsZWFzZSBzZWN0aW9ucyBvZlxuLy8gdGhlIHZlcnNpb24gc3RyaW5nIGFyZSBjYXB0dXJpbmcgZ3JvdXBzLiAgVGhlIGJ1aWxkIG1ldGFkYXRhIGlzIG5vdCBhXG4vLyBjYXB0dXJpbmcgZ3JvdXAsIGJlY2F1c2UgaXQgc2hvdWxkIG5vdCBldmVyIGJlIHVzZWQgaW4gdmVyc2lvblxuLy8gY29tcGFyaXNvbi5cblxuY3JlYXRlVG9rZW4oJ0ZVTExQTEFJTicsIGB2PyR7c3JjW3QuTUFJTlZFUlNJT05dXG59JHtzcmNbdC5QUkVSRUxFQVNFXX0/JHtcbiAgc3JjW3QuQlVJTERdfT9gKVxuXG5jcmVhdGVUb2tlbignRlVMTCcsIGBeJHtzcmNbdC5GVUxMUExBSU5dfSRgKVxuXG4vLyBsaWtlIGZ1bGwsIGJ1dCBhbGxvd3MgdjEuMi4zIGFuZCA9MS4yLjMsIHdoaWNoIHBlb3BsZSBkbyBzb21ldGltZXMuXG4vLyBhbHNvLCAxLjAuMGFscGhhMSAocHJlcmVsZWFzZSB3aXRob3V0IHRoZSBoeXBoZW4pIHdoaWNoIGlzIHByZXR0eVxuLy8gY29tbW9uIGluIHRoZSBucG0gcmVnaXN0cnkuXG5jcmVhdGVUb2tlbignTE9PU0VQTEFJTicsIGBbdj1cXFxcc10qJHtzcmNbdC5NQUlOVkVSU0lPTkxPT1NFXVxufSR7c3JjW3QuUFJFUkVMRUFTRUxPT1NFXX0/JHtcbiAgc3JjW3QuQlVJTERdfT9gKVxuXG5jcmVhdGVUb2tlbignTE9PU0UnLCBgXiR7c3JjW3QuTE9PU0VQTEFJTl19JGApXG5cbmNyZWF0ZVRva2VuKCdHVExUJywgJygoPzo8fD4pPz0/KScpXG5cbi8vIFNvbWV0aGluZyBsaWtlIFwiMi4qXCIgb3IgXCIxLjIueFwiLlxuLy8gTm90ZSB0aGF0IFwieC54XCIgaXMgYSB2YWxpZCB4UmFuZ2UgaWRlbnRpZmllciwgbWVhbmluZyBcImFueSB2ZXJzaW9uXCJcbi8vIE9ubHkgdGhlIGZpcnN0IGl0ZW0gaXMgc3RyaWN0bHkgcmVxdWlyZWQuXG5jcmVhdGVUb2tlbignWFJBTkdFSURFTlRJRklFUkxPT1NFJywgYCR7c3JjW3QuTlVNRVJJQ0lERU5USUZJRVJMT09TRV19fHh8WHxcXFxcKmApXG5jcmVhdGVUb2tlbignWFJBTkdFSURFTlRJRklFUicsIGAke3NyY1t0Lk5VTUVSSUNJREVOVElGSUVSXX18eHxYfFxcXFwqYClcblxuY3JlYXRlVG9rZW4oJ1hSQU5HRVBMQUlOJywgYFt2PVxcXFxzXSooJHtzcmNbdC5YUkFOR0VJREVOVElGSUVSXX0pYCArXG4gICAgICAgICAgICAgICAgICAgYCg/OlxcXFwuKCR7c3JjW3QuWFJBTkdFSURFTlRJRklFUl19KWAgK1xuICAgICAgICAgICAgICAgICAgIGAoPzpcXFxcLigke3NyY1t0LlhSQU5HRUlERU5USUZJRVJdfSlgICtcbiAgICAgICAgICAgICAgICAgICBgKD86JHtzcmNbdC5QUkVSRUxFQVNFXX0pPyR7XG4gICAgICAgICAgICAgICAgICAgICBzcmNbdC5CVUlMRF19P2AgK1xuICAgICAgICAgICAgICAgICAgIGApPyk/YClcblxuY3JlYXRlVG9rZW4oJ1hSQU5HRVBMQUlOTE9PU0UnLCBgW3Y9XFxcXHNdKigke3NyY1t0LlhSQU5HRUlERU5USUZJRVJMT09TRV19KWAgK1xuICAgICAgICAgICAgICAgICAgICAgICAgYCg/OlxcXFwuKCR7c3JjW3QuWFJBTkdFSURFTlRJRklFUkxPT1NFXX0pYCArXG4gICAgICAgICAgICAgICAgICAgICAgICBgKD86XFxcXC4oJHtzcmNbdC5YUkFOR0VJREVOVElGSUVSTE9PU0VdfSlgICtcbiAgICAgICAgICAgICAgICAgICAgICAgIGAoPzoke3NyY1t0LlBSRVJFTEVBU0VMT09TRV19KT8ke1xuICAgICAgICAgICAgICAgICAgICAgICAgICBzcmNbdC5CVUlMRF19P2AgK1xuICAgICAgICAgICAgICAgICAgICAgICAgYCk/KT9gKVxuXG5jcmVhdGVUb2tlbignWFJBTkdFJywgYF4ke3NyY1t0LkdUTFRdfVxcXFxzKiR7c3JjW3QuWFJBTkdFUExBSU5dfSRgKVxuY3JlYXRlVG9rZW4oJ1hSQU5HRUxPT1NFJywgYF4ke3NyY1t0LkdUTFRdfVxcXFxzKiR7c3JjW3QuWFJBTkdFUExBSU5MT09TRV19JGApXG5cbi8vIENvZXJjaW9uLlxuLy8gRXh0cmFjdCBhbnl0aGluZyB0aGF0IGNvdWxkIGNvbmNlaXZhYmx5IGJlIGEgcGFydCBvZiBhIHZhbGlkIHNlbXZlclxuY3JlYXRlVG9rZW4oJ0NPRVJDRVBMQUlOJywgYCR7JyhefFteXFxcXGRdKScgK1xuICAgICAgICAgICAgICAnKFxcXFxkezEsJ30ke01BWF9TQUZFX0NPTVBPTkVOVF9MRU5HVEh9fSlgICtcbiAgICAgICAgICAgICAgYCg/OlxcXFwuKFxcXFxkezEsJHtNQVhfU0FGRV9DT01QT05FTlRfTEVOR1RIfX0pKT9gICtcbiAgICAgICAgICAgICAgYCg/OlxcXFwuKFxcXFxkezEsJHtNQVhfU0FGRV9DT01QT05FTlRfTEVOR1RIfX0pKT9gKVxuY3JlYXRlVG9rZW4oJ0NPRVJDRScsIGAke3NyY1t0LkNPRVJDRVBMQUlOXX0oPzokfFteXFxcXGRdKWApXG5jcmVhdGVUb2tlbignQ09FUkNFRlVMTCcsIHNyY1t0LkNPRVJDRVBMQUlOXSArXG4gICAgICAgICAgICAgIGAoPzoke3NyY1t0LlBSRVJFTEVBU0VdfSk/YCArXG4gICAgICAgICAgICAgIGAoPzoke3NyY1t0LkJVSUxEXX0pP2AgK1xuICAgICAgICAgICAgICBgKD86JHxbXlxcXFxkXSlgKVxuY3JlYXRlVG9rZW4oJ0NPRVJDRVJUTCcsIHNyY1t0LkNPRVJDRV0sIHRydWUpXG5jcmVhdGVUb2tlbignQ09FUkNFUlRMRlVMTCcsIHNyY1t0LkNPRVJDRUZVTExdLCB0cnVlKVxuXG4vLyBUaWxkZSByYW5nZXMuXG4vLyBNZWFuaW5nIGlzIFwicmVhc29uYWJseSBhdCBvciBncmVhdGVyIHRoYW5cIlxuY3JlYXRlVG9rZW4oJ0xPTkVUSUxERScsICcoPzp+Pj8pJylcblxuY3JlYXRlVG9rZW4oJ1RJTERFVFJJTScsIGAoXFxcXHMqKSR7c3JjW3QuTE9ORVRJTERFXX1cXFxccytgLCB0cnVlKVxuZXhwb3J0cy50aWxkZVRyaW1SZXBsYWNlID0gJyQxfidcblxuY3JlYXRlVG9rZW4oJ1RJTERFJywgYF4ke3NyY1t0LkxPTkVUSUxERV19JHtzcmNbdC5YUkFOR0VQTEFJTl19JGApXG5jcmVhdGVUb2tlbignVElMREVMT09TRScsIGBeJHtzcmNbdC5MT05FVElMREVdfSR7c3JjW3QuWFJBTkdFUExBSU5MT09TRV19JGApXG5cbi8vIENhcmV0IHJhbmdlcy5cbi8vIE1lYW5pbmcgaXMgXCJhdCBsZWFzdCBhbmQgYmFja3dhcmRzIGNvbXBhdGlibGUgd2l0aFwiXG5jcmVhdGVUb2tlbignTE9ORUNBUkVUJywgJyg/OlxcXFxeKScpXG5cbmNyZWF0ZVRva2VuKCdDQVJFVFRSSU0nLCBgKFxcXFxzKikke3NyY1t0LkxPTkVDQVJFVF19XFxcXHMrYCwgdHJ1ZSlcbmV4cG9ydHMuY2FyZXRUcmltUmVwbGFjZSA9ICckMV4nXG5cbmNyZWF0ZVRva2VuKCdDQVJFVCcsIGBeJHtzcmNbdC5MT05FQ0FSRVRdfSR7c3JjW3QuWFJBTkdFUExBSU5dfSRgKVxuY3JlYXRlVG9rZW4oJ0NBUkVUTE9PU0UnLCBgXiR7c3JjW3QuTE9ORUNBUkVUXX0ke3NyY1t0LlhSQU5HRVBMQUlOTE9PU0VdfSRgKVxuXG4vLyBBIHNpbXBsZSBndC9sdC9lcSB0aGluZywgb3IganVzdCBcIlwiIHRvIGluZGljYXRlIFwiYW55IHZlcnNpb25cIlxuY3JlYXRlVG9rZW4oJ0NPTVBBUkFUT1JMT09TRScsIGBeJHtzcmNbdC5HVExUXX1cXFxccyooJHtzcmNbdC5MT09TRVBMQUlOXX0pJHxeJGApXG5jcmVhdGVUb2tlbignQ09NUEFSQVRPUicsIGBeJHtzcmNbdC5HVExUXX1cXFxccyooJHtzcmNbdC5GVUxMUExBSU5dfSkkfF4kYClcblxuLy8gQW4gZXhwcmVzc2lvbiB0byBzdHJpcCBhbnkgd2hpdGVzcGFjZSBiZXR3ZWVuIHRoZSBndGx0IGFuZCB0aGUgdGhpbmdcbi8vIGl0IG1vZGlmaWVzLCBzbyB0aGF0IGA+IDEuMi4zYCA9PT4gYD4xLjIuM2BcbmNyZWF0ZVRva2VuKCdDT01QQVJBVE9SVFJJTScsIGAoXFxcXHMqKSR7c3JjW3QuR1RMVF1cbn1cXFxccyooJHtzcmNbdC5MT09TRVBMQUlOXX18JHtzcmNbdC5YUkFOR0VQTEFJTl19KWAsIHRydWUpXG5leHBvcnRzLmNvbXBhcmF0b3JUcmltUmVwbGFjZSA9ICckMSQyJDMnXG5cbi8vIFNvbWV0aGluZyBsaWtlIGAxLjIuMyAtIDEuMi40YFxuLy8gTm90ZSB0aGF0IHRoZXNlIGFsbCB1c2UgdGhlIGxvb3NlIGZvcm0sIGJlY2F1c2UgdGhleSdsbCBiZVxuLy8gY2hlY2tlZCBhZ2FpbnN0IGVpdGhlciB0aGUgc3RyaWN0IG9yIGxvb3NlIGNvbXBhcmF0b3IgZm9ybVxuLy8gbGF0ZXIuXG5jcmVhdGVUb2tlbignSFlQSEVOUkFOR0UnLCBgXlxcXFxzKigke3NyY1t0LlhSQU5HRVBMQUlOXX0pYCArXG4gICAgICAgICAgICAgICAgICAgYFxcXFxzKy1cXFxccytgICtcbiAgICAgICAgICAgICAgICAgICBgKCR7c3JjW3QuWFJBTkdFUExBSU5dfSlgICtcbiAgICAgICAgICAgICAgICAgICBgXFxcXHMqJGApXG5cbmNyZWF0ZVRva2VuKCdIWVBIRU5SQU5HRUxPT1NFJywgYF5cXFxccyooJHtzcmNbdC5YUkFOR0VQTEFJTkxPT1NFXX0pYCArXG4gICAgICAgICAgICAgICAgICAgICAgICBgXFxcXHMrLVxcXFxzK2AgK1xuICAgICAgICAgICAgICAgICAgICAgICAgYCgke3NyY1t0LlhSQU5HRVBMQUlOTE9PU0VdfSlgICtcbiAgICAgICAgICAgICAgICAgICAgICAgIGBcXFxccyokYClcblxuLy8gU3RhciByYW5nZXMgYmFzaWNhbGx5IGp1c3QgYWxsb3cgYW55dGhpbmcgYXQgYWxsLlxuY3JlYXRlVG9rZW4oJ1NUQVInLCAnKDx8Pik/PT9cXFxccypcXFxcKicpXG4vLyA+PTAuMC4wIGlzIGxpa2UgYSBzdGFyXG5jcmVhdGVUb2tlbignR1RFMCcsICdeXFxcXHMqPj1cXFxccyowXFxcXC4wXFxcXC4wXFxcXHMqJCcpXG5jcmVhdGVUb2tlbignR1RFMFBSRScsICdeXFxcXHMqPj1cXFxccyowXFxcXC4wXFxcXC4wLTBcXFxccyokJylcbiIsICIndXNlIHN0cmljdCdcblxuLy8gcGFyc2Ugb3V0IGp1c3QgdGhlIG9wdGlvbnMgd2UgY2FyZSBhYm91dFxuY29uc3QgbG9vc2VPcHRpb24gPSBPYmplY3QuZnJlZXplKHsgbG9vc2U6IHRydWUgfSlcbmNvbnN0IGVtcHR5T3B0cyA9IE9iamVjdC5mcmVlemUoeyB9KVxuY29uc3QgcGFyc2VPcHRpb25zID0gb3B0aW9ucyA9PiB7XG4gIGlmICghb3B0aW9ucykge1xuICAgIHJldHVybiBlbXB0eU9wdHNcbiAgfVxuXG4gIGlmICh0eXBlb2Ygb3B0aW9ucyAhPT0gJ29iamVjdCcpIHtcbiAgICByZXR1cm4gbG9vc2VPcHRpb25cbiAgfVxuXG4gIHJldHVybiBvcHRpb25zXG59XG5tb2R1bGUuZXhwb3J0cyA9IHBhcnNlT3B0aW9uc1xuIiwgIid1c2Ugc3RyaWN0J1xuXG5jb25zdCBudW1lcmljID0gL15bMC05XSskL1xuY29uc3QgY29tcGFyZUlkZW50aWZpZXJzID0gKGEsIGIpID0+IHtcbiAgaWYgKHR5cGVvZiBhID09PSAnbnVtYmVyJyAmJiB0eXBlb2YgYiA9PT0gJ251bWJlcicpIHtcbiAgICByZXR1cm4gYSA9PT0gYiA/IDAgOiBhIDwgYiA/IC0xIDogMVxuICB9XG5cbiAgY29uc3QgYW51bSA9IG51bWVyaWMudGVzdChhKVxuICBjb25zdCBibnVtID0gbnVtZXJpYy50ZXN0KGIpXG5cbiAgaWYgKGFudW0gJiYgYm51bSkge1xuICAgIGEgPSArYVxuICAgIGIgPSArYlxuICB9XG5cbiAgcmV0dXJuIGEgPT09IGIgPyAwXG4gICAgOiAoYW51bSAmJiAhYm51bSkgPyAtMVxuICAgIDogKGJudW0gJiYgIWFudW0pID8gMVxuICAgIDogYSA8IGIgPyAtMVxuICAgIDogMVxufVxuXG5jb25zdCByY29tcGFyZUlkZW50aWZpZXJzID0gKGEsIGIpID0+IGNvbXBhcmVJZGVudGlmaWVycyhiLCBhKVxuXG5tb2R1bGUuZXhwb3J0cyA9IHtcbiAgY29tcGFyZUlkZW50aWZpZXJzLFxuICByY29tcGFyZUlkZW50aWZpZXJzLFxufVxuIiwgIid1c2Ugc3RyaWN0J1xuXG5jb25zdCBkZWJ1ZyA9IHJlcXVpcmUoJy4uL2ludGVybmFsL2RlYnVnJylcbmNvbnN0IHsgTUFYX0xFTkdUSCwgTUFYX1NBRkVfSU5URUdFUiB9ID0gcmVxdWlyZSgnLi4vaW50ZXJuYWwvY29uc3RhbnRzJylcbmNvbnN0IHsgc2FmZVJlOiByZSwgdCB9ID0gcmVxdWlyZSgnLi4vaW50ZXJuYWwvcmUnKVxuXG5jb25zdCBwYXJzZU9wdGlvbnMgPSByZXF1aXJlKCcuLi9pbnRlcm5hbC9wYXJzZS1vcHRpb25zJylcbmNvbnN0IHsgY29tcGFyZUlkZW50aWZpZXJzIH0gPSByZXF1aXJlKCcuLi9pbnRlcm5hbC9pZGVudGlmaWVycycpXG5cbmNvbnN0IGlzUHJlcmVsZWFzZUlkZW50aWZpZXIgPSAocHJlcmVsZWFzZSwgaWRlbnRpZmllcikgPT4ge1xuICBjb25zdCBpZGVudGlmaWVycyA9IGlkZW50aWZpZXIuc3BsaXQoJy4nKVxuICBpZiAoaWRlbnRpZmllcnMubGVuZ3RoID4gcHJlcmVsZWFzZS5sZW5ndGgpIHtcbiAgICByZXR1cm4gZmFsc2VcbiAgfVxuXG4gIGZvciAobGV0IGkgPSAwOyBpIDwgaWRlbnRpZmllcnMubGVuZ3RoOyBpKyspIHtcbiAgICBpZiAoY29tcGFyZUlkZW50aWZpZXJzKHByZXJlbGVhc2VbaV0sIGlkZW50aWZpZXJzW2ldKSAhPT0gMCkge1xuICAgICAgcmV0dXJuIGZhbHNlXG4gICAgfVxuICB9XG5cbiAgcmV0dXJuIHRydWVcbn1cblxuY2xhc3MgU2VtVmVyIHtcbiAgY29uc3RydWN0b3IgKHZlcnNpb24sIG9wdGlvbnMpIHtcbiAgICBvcHRpb25zID0gcGFyc2VPcHRpb25zKG9wdGlvbnMpXG5cbiAgICBpZiAodmVyc2lvbiBpbnN0YW5jZW9mIFNlbVZlcikge1xuICAgICAgaWYgKHZlcnNpb24ubG9vc2UgPT09ICEhb3B0aW9ucy5sb29zZSAmJlxuICAgICAgICB2ZXJzaW9uLmluY2x1ZGVQcmVyZWxlYXNlID09PSAhIW9wdGlvbnMuaW5jbHVkZVByZXJlbGVhc2UpIHtcbiAgICAgICAgcmV0dXJuIHZlcnNpb25cbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHZlcnNpb24gPSB2ZXJzaW9uLnZlcnNpb25cbiAgICAgIH1cbiAgICB9IGVsc2UgaWYgKHR5cGVvZiB2ZXJzaW9uICE9PSAnc3RyaW5nJykge1xuICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcihgSW52YWxpZCB2ZXJzaW9uLiBNdXN0IGJlIGEgc3RyaW5nLiBHb3QgdHlwZSBcIiR7dHlwZW9mIHZlcnNpb259XCIuYClcbiAgICB9XG5cbiAgICBpZiAodmVyc2lvbi5sZW5ndGggPiBNQVhfTEVOR1RIKSB7XG4gICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKFxuICAgICAgICBgdmVyc2lvbiBpcyBsb25nZXIgdGhhbiAke01BWF9MRU5HVEh9IGNoYXJhY3RlcnNgXG4gICAgICApXG4gICAgfVxuXG4gICAgZGVidWcoJ1NlbVZlcicsIHZlcnNpb24sIG9wdGlvbnMpXG4gICAgdGhpcy5vcHRpb25zID0gb3B0aW9uc1xuICAgIHRoaXMubG9vc2UgPSAhIW9wdGlvbnMubG9vc2VcbiAgICAvLyB0aGlzIGlzbid0IGFjdHVhbGx5IHJlbGV2YW50IGZvciB2ZXJzaW9ucywgYnV0IGtlZXAgaXQgc28gdGhhdCB3ZVxuICAgIC8vIGRvbid0IHJ1biBpbnRvIHRyb3VibGUgcGFzc2luZyB0aGlzLm9wdGlvbnMgYXJvdW5kLlxuICAgIHRoaXMuaW5jbHVkZVByZXJlbGVhc2UgPSAhIW9wdGlvbnMuaW5jbHVkZVByZXJlbGVhc2VcblxuICAgIGNvbnN0IG0gPSB2ZXJzaW9uLnRyaW0oKS5tYXRjaChvcHRpb25zLmxvb3NlID8gcmVbdC5MT09TRV0gOiByZVt0LkZVTExdKVxuXG4gICAgaWYgKCFtKSB7XG4gICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKGBJbnZhbGlkIFZlcnNpb246ICR7dmVyc2lvbn1gKVxuICAgIH1cblxuICAgIHRoaXMucmF3ID0gdmVyc2lvblxuXG4gICAgLy8gdGhlc2UgYXJlIGFjdHVhbGx5IG51bWJlcnNcbiAgICB0aGlzLm1ham9yID0gK21bMV1cbiAgICB0aGlzLm1pbm9yID0gK21bMl1cbiAgICB0aGlzLnBhdGNoID0gK21bM11cblxuICAgIGlmICh0aGlzLm1ham9yID4gTUFYX1NBRkVfSU5URUdFUiB8fCB0aGlzLm1ham9yIDwgMCkge1xuICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcignSW52YWxpZCBtYWpvciB2ZXJzaW9uJylcbiAgICB9XG5cbiAgICBpZiAodGhpcy5taW5vciA+IE1BWF9TQUZFX0lOVEVHRVIgfHwgdGhpcy5taW5vciA8IDApIHtcbiAgICAgIHRocm93IG5ldyBUeXBlRXJyb3IoJ0ludmFsaWQgbWlub3IgdmVyc2lvbicpXG4gICAgfVxuXG4gICAgaWYgKHRoaXMucGF0Y2ggPiBNQVhfU0FGRV9JTlRFR0VSIHx8IHRoaXMucGF0Y2ggPCAwKSB7XG4gICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKCdJbnZhbGlkIHBhdGNoIHZlcnNpb24nKVxuICAgIH1cblxuICAgIC8vIG51bWJlcmlmeSBhbnkgcHJlcmVsZWFzZSBudW1lcmljIGlkc1xuICAgIGlmICghbVs0XSkge1xuICAgICAgdGhpcy5wcmVyZWxlYXNlID0gW11cbiAgICB9IGVsc2Uge1xuICAgICAgdGhpcy5wcmVyZWxlYXNlID0gbVs0XS5zcGxpdCgnLicpLm1hcCgoaWQpID0+IHtcbiAgICAgICAgaWYgKC9eWzAtOV0rJC8udGVzdChpZCkpIHtcbiAgICAgICAgICBjb25zdCBudW0gPSAraWRcbiAgICAgICAgICBpZiAobnVtID49IDAgJiYgbnVtIDwgTUFYX1NBRkVfSU5URUdFUikge1xuICAgICAgICAgICAgcmV0dXJuIG51bVxuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gaWRcbiAgICAgIH0pXG4gICAgfVxuXG4gICAgdGhpcy5idWlsZCA9IG1bNV0gPyBtWzVdLnNwbGl0KCcuJykgOiBbXVxuICAgIHRoaXMuZm9ybWF0KClcbiAgfVxuXG4gIGZvcm1hdCAoKSB7XG4gICAgdGhpcy52ZXJzaW9uID0gYCR7dGhpcy5tYWpvcn0uJHt0aGlzLm1pbm9yfS4ke3RoaXMucGF0Y2h9YFxuICAgIGlmICh0aGlzLnByZXJlbGVhc2UubGVuZ3RoKSB7XG4gICAgICB0aGlzLnZlcnNpb24gKz0gYC0ke3RoaXMucHJlcmVsZWFzZS5qb2luKCcuJyl9YFxuICAgIH1cbiAgICByZXR1cm4gdGhpcy52ZXJzaW9uXG4gIH1cblxuICB0b1N0cmluZyAoKSB7XG4gICAgcmV0dXJuIHRoaXMudmVyc2lvblxuICB9XG5cbiAgY29tcGFyZSAob3RoZXIpIHtcbiAgICBkZWJ1ZygnU2VtVmVyLmNvbXBhcmUnLCB0aGlzLnZlcnNpb24sIHRoaXMub3B0aW9ucywgb3RoZXIpXG4gICAgaWYgKCEob3RoZXIgaW5zdGFuY2VvZiBTZW1WZXIpKSB7XG4gICAgICBpZiAodHlwZW9mIG90aGVyID09PSAnc3RyaW5nJyAmJiBvdGhlciA9PT0gdGhpcy52ZXJzaW9uKSB7XG4gICAgICAgIHJldHVybiAwXG4gICAgICB9XG4gICAgICBvdGhlciA9IG5ldyBTZW1WZXIob3RoZXIsIHRoaXMub3B0aW9ucylcbiAgICB9XG5cbiAgICBpZiAob3RoZXIudmVyc2lvbiA9PT0gdGhpcy52ZXJzaW9uKSB7XG4gICAgICByZXR1cm4gMFxuICAgIH1cblxuICAgIHJldHVybiB0aGlzLmNvbXBhcmVNYWluKG90aGVyKSB8fCB0aGlzLmNvbXBhcmVQcmUob3RoZXIpXG4gIH1cblxuICBjb21wYXJlTWFpbiAob3RoZXIpIHtcbiAgICBpZiAoIShvdGhlciBpbnN0YW5jZW9mIFNlbVZlcikpIHtcbiAgICAgIG90aGVyID0gbmV3IFNlbVZlcihvdGhlciwgdGhpcy5vcHRpb25zKVxuICAgIH1cblxuICAgIGlmICh0aGlzLm1ham9yIDwgb3RoZXIubWFqb3IpIHtcbiAgICAgIHJldHVybiAtMVxuICAgIH1cbiAgICBpZiAodGhpcy5tYWpvciA+IG90aGVyLm1ham9yKSB7XG4gICAgICByZXR1cm4gMVxuICAgIH1cbiAgICBpZiAodGhpcy5taW5vciA8IG90aGVyLm1pbm9yKSB7XG4gICAgICByZXR1cm4gLTFcbiAgICB9XG4gICAgaWYgKHRoaXMubWlub3IgPiBvdGhlci5taW5vcikge1xuICAgICAgcmV0dXJuIDFcbiAgICB9XG4gICAgaWYgKHRoaXMucGF0Y2ggPCBvdGhlci5wYXRjaCkge1xuICAgICAgcmV0dXJuIC0xXG4gICAgfVxuICAgIGlmICh0aGlzLnBhdGNoID4gb3RoZXIucGF0Y2gpIHtcbiAgICAgIHJldHVybiAxXG4gICAgfVxuICAgIHJldHVybiAwXG4gIH1cblxuICBjb21wYXJlUHJlIChvdGhlcikge1xuICAgIGlmICghKG90aGVyIGluc3RhbmNlb2YgU2VtVmVyKSkge1xuICAgICAgb3RoZXIgPSBuZXcgU2VtVmVyKG90aGVyLCB0aGlzLm9wdGlvbnMpXG4gICAgfVxuXG4gICAgLy8gTk9UIGhhdmluZyBhIHByZXJlbGVhc2UgaXMgPiBoYXZpbmcgb25lXG4gICAgaWYgKHRoaXMucHJlcmVsZWFzZS5sZW5ndGggJiYgIW90aGVyLnByZXJlbGVhc2UubGVuZ3RoKSB7XG4gICAgICByZXR1cm4gLTFcbiAgICB9IGVsc2UgaWYgKCF0aGlzLnByZXJlbGVhc2UubGVuZ3RoICYmIG90aGVyLnByZXJlbGVhc2UubGVuZ3RoKSB7XG4gICAgICByZXR1cm4gMVxuICAgIH0gZWxzZSBpZiAoIXRoaXMucHJlcmVsZWFzZS5sZW5ndGggJiYgIW90aGVyLnByZXJlbGVhc2UubGVuZ3RoKSB7XG4gICAgICByZXR1cm4gMFxuICAgIH1cblxuICAgIGxldCBpID0gMFxuICAgIGRvIHtcbiAgICAgIGNvbnN0IGEgPSB0aGlzLnByZXJlbGVhc2VbaV1cbiAgICAgIGNvbnN0IGIgPSBvdGhlci5wcmVyZWxlYXNlW2ldXG4gICAgICBkZWJ1ZygncHJlcmVsZWFzZSBjb21wYXJlJywgaSwgYSwgYilcbiAgICAgIGlmIChhID09PSB1bmRlZmluZWQgJiYgYiA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICAgIHJldHVybiAwXG4gICAgICB9IGVsc2UgaWYgKGIgPT09IHVuZGVmaW5lZCkge1xuICAgICAgICByZXR1cm4gMVxuICAgICAgfSBlbHNlIGlmIChhID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgcmV0dXJuIC0xXG4gICAgICB9IGVsc2UgaWYgKGEgPT09IGIpIHtcbiAgICAgICAgY29udGludWVcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHJldHVybiBjb21wYXJlSWRlbnRpZmllcnMoYSwgYilcbiAgICAgIH1cbiAgICB9IHdoaWxlICgrK2kpXG4gIH1cblxuICBjb21wYXJlQnVpbGQgKG90aGVyKSB7XG4gICAgaWYgKCEob3RoZXIgaW5zdGFuY2VvZiBTZW1WZXIpKSB7XG4gICAgICBvdGhlciA9IG5ldyBTZW1WZXIob3RoZXIsIHRoaXMub3B0aW9ucylcbiAgICB9XG5cbiAgICBsZXQgaSA9IDBcbiAgICBkbyB7XG4gICAgICBjb25zdCBhID0gdGhpcy5idWlsZFtpXVxuICAgICAgY29uc3QgYiA9IG90aGVyLmJ1aWxkW2ldXG4gICAgICBkZWJ1ZygnYnVpbGQgY29tcGFyZScsIGksIGEsIGIpXG4gICAgICBpZiAoYSA9PT0gdW5kZWZpbmVkICYmIGIgPT09IHVuZGVmaW5lZCkge1xuICAgICAgICByZXR1cm4gMFxuICAgICAgfSBlbHNlIGlmIChiID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgcmV0dXJuIDFcbiAgICAgIH0gZWxzZSBpZiAoYSA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICAgIHJldHVybiAtMVxuICAgICAgfSBlbHNlIGlmIChhID09PSBiKSB7XG4gICAgICAgIGNvbnRpbnVlXG4gICAgICB9IGVsc2Uge1xuICAgICAgICByZXR1cm4gY29tcGFyZUlkZW50aWZpZXJzKGEsIGIpXG4gICAgICB9XG4gICAgfSB3aGlsZSAoKytpKVxuICB9XG5cbiAgLy8gcHJlbWlub3Igd2lsbCBidW1wIHRoZSB2ZXJzaW9uIHVwIHRvIHRoZSBuZXh0IG1pbm9yIHJlbGVhc2UsIGFuZCBpbW1lZGlhdGVseVxuICAvLyBkb3duIHRvIHByZS1yZWxlYXNlLiBwcmVtYWpvciBhbmQgcHJlcGF0Y2ggd29yayB0aGUgc2FtZSB3YXkuXG4gIGluYyAocmVsZWFzZSwgaWRlbnRpZmllciwgaWRlbnRpZmllckJhc2UpIHtcbiAgICBpZiAocmVsZWFzZS5zdGFydHNXaXRoKCdwcmUnKSkge1xuICAgICAgaWYgKCFpZGVudGlmaWVyICYmIGlkZW50aWZpZXJCYXNlID09PSBmYWxzZSkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ2ludmFsaWQgaW5jcmVtZW50IGFyZ3VtZW50OiBpZGVudGlmaWVyIGlzIGVtcHR5JylcbiAgICAgIH1cbiAgICAgIC8vIEF2b2lkIGFuIGludmFsaWQgc2VtdmVyIHJlc3VsdHNcbiAgICAgIGlmIChpZGVudGlmaWVyKSB7XG4gICAgICAgIGNvbnN0IG1hdGNoID0gYC0ke2lkZW50aWZpZXJ9YC5tYXRjaCh0aGlzLm9wdGlvbnMubG9vc2UgPyByZVt0LlBSRVJFTEVBU0VMT09TRV0gOiByZVt0LlBSRVJFTEVBU0VdKVxuICAgICAgICBpZiAoIW1hdGNoIHx8IG1hdGNoWzFdICE9PSBpZGVudGlmaWVyKSB7XG4gICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBpbnZhbGlkIGlkZW50aWZpZXI6ICR7aWRlbnRpZmllcn1gKVxuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuXG4gICAgc3dpdGNoIChyZWxlYXNlKSB7XG4gICAgICBjYXNlICdwcmVtYWpvcic6XG4gICAgICAgIHRoaXMucHJlcmVsZWFzZS5sZW5ndGggPSAwXG4gICAgICAgIHRoaXMucGF0Y2ggPSAwXG4gICAgICAgIHRoaXMubWlub3IgPSAwXG4gICAgICAgIHRoaXMubWFqb3IrK1xuICAgICAgICB0aGlzLmluYygncHJlJywgaWRlbnRpZmllciwgaWRlbnRpZmllckJhc2UpXG4gICAgICAgIGJyZWFrXG4gICAgICBjYXNlICdwcmVtaW5vcic6XG4gICAgICAgIHRoaXMucHJlcmVsZWFzZS5sZW5ndGggPSAwXG4gICAgICAgIHRoaXMucGF0Y2ggPSAwXG4gICAgICAgIHRoaXMubWlub3IrK1xuICAgICAgICB0aGlzLmluYygncHJlJywgaWRlbnRpZmllciwgaWRlbnRpZmllckJhc2UpXG4gICAgICAgIGJyZWFrXG4gICAgICBjYXNlICdwcmVwYXRjaCc6XG4gICAgICAgIC8vIElmIHRoaXMgaXMgYWxyZWFkeSBhIHByZXJlbGVhc2UsIGl0IHdpbGwgYnVtcCB0byB0aGUgbmV4dCB2ZXJzaW9uXG4gICAgICAgIC8vIGRyb3AgYW55IHByZXJlbGVhc2VzIHRoYXQgbWlnaHQgYWxyZWFkeSBleGlzdCwgc2luY2UgdGhleSBhcmUgbm90XG4gICAgICAgIC8vIHJlbGV2YW50IGF0IHRoaXMgcG9pbnQuXG4gICAgICAgIHRoaXMucHJlcmVsZWFzZS5sZW5ndGggPSAwXG4gICAgICAgIHRoaXMuaW5jKCdwYXRjaCcsIGlkZW50aWZpZXIsIGlkZW50aWZpZXJCYXNlKVxuICAgICAgICB0aGlzLmluYygncHJlJywgaWRlbnRpZmllciwgaWRlbnRpZmllckJhc2UpXG4gICAgICAgIGJyZWFrXG4gICAgICAvLyBJZiB0aGUgaW5wdXQgaXMgYSBub24tcHJlcmVsZWFzZSB2ZXJzaW9uLCB0aGlzIGFjdHMgdGhlIHNhbWUgYXNcbiAgICAgIC8vIHByZXBhdGNoLlxuICAgICAgY2FzZSAncHJlcmVsZWFzZSc6XG4gICAgICAgIGlmICh0aGlzLnByZXJlbGVhc2UubGVuZ3RoID09PSAwKSB7XG4gICAgICAgICAgdGhpcy5pbmMoJ3BhdGNoJywgaWRlbnRpZmllciwgaWRlbnRpZmllckJhc2UpXG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5pbmMoJ3ByZScsIGlkZW50aWZpZXIsIGlkZW50aWZpZXJCYXNlKVxuICAgICAgICBicmVha1xuICAgICAgY2FzZSAncmVsZWFzZSc6XG4gICAgICAgIGlmICh0aGlzLnByZXJlbGVhc2UubGVuZ3RoID09PSAwKSB7XG4gICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGB2ZXJzaW9uICR7dGhpcy5yYXd9IGlzIG5vdCBhIHByZXJlbGVhc2VgKVxuICAgICAgICB9XG4gICAgICAgIHRoaXMucHJlcmVsZWFzZS5sZW5ndGggPSAwXG4gICAgICAgIGJyZWFrXG5cbiAgICAgIGNhc2UgJ21ham9yJzpcbiAgICAgICAgLy8gSWYgdGhpcyBpcyBhIHByZS1tYWpvciB2ZXJzaW9uLCBidW1wIHVwIHRvIHRoZSBzYW1lIG1ham9yIHZlcnNpb24uXG4gICAgICAgIC8vIE90aGVyd2lzZSBpbmNyZW1lbnQgbWFqb3IuXG4gICAgICAgIC8vIDEuMC4wLTUgYnVtcHMgdG8gMS4wLjBcbiAgICAgICAgLy8gMS4xLjAgYnVtcHMgdG8gMi4wLjBcbiAgICAgICAgaWYgKFxuICAgICAgICAgIHRoaXMubWlub3IgIT09IDAgfHxcbiAgICAgICAgICB0aGlzLnBhdGNoICE9PSAwIHx8XG4gICAgICAgICAgdGhpcy5wcmVyZWxlYXNlLmxlbmd0aCA9PT0gMFxuICAgICAgICApIHtcbiAgICAgICAgICB0aGlzLm1ham9yKytcbiAgICAgICAgfVxuICAgICAgICB0aGlzLm1pbm9yID0gMFxuICAgICAgICB0aGlzLnBhdGNoID0gMFxuICAgICAgICB0aGlzLnByZXJlbGVhc2UgPSBbXVxuICAgICAgICBicmVha1xuICAgICAgY2FzZSAnbWlub3InOlxuICAgICAgICAvLyBJZiB0aGlzIGlzIGEgcHJlLW1pbm9yIHZlcnNpb24sIGJ1bXAgdXAgdG8gdGhlIHNhbWUgbWlub3IgdmVyc2lvbi5cbiAgICAgICAgLy8gT3RoZXJ3aXNlIGluY3JlbWVudCBtaW5vci5cbiAgICAgICAgLy8gMS4yLjAtNSBidW1wcyB0byAxLjIuMFxuICAgICAgICAvLyAxLjIuMSBidW1wcyB0byAxLjMuMFxuICAgICAgICBpZiAodGhpcy5wYXRjaCAhPT0gMCB8fCB0aGlzLnByZXJlbGVhc2UubGVuZ3RoID09PSAwKSB7XG4gICAgICAgICAgdGhpcy5taW5vcisrXG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5wYXRjaCA9IDBcbiAgICAgICAgdGhpcy5wcmVyZWxlYXNlID0gW11cbiAgICAgICAgYnJlYWtcbiAgICAgIGNhc2UgJ3BhdGNoJzpcbiAgICAgICAgLy8gSWYgdGhpcyBpcyBub3QgYSBwcmUtcmVsZWFzZSB2ZXJzaW9uLCBpdCB3aWxsIGluY3JlbWVudCB0aGUgcGF0Y2guXG4gICAgICAgIC8vIElmIGl0IGlzIGEgcHJlLXJlbGVhc2UgaXQgd2lsbCBidW1wIHVwIHRvIHRoZSBzYW1lIHBhdGNoIHZlcnNpb24uXG4gICAgICAgIC8vIDEuMi4wLTUgcGF0Y2hlcyB0byAxLjIuMFxuICAgICAgICAvLyAxLjIuMCBwYXRjaGVzIHRvIDEuMi4xXG4gICAgICAgIGlmICh0aGlzLnByZXJlbGVhc2UubGVuZ3RoID09PSAwKSB7XG4gICAgICAgICAgdGhpcy5wYXRjaCsrXG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5wcmVyZWxlYXNlID0gW11cbiAgICAgICAgYnJlYWtcbiAgICAgIC8vIFRoaXMgcHJvYmFibHkgc2hvdWxkbid0IGJlIHVzZWQgcHVibGljbHkuXG4gICAgICAvLyAxLjAuMCAncHJlJyB3b3VsZCBiZWNvbWUgMS4wLjAtMCB3aGljaCBpcyB0aGUgd3JvbmcgZGlyZWN0aW9uLlxuICAgICAgY2FzZSAncHJlJzoge1xuICAgICAgICBjb25zdCBiYXNlID0gTnVtYmVyKGlkZW50aWZpZXJCYXNlKSA/IDEgOiAwXG5cbiAgICAgICAgaWYgKHRoaXMucHJlcmVsZWFzZS5sZW5ndGggPT09IDApIHtcbiAgICAgICAgICB0aGlzLnByZXJlbGVhc2UgPSBbYmFzZV1cbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBsZXQgaSA9IHRoaXMucHJlcmVsZWFzZS5sZW5ndGhcbiAgICAgICAgICB3aGlsZSAoLS1pID49IDApIHtcbiAgICAgICAgICAgIGlmICh0eXBlb2YgdGhpcy5wcmVyZWxlYXNlW2ldID09PSAnbnVtYmVyJykge1xuICAgICAgICAgICAgICB0aGlzLnByZXJlbGVhc2VbaV0rK1xuICAgICAgICAgICAgICBpID0gLTJcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgICAgaWYgKGkgPT09IC0xKSB7XG4gICAgICAgICAgICAvLyBkaWRuJ3QgaW5jcmVtZW50IGFueXRoaW5nXG4gICAgICAgICAgICBpZiAoaWRlbnRpZmllciA9PT0gdGhpcy5wcmVyZWxlYXNlLmpvaW4oJy4nKSAmJiBpZGVudGlmaWVyQmFzZSA9PT0gZmFsc2UpIHtcbiAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdpbnZhbGlkIGluY3JlbWVudCBhcmd1bWVudDogaWRlbnRpZmllciBhbHJlYWR5IGV4aXN0cycpXG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB0aGlzLnByZXJlbGVhc2UucHVzaChiYXNlKVxuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBpZiAoaWRlbnRpZmllcikge1xuICAgICAgICAgIC8vIDEuMi4wLWJldGEuMSBidW1wcyB0byAxLjIuMC1iZXRhLjIsXG4gICAgICAgICAgLy8gMS4yLjAtYmV0YS5mb29ibHogb3IgMS4yLjAtYmV0YSBidW1wcyB0byAxLjIuMC1iZXRhLjBcbiAgICAgICAgICBsZXQgcHJlcmVsZWFzZSA9IFtpZGVudGlmaWVyLCBiYXNlXVxuICAgICAgICAgIGlmIChpZGVudGlmaWVyQmFzZSA9PT0gZmFsc2UpIHtcbiAgICAgICAgICAgIHByZXJlbGVhc2UgPSBbaWRlbnRpZmllcl1cbiAgICAgICAgICB9XG4gICAgICAgICAgaWYgKGlzUHJlcmVsZWFzZUlkZW50aWZpZXIodGhpcy5wcmVyZWxlYXNlLCBpZGVudGlmaWVyKSkge1xuICAgICAgICAgICAgY29uc3QgcHJlcmVsZWFzZUJhc2UgPSB0aGlzLnByZXJlbGVhc2VbaWRlbnRpZmllci5zcGxpdCgnLicpLmxlbmd0aF1cbiAgICAgICAgICAgIGlmIChpc05hTihwcmVyZWxlYXNlQmFzZSkpIHtcbiAgICAgICAgICAgICAgdGhpcy5wcmVyZWxlYXNlID0gcHJlcmVsZWFzZVxuICAgICAgICAgICAgfVxuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICB0aGlzLnByZXJlbGVhc2UgPSBwcmVyZWxlYXNlXG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGJyZWFrXG4gICAgICB9XG4gICAgICBkZWZhdWx0OlxuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYGludmFsaWQgaW5jcmVtZW50IGFyZ3VtZW50OiAke3JlbGVhc2V9YClcbiAgICB9XG4gICAgdGhpcy5yYXcgPSB0aGlzLmZvcm1hdCgpXG4gICAgaWYgKHRoaXMuYnVpbGQubGVuZ3RoKSB7XG4gICAgICB0aGlzLnJhdyArPSBgKyR7dGhpcy5idWlsZC5qb2luKCcuJyl9YFxuICAgIH1cbiAgICByZXR1cm4gdGhpc1xuICB9XG59XG5cbm1vZHVsZS5leHBvcnRzID0gU2VtVmVyXG4iLCAiJ3VzZSBzdHJpY3QnXG5cbmNvbnN0IFNlbVZlciA9IHJlcXVpcmUoJy4uL2NsYXNzZXMvc2VtdmVyJylcbmNvbnN0IHBhcnNlID0gKHZlcnNpb24sIG9wdGlvbnMsIHRocm93RXJyb3JzID0gZmFsc2UpID0+IHtcbiAgaWYgKHZlcnNpb24gaW5zdGFuY2VvZiBTZW1WZXIpIHtcbiAgICByZXR1cm4gdmVyc2lvblxuICB9XG4gIHRyeSB7XG4gICAgcmV0dXJuIG5ldyBTZW1WZXIodmVyc2lvbiwgb3B0aW9ucylcbiAgfSBjYXRjaCAoZXIpIHtcbiAgICBpZiAoIXRocm93RXJyb3JzKSB7XG4gICAgICByZXR1cm4gbnVsbFxuICAgIH1cbiAgICB0aHJvdyBlclxuICB9XG59XG5cbm1vZHVsZS5leHBvcnRzID0gcGFyc2VcbiIsICIndXNlIHN0cmljdCdcblxuY29uc3QgcGFyc2UgPSByZXF1aXJlKCcuL3BhcnNlJylcbmNvbnN0IHZhbGlkID0gKHZlcnNpb24sIG9wdGlvbnMpID0+IHtcbiAgY29uc3QgdiA9IHBhcnNlKHZlcnNpb24sIG9wdGlvbnMpXG4gIHJldHVybiB2ID8gdi52ZXJzaW9uIDogbnVsbFxufVxubW9kdWxlLmV4cG9ydHMgPSB2YWxpZFxuIiwgIid1c2Ugc3RyaWN0J1xuXG5jb25zdCBwYXJzZSA9IHJlcXVpcmUoJy4vcGFyc2UnKVxuY29uc3QgY2xlYW4gPSAodmVyc2lvbiwgb3B0aW9ucykgPT4ge1xuICBjb25zdCBzID0gcGFyc2UodmVyc2lvbi50cmltKCkucmVwbGFjZSgvXls9dl0rLywgJycpLCBvcHRpb25zKVxuICByZXR1cm4gcyA/IHMudmVyc2lvbiA6IG51bGxcbn1cbm1vZHVsZS5leHBvcnRzID0gY2xlYW5cbiIsICIndXNlIHN0cmljdCdcblxuY29uc3QgU2VtVmVyID0gcmVxdWlyZSgnLi4vY2xhc3Nlcy9zZW12ZXInKVxuXG5jb25zdCBpbmMgPSAodmVyc2lvbiwgcmVsZWFzZSwgb3B0aW9ucywgaWRlbnRpZmllciwgaWRlbnRpZmllckJhc2UpID0+IHtcbiAgaWYgKHR5cGVvZiAob3B0aW9ucykgPT09ICdzdHJpbmcnKSB7XG4gICAgaWRlbnRpZmllckJhc2UgPSBpZGVudGlmaWVyXG4gICAgaWRlbnRpZmllciA9IG9wdGlvbnNcbiAgICBvcHRpb25zID0gdW5kZWZpbmVkXG4gIH1cblxuICB0cnkge1xuICAgIHJldHVybiBuZXcgU2VtVmVyKFxuICAgICAgdmVyc2lvbiBpbnN0YW5jZW9mIFNlbVZlciA/IHZlcnNpb24udmVyc2lvbiA6IHZlcnNpb24sXG4gICAgICBvcHRpb25zXG4gICAgKS5pbmMocmVsZWFzZSwgaWRlbnRpZmllciwgaWRlbnRpZmllckJhc2UpLnZlcnNpb25cbiAgfSBjYXRjaCAoZXIpIHtcbiAgICByZXR1cm4gbnVsbFxuICB9XG59XG5tb2R1bGUuZXhwb3J0cyA9IGluY1xuIiwgIid1c2Ugc3RyaWN0J1xuXG5jb25zdCBwYXJzZSA9IHJlcXVpcmUoJy4vcGFyc2UuanMnKVxuXG5jb25zdCBkaWZmID0gKHZlcnNpb24xLCB2ZXJzaW9uMikgPT4ge1xuICBjb25zdCB2MSA9IHBhcnNlKHZlcnNpb24xLCBudWxsLCB0cnVlKVxuICBjb25zdCB2MiA9IHBhcnNlKHZlcnNpb24yLCBudWxsLCB0cnVlKVxuICBjb25zdCBjb21wYXJpc29uID0gdjEuY29tcGFyZSh2MilcblxuICBpZiAoY29tcGFyaXNvbiA9PT0gMCkge1xuICAgIHJldHVybiBudWxsXG4gIH1cblxuICBjb25zdCB2MUhpZ2hlciA9IGNvbXBhcmlzb24gPiAwXG4gIGNvbnN0IGhpZ2hWZXJzaW9uID0gdjFIaWdoZXIgPyB2MSA6IHYyXG4gIGNvbnN0IGxvd1ZlcnNpb24gPSB2MUhpZ2hlciA/IHYyIDogdjFcbiAgY29uc3QgaGlnaEhhc1ByZSA9ICEhaGlnaFZlcnNpb24ucHJlcmVsZWFzZS5sZW5ndGhcbiAgY29uc3QgbG93SGFzUHJlID0gISFsb3dWZXJzaW9uLnByZXJlbGVhc2UubGVuZ3RoXG5cbiAgaWYgKGxvd0hhc1ByZSAmJiAhaGlnaEhhc1ByZSkge1xuICAgIC8vIEdvaW5nIGZyb20gcHJlcmVsZWFzZSAtPiBubyBwcmVyZWxlYXNlIHJlcXVpcmVzIHNvbWUgc3BlY2lhbCBjYXNpbmdcblxuICAgIC8vIElmIHRoZSBsb3cgdmVyc2lvbiBoYXMgb25seSBhIG1ham9yLCB0aGVuIGl0IHdpbGwgYWx3YXlzIGJlIGEgbWFqb3JcbiAgICAvLyBTb21lIGV4YW1wbGVzOlxuICAgIC8vIDEuMC4wLTEgLT4gMS4wLjBcbiAgICAvLyAxLjAuMC0xIC0+IDEuMS4xXG4gICAgLy8gMS4wLjAtMSAtPiAyLjAuMFxuICAgIGlmICghbG93VmVyc2lvbi5wYXRjaCAmJiAhbG93VmVyc2lvbi5taW5vcikge1xuICAgICAgcmV0dXJuICdtYWpvcidcbiAgICB9XG5cbiAgICAvLyBJZiB0aGUgbWFpbiBwYXJ0IGhhcyBubyBkaWZmZXJlbmNlXG4gICAgaWYgKGxvd1ZlcnNpb24uY29tcGFyZU1haW4oaGlnaFZlcnNpb24pID09PSAwKSB7XG4gICAgICBpZiAobG93VmVyc2lvbi5taW5vciAmJiAhbG93VmVyc2lvbi5wYXRjaCkge1xuICAgICAgICByZXR1cm4gJ21pbm9yJ1xuICAgICAgfVxuICAgICAgcmV0dXJuICdwYXRjaCdcbiAgICB9XG4gIH1cblxuICAvLyBhZGQgdGhlIGBwcmVgIHByZWZpeCBpZiB3ZSBhcmUgZ29pbmcgdG8gYSBwcmVyZWxlYXNlIHZlcnNpb25cbiAgY29uc3QgcHJlZml4ID0gaGlnaEhhc1ByZSA/ICdwcmUnIDogJydcblxuICBpZiAodjEubWFqb3IgIT09IHYyLm1ham9yKSB7XG4gICAgcmV0dXJuIHByZWZpeCArICdtYWpvcidcbiAgfVxuXG4gIGlmICh2MS5taW5vciAhPT0gdjIubWlub3IpIHtcbiAgICByZXR1cm4gcHJlZml4ICsgJ21pbm9yJ1xuICB9XG5cbiAgaWYgKHYxLnBhdGNoICE9PSB2Mi5wYXRjaCkge1xuICAgIHJldHVybiBwcmVmaXggKyAncGF0Y2gnXG4gIH1cblxuICAvLyBoaWdoIGFuZCBsb3cgYXJlIHByZXJlbGVhc2VzXG4gIHJldHVybiAncHJlcmVsZWFzZSdcbn1cblxubW9kdWxlLmV4cG9ydHMgPSBkaWZmXG4iLCAiJ3VzZSBzdHJpY3QnXG5cbmNvbnN0IFNlbVZlciA9IHJlcXVpcmUoJy4uL2NsYXNzZXMvc2VtdmVyJylcbmNvbnN0IG1ham9yID0gKGEsIGxvb3NlKSA9PiBuZXcgU2VtVmVyKGEsIGxvb3NlKS5tYWpvclxubW9kdWxlLmV4cG9ydHMgPSBtYWpvclxuIiwgIid1c2Ugc3RyaWN0J1xuXG5jb25zdCBTZW1WZXIgPSByZXF1aXJlKCcuLi9jbGFzc2VzL3NlbXZlcicpXG5jb25zdCBtaW5vciA9IChhLCBsb29zZSkgPT4gbmV3IFNlbVZlcihhLCBsb29zZSkubWlub3Jcbm1vZHVsZS5leHBvcnRzID0gbWlub3JcbiIsICIndXNlIHN0cmljdCdcblxuY29uc3QgU2VtVmVyID0gcmVxdWlyZSgnLi4vY2xhc3Nlcy9zZW12ZXInKVxuY29uc3QgcGF0Y2ggPSAoYSwgbG9vc2UpID0+IG5ldyBTZW1WZXIoYSwgbG9vc2UpLnBhdGNoXG5tb2R1bGUuZXhwb3J0cyA9IHBhdGNoXG4iLCAiJ3VzZSBzdHJpY3QnXG5cbmNvbnN0IHBhcnNlID0gcmVxdWlyZSgnLi9wYXJzZScpXG5jb25zdCBwcmVyZWxlYXNlID0gKHZlcnNpb24sIG9wdGlvbnMpID0+IHtcbiAgY29uc3QgcGFyc2VkID0gcGFyc2UodmVyc2lvbiwgb3B0aW9ucylcbiAgcmV0dXJuIChwYXJzZWQgJiYgcGFyc2VkLnByZXJlbGVhc2UubGVuZ3RoKSA/IHBhcnNlZC5wcmVyZWxlYXNlIDogbnVsbFxufVxubW9kdWxlLmV4cG9ydHMgPSBwcmVyZWxlYXNlXG4iLCAiJ3VzZSBzdHJpY3QnXG5cbmNvbnN0IFNlbVZlciA9IHJlcXVpcmUoJy4uL2NsYXNzZXMvc2VtdmVyJylcbmNvbnN0IGNvbXBhcmUgPSAoYSwgYiwgbG9vc2UpID0+XG4gIG5ldyBTZW1WZXIoYSwgbG9vc2UpLmNvbXBhcmUobmV3IFNlbVZlcihiLCBsb29zZSkpXG5cbm1vZHVsZS5leHBvcnRzID0gY29tcGFyZVxuIiwgIid1c2Ugc3RyaWN0J1xuXG5jb25zdCBjb21wYXJlID0gcmVxdWlyZSgnLi9jb21wYXJlJylcbmNvbnN0IHJjb21wYXJlID0gKGEsIGIsIGxvb3NlKSA9PiBjb21wYXJlKGIsIGEsIGxvb3NlKVxubW9kdWxlLmV4cG9ydHMgPSByY29tcGFyZVxuIiwgIid1c2Ugc3RyaWN0J1xuXG5jb25zdCBjb21wYXJlID0gcmVxdWlyZSgnLi9jb21wYXJlJylcbmNvbnN0IGNvbXBhcmVMb29zZSA9IChhLCBiKSA9PiBjb21wYXJlKGEsIGIsIHRydWUpXG5tb2R1bGUuZXhwb3J0cyA9IGNvbXBhcmVMb29zZVxuIiwgIid1c2Ugc3RyaWN0J1xuXG5jb25zdCBTZW1WZXIgPSByZXF1aXJlKCcuLi9jbGFzc2VzL3NlbXZlcicpXG5jb25zdCBjb21wYXJlQnVpbGQgPSAoYSwgYiwgbG9vc2UpID0+IHtcbiAgY29uc3QgdmVyc2lvbkEgPSBuZXcgU2VtVmVyKGEsIGxvb3NlKVxuICBjb25zdCB2ZXJzaW9uQiA9IG5ldyBTZW1WZXIoYiwgbG9vc2UpXG4gIHJldHVybiB2ZXJzaW9uQS5jb21wYXJlKHZlcnNpb25CKSB8fCB2ZXJzaW9uQS5jb21wYXJlQnVpbGQodmVyc2lvbkIpXG59XG5tb2R1bGUuZXhwb3J0cyA9IGNvbXBhcmVCdWlsZFxuIiwgIid1c2Ugc3RyaWN0J1xuXG5jb25zdCBjb21wYXJlQnVpbGQgPSByZXF1aXJlKCcuL2NvbXBhcmUtYnVpbGQnKVxuY29uc3Qgc29ydCA9IChsaXN0LCBsb29zZSkgPT4gbGlzdC5zb3J0KChhLCBiKSA9PiBjb21wYXJlQnVpbGQoYSwgYiwgbG9vc2UpKVxubW9kdWxlLmV4cG9ydHMgPSBzb3J0XG4iLCAiJ3VzZSBzdHJpY3QnXG5cbmNvbnN0IGNvbXBhcmVCdWlsZCA9IHJlcXVpcmUoJy4vY29tcGFyZS1idWlsZCcpXG5jb25zdCByc29ydCA9IChsaXN0LCBsb29zZSkgPT4gbGlzdC5zb3J0KChhLCBiKSA9PiBjb21wYXJlQnVpbGQoYiwgYSwgbG9vc2UpKVxubW9kdWxlLmV4cG9ydHMgPSByc29ydFxuIiwgIid1c2Ugc3RyaWN0J1xuXG5jb25zdCBjb21wYXJlID0gcmVxdWlyZSgnLi9jb21wYXJlJylcbmNvbnN0IGd0ID0gKGEsIGIsIGxvb3NlKSA9PiBjb21wYXJlKGEsIGIsIGxvb3NlKSA+IDBcbm1vZHVsZS5leHBvcnRzID0gZ3RcbiIsICIndXNlIHN0cmljdCdcblxuY29uc3QgY29tcGFyZSA9IHJlcXVpcmUoJy4vY29tcGFyZScpXG5jb25zdCBsdCA9IChhLCBiLCBsb29zZSkgPT4gY29tcGFyZShhLCBiLCBsb29zZSkgPCAwXG5tb2R1bGUuZXhwb3J0cyA9IGx0XG4iLCAiJ3VzZSBzdHJpY3QnXG5cbmNvbnN0IGNvbXBhcmUgPSByZXF1aXJlKCcuL2NvbXBhcmUnKVxuY29uc3QgZXEgPSAoYSwgYiwgbG9vc2UpID0+IGNvbXBhcmUoYSwgYiwgbG9vc2UpID09PSAwXG5tb2R1bGUuZXhwb3J0cyA9IGVxXG4iLCAiJ3VzZSBzdHJpY3QnXG5cbmNvbnN0IGNvbXBhcmUgPSByZXF1aXJlKCcuL2NvbXBhcmUnKVxuY29uc3QgbmVxID0gKGEsIGIsIGxvb3NlKSA9PiBjb21wYXJlKGEsIGIsIGxvb3NlKSAhPT0gMFxubW9kdWxlLmV4cG9ydHMgPSBuZXFcbiIsICIndXNlIHN0cmljdCdcblxuY29uc3QgY29tcGFyZSA9IHJlcXVpcmUoJy4vY29tcGFyZScpXG5jb25zdCBndGUgPSAoYSwgYiwgbG9vc2UpID0+IGNvbXBhcmUoYSwgYiwgbG9vc2UpID49IDBcbm1vZHVsZS5leHBvcnRzID0gZ3RlXG4iLCAiJ3VzZSBzdHJpY3QnXG5cbmNvbnN0IGNvbXBhcmUgPSByZXF1aXJlKCcuL2NvbXBhcmUnKVxuY29uc3QgbHRlID0gKGEsIGIsIGxvb3NlKSA9PiBjb21wYXJlKGEsIGIsIGxvb3NlKSA8PSAwXG5tb2R1bGUuZXhwb3J0cyA9IGx0ZVxuIiwgIid1c2Ugc3RyaWN0J1xuXG5jb25zdCBlcSA9IHJlcXVpcmUoJy4vZXEnKVxuY29uc3QgbmVxID0gcmVxdWlyZSgnLi9uZXEnKVxuY29uc3QgZ3QgPSByZXF1aXJlKCcuL2d0JylcbmNvbnN0IGd0ZSA9IHJlcXVpcmUoJy4vZ3RlJylcbmNvbnN0IGx0ID0gcmVxdWlyZSgnLi9sdCcpXG5jb25zdCBsdGUgPSByZXF1aXJlKCcuL2x0ZScpXG5cbmNvbnN0IGNtcCA9IChhLCBvcCwgYiwgbG9vc2UpID0+IHtcbiAgc3dpdGNoIChvcCkge1xuICAgIGNhc2UgJz09PSc6XG4gICAgICBpZiAodHlwZW9mIGEgPT09ICdvYmplY3QnKSB7XG4gICAgICAgIGEgPSBhLnZlcnNpb25cbiAgICAgIH1cbiAgICAgIGlmICh0eXBlb2YgYiA9PT0gJ29iamVjdCcpIHtcbiAgICAgICAgYiA9IGIudmVyc2lvblxuICAgICAgfVxuICAgICAgcmV0dXJuIGEgPT09IGJcblxuICAgIGNhc2UgJyE9PSc6XG4gICAgICBpZiAodHlwZW9mIGEgPT09ICdvYmplY3QnKSB7XG4gICAgICAgIGEgPSBhLnZlcnNpb25cbiAgICAgIH1cbiAgICAgIGlmICh0eXBlb2YgYiA9PT0gJ29iamVjdCcpIHtcbiAgICAgICAgYiA9IGIudmVyc2lvblxuICAgICAgfVxuICAgICAgcmV0dXJuIGEgIT09IGJcblxuICAgIGNhc2UgJyc6XG4gICAgY2FzZSAnPSc6XG4gICAgY2FzZSAnPT0nOlxuICAgICAgcmV0dXJuIGVxKGEsIGIsIGxvb3NlKVxuXG4gICAgY2FzZSAnIT0nOlxuICAgICAgcmV0dXJuIG5lcShhLCBiLCBsb29zZSlcblxuICAgIGNhc2UgJz4nOlxuICAgICAgcmV0dXJuIGd0KGEsIGIsIGxvb3NlKVxuXG4gICAgY2FzZSAnPj0nOlxuICAgICAgcmV0dXJuIGd0ZShhLCBiLCBsb29zZSlcblxuICAgIGNhc2UgJzwnOlxuICAgICAgcmV0dXJuIGx0KGEsIGIsIGxvb3NlKVxuXG4gICAgY2FzZSAnPD0nOlxuICAgICAgcmV0dXJuIGx0ZShhLCBiLCBsb29zZSlcblxuICAgIGRlZmF1bHQ6XG4gICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKGBJbnZhbGlkIG9wZXJhdG9yOiAke29wfWApXG4gIH1cbn1cbm1vZHVsZS5leHBvcnRzID0gY21wXG4iLCAiJ3VzZSBzdHJpY3QnXG5cbmNvbnN0IFNlbVZlciA9IHJlcXVpcmUoJy4uL2NsYXNzZXMvc2VtdmVyJylcbmNvbnN0IHBhcnNlID0gcmVxdWlyZSgnLi9wYXJzZScpXG5jb25zdCB7IHNhZmVSZTogcmUsIHQgfSA9IHJlcXVpcmUoJy4uL2ludGVybmFsL3JlJylcblxuY29uc3QgY29lcmNlID0gKHZlcnNpb24sIG9wdGlvbnMpID0+IHtcbiAgaWYgKHZlcnNpb24gaW5zdGFuY2VvZiBTZW1WZXIpIHtcbiAgICByZXR1cm4gdmVyc2lvblxuICB9XG5cbiAgaWYgKHR5cGVvZiB2ZXJzaW9uID09PSAnbnVtYmVyJykge1xuICAgIHZlcnNpb24gPSBTdHJpbmcodmVyc2lvbilcbiAgfVxuXG4gIGlmICh0eXBlb2YgdmVyc2lvbiAhPT0gJ3N0cmluZycpIHtcbiAgICByZXR1cm4gbnVsbFxuICB9XG5cbiAgb3B0aW9ucyA9IG9wdGlvbnMgfHwge31cblxuICBsZXQgbWF0Y2ggPSBudWxsXG4gIGlmICghb3B0aW9ucy5ydGwpIHtcbiAgICBtYXRjaCA9IHZlcnNpb24ubWF0Y2gob3B0aW9ucy5pbmNsdWRlUHJlcmVsZWFzZSA/IHJlW3QuQ09FUkNFRlVMTF0gOiByZVt0LkNPRVJDRV0pXG4gIH0gZWxzZSB7XG4gICAgLy8gRmluZCB0aGUgcmlnaHQtbW9zdCBjb2VyY2libGUgc3RyaW5nIHRoYXQgZG9lcyBub3Qgc2hhcmVcbiAgICAvLyBhIHRlcm1pbnVzIHdpdGggYSBtb3JlIGxlZnQtd2FyZCBjb2VyY2libGUgc3RyaW5nLlxuICAgIC8vIEVnLCAnMS4yLjMuNCcgd2FudHMgdG8gY29lcmNlICcyLjMuNCcsIG5vdCAnMy40JyBvciAnNCdcbiAgICAvLyBXaXRoIGluY2x1ZGVQcmVyZWxlYXNlIG9wdGlvbiBzZXQsICcxLjIuMy40LXJjJyB3YW50cyB0byBjb2VyY2UgJzIuMy40LXJjJywgbm90ICcyLjMuNCdcbiAgICAvL1xuICAgIC8vIFdhbGsgdGhyb3VnaCB0aGUgc3RyaW5nIGNoZWNraW5nIHdpdGggYSAvZyByZWdleHBcbiAgICAvLyBNYW51YWxseSBzZXQgdGhlIGluZGV4IHNvIGFzIHRvIHBpY2sgdXAgb3ZlcmxhcHBpbmcgbWF0Y2hlcy5cbiAgICAvLyBTdG9wIHdoZW4gd2UgZ2V0IGEgbWF0Y2ggdGhhdCBlbmRzIGF0IHRoZSBzdHJpbmcgZW5kLCBzaW5jZSBub1xuICAgIC8vIGNvZXJjaWJsZSBzdHJpbmcgY2FuIGJlIG1vcmUgcmlnaHQtd2FyZCB3aXRob3V0IHRoZSBzYW1lIHRlcm1pbnVzLlxuICAgIGNvbnN0IGNvZXJjZVJ0bFJlZ2V4ID0gb3B0aW9ucy5pbmNsdWRlUHJlcmVsZWFzZSA/IHJlW3QuQ09FUkNFUlRMRlVMTF0gOiByZVt0LkNPRVJDRVJUTF1cbiAgICBsZXQgbmV4dFxuICAgIHdoaWxlICgobmV4dCA9IGNvZXJjZVJ0bFJlZ2V4LmV4ZWModmVyc2lvbikpICYmXG4gICAgICAgICghbWF0Y2ggfHwgbWF0Y2guaW5kZXggKyBtYXRjaFswXS5sZW5ndGggIT09IHZlcnNpb24ubGVuZ3RoKVxuICAgICkge1xuICAgICAgaWYgKCFtYXRjaCB8fFxuICAgICAgICAgICAgbmV4dC5pbmRleCArIG5leHRbMF0ubGVuZ3RoICE9PSBtYXRjaC5pbmRleCArIG1hdGNoWzBdLmxlbmd0aCkge1xuICAgICAgICBtYXRjaCA9IG5leHRcbiAgICAgIH1cbiAgICAgIGNvZXJjZVJ0bFJlZ2V4Lmxhc3RJbmRleCA9IG5leHQuaW5kZXggKyBuZXh0WzFdLmxlbmd0aCArIG5leHRbMl0ubGVuZ3RoXG4gICAgfVxuICAgIC8vIGxlYXZlIGl0IGluIGEgY2xlYW4gc3RhdGVcbiAgICBjb2VyY2VSdGxSZWdleC5sYXN0SW5kZXggPSAtMVxuICB9XG5cbiAgaWYgKG1hdGNoID09PSBudWxsKSB7XG4gICAgcmV0dXJuIG51bGxcbiAgfVxuXG4gIGNvbnN0IG1ham9yID0gbWF0Y2hbMl1cbiAgY29uc3QgbWlub3IgPSBtYXRjaFszXSB8fCAnMCdcbiAgY29uc3QgcGF0Y2ggPSBtYXRjaFs0XSB8fCAnMCdcbiAgY29uc3QgcHJlcmVsZWFzZSA9IG9wdGlvbnMuaW5jbHVkZVByZXJlbGVhc2UgJiYgbWF0Y2hbNV0gPyBgLSR7bWF0Y2hbNV19YCA6ICcnXG4gIGNvbnN0IGJ1aWxkID0gb3B0aW9ucy5pbmNsdWRlUHJlcmVsZWFzZSAmJiBtYXRjaFs2XSA/IGArJHttYXRjaFs2XX1gIDogJydcblxuICByZXR1cm4gcGFyc2UoYCR7bWFqb3J9LiR7bWlub3J9LiR7cGF0Y2h9JHtwcmVyZWxlYXNlfSR7YnVpbGR9YCwgb3B0aW9ucylcbn1cbm1vZHVsZS5leHBvcnRzID0gY29lcmNlXG4iLCAiJ3VzZSBzdHJpY3QnXG5cbmNvbnN0IHBhcnNlID0gcmVxdWlyZSgnLi9wYXJzZScpXG5jb25zdCBjb25zdGFudHMgPSByZXF1aXJlKCcuLi9pbnRlcm5hbC9jb25zdGFudHMnKVxuY29uc3QgU2VtVmVyID0gcmVxdWlyZSgnLi4vY2xhc3Nlcy9zZW12ZXInKVxuXG5jb25zdCB0cnVuY2F0ZSA9ICh2ZXJzaW9uLCB0cnVuY2F0aW9uLCBvcHRpb25zKSA9PiB7XG4gIGlmICghY29uc3RhbnRzLlJFTEVBU0VfVFlQRVMuaW5jbHVkZXModHJ1bmNhdGlvbikpIHtcbiAgICByZXR1cm4gbnVsbFxuICB9XG5cbiAgY29uc3QgY2xvbmVkVmVyc2lvbiA9IGNsb25lSW5wdXRWZXJzaW9uKHZlcnNpb24sIG9wdGlvbnMpXG4gIHJldHVybiBjbG9uZWRWZXJzaW9uICYmIGRvVHJ1bmNhdGlvbihjbG9uZWRWZXJzaW9uLCB0cnVuY2F0aW9uKVxufVxuXG5jb25zdCBjbG9uZUlucHV0VmVyc2lvbiA9ICh2ZXJzaW9uLCBvcHRpb25zKSA9PiB7XG4gIGNvbnN0IHZlcnNpb25TdHJpbmdUb1BhcnNlID0gKFxuICAgIHZlcnNpb24gaW5zdGFuY2VvZiBTZW1WZXIgPyB2ZXJzaW9uLnZlcnNpb24gOiB2ZXJzaW9uXG4gIClcblxuICByZXR1cm4gcGFyc2UodmVyc2lvblN0cmluZ1RvUGFyc2UsIG9wdGlvbnMpXG59XG5cbmNvbnN0IGRvVHJ1bmNhdGlvbiA9ICh2ZXJzaW9uLCB0cnVuY2F0aW9uKSA9PiB7XG4gIGlmIChpc1ByZXJlbGVhc2UodHJ1bmNhdGlvbikpIHtcbiAgICByZXR1cm4gdmVyc2lvbi52ZXJzaW9uXG4gIH1cblxuICB2ZXJzaW9uLnByZXJlbGVhc2UgPSBbXVxuXG4gIHN3aXRjaCAodHJ1bmNhdGlvbikge1xuICAgIGNhc2UgJ21ham9yJzpcbiAgICAgIHZlcnNpb24ubWlub3IgPSAwXG4gICAgICB2ZXJzaW9uLnBhdGNoID0gMFxuICAgICAgYnJlYWtcbiAgICBjYXNlICdtaW5vcic6XG4gICAgICB2ZXJzaW9uLnBhdGNoID0gMFxuICAgICAgYnJlYWtcbiAgfVxuXG4gIHJldHVybiB2ZXJzaW9uLmZvcm1hdCgpXG59XG5cbmNvbnN0IGlzUHJlcmVsZWFzZSA9ICh0eXBlKSA9PiB7XG4gIHJldHVybiB0eXBlLnN0YXJ0c1dpdGgoJ3ByZScpXG59XG5cbm1vZHVsZS5leHBvcnRzID0gdHJ1bmNhdGVcbiIsICIndXNlIHN0cmljdCdcblxuY2xhc3MgTFJVQ2FjaGUge1xuICBjb25zdHJ1Y3RvciAoKSB7XG4gICAgdGhpcy5tYXggPSAxMDAwXG4gICAgdGhpcy5tYXAgPSBuZXcgTWFwKClcbiAgfVxuXG4gIGdldCAoa2V5KSB7XG4gICAgY29uc3QgdmFsdWUgPSB0aGlzLm1hcC5nZXQoa2V5KVxuICAgIGlmICh2YWx1ZSA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICByZXR1cm4gdW5kZWZpbmVkXG4gICAgfSBlbHNlIHtcbiAgICAgIC8vIFJlbW92ZSB0aGUga2V5IGZyb20gdGhlIG1hcCBhbmQgYWRkIGl0IHRvIHRoZSBlbmRcbiAgICAgIHRoaXMubWFwLmRlbGV0ZShrZXkpXG4gICAgICB0aGlzLm1hcC5zZXQoa2V5LCB2YWx1ZSlcbiAgICAgIHJldHVybiB2YWx1ZVxuICAgIH1cbiAgfVxuXG4gIGRlbGV0ZSAoa2V5KSB7XG4gICAgcmV0dXJuIHRoaXMubWFwLmRlbGV0ZShrZXkpXG4gIH1cblxuICBzZXQgKGtleSwgdmFsdWUpIHtcbiAgICBjb25zdCBkZWxldGVkID0gdGhpcy5kZWxldGUoa2V5KVxuXG4gICAgaWYgKCFkZWxldGVkICYmIHZhbHVlICE9PSB1bmRlZmluZWQpIHtcbiAgICAgIC8vIElmIGNhY2hlIGlzIGZ1bGwsIGRlbGV0ZSB0aGUgbGVhc3QgcmVjZW50bHkgdXNlZCBpdGVtXG4gICAgICBpZiAodGhpcy5tYXAuc2l6ZSA+PSB0aGlzLm1heCkge1xuICAgICAgICBjb25zdCBmaXJzdEtleSA9IHRoaXMubWFwLmtleXMoKS5uZXh0KCkudmFsdWVcbiAgICAgICAgdGhpcy5kZWxldGUoZmlyc3RLZXkpXG4gICAgICB9XG5cbiAgICAgIHRoaXMubWFwLnNldChrZXksIHZhbHVlKVxuICAgIH1cblxuICAgIHJldHVybiB0aGlzXG4gIH1cbn1cblxubW9kdWxlLmV4cG9ydHMgPSBMUlVDYWNoZVxuIiwgIid1c2Ugc3RyaWN0J1xuXG5jb25zdCBTUEFDRV9DSEFSQUNURVJTID0gL1xccysvZ1xuXG4vLyBob2lzdGVkIGNsYXNzIGZvciBjeWNsaWMgZGVwZW5kZW5jeVxuY2xhc3MgUmFuZ2Uge1xuICBjb25zdHJ1Y3RvciAocmFuZ2UsIG9wdGlvbnMpIHtcbiAgICBvcHRpb25zID0gcGFyc2VPcHRpb25zKG9wdGlvbnMpXG5cbiAgICBpZiAocmFuZ2UgaW5zdGFuY2VvZiBSYW5nZSkge1xuICAgICAgaWYgKFxuICAgICAgICByYW5nZS5sb29zZSA9PT0gISFvcHRpb25zLmxvb3NlICYmXG4gICAgICAgIHJhbmdlLmluY2x1ZGVQcmVyZWxlYXNlID09PSAhIW9wdGlvbnMuaW5jbHVkZVByZXJlbGVhc2VcbiAgICAgICkge1xuICAgICAgICByZXR1cm4gcmFuZ2VcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHJldHVybiBuZXcgUmFuZ2UocmFuZ2UucmF3LCBvcHRpb25zKVxuICAgICAgfVxuICAgIH1cblxuICAgIGlmIChyYW5nZSBpbnN0YW5jZW9mIENvbXBhcmF0b3IpIHtcbiAgICAgIC8vIGp1c3QgcHV0IGl0IGluIHRoZSBzZXQgYW5kIHJldHVyblxuICAgICAgdGhpcy5yYXcgPSByYW5nZS52YWx1ZVxuICAgICAgdGhpcy5zZXQgPSBbW3JhbmdlXV1cbiAgICAgIHRoaXMuZm9ybWF0dGVkID0gdW5kZWZpbmVkXG4gICAgICByZXR1cm4gdGhpc1xuICAgIH1cblxuICAgIHRoaXMub3B0aW9ucyA9IG9wdGlvbnNcbiAgICB0aGlzLmxvb3NlID0gISFvcHRpb25zLmxvb3NlXG4gICAgdGhpcy5pbmNsdWRlUHJlcmVsZWFzZSA9ICEhb3B0aW9ucy5pbmNsdWRlUHJlcmVsZWFzZVxuXG4gICAgLy8gRmlyc3QgcmVkdWNlIGFsbCB3aGl0ZXNwYWNlIGFzIG11Y2ggYXMgcG9zc2libGUgc28gd2UgZG8gbm90IGhhdmUgdG8gcmVseVxuICAgIC8vIG9uIHBvdGVudGlhbGx5IHNsb3cgcmVnZXhlcyBsaWtlIFxccyouIFRoaXMgaXMgdGhlbiBzdG9yZWQgYW5kIHVzZWQgZm9yXG4gICAgLy8gZnV0dXJlIGVycm9yIG1lc3NhZ2VzIGFzIHdlbGwuXG4gICAgdGhpcy5yYXcgPSByYW5nZS50cmltKCkucmVwbGFjZShTUEFDRV9DSEFSQUNURVJTLCAnICcpXG5cbiAgICAvLyBGaXJzdCwgc3BsaXQgb24gfHxcbiAgICB0aGlzLnNldCA9IHRoaXMucmF3XG4gICAgICAuc3BsaXQoJ3x8JylcbiAgICAgIC8vIG1hcCB0aGUgcmFuZ2UgdG8gYSAyZCBhcnJheSBvZiBjb21wYXJhdG9yc1xuICAgICAgLm1hcChyID0+IHRoaXMucGFyc2VSYW5nZShyLnRyaW0oKSkpXG4gICAgICAvLyB0aHJvdyBvdXQgYW55IGNvbXBhcmF0b3IgbGlzdHMgdGhhdCBhcmUgZW1wdHlcbiAgICAgIC8vIHRoaXMgZ2VuZXJhbGx5IG1lYW5zIHRoYXQgaXQgd2FzIG5vdCBhIHZhbGlkIHJhbmdlLCB3aGljaCBpcyBhbGxvd2VkXG4gICAgICAvLyBpbiBsb29zZSBtb2RlLCBidXQgd2lsbCBzdGlsbCB0aHJvdyBpZiB0aGUgV0hPTEUgcmFuZ2UgaXMgaW52YWxpZC5cbiAgICAgIC5maWx0ZXIoYyA9PiBjLmxlbmd0aClcblxuICAgIGlmICghdGhpcy5zZXQubGVuZ3RoKSB7XG4gICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKGBJbnZhbGlkIFNlbVZlciBSYW5nZTogJHt0aGlzLnJhd31gKVxuICAgIH1cblxuICAgIC8vIGlmIHdlIGhhdmUgYW55IHRoYXQgYXJlIG5vdCB0aGUgbnVsbCBzZXQsIHRocm93IG91dCBudWxsIHNldHMuXG4gICAgaWYgKHRoaXMuc2V0Lmxlbmd0aCA+IDEpIHtcbiAgICAgIC8vIGtlZXAgdGhlIGZpcnN0IG9uZSwgaW4gY2FzZSB0aGV5J3JlIGFsbCBudWxsIHNldHNcbiAgICAgIGNvbnN0IGZpcnN0ID0gdGhpcy5zZXRbMF1cbiAgICAgIHRoaXMuc2V0ID0gdGhpcy5zZXQuZmlsdGVyKGMgPT4gIWlzTnVsbFNldChjWzBdKSlcbiAgICAgIGlmICh0aGlzLnNldC5sZW5ndGggPT09IDApIHtcbiAgICAgICAgdGhpcy5zZXQgPSBbZmlyc3RdXG4gICAgICB9IGVsc2UgaWYgKHRoaXMuc2V0Lmxlbmd0aCA+IDEpIHtcbiAgICAgICAgLy8gaWYgd2UgaGF2ZSBhbnkgdGhhdCBhcmUgKiwgdGhlbiB0aGUgcmFuZ2UgaXMganVzdCAqXG4gICAgICAgIGZvciAoY29uc3QgYyBvZiB0aGlzLnNldCkge1xuICAgICAgICAgIGlmIChjLmxlbmd0aCA9PT0gMSAmJiBpc0FueShjWzBdKSkge1xuICAgICAgICAgICAgdGhpcy5zZXQgPSBbY11cbiAgICAgICAgICAgIGJyZWFrXG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuXG4gICAgdGhpcy5mb3JtYXR0ZWQgPSB1bmRlZmluZWRcbiAgfVxuXG4gIGdldCByYW5nZSAoKSB7XG4gICAgaWYgKHRoaXMuZm9ybWF0dGVkID09PSB1bmRlZmluZWQpIHtcbiAgICAgIHRoaXMuZm9ybWF0dGVkID0gJydcbiAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgdGhpcy5zZXQubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgaWYgKGkgPiAwKSB7XG4gICAgICAgICAgdGhpcy5mb3JtYXR0ZWQgKz0gJ3x8J1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IGNvbXBzID0gdGhpcy5zZXRbaV1cbiAgICAgICAgZm9yIChsZXQgayA9IDA7IGsgPCBjb21wcy5sZW5ndGg7IGsrKykge1xuICAgICAgICAgIGlmIChrID4gMCkge1xuICAgICAgICAgICAgdGhpcy5mb3JtYXR0ZWQgKz0gJyAnXG4gICAgICAgICAgfVxuICAgICAgICAgIHRoaXMuZm9ybWF0dGVkICs9IGNvbXBzW2tdLnRvU3RyaW5nKCkudHJpbSgpXG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIHRoaXMuZm9ybWF0dGVkXG4gIH1cblxuICBmb3JtYXQgKCkge1xuICAgIHJldHVybiB0aGlzLnJhbmdlXG4gIH1cblxuICB0b1N0cmluZyAoKSB7XG4gICAgcmV0dXJuIHRoaXMucmFuZ2VcbiAgfVxuXG4gIHBhcnNlUmFuZ2UgKHJhbmdlKSB7XG4gICAgLy8gc3RyaXAgYnVpbGQgbWV0YWRhdGEgc28gaXQgY2FuJ3QgYmxlZWQgaW50byB0aGUgdmVyc2lvblxuICAgIHJhbmdlID0gcmFuZ2UucmVwbGFjZShCVUlMRFNUUklQUkUsICcnKVxuXG4gICAgLy8gbWVtb2l6ZSByYW5nZSBwYXJzaW5nIGZvciBwZXJmb3JtYW5jZS5cbiAgICAvLyB0aGlzIGlzIGEgdmVyeSBob3QgcGF0aCwgYW5kIGZ1bGx5IGRldGVybWluaXN0aWMuXG4gICAgY29uc3QgbWVtb09wdHMgPVxuICAgICAgKHRoaXMub3B0aW9ucy5pbmNsdWRlUHJlcmVsZWFzZSAmJiBGTEFHX0lOQ0xVREVfUFJFUkVMRUFTRSkgfFxuICAgICAgKHRoaXMub3B0aW9ucy5sb29zZSAmJiBGTEFHX0xPT1NFKVxuICAgIGNvbnN0IG1lbW9LZXkgPSBtZW1vT3B0cyArICc6JyArIHJhbmdlXG4gICAgY29uc3QgY2FjaGVkID0gY2FjaGUuZ2V0KG1lbW9LZXkpXG4gICAgaWYgKGNhY2hlZCkge1xuICAgICAgcmV0dXJuIGNhY2hlZFxuICAgIH1cblxuICAgIGNvbnN0IGxvb3NlID0gdGhpcy5vcHRpb25zLmxvb3NlXG4gICAgLy8gYDEuMi4zIC0gMS4yLjRgID0+IGA+PTEuMi4zIDw9MS4yLjRgXG4gICAgY29uc3QgaHIgPSBsb29zZSA/IHJlW3QuSFlQSEVOUkFOR0VMT09TRV0gOiByZVt0LkhZUEhFTlJBTkdFXVxuICAgIHJhbmdlID0gcmFuZ2UucmVwbGFjZShociwgaHlwaGVuUmVwbGFjZSh0aGlzLm9wdGlvbnMuaW5jbHVkZVByZXJlbGVhc2UpKVxuICAgIGRlYnVnKCdoeXBoZW4gcmVwbGFjZScsIHJhbmdlKVxuXG4gICAgLy8gYD4gMS4yLjMgPCAxLjIuNWAgPT4gYD4xLjIuMyA8MS4yLjVgXG4gICAgcmFuZ2UgPSByYW5nZS5yZXBsYWNlKHJlW3QuQ09NUEFSQVRPUlRSSU1dLCBjb21wYXJhdG9yVHJpbVJlcGxhY2UpXG4gICAgZGVidWcoJ2NvbXBhcmF0b3IgdHJpbScsIHJhbmdlKVxuXG4gICAgLy8gYH4gMS4yLjNgID0+IGB+MS4yLjNgXG4gICAgcmFuZ2UgPSByYW5nZS5yZXBsYWNlKHJlW3QuVElMREVUUklNXSwgdGlsZGVUcmltUmVwbGFjZSlcbiAgICBkZWJ1ZygndGlsZGUgdHJpbScsIHJhbmdlKVxuXG4gICAgLy8gYF4gMS4yLjNgID0+IGBeMS4yLjNgXG4gICAgcmFuZ2UgPSByYW5nZS5yZXBsYWNlKHJlW3QuQ0FSRVRUUklNXSwgY2FyZXRUcmltUmVwbGFjZSlcbiAgICBkZWJ1ZygnY2FyZXQgdHJpbScsIHJhbmdlKVxuXG4gICAgLy8gQXQgdGhpcyBwb2ludCwgdGhlIHJhbmdlIGlzIGNvbXBsZXRlbHkgdHJpbW1lZCBhbmRcbiAgICAvLyByZWFkeSB0byBiZSBzcGxpdCBpbnRvIGNvbXBhcmF0b3JzLlxuXG4gICAgbGV0IHJhbmdlTGlzdCA9IHJhbmdlXG4gICAgICAuc3BsaXQoJyAnKVxuICAgICAgLm1hcChjb21wID0+IHBhcnNlQ29tcGFyYXRvcihjb21wLCB0aGlzLm9wdGlvbnMpKVxuICAgICAgLmpvaW4oJyAnKVxuICAgICAgLnNwbGl0KC9cXHMrLylcbiAgICAgIC8vID49MC4wLjAgaXMgZXF1aXZhbGVudCB0byAqXG4gICAgICAubWFwKGNvbXAgPT4gcmVwbGFjZUdURTAoY29tcCwgdGhpcy5vcHRpb25zKSlcblxuICAgIGlmIChsb29zZSkge1xuICAgICAgLy8gaW4gbG9vc2UgbW9kZSwgdGhyb3cgb3V0IGFueSB0aGF0IGFyZSBub3QgdmFsaWQgY29tcGFyYXRvcnNcbiAgICAgIHJhbmdlTGlzdCA9IHJhbmdlTGlzdC5maWx0ZXIoY29tcCA9PiB7XG4gICAgICAgIGRlYnVnKCdsb29zZSBpbnZhbGlkIGZpbHRlcicsIGNvbXAsIHRoaXMub3B0aW9ucylcbiAgICAgICAgcmV0dXJuICEhY29tcC5tYXRjaChyZVt0LkNPTVBBUkFUT1JMT09TRV0pXG4gICAgICB9KVxuICAgIH1cbiAgICBkZWJ1ZygncmFuZ2UgbGlzdCcsIHJhbmdlTGlzdClcblxuICAgIC8vIGlmIGFueSBjb21wYXJhdG9ycyBhcmUgdGhlIG51bGwgc2V0LCB0aGVuIHJlcGxhY2Ugd2l0aCBKVVNUIG51bGwgc2V0XG4gICAgLy8gaWYgbW9yZSB0aGFuIG9uZSBjb21wYXJhdG9yLCByZW1vdmUgYW55ICogY29tcGFyYXRvcnNcbiAgICAvLyBhbHNvLCBkb24ndCBpbmNsdWRlIHRoZSBzYW1lIGNvbXBhcmF0b3IgbW9yZSB0aGFuIG9uY2VcbiAgICBjb25zdCByYW5nZU1hcCA9IG5ldyBNYXAoKVxuICAgIGNvbnN0IGNvbXBhcmF0b3JzID0gcmFuZ2VMaXN0Lm1hcChjb21wID0+IG5ldyBDb21wYXJhdG9yKGNvbXAsIHRoaXMub3B0aW9ucykpXG4gICAgZm9yIChjb25zdCBjb21wIG9mIGNvbXBhcmF0b3JzKSB7XG4gICAgICBpZiAoaXNOdWxsU2V0KGNvbXApKSB7XG4gICAgICAgIHJldHVybiBbY29tcF1cbiAgICAgIH1cbiAgICAgIHJhbmdlTWFwLnNldChjb21wLnZhbHVlLCBjb21wKVxuICAgIH1cbiAgICBpZiAocmFuZ2VNYXAuc2l6ZSA+IDEgJiYgcmFuZ2VNYXAuaGFzKCcnKSkge1xuICAgICAgcmFuZ2VNYXAuZGVsZXRlKCcnKVxuICAgIH1cblxuICAgIGNvbnN0IHJlc3VsdCA9IFsuLi5yYW5nZU1hcC52YWx1ZXMoKV1cbiAgICBjYWNoZS5zZXQobWVtb0tleSwgcmVzdWx0KVxuICAgIHJldHVybiByZXN1bHRcbiAgfVxuXG4gIGludGVyc2VjdHMgKHJhbmdlLCBvcHRpb25zKSB7XG4gICAgaWYgKCEocmFuZ2UgaW5zdGFuY2VvZiBSYW5nZSkpIHtcbiAgICAgIHRocm93IG5ldyBUeXBlRXJyb3IoJ2EgUmFuZ2UgaXMgcmVxdWlyZWQnKVxuICAgIH1cblxuICAgIHJldHVybiB0aGlzLnNldC5zb21lKCh0aGlzQ29tcGFyYXRvcnMpID0+IHtcbiAgICAgIHJldHVybiAoXG4gICAgICAgIGlzU2F0aXNmaWFibGUodGhpc0NvbXBhcmF0b3JzLCBvcHRpb25zKSAmJlxuICAgICAgICByYW5nZS5zZXQuc29tZSgocmFuZ2VDb21wYXJhdG9ycykgPT4ge1xuICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICBpc1NhdGlzZmlhYmxlKHJhbmdlQ29tcGFyYXRvcnMsIG9wdGlvbnMpICYmXG4gICAgICAgICAgICB0aGlzQ29tcGFyYXRvcnMuZXZlcnkoKHRoaXNDb21wYXJhdG9yKSA9PiB7XG4gICAgICAgICAgICAgIHJldHVybiByYW5nZUNvbXBhcmF0b3JzLmV2ZXJ5KChyYW5nZUNvbXBhcmF0b3IpID0+IHtcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpc0NvbXBhcmF0b3IuaW50ZXJzZWN0cyhyYW5nZUNvbXBhcmF0b3IsIG9wdGlvbnMpXG4gICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICB9KVxuICAgICAgICAgIClcbiAgICAgICAgfSlcbiAgICAgIClcbiAgICB9KVxuICB9XG5cbiAgLy8gaWYgQU5ZIG9mIHRoZSBzZXRzIG1hdGNoIEFMTCBvZiBpdHMgY29tcGFyYXRvcnMsIHRoZW4gcGFzc1xuICB0ZXN0ICh2ZXJzaW9uKSB7XG4gICAgaWYgKCF2ZXJzaW9uKSB7XG4gICAgICByZXR1cm4gZmFsc2VcbiAgICB9XG5cbiAgICBpZiAodHlwZW9mIHZlcnNpb24gPT09ICdzdHJpbmcnKSB7XG4gICAgICB0cnkge1xuICAgICAgICB2ZXJzaW9uID0gbmV3IFNlbVZlcih2ZXJzaW9uLCB0aGlzLm9wdGlvbnMpXG4gICAgICB9IGNhdGNoIChlcikge1xuICAgICAgICByZXR1cm4gZmFsc2VcbiAgICAgIH1cbiAgICB9XG5cbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IHRoaXMuc2V0Lmxlbmd0aDsgaSsrKSB7XG4gICAgICBpZiAodGVzdFNldCh0aGlzLnNldFtpXSwgdmVyc2lvbiwgdGhpcy5vcHRpb25zKSkge1xuICAgICAgICByZXR1cm4gdHJ1ZVxuICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gZmFsc2VcbiAgfVxufVxuXG5tb2R1bGUuZXhwb3J0cyA9IFJhbmdlXG5cbmNvbnN0IExSVSA9IHJlcXVpcmUoJy4uL2ludGVybmFsL2xydWNhY2hlJylcbmNvbnN0IGNhY2hlID0gbmV3IExSVSgpXG5cbmNvbnN0IHBhcnNlT3B0aW9ucyA9IHJlcXVpcmUoJy4uL2ludGVybmFsL3BhcnNlLW9wdGlvbnMnKVxuY29uc3QgQ29tcGFyYXRvciA9IHJlcXVpcmUoJy4vY29tcGFyYXRvcicpXG5jb25zdCBkZWJ1ZyA9IHJlcXVpcmUoJy4uL2ludGVybmFsL2RlYnVnJylcbmNvbnN0IFNlbVZlciA9IHJlcXVpcmUoJy4vc2VtdmVyJylcbmNvbnN0IHtcbiAgc2FmZVJlOiByZSxcbiAgc3JjLFxuICB0LFxuICBjb21wYXJhdG9yVHJpbVJlcGxhY2UsXG4gIHRpbGRlVHJpbVJlcGxhY2UsXG4gIGNhcmV0VHJpbVJlcGxhY2UsXG59ID0gcmVxdWlyZSgnLi4vaW50ZXJuYWwvcmUnKVxuY29uc3QgeyBGTEFHX0lOQ0xVREVfUFJFUkVMRUFTRSwgRkxBR19MT09TRSB9ID0gcmVxdWlyZSgnLi4vaW50ZXJuYWwvY29uc3RhbnRzJylcblxuLy8gdW5ib3VuZGVkIGdsb2JhbCBidWlsZC1tZXRhZGF0YSBzdHJpcHBlciB1c2VkIGJ5IHBhcnNlUmFuZ2VcbmNvbnN0IEJVSUxEU1RSSVBSRSA9IG5ldyBSZWdFeHAoc3JjW3QuQlVJTERdLCAnZycpXG5cbmNvbnN0IGlzTnVsbFNldCA9IGMgPT4gYy52YWx1ZSA9PT0gJzwwLjAuMC0wJ1xuY29uc3QgaXNBbnkgPSBjID0+IGMudmFsdWUgPT09ICcnXG5cbi8vIHRha2UgYSBzZXQgb2YgY29tcGFyYXRvcnMgYW5kIGRldGVybWluZSB3aGV0aGVyIHRoZXJlXG4vLyBleGlzdHMgYSB2ZXJzaW9uIHdoaWNoIGNhbiBzYXRpc2Z5IGl0XG5jb25zdCBpc1NhdGlzZmlhYmxlID0gKGNvbXBhcmF0b3JzLCBvcHRpb25zKSA9PiB7XG4gIGxldCByZXN1bHQgPSB0cnVlXG4gIGNvbnN0IHJlbWFpbmluZ0NvbXBhcmF0b3JzID0gY29tcGFyYXRvcnMuc2xpY2UoKVxuICBsZXQgdGVzdENvbXBhcmF0b3IgPSByZW1haW5pbmdDb21wYXJhdG9ycy5wb3AoKVxuXG4gIHdoaWxlIChyZXN1bHQgJiYgcmVtYWluaW5nQ29tcGFyYXRvcnMubGVuZ3RoKSB7XG4gICAgcmVzdWx0ID0gcmVtYWluaW5nQ29tcGFyYXRvcnMuZXZlcnkoKG90aGVyQ29tcGFyYXRvcikgPT4ge1xuICAgICAgcmV0dXJuIHRlc3RDb21wYXJhdG9yLmludGVyc2VjdHMob3RoZXJDb21wYXJhdG9yLCBvcHRpb25zKVxuICAgIH0pXG5cbiAgICB0ZXN0Q29tcGFyYXRvciA9IHJlbWFpbmluZ0NvbXBhcmF0b3JzLnBvcCgpXG4gIH1cblxuICByZXR1cm4gcmVzdWx0XG59XG5cbi8vIGNvbXByaXNlZCBvZiB4cmFuZ2VzLCB0aWxkZXMsIHN0YXJzLCBhbmQgZ3RsdCdzIGF0IHRoaXMgcG9pbnQuXG4vLyBhbHJlYWR5IHJlcGxhY2VkIHRoZSBoeXBoZW4gcmFuZ2VzXG4vLyB0dXJuIGludG8gYSBzZXQgb2YgSlVTVCBjb21wYXJhdG9ycy5cbmNvbnN0IHBhcnNlQ29tcGFyYXRvciA9IChjb21wLCBvcHRpb25zKSA9PiB7XG4gIGNvbXAgPSBjb21wLnJlcGxhY2UocmVbdC5CVUlMRF0sICcnKVxuICBkZWJ1ZygnY29tcCcsIGNvbXAsIG9wdGlvbnMpXG4gIGNvbXAgPSByZXBsYWNlQ2FyZXRzKGNvbXAsIG9wdGlvbnMpXG4gIGRlYnVnKCdjYXJldCcsIGNvbXApXG4gIGNvbXAgPSByZXBsYWNlVGlsZGVzKGNvbXAsIG9wdGlvbnMpXG4gIGRlYnVnKCd0aWxkZXMnLCBjb21wKVxuICBjb21wID0gcmVwbGFjZVhSYW5nZXMoY29tcCwgb3B0aW9ucylcbiAgZGVidWcoJ3hyYW5nZScsIGNvbXApXG4gIGNvbXAgPSByZXBsYWNlU3RhcnMoY29tcCwgb3B0aW9ucylcbiAgZGVidWcoJ3N0YXJzJywgY29tcClcbiAgcmV0dXJuIGNvbXBcbn1cblxuY29uc3QgaXNYID0gaWQgPT4gIWlkIHx8IGlkLnRvTG93ZXJDYXNlKCkgPT09ICd4JyB8fCBpZCA9PT0gJyonXG5cbmNvbnN0IGludmFsaWRYUmFuZ2VPcmRlciA9IChNLCBtLCBwKSA9PiAoXG4gIChpc1goTSkgJiYgIWlzWChtKSkgfHxcbiAgKGlzWChtKSAmJiBwICYmICFpc1gocCkpXG4pXG5cbi8vIH4sIH4+IC0tPiAqIChhbnksIGtpbmRhIHNpbGx5KVxuLy8gfjIsIH4yLngsIH4yLngueCwgfj4yLCB+PjIueCB+PjIueC54IC0tPiA+PTIuMC4wIDwzLjAuMC0wXG4vLyB+Mi4wLCB+Mi4wLngsIH4+Mi4wLCB+PjIuMC54IC0tPiA+PTIuMC4wIDwyLjEuMC0wXG4vLyB+MS4yLCB+MS4yLngsIH4+MS4yLCB+PjEuMi54IC0tPiA+PTEuMi4wIDwxLjMuMC0wXG4vLyB+MS4yLjMsIH4+MS4yLjMgLS0+ID49MS4yLjMgPDEuMy4wLTBcbi8vIH4xLjIuMCwgfj4xLjIuMCAtLT4gPj0xLjIuMCA8MS4zLjAtMFxuLy8gfjAuMC4xIC0tPiA+PTAuMC4xIDwwLjEuMC0wXG5jb25zdCByZXBsYWNlVGlsZGVzID0gKGNvbXAsIG9wdGlvbnMpID0+IHtcbiAgcmV0dXJuIGNvbXBcbiAgICAudHJpbSgpXG4gICAgLnNwbGl0KC9cXHMrLylcbiAgICAubWFwKChjKSA9PiByZXBsYWNlVGlsZGUoYywgb3B0aW9ucykpXG4gICAgLmpvaW4oJyAnKVxufVxuXG5jb25zdCByZXBsYWNlVGlsZGUgPSAoY29tcCwgb3B0aW9ucykgPT4ge1xuICBjb25zdCByID0gb3B0aW9ucy5sb29zZSA/IHJlW3QuVElMREVMT09TRV0gOiByZVt0LlRJTERFXVxuICAvLyBpZiB3ZSdyZSBpbmNsdWRpbmcgcHJlcmVsZWFzZXMgaW4gdGhlIG1hdGNoLCB0aGVuIHRoZSBsb3dlciBib3VuZCBpc1xuICAvLyAtMCwgdGhlIGxvd2VzdCBwb3NzaWJsZSBwcmVyZWxlYXNlIHZhbHVlLCBqdXN0IGxpa2UgeC1yYW5nZXMgYW5kIGNhcmV0cy5cbiAgLy8gdGhpcyBrZWVwcyBgfjEuMmAgZXF1aXZhbGVudCB0byB0aGUgYDEuMi54YCB4LXJhbmdlIGl0J3MgZG9jdW1lbnRlZCBhcy5cbiAgY29uc3QgeiA9IG9wdGlvbnMuaW5jbHVkZVByZXJlbGVhc2UgPyAnLTAnIDogJydcbiAgcmV0dXJuIGNvbXAucmVwbGFjZShyLCAoXywgTSwgbSwgcCwgcHIpID0+IHtcbiAgICBkZWJ1ZygndGlsZGUnLCBjb21wLCBfLCBNLCBtLCBwLCBwcilcbiAgICBsZXQgcmV0XG5cbiAgICBpZiAoaXNYKE0pKSB7XG4gICAgICByZXQgPSAnJ1xuICAgIH0gZWxzZSBpZiAoaXNYKG0pKSB7XG4gICAgICByZXQgPSBgPj0ke019LjAuMCR7en0gPCR7K00gKyAxfS4wLjAtMGBcbiAgICB9IGVsc2UgaWYgKGlzWChwKSkge1xuICAgICAgLy8gfjEuMiA9PSA+PTEuMi4wIDwxLjMuMC0wXG4gICAgICByZXQgPSBgPj0ke019LiR7bX0uMCR7en0gPCR7TX0uJHsrbSArIDF9LjAtMGBcbiAgICB9IGVsc2UgaWYgKHByKSB7XG4gICAgICBkZWJ1ZygncmVwbGFjZVRpbGRlIHByJywgcHIpXG4gICAgICByZXQgPSBgPj0ke019LiR7bX0uJHtwfS0ke3ByXG4gICAgICB9IDwke019LiR7K20gKyAxfS4wLTBgXG4gICAgfSBlbHNlIHtcbiAgICAgIC8vIH4xLjIuMyA9PSA+PTEuMi4zIDwxLjMuMC0wXG4gICAgICByZXQgPSBgPj0ke019LiR7bX0uJHtwXG4gICAgICB9IDwke019LiR7K20gKyAxfS4wLTBgXG4gICAgfVxuXG4gICAgZGVidWcoJ3RpbGRlIHJldHVybicsIHJldClcbiAgICByZXR1cm4gcmV0XG4gIH0pXG59XG5cbi8vIF4gLS0+ICogKGFueSwga2luZGEgc2lsbHkpXG4vLyBeMiwgXjIueCwgXjIueC54IC0tPiA+PTIuMC4wIDwzLjAuMC0wXG4vLyBeMi4wLCBeMi4wLnggLS0+ID49Mi4wLjAgPDMuMC4wLTBcbi8vIF4xLjIsIF4xLjIueCAtLT4gPj0xLjIuMCA8Mi4wLjAtMFxuLy8gXjEuMi4zIC0tPiA+PTEuMi4zIDwyLjAuMC0wXG4vLyBeMS4yLjAgLS0+ID49MS4yLjAgPDIuMC4wLTBcbi8vIF4wLjAuMSAtLT4gPj0wLjAuMSA8MC4wLjItMFxuLy8gXjAuMS4wIC0tPiA+PTAuMS4wIDwwLjIuMC0wXG5jb25zdCByZXBsYWNlQ2FyZXRzID0gKGNvbXAsIG9wdGlvbnMpID0+IHtcbiAgcmV0dXJuIGNvbXBcbiAgICAudHJpbSgpXG4gICAgLnNwbGl0KC9cXHMrLylcbiAgICAubWFwKChjKSA9PiByZXBsYWNlQ2FyZXQoYywgb3B0aW9ucykpXG4gICAgLmpvaW4oJyAnKVxufVxuXG5jb25zdCByZXBsYWNlQ2FyZXQgPSAoY29tcCwgb3B0aW9ucykgPT4ge1xuICBkZWJ1ZygnY2FyZXQnLCBjb21wLCBvcHRpb25zKVxuICBjb25zdCByID0gb3B0aW9ucy5sb29zZSA/IHJlW3QuQ0FSRVRMT09TRV0gOiByZVt0LkNBUkVUXVxuICBjb25zdCB6ID0gb3B0aW9ucy5pbmNsdWRlUHJlcmVsZWFzZSA/ICctMCcgOiAnJ1xuICByZXR1cm4gY29tcC5yZXBsYWNlKHIsIChfLCBNLCBtLCBwLCBwcikgPT4ge1xuICAgIGRlYnVnKCdjYXJldCcsIGNvbXAsIF8sIE0sIG0sIHAsIHByKVxuICAgIGxldCByZXRcblxuICAgIGlmIChpc1goTSkpIHtcbiAgICAgIHJldCA9ICcnXG4gICAgfSBlbHNlIGlmIChpc1gobSkpIHtcbiAgICAgIHJldCA9IGA+PSR7TX0uMC4wJHt6fSA8JHsrTSArIDF9LjAuMC0wYFxuICAgIH0gZWxzZSBpZiAoaXNYKHApKSB7XG4gICAgICBpZiAoTSA9PT0gJzAnKSB7XG4gICAgICAgIHJldCA9IGA+PSR7TX0uJHttfS4wJHt6fSA8JHtNfS4keyttICsgMX0uMC0wYFxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgcmV0ID0gYD49JHtNfS4ke219LjAke3p9IDwkeytNICsgMX0uMC4wLTBgXG4gICAgICB9XG4gICAgfSBlbHNlIGlmIChwcikge1xuICAgICAgZGVidWcoJ3JlcGxhY2VDYXJldCBwcicsIHByKVxuICAgICAgaWYgKE0gPT09ICcwJykge1xuICAgICAgICBpZiAobSA9PT0gJzAnKSB7XG4gICAgICAgICAgcmV0ID0gYD49JHtNfS4ke219LiR7cH0tJHtwclxuICAgICAgICAgIH0gPCR7TX0uJHttfS4keytwICsgMX0tMGBcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICByZXQgPSBgPj0ke019LiR7bX0uJHtwfS0ke3ByXG4gICAgICAgICAgfSA8JHtNfS4keyttICsgMX0uMC0wYFxuICAgICAgICB9XG4gICAgICB9IGVsc2Uge1xuICAgICAgICByZXQgPSBgPj0ke019LiR7bX0uJHtwfS0ke3ByXG4gICAgICAgIH0gPCR7K00gKyAxfS4wLjAtMGBcbiAgICAgIH1cbiAgICB9IGVsc2Uge1xuICAgICAgZGVidWcoJ25vIHByJylcbiAgICAgIGlmIChNID09PSAnMCcpIHtcbiAgICAgICAgaWYgKG0gPT09ICcwJykge1xuICAgICAgICAgIHJldCA9IGA+PSR7TX0uJHttfS4ke3BcbiAgICAgICAgICB9IDwke019LiR7bX0uJHsrcCArIDF9LTBgXG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgcmV0ID0gYD49JHtNfS4ke219LiR7cFxuICAgICAgICAgIH0gPCR7TX0uJHsrbSArIDF9LjAtMGBcbiAgICAgICAgfVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgcmV0ID0gYD49JHtNfS4ke219LiR7cFxuICAgICAgICB9IDwkeytNICsgMX0uMC4wLTBgXG4gICAgICB9XG4gICAgfVxuXG4gICAgZGVidWcoJ2NhcmV0IHJldHVybicsIHJldClcbiAgICByZXR1cm4gcmV0XG4gIH0pXG59XG5cbmNvbnN0IHJlcGxhY2VYUmFuZ2VzID0gKGNvbXAsIG9wdGlvbnMpID0+IHtcbiAgZGVidWcoJ3JlcGxhY2VYUmFuZ2VzJywgY29tcCwgb3B0aW9ucylcbiAgcmV0dXJuIGNvbXBcbiAgICAuc3BsaXQoL1xccysvKVxuICAgIC5tYXAoKGMpID0+IHJlcGxhY2VYUmFuZ2UoYywgb3B0aW9ucykpXG4gICAgLmpvaW4oJyAnKVxufVxuXG5jb25zdCByZXBsYWNlWFJhbmdlID0gKGNvbXAsIG9wdGlvbnMpID0+IHtcbiAgY29tcCA9IGNvbXAudHJpbSgpXG4gIGNvbnN0IHIgPSBvcHRpb25zLmxvb3NlID8gcmVbdC5YUkFOR0VMT09TRV0gOiByZVt0LlhSQU5HRV1cbiAgcmV0dXJuIGNvbXAucmVwbGFjZShyLCAocmV0LCBndGx0LCBNLCBtLCBwLCBwcikgPT4ge1xuICAgIGRlYnVnKCd4UmFuZ2UnLCBjb21wLCByZXQsIGd0bHQsIE0sIG0sIHAsIHByKVxuICAgIGlmIChpbnZhbGlkWFJhbmdlT3JkZXIoTSwgbSwgcCkpIHtcbiAgICAgIHJldHVybiBjb21wXG4gICAgfVxuXG4gICAgY29uc3QgeE0gPSBpc1goTSlcbiAgICBjb25zdCB4bSA9IHhNIHx8IGlzWChtKVxuICAgIGNvbnN0IHhwID0geG0gfHwgaXNYKHApXG4gICAgY29uc3QgYW55WCA9IHhwXG5cbiAgICBpZiAoZ3RsdCA9PT0gJz0nICYmIGFueVgpIHtcbiAgICAgIGd0bHQgPSAnJ1xuICAgIH1cblxuICAgIC8vIGlmIHdlJ3JlIGluY2x1ZGluZyBwcmVyZWxlYXNlcyBpbiB0aGUgbWF0Y2gsIHRoZW4gd2UgbmVlZFxuICAgIC8vIHRvIGZpeCB0aGlzIHRvIC0wLCB0aGUgbG93ZXN0IHBvc3NpYmxlIHByZXJlbGVhc2UgdmFsdWVcbiAgICBwciA9IG9wdGlvbnMuaW5jbHVkZVByZXJlbGVhc2UgPyAnLTAnIDogJydcblxuICAgIGlmICh4TSkge1xuICAgICAgaWYgKGd0bHQgPT09ICc+JyB8fCBndGx0ID09PSAnPCcpIHtcbiAgICAgICAgLy8gbm90aGluZyBpcyBhbGxvd2VkXG4gICAgICAgIHJldCA9ICc8MC4wLjAtMCdcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIC8vIG5vdGhpbmcgaXMgZm9yYmlkZGVuXG4gICAgICAgIHJldCA9ICcqJ1xuICAgICAgfVxuICAgIH0gZWxzZSBpZiAoZ3RsdCAmJiBhbnlYKSB7XG4gICAgICAvLyB3ZSBrbm93IHBhdGNoIGlzIGFuIHgsIGJlY2F1c2Ugd2UgaGF2ZSBhbnkgeCBhdCBhbGwuXG4gICAgICAvLyByZXBsYWNlIFggd2l0aCAwXG4gICAgICBpZiAoeG0pIHtcbiAgICAgICAgbSA9IDBcbiAgICAgIH1cbiAgICAgIHAgPSAwXG5cbiAgICAgIGlmIChndGx0ID09PSAnPicpIHtcbiAgICAgICAgLy8gPjEgPT4gPj0yLjAuMFxuICAgICAgICAvLyA+MS4yID0+ID49MS4zLjBcbiAgICAgICAgZ3RsdCA9ICc+PSdcbiAgICAgICAgaWYgKHhtKSB7XG4gICAgICAgICAgTSA9ICtNICsgMVxuICAgICAgICAgIG0gPSAwXG4gICAgICAgICAgcCA9IDBcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBtID0gK20gKyAxXG4gICAgICAgICAgcCA9IDBcbiAgICAgICAgfVxuICAgICAgfSBlbHNlIGlmIChndGx0ID09PSAnPD0nKSB7XG4gICAgICAgIC8vIDw9MC43LnggaXMgYWN0dWFsbHkgPDAuOC4wLCBzaW5jZSBhbnkgMC43Lnggc2hvdWxkXG4gICAgICAgIC8vIHBhc3MuICBTaW1pbGFybHksIDw9Ny54IGlzIGFjdHVhbGx5IDw4LjAuMCwgZXRjLlxuICAgICAgICBndGx0ID0gJzwnXG4gICAgICAgIGlmICh4bSkge1xuICAgICAgICAgIE0gPSArTSArIDFcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBtID0gK20gKyAxXG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgaWYgKGd0bHQgPT09ICc8Jykge1xuICAgICAgICBwciA9ICctMCdcbiAgICAgIH1cblxuICAgICAgcmV0ID0gYCR7Z3RsdCArIE19LiR7bX0uJHtwfSR7cHJ9YFxuICAgIH0gZWxzZSBpZiAoeG0pIHtcbiAgICAgIHJldCA9IGA+PSR7TX0uMC4wJHtwcn0gPCR7K00gKyAxfS4wLjAtMGBcbiAgICB9IGVsc2UgaWYgKHhwKSB7XG4gICAgICByZXQgPSBgPj0ke019LiR7bX0uMCR7cHJcbiAgICAgIH0gPCR7TX0uJHsrbSArIDF9LjAtMGBcbiAgICB9XG5cbiAgICBkZWJ1ZygneFJhbmdlIHJldHVybicsIHJldClcblxuICAgIHJldHVybiByZXRcbiAgfSlcbn1cblxuLy8gQmVjYXVzZSAqIGlzIEFORC1lZCB3aXRoIGV2ZXJ5dGhpbmcgZWxzZSBpbiB0aGUgY29tcGFyYXRvcixcbi8vIGFuZCAnJyBtZWFucyBcImFueSB2ZXJzaW9uXCIsIGp1c3QgcmVtb3ZlIHRoZSAqcyBlbnRpcmVseS5cbmNvbnN0IHJlcGxhY2VTdGFycyA9IChjb21wLCBvcHRpb25zKSA9PiB7XG4gIGRlYnVnKCdyZXBsYWNlU3RhcnMnLCBjb21wLCBvcHRpb25zKVxuICAvLyBMb29zZW5lc3MgaXMgaWdub3JlZCBoZXJlLiAgc3RhciBpcyBhbHdheXMgYXMgbG9vc2UgYXMgaXQgZ2V0cyFcbiAgcmV0dXJuIGNvbXBcbiAgICAudHJpbSgpXG4gICAgLnJlcGxhY2UocmVbdC5TVEFSXSwgJycpXG59XG5cbmNvbnN0IHJlcGxhY2VHVEUwID0gKGNvbXAsIG9wdGlvbnMpID0+IHtcbiAgZGVidWcoJ3JlcGxhY2VHVEUwJywgY29tcCwgb3B0aW9ucylcbiAgcmV0dXJuIGNvbXBcbiAgICAudHJpbSgpXG4gICAgLnJlcGxhY2UocmVbb3B0aW9ucy5pbmNsdWRlUHJlcmVsZWFzZSA/IHQuR1RFMFBSRSA6IHQuR1RFMF0sICcnKVxufVxuXG4vLyBUaGlzIGZ1bmN0aW9uIGlzIHBhc3NlZCB0byBzdHJpbmcucmVwbGFjZShyZVt0LkhZUEhFTlJBTkdFXSlcbi8vIE0sIG0sIHBhdGNoLCBwcmVyZWxlYXNlLCBidWlsZFxuLy8gMS4yIC0gMy40LjUgPT4gPj0xLjIuMCA8PTMuNC41XG4vLyAxLjIuMyAtIDMuNCA9PiA+PTEuMi4wIDwzLjUuMC0wIEFueSAzLjQueCB3aWxsIGRvXG4vLyAxLjIgLSAzLjQgPT4gPj0xLjIuMCA8My41LjAtMFxuLy8gVE9ETyBidWlsZD9cbmNvbnN0IGh5cGhlblJlcGxhY2UgPSBpbmNQciA9PiAoJDAsXG4gIGZyb20sIGZNLCBmbSwgZnAsIGZwciwgZmIsXG4gIHRvLCB0TSwgdG0sIHRwLCB0cHIpID0+IHtcbiAgaWYgKGlzWChmTSkpIHtcbiAgICBmcm9tID0gJydcbiAgfSBlbHNlIGlmIChpc1goZm0pKSB7XG4gICAgZnJvbSA9IGA+PSR7Zk19LjAuMCR7aW5jUHIgPyAnLTAnIDogJyd9YFxuICB9IGVsc2UgaWYgKGlzWChmcCkpIHtcbiAgICBmcm9tID0gYD49JHtmTX0uJHtmbX0uMCR7aW5jUHIgPyAnLTAnIDogJyd9YFxuICB9IGVsc2UgaWYgKGZwcikge1xuICAgIGZyb20gPSBgPj0ke2Zyb219YFxuICB9IGVsc2Uge1xuICAgIGZyb20gPSBgPj0ke2Zyb219JHtpbmNQciA/ICctMCcgOiAnJ31gXG4gIH1cblxuICBpZiAoaXNYKHRNKSkge1xuICAgIHRvID0gJydcbiAgfSBlbHNlIGlmIChpc1godG0pKSB7XG4gICAgdG8gPSBgPCR7K3RNICsgMX0uMC4wLTBgXG4gIH0gZWxzZSBpZiAoaXNYKHRwKSkge1xuICAgIHRvID0gYDwke3RNfS4keyt0bSArIDF9LjAtMGBcbiAgfSBlbHNlIGlmICh0cHIpIHtcbiAgICB0byA9IGA8PSR7dE19LiR7dG19LiR7dHB9LSR7dHByfWBcbiAgfSBlbHNlIGlmIChpbmNQcikge1xuICAgIHRvID0gYDwke3RNfS4ke3RtfS4keyt0cCArIDF9LTBgXG4gIH0gZWxzZSB7XG4gICAgdG8gPSBgPD0ke3RvfWBcbiAgfVxuXG4gIHJldHVybiBgJHtmcm9tfSAke3RvfWAudHJpbSgpXG59XG5cbmNvbnN0IHRlc3RTZXQgPSAoc2V0LCB2ZXJzaW9uLCBvcHRpb25zKSA9PiB7XG4gIGZvciAobGV0IGkgPSAwOyBpIDwgc2V0Lmxlbmd0aDsgaSsrKSB7XG4gICAgaWYgKCFzZXRbaV0udGVzdCh2ZXJzaW9uKSkge1xuICAgICAgcmV0dXJuIGZhbHNlXG4gICAgfVxuICB9XG5cbiAgaWYgKHZlcnNpb24ucHJlcmVsZWFzZS5sZW5ndGggJiYgIW9wdGlvbnMuaW5jbHVkZVByZXJlbGVhc2UpIHtcbiAgICAvLyBGaW5kIHRoZSBzZXQgb2YgdmVyc2lvbnMgdGhhdCBhcmUgYWxsb3dlZCB0byBoYXZlIHByZXJlbGVhc2VzXG4gICAgLy8gRm9yIGV4YW1wbGUsIF4xLjIuMy1wci4xIGRlc3VnYXJzIHRvID49MS4yLjMtcHIuMSA8Mi4wLjBcbiAgICAvLyBUaGF0IHNob3VsZCBhbGxvdyBgMS4yLjMtcHIuMmAgdG8gcGFzcy5cbiAgICAvLyBIb3dldmVyLCBgMS4yLjQtYWxwaGEubm90cmVhZHlgIHNob3VsZCBOT1QgYmUgYWxsb3dlZCxcbiAgICAvLyBldmVuIHRob3VnaCBpdCdzIHdpdGhpbiB0aGUgcmFuZ2Ugc2V0IGJ5IHRoZSBjb21wYXJhdG9ycy5cbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IHNldC5sZW5ndGg7IGkrKykge1xuICAgICAgZGVidWcoc2V0W2ldLnNlbXZlcilcbiAgICAgIGlmIChzZXRbaV0uc2VtdmVyID09PSBDb21wYXJhdG9yLkFOWSkge1xuICAgICAgICBjb250aW51ZVxuICAgICAgfVxuXG4gICAgICBpZiAoc2V0W2ldLnNlbXZlci5wcmVyZWxlYXNlLmxlbmd0aCA+IDApIHtcbiAgICAgICAgY29uc3QgYWxsb3dlZCA9IHNldFtpXS5zZW12ZXJcbiAgICAgICAgaWYgKGFsbG93ZWQubWFqb3IgPT09IHZlcnNpb24ubWFqb3IgJiZcbiAgICAgICAgICAgIGFsbG93ZWQubWlub3IgPT09IHZlcnNpb24ubWlub3IgJiZcbiAgICAgICAgICAgIGFsbG93ZWQucGF0Y2ggPT09IHZlcnNpb24ucGF0Y2gpIHtcbiAgICAgICAgICByZXR1cm4gdHJ1ZVxuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuXG4gICAgLy8gVmVyc2lvbiBoYXMgYSAtcHJlLCBidXQgaXQncyBub3Qgb25lIG9mIHRoZSBvbmVzIHdlIGxpa2UuXG4gICAgcmV0dXJuIGZhbHNlXG4gIH1cblxuICByZXR1cm4gdHJ1ZVxufVxuIiwgIid1c2Ugc3RyaWN0J1xuXG5jb25zdCBBTlkgPSBTeW1ib2woJ1NlbVZlciBBTlknKVxuLy8gaG9pc3RlZCBjbGFzcyBmb3IgY3ljbGljIGRlcGVuZGVuY3lcbmNsYXNzIENvbXBhcmF0b3Ige1xuICBzdGF0aWMgZ2V0IEFOWSAoKSB7XG4gICAgcmV0dXJuIEFOWVxuICB9XG5cbiAgY29uc3RydWN0b3IgKGNvbXAsIG9wdGlvbnMpIHtcbiAgICBvcHRpb25zID0gcGFyc2VPcHRpb25zKG9wdGlvbnMpXG5cbiAgICBpZiAoY29tcCBpbnN0YW5jZW9mIENvbXBhcmF0b3IpIHtcbiAgICAgIGlmIChjb21wLmxvb3NlID09PSAhIW9wdGlvbnMubG9vc2UpIHtcbiAgICAgICAgcmV0dXJuIGNvbXBcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGNvbXAgPSBjb21wLnZhbHVlXG4gICAgICB9XG4gICAgfVxuXG4gICAgY29tcCA9IGNvbXAudHJpbSgpLnNwbGl0KC9cXHMrLykuam9pbignICcpXG4gICAgZGVidWcoJ2NvbXBhcmF0b3InLCBjb21wLCBvcHRpb25zKVxuICAgIHRoaXMub3B0aW9ucyA9IG9wdGlvbnNcbiAgICB0aGlzLmxvb3NlID0gISFvcHRpb25zLmxvb3NlXG4gICAgdGhpcy5wYXJzZShjb21wKVxuXG4gICAgaWYgKHRoaXMuc2VtdmVyID09PSBBTlkpIHtcbiAgICAgIHRoaXMudmFsdWUgPSAnJ1xuICAgIH0gZWxzZSB7XG4gICAgICB0aGlzLnZhbHVlID0gdGhpcy5vcGVyYXRvciArIHRoaXMuc2VtdmVyLnZlcnNpb25cbiAgICB9XG5cbiAgICBkZWJ1ZygnY29tcCcsIHRoaXMpXG4gIH1cblxuICBwYXJzZSAoY29tcCkge1xuICAgIGNvbnN0IHIgPSB0aGlzLm9wdGlvbnMubG9vc2UgPyByZVt0LkNPTVBBUkFUT1JMT09TRV0gOiByZVt0LkNPTVBBUkFUT1JdXG4gICAgY29uc3QgbSA9IGNvbXAubWF0Y2gocilcblxuICAgIGlmICghbSkge1xuICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcihgSW52YWxpZCBjb21wYXJhdG9yOiAke2NvbXB9YClcbiAgICB9XG5cbiAgICB0aGlzLm9wZXJhdG9yID0gbVsxXSAhPT0gdW5kZWZpbmVkID8gbVsxXSA6ICcnXG4gICAgaWYgKHRoaXMub3BlcmF0b3IgPT09ICc9Jykge1xuICAgICAgdGhpcy5vcGVyYXRvciA9ICcnXG4gICAgfVxuXG4gICAgLy8gaWYgaXQgbGl0ZXJhbGx5IGlzIGp1c3QgJz4nIG9yICcnIHRoZW4gYWxsb3cgYW55dGhpbmcuXG4gICAgaWYgKCFtWzJdKSB7XG4gICAgICB0aGlzLnNlbXZlciA9IEFOWVxuICAgIH0gZWxzZSB7XG4gICAgICB0aGlzLnNlbXZlciA9IG5ldyBTZW1WZXIobVsyXSwgdGhpcy5vcHRpb25zLmxvb3NlKVxuICAgIH1cbiAgfVxuXG4gIHRvU3RyaW5nICgpIHtcbiAgICByZXR1cm4gdGhpcy52YWx1ZVxuICB9XG5cbiAgdGVzdCAodmVyc2lvbikge1xuICAgIGRlYnVnKCdDb21wYXJhdG9yLnRlc3QnLCB2ZXJzaW9uLCB0aGlzLm9wdGlvbnMubG9vc2UpXG5cbiAgICBpZiAodGhpcy5zZW12ZXIgPT09IEFOWSB8fCB2ZXJzaW9uID09PSBBTlkpIHtcbiAgICAgIHJldHVybiB0cnVlXG4gICAgfVxuXG4gICAgaWYgKHR5cGVvZiB2ZXJzaW9uID09PSAnc3RyaW5nJykge1xuICAgICAgdHJ5IHtcbiAgICAgICAgdmVyc2lvbiA9IG5ldyBTZW1WZXIodmVyc2lvbiwgdGhpcy5vcHRpb25zKVxuICAgICAgfSBjYXRjaCAoZXIpIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlXG4gICAgICB9XG4gICAgfVxuXG4gICAgcmV0dXJuIGNtcCh2ZXJzaW9uLCB0aGlzLm9wZXJhdG9yLCB0aGlzLnNlbXZlciwgdGhpcy5vcHRpb25zKVxuICB9XG5cbiAgaW50ZXJzZWN0cyAoY29tcCwgb3B0aW9ucykge1xuICAgIGlmICghKGNvbXAgaW5zdGFuY2VvZiBDb21wYXJhdG9yKSkge1xuICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcignYSBDb21wYXJhdG9yIGlzIHJlcXVpcmVkJylcbiAgICB9XG5cbiAgICBpZiAodGhpcy5vcGVyYXRvciA9PT0gJycpIHtcbiAgICAgIGlmICh0aGlzLnZhbHVlID09PSAnJykge1xuICAgICAgICByZXR1cm4gdHJ1ZVxuICAgICAgfVxuICAgICAgcmV0dXJuIG5ldyBSYW5nZShjb21wLnZhbHVlLCBvcHRpb25zKS50ZXN0KHRoaXMudmFsdWUpXG4gICAgfSBlbHNlIGlmIChjb21wLm9wZXJhdG9yID09PSAnJykge1xuICAgICAgaWYgKGNvbXAudmFsdWUgPT09ICcnKSB7XG4gICAgICAgIHJldHVybiB0cnVlXG4gICAgICB9XG4gICAgICByZXR1cm4gbmV3IFJhbmdlKHRoaXMudmFsdWUsIG9wdGlvbnMpLnRlc3QoY29tcC5zZW12ZXIpXG4gICAgfVxuXG4gICAgb3B0aW9ucyA9IHBhcnNlT3B0aW9ucyhvcHRpb25zKVxuXG4gICAgLy8gU3BlY2lhbCBjYXNlcyB3aGVyZSBub3RoaW5nIGNhbiBwb3NzaWJseSBiZSBsb3dlclxuICAgIGlmIChvcHRpb25zLmluY2x1ZGVQcmVyZWxlYXNlICYmXG4gICAgICAodGhpcy52YWx1ZSA9PT0gJzwwLjAuMC0wJyB8fCBjb21wLnZhbHVlID09PSAnPDAuMC4wLTAnKSkge1xuICAgICAgcmV0dXJuIGZhbHNlXG4gICAgfVxuICAgIGlmICghb3B0aW9ucy5pbmNsdWRlUHJlcmVsZWFzZSAmJlxuICAgICAgKHRoaXMudmFsdWUuc3RhcnRzV2l0aCgnPDAuMC4wJykgfHwgY29tcC52YWx1ZS5zdGFydHNXaXRoKCc8MC4wLjAnKSkpIHtcbiAgICAgIHJldHVybiBmYWxzZVxuICAgIH1cblxuICAgIC8vIFNhbWUgZGlyZWN0aW9uIGluY3JlYXNpbmcgKD4gb3IgPj0pXG4gICAgaWYgKHRoaXMub3BlcmF0b3Iuc3RhcnRzV2l0aCgnPicpICYmIGNvbXAub3BlcmF0b3Iuc3RhcnRzV2l0aCgnPicpKSB7XG4gICAgICByZXR1cm4gdHJ1ZVxuICAgIH1cbiAgICAvLyBTYW1lIGRpcmVjdGlvbiBkZWNyZWFzaW5nICg8IG9yIDw9KVxuICAgIGlmICh0aGlzLm9wZXJhdG9yLnN0YXJ0c1dpdGgoJzwnKSAmJiBjb21wLm9wZXJhdG9yLnN0YXJ0c1dpdGgoJzwnKSkge1xuICAgICAgcmV0dXJuIHRydWVcbiAgICB9XG4gICAgLy8gc2FtZSBTZW1WZXIgYW5kIGJvdGggc2lkZXMgYXJlIGluY2x1c2l2ZSAoPD0gb3IgPj0pXG4gICAgaWYgKFxuICAgICAgKHRoaXMuc2VtdmVyLnZlcnNpb24gPT09IGNvbXAuc2VtdmVyLnZlcnNpb24pICYmXG4gICAgICB0aGlzLm9wZXJhdG9yLmluY2x1ZGVzKCc9JykgJiYgY29tcC5vcGVyYXRvci5pbmNsdWRlcygnPScpKSB7XG4gICAgICByZXR1cm4gdHJ1ZVxuICAgIH1cbiAgICAvLyBvcHBvc2l0ZSBkaXJlY3Rpb25zIGxlc3MgdGhhblxuICAgIGlmIChjbXAodGhpcy5zZW12ZXIsICc8JywgY29tcC5zZW12ZXIsIG9wdGlvbnMpICYmXG4gICAgICB0aGlzLm9wZXJhdG9yLnN0YXJ0c1dpdGgoJz4nKSAmJiBjb21wLm9wZXJhdG9yLnN0YXJ0c1dpdGgoJzwnKSkge1xuICAgICAgcmV0dXJuIHRydWVcbiAgICB9XG4gICAgLy8gb3Bwb3NpdGUgZGlyZWN0aW9ucyBncmVhdGVyIHRoYW5cbiAgICBpZiAoY21wKHRoaXMuc2VtdmVyLCAnPicsIGNvbXAuc2VtdmVyLCBvcHRpb25zKSAmJlxuICAgICAgdGhpcy5vcGVyYXRvci5zdGFydHNXaXRoKCc8JykgJiYgY29tcC5vcGVyYXRvci5zdGFydHNXaXRoKCc+JykpIHtcbiAgICAgIHJldHVybiB0cnVlXG4gICAgfVxuICAgIHJldHVybiBmYWxzZVxuICB9XG59XG5cbm1vZHVsZS5leHBvcnRzID0gQ29tcGFyYXRvclxuXG5jb25zdCBwYXJzZU9wdGlvbnMgPSByZXF1aXJlKCcuLi9pbnRlcm5hbC9wYXJzZS1vcHRpb25zJylcbmNvbnN0IHsgc2FmZVJlOiByZSwgdCB9ID0gcmVxdWlyZSgnLi4vaW50ZXJuYWwvcmUnKVxuY29uc3QgY21wID0gcmVxdWlyZSgnLi4vZnVuY3Rpb25zL2NtcCcpXG5jb25zdCBkZWJ1ZyA9IHJlcXVpcmUoJy4uL2ludGVybmFsL2RlYnVnJylcbmNvbnN0IFNlbVZlciA9IHJlcXVpcmUoJy4vc2VtdmVyJylcbmNvbnN0IFJhbmdlID0gcmVxdWlyZSgnLi9yYW5nZScpXG4iLCAiJ3VzZSBzdHJpY3QnXG5cbmNvbnN0IFJhbmdlID0gcmVxdWlyZSgnLi4vY2xhc3Nlcy9yYW5nZScpXG5jb25zdCBzYXRpc2ZpZXMgPSAodmVyc2lvbiwgcmFuZ2UsIG9wdGlvbnMpID0+IHtcbiAgdHJ5IHtcbiAgICByYW5nZSA9IG5ldyBSYW5nZShyYW5nZSwgb3B0aW9ucylcbiAgfSBjYXRjaCAoZXIpIHtcbiAgICByZXR1cm4gZmFsc2VcbiAgfVxuICByZXR1cm4gcmFuZ2UudGVzdCh2ZXJzaW9uKVxufVxubW9kdWxlLmV4cG9ydHMgPSBzYXRpc2ZpZXNcbiIsICIndXNlIHN0cmljdCdcblxuY29uc3QgUmFuZ2UgPSByZXF1aXJlKCcuLi9jbGFzc2VzL3JhbmdlJylcblxuLy8gTW9zdGx5IGp1c3QgZm9yIHRlc3RpbmcgYW5kIGxlZ2FjeSBBUEkgcmVhc29uc1xuY29uc3QgdG9Db21wYXJhdG9ycyA9IChyYW5nZSwgb3B0aW9ucykgPT5cbiAgbmV3IFJhbmdlKHJhbmdlLCBvcHRpb25zKS5zZXRcbiAgICAubWFwKGNvbXAgPT4gY29tcC5tYXAoYyA9PiBjLnZhbHVlKS5qb2luKCcgJykudHJpbSgpLnNwbGl0KCcgJykpXG5cbm1vZHVsZS5leHBvcnRzID0gdG9Db21wYXJhdG9yc1xuIiwgIid1c2Ugc3RyaWN0J1xuXG5jb25zdCBTZW1WZXIgPSByZXF1aXJlKCcuLi9jbGFzc2VzL3NlbXZlcicpXG5jb25zdCBSYW5nZSA9IHJlcXVpcmUoJy4uL2NsYXNzZXMvcmFuZ2UnKVxuXG5jb25zdCBtYXhTYXRpc2Z5aW5nID0gKHZlcnNpb25zLCByYW5nZSwgb3B0aW9ucykgPT4ge1xuICBsZXQgbWF4ID0gbnVsbFxuICBsZXQgbWF4U1YgPSBudWxsXG4gIGxldCByYW5nZU9iaiA9IG51bGxcbiAgdHJ5IHtcbiAgICByYW5nZU9iaiA9IG5ldyBSYW5nZShyYW5nZSwgb3B0aW9ucylcbiAgfSBjYXRjaCAoZXIpIHtcbiAgICByZXR1cm4gbnVsbFxuICB9XG4gIHZlcnNpb25zLmZvckVhY2goKHYpID0+IHtcbiAgICBpZiAocmFuZ2VPYmoudGVzdCh2KSkge1xuICAgICAgLy8gc2F0aXNmaWVzKHYsIHJhbmdlLCBvcHRpb25zKVxuICAgICAgaWYgKCFtYXggfHwgbWF4U1YuY29tcGFyZSh2KSA9PT0gLTEpIHtcbiAgICAgICAgLy8gY29tcGFyZShtYXgsIHYsIHRydWUpXG4gICAgICAgIG1heCA9IHZcbiAgICAgICAgbWF4U1YgPSBuZXcgU2VtVmVyKG1heCwgb3B0aW9ucylcbiAgICAgIH1cbiAgICB9XG4gIH0pXG4gIHJldHVybiBtYXhcbn1cbm1vZHVsZS5leHBvcnRzID0gbWF4U2F0aXNmeWluZ1xuIiwgIid1c2Ugc3RyaWN0J1xuXG5jb25zdCBTZW1WZXIgPSByZXF1aXJlKCcuLi9jbGFzc2VzL3NlbXZlcicpXG5jb25zdCBSYW5nZSA9IHJlcXVpcmUoJy4uL2NsYXNzZXMvcmFuZ2UnKVxuY29uc3QgbWluU2F0aXNmeWluZyA9ICh2ZXJzaW9ucywgcmFuZ2UsIG9wdGlvbnMpID0+IHtcbiAgbGV0IG1pbiA9IG51bGxcbiAgbGV0IG1pblNWID0gbnVsbFxuICBsZXQgcmFuZ2VPYmogPSBudWxsXG4gIHRyeSB7XG4gICAgcmFuZ2VPYmogPSBuZXcgUmFuZ2UocmFuZ2UsIG9wdGlvbnMpXG4gIH0gY2F0Y2ggKGVyKSB7XG4gICAgcmV0dXJuIG51bGxcbiAgfVxuICB2ZXJzaW9ucy5mb3JFYWNoKCh2KSA9PiB7XG4gICAgaWYgKHJhbmdlT2JqLnRlc3QodikpIHtcbiAgICAgIC8vIHNhdGlzZmllcyh2LCByYW5nZSwgb3B0aW9ucylcbiAgICAgIGlmICghbWluIHx8IG1pblNWLmNvbXBhcmUodikgPT09IDEpIHtcbiAgICAgICAgLy8gY29tcGFyZShtaW4sIHYsIHRydWUpXG4gICAgICAgIG1pbiA9IHZcbiAgICAgICAgbWluU1YgPSBuZXcgU2VtVmVyKG1pbiwgb3B0aW9ucylcbiAgICAgIH1cbiAgICB9XG4gIH0pXG4gIHJldHVybiBtaW5cbn1cbm1vZHVsZS5leHBvcnRzID0gbWluU2F0aXNmeWluZ1xuIiwgIid1c2Ugc3RyaWN0J1xuXG5jb25zdCBTZW1WZXIgPSByZXF1aXJlKCcuLi9jbGFzc2VzL3NlbXZlcicpXG5jb25zdCBSYW5nZSA9IHJlcXVpcmUoJy4uL2NsYXNzZXMvcmFuZ2UnKVxuY29uc3QgZ3QgPSByZXF1aXJlKCcuLi9mdW5jdGlvbnMvZ3QnKVxuXG5jb25zdCBtaW5WZXJzaW9uID0gKHJhbmdlLCBsb29zZSkgPT4ge1xuICByYW5nZSA9IG5ldyBSYW5nZShyYW5nZSwgbG9vc2UpXG5cbiAgbGV0IG1pbnZlciA9IG5ldyBTZW1WZXIoJzAuMC4wJylcbiAgaWYgKHJhbmdlLnRlc3QobWludmVyKSkge1xuICAgIHJldHVybiBtaW52ZXJcbiAgfVxuXG4gIG1pbnZlciA9IG5ldyBTZW1WZXIoJzAuMC4wLTAnKVxuICBpZiAocmFuZ2UudGVzdChtaW52ZXIpKSB7XG4gICAgcmV0dXJuIG1pbnZlclxuICB9XG5cbiAgbWludmVyID0gbnVsbFxuICBmb3IgKGxldCBpID0gMDsgaSA8IHJhbmdlLnNldC5sZW5ndGg7ICsraSkge1xuICAgIGNvbnN0IGNvbXBhcmF0b3JzID0gcmFuZ2Uuc2V0W2ldXG5cbiAgICBsZXQgc2V0TWluID0gbnVsbFxuICAgIGNvbXBhcmF0b3JzLmZvckVhY2goKGNvbXBhcmF0b3IpID0+IHtcbiAgICAgIC8vIENsb25lIHRvIGF2b2lkIG1hbmlwdWxhdGluZyB0aGUgY29tcGFyYXRvcidzIHNlbXZlciBvYmplY3QuXG4gICAgICBjb25zdCBjb21wdmVyID0gbmV3IFNlbVZlcihjb21wYXJhdG9yLnNlbXZlci52ZXJzaW9uKVxuICAgICAgc3dpdGNoIChjb21wYXJhdG9yLm9wZXJhdG9yKSB7XG4gICAgICAgIGNhc2UgJz4nOlxuICAgICAgICAgIGlmIChjb21wdmVyLnByZXJlbGVhc2UubGVuZ3RoID09PSAwKSB7XG4gICAgICAgICAgICBjb21wdmVyLnBhdGNoKytcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgY29tcHZlci5wcmVyZWxlYXNlLnB1c2goMClcbiAgICAgICAgICB9XG4gICAgICAgICAgY29tcHZlci5yYXcgPSBjb21wdmVyLmZvcm1hdCgpXG4gICAgICAgICAgLyogZmFsbHRocm91Z2ggKi9cbiAgICAgICAgY2FzZSAnJzpcbiAgICAgICAgY2FzZSAnPj0nOlxuICAgICAgICAgIGlmICghc2V0TWluIHx8IGd0KGNvbXB2ZXIsIHNldE1pbikpIHtcbiAgICAgICAgICAgIHNldE1pbiA9IGNvbXB2ZXJcbiAgICAgICAgICB9XG4gICAgICAgICAgYnJlYWtcbiAgICAgICAgY2FzZSAnPCc6XG4gICAgICAgIGNhc2UgJzw9JzpcbiAgICAgICAgICAvKiBJZ25vcmUgbWF4aW11bSB2ZXJzaW9ucyAqL1xuICAgICAgICAgIGJyZWFrXG4gICAgICAgIC8qIGlzdGFuYnVsIGlnbm9yZSBuZXh0ICovXG4gICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBVbmV4cGVjdGVkIG9wZXJhdGlvbjogJHtjb21wYXJhdG9yLm9wZXJhdG9yfWApXG4gICAgICB9XG4gICAgfSlcbiAgICBpZiAoc2V0TWluICYmICghbWludmVyIHx8IGd0KG1pbnZlciwgc2V0TWluKSkpIHtcbiAgICAgIG1pbnZlciA9IHNldE1pblxuICAgIH1cbiAgfVxuXG4gIGlmIChtaW52ZXIgJiYgcmFuZ2UudGVzdChtaW52ZXIpKSB7XG4gICAgcmV0dXJuIG1pbnZlclxuICB9XG5cbiAgcmV0dXJuIG51bGxcbn1cbm1vZHVsZS5leHBvcnRzID0gbWluVmVyc2lvblxuIiwgIid1c2Ugc3RyaWN0J1xuXG5jb25zdCBSYW5nZSA9IHJlcXVpcmUoJy4uL2NsYXNzZXMvcmFuZ2UnKVxuY29uc3QgdmFsaWRSYW5nZSA9IChyYW5nZSwgb3B0aW9ucykgPT4ge1xuICB0cnkge1xuICAgIC8vIFJldHVybiAnKicgaW5zdGVhZCBvZiAnJyBzbyB0aGF0IHRydXRoaW5lc3Mgd29ya3MuXG4gICAgLy8gVGhpcyB3aWxsIHRocm93IGlmIGl0J3MgaW52YWxpZCBhbnl3YXlcbiAgICByZXR1cm4gbmV3IFJhbmdlKHJhbmdlLCBvcHRpb25zKS5yYW5nZSB8fCAnKidcbiAgfSBjYXRjaCAoZXIpIHtcbiAgICByZXR1cm4gbnVsbFxuICB9XG59XG5tb2R1bGUuZXhwb3J0cyA9IHZhbGlkUmFuZ2VcbiIsICIndXNlIHN0cmljdCdcblxuY29uc3QgU2VtVmVyID0gcmVxdWlyZSgnLi4vY2xhc3Nlcy9zZW12ZXInKVxuY29uc3QgQ29tcGFyYXRvciA9IHJlcXVpcmUoJy4uL2NsYXNzZXMvY29tcGFyYXRvcicpXG5jb25zdCB7IEFOWSB9ID0gQ29tcGFyYXRvclxuY29uc3QgUmFuZ2UgPSByZXF1aXJlKCcuLi9jbGFzc2VzL3JhbmdlJylcbmNvbnN0IHNhdGlzZmllcyA9IHJlcXVpcmUoJy4uL2Z1bmN0aW9ucy9zYXRpc2ZpZXMnKVxuY29uc3QgZ3QgPSByZXF1aXJlKCcuLi9mdW5jdGlvbnMvZ3QnKVxuY29uc3QgbHQgPSByZXF1aXJlKCcuLi9mdW5jdGlvbnMvbHQnKVxuY29uc3QgbHRlID0gcmVxdWlyZSgnLi4vZnVuY3Rpb25zL2x0ZScpXG5jb25zdCBndGUgPSByZXF1aXJlKCcuLi9mdW5jdGlvbnMvZ3RlJylcblxuY29uc3Qgb3V0c2lkZSA9ICh2ZXJzaW9uLCByYW5nZSwgaGlsbywgb3B0aW9ucykgPT4ge1xuICB2ZXJzaW9uID0gbmV3IFNlbVZlcih2ZXJzaW9uLCBvcHRpb25zKVxuICByYW5nZSA9IG5ldyBSYW5nZShyYW5nZSwgb3B0aW9ucylcblxuICBsZXQgZ3RmbiwgbHRlZm4sIGx0Zm4sIGNvbXAsIGVjb21wXG4gIHN3aXRjaCAoaGlsbykge1xuICAgIGNhc2UgJz4nOlxuICAgICAgZ3RmbiA9IGd0XG4gICAgICBsdGVmbiA9IGx0ZVxuICAgICAgbHRmbiA9IGx0XG4gICAgICBjb21wID0gJz4nXG4gICAgICBlY29tcCA9ICc+PSdcbiAgICAgIGJyZWFrXG4gICAgY2FzZSAnPCc6XG4gICAgICBndGZuID0gbHRcbiAgICAgIGx0ZWZuID0gZ3RlXG4gICAgICBsdGZuID0gZ3RcbiAgICAgIGNvbXAgPSAnPCdcbiAgICAgIGVjb21wID0gJzw9J1xuICAgICAgYnJlYWtcbiAgICBkZWZhdWx0OlxuICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcignTXVzdCBwcm92aWRlIGEgaGlsbyB2YWwgb2YgXCI8XCIgb3IgXCI+XCInKVxuICB9XG5cbiAgLy8gSWYgaXQgc2F0aXNmaWVzIHRoZSByYW5nZSBpdCBpcyBub3Qgb3V0c2lkZVxuICBpZiAoc2F0aXNmaWVzKHZlcnNpb24sIHJhbmdlLCBvcHRpb25zKSkge1xuICAgIHJldHVybiBmYWxzZVxuICB9XG5cbiAgLy8gRnJvbSBub3cgb24sIHZhcmlhYmxlIHRlcm1zIGFyZSBhcyBpZiB3ZSdyZSBpbiBcImd0clwiIG1vZGUuXG4gIC8vIGJ1dCBub3RlIHRoYXQgZXZlcnl0aGluZyBpcyBmbGlwcGVkIGZvciB0aGUgXCJsdHJcIiBmdW5jdGlvbi5cblxuICBmb3IgKGxldCBpID0gMDsgaSA8IHJhbmdlLnNldC5sZW5ndGg7ICsraSkge1xuICAgIGNvbnN0IGNvbXBhcmF0b3JzID0gcmFuZ2Uuc2V0W2ldXG5cbiAgICBsZXQgaGlnaCA9IG51bGxcbiAgICBsZXQgbG93ID0gbnVsbFxuXG4gICAgY29tcGFyYXRvcnMuZm9yRWFjaCgoY29tcGFyYXRvcikgPT4ge1xuICAgICAgaWYgKGNvbXBhcmF0b3Iuc2VtdmVyID09PSBBTlkpIHtcbiAgICAgICAgY29tcGFyYXRvciA9IG5ldyBDb21wYXJhdG9yKCc+PTAuMC4wJylcbiAgICAgIH1cbiAgICAgIGhpZ2ggPSBoaWdoIHx8IGNvbXBhcmF0b3JcbiAgICAgIGxvdyA9IGxvdyB8fCBjb21wYXJhdG9yXG4gICAgICBpZiAoZ3Rmbihjb21wYXJhdG9yLnNlbXZlciwgaGlnaC5zZW12ZXIsIG9wdGlvbnMpKSB7XG4gICAgICAgIGhpZ2ggPSBjb21wYXJhdG9yXG4gICAgICB9IGVsc2UgaWYgKGx0Zm4oY29tcGFyYXRvci5zZW12ZXIsIGxvdy5zZW12ZXIsIG9wdGlvbnMpKSB7XG4gICAgICAgIGxvdyA9IGNvbXBhcmF0b3JcbiAgICAgIH1cbiAgICB9KVxuXG4gICAgLy8gSWYgdGhlIGVkZ2UgdmVyc2lvbiBjb21wYXJhdG9yIGhhcyBhIG9wZXJhdG9yIHRoZW4gb3VyIHZlcnNpb25cbiAgICAvLyBpc24ndCBvdXRzaWRlIGl0XG4gICAgaWYgKGhpZ2gub3BlcmF0b3IgPT09IGNvbXAgfHwgaGlnaC5vcGVyYXRvciA9PT0gZWNvbXApIHtcbiAgICAgIHJldHVybiBmYWxzZVxuICAgIH1cblxuICAgIC8vIElmIHRoZSBsb3dlc3QgdmVyc2lvbiBjb21wYXJhdG9yIGhhcyBhbiBvcGVyYXRvciBhbmQgb3VyIHZlcnNpb25cbiAgICAvLyBpcyBsZXNzIHRoYW4gaXQgdGhlbiBpdCBpc24ndCBoaWdoZXIgdGhhbiB0aGUgcmFuZ2VcbiAgICBpZiAoKCFsb3cub3BlcmF0b3IgfHwgbG93Lm9wZXJhdG9yID09PSBjb21wKSAmJlxuICAgICAgICBsdGVmbih2ZXJzaW9uLCBsb3cuc2VtdmVyKSkge1xuICAgICAgcmV0dXJuIGZhbHNlXG4gICAgfSBlbHNlIGlmIChsb3cub3BlcmF0b3IgPT09IGVjb21wICYmIGx0Zm4odmVyc2lvbiwgbG93LnNlbXZlcikpIHtcbiAgICAgIHJldHVybiBmYWxzZVxuICAgIH1cbiAgfVxuICByZXR1cm4gdHJ1ZVxufVxuXG5tb2R1bGUuZXhwb3J0cyA9IG91dHNpZGVcbiIsICIndXNlIHN0cmljdCdcblxuLy8gRGV0ZXJtaW5lIGlmIHZlcnNpb24gaXMgZ3JlYXRlciB0aGFuIGFsbCB0aGUgdmVyc2lvbnMgcG9zc2libGUgaW4gdGhlIHJhbmdlLlxuY29uc3Qgb3V0c2lkZSA9IHJlcXVpcmUoJy4vb3V0c2lkZScpXG5jb25zdCBndHIgPSAodmVyc2lvbiwgcmFuZ2UsIG9wdGlvbnMpID0+IG91dHNpZGUodmVyc2lvbiwgcmFuZ2UsICc+Jywgb3B0aW9ucylcbm1vZHVsZS5leHBvcnRzID0gZ3RyXG4iLCAiJ3VzZSBzdHJpY3QnXG5cbmNvbnN0IG91dHNpZGUgPSByZXF1aXJlKCcuL291dHNpZGUnKVxuLy8gRGV0ZXJtaW5lIGlmIHZlcnNpb24gaXMgbGVzcyB0aGFuIGFsbCB0aGUgdmVyc2lvbnMgcG9zc2libGUgaW4gdGhlIHJhbmdlXG5jb25zdCBsdHIgPSAodmVyc2lvbiwgcmFuZ2UsIG9wdGlvbnMpID0+IG91dHNpZGUodmVyc2lvbiwgcmFuZ2UsICc8Jywgb3B0aW9ucylcbm1vZHVsZS5leHBvcnRzID0gbHRyXG4iLCAiJ3VzZSBzdHJpY3QnXG5cbmNvbnN0IFJhbmdlID0gcmVxdWlyZSgnLi4vY2xhc3Nlcy9yYW5nZScpXG5jb25zdCBpbnRlcnNlY3RzID0gKHIxLCByMiwgb3B0aW9ucykgPT4ge1xuICByMSA9IG5ldyBSYW5nZShyMSwgb3B0aW9ucylcbiAgcjIgPSBuZXcgUmFuZ2UocjIsIG9wdGlvbnMpXG4gIHJldHVybiByMS5pbnRlcnNlY3RzKHIyLCBvcHRpb25zKVxufVxubW9kdWxlLmV4cG9ydHMgPSBpbnRlcnNlY3RzXG4iLCAiJ3VzZSBzdHJpY3QnXG5cbi8vIGdpdmVuIGEgc2V0IG9mIHZlcnNpb25zIGFuZCBhIHJhbmdlLCBjcmVhdGUgYSBcInNpbXBsaWZpZWRcIiByYW5nZVxuLy8gdGhhdCBpbmNsdWRlcyB0aGUgc2FtZSB2ZXJzaW9ucyB0aGF0IHRoZSBvcmlnaW5hbCByYW5nZSBkb2VzXG4vLyBJZiB0aGUgb3JpZ2luYWwgcmFuZ2UgaXMgc2hvcnRlciB0aGFuIHRoZSBzaW1wbGlmaWVkIG9uZSwgcmV0dXJuIHRoYXQuXG5jb25zdCBzYXRpc2ZpZXMgPSByZXF1aXJlKCcuLi9mdW5jdGlvbnMvc2F0aXNmaWVzLmpzJylcbmNvbnN0IGNvbXBhcmUgPSByZXF1aXJlKCcuLi9mdW5jdGlvbnMvY29tcGFyZS5qcycpXG5tb2R1bGUuZXhwb3J0cyA9ICh2ZXJzaW9ucywgcmFuZ2UsIG9wdGlvbnMpID0+IHtcbiAgY29uc3Qgc2V0ID0gW11cbiAgbGV0IGZpcnN0ID0gbnVsbFxuICBsZXQgcHJldiA9IG51bGxcbiAgY29uc3QgdiA9IHZlcnNpb25zLnNvcnQoKGEsIGIpID0+IGNvbXBhcmUoYSwgYiwgb3B0aW9ucykpXG4gIGZvciAoY29uc3QgdmVyc2lvbiBvZiB2KSB7XG4gICAgY29uc3QgaW5jbHVkZWQgPSBzYXRpc2ZpZXModmVyc2lvbiwgcmFuZ2UsIG9wdGlvbnMpXG4gICAgaWYgKGluY2x1ZGVkKSB7XG4gICAgICBwcmV2ID0gdmVyc2lvblxuICAgICAgaWYgKCFmaXJzdCkge1xuICAgICAgICBmaXJzdCA9IHZlcnNpb25cbiAgICAgIH1cbiAgICB9IGVsc2Uge1xuICAgICAgaWYgKHByZXYpIHtcbiAgICAgICAgc2V0LnB1c2goW2ZpcnN0LCBwcmV2XSlcbiAgICAgIH1cbiAgICAgIHByZXYgPSBudWxsXG4gICAgICBmaXJzdCA9IG51bGxcbiAgICB9XG4gIH1cbiAgaWYgKGZpcnN0KSB7XG4gICAgc2V0LnB1c2goW2ZpcnN0LCBudWxsXSlcbiAgfVxuXG4gIGNvbnN0IHJhbmdlcyA9IFtdXG4gIGZvciAoY29uc3QgW21pbiwgbWF4XSBvZiBzZXQpIHtcbiAgICBpZiAobWluID09PSBtYXgpIHtcbiAgICAgIHJhbmdlcy5wdXNoKG1pbilcbiAgICB9IGVsc2UgaWYgKCFtYXggJiYgbWluID09PSB2WzBdKSB7XG4gICAgICByYW5nZXMucHVzaCgnKicpXG4gICAgfSBlbHNlIGlmICghbWF4KSB7XG4gICAgICByYW5nZXMucHVzaChgPj0ke21pbn1gKVxuICAgIH0gZWxzZSBpZiAobWluID09PSB2WzBdKSB7XG4gICAgICByYW5nZXMucHVzaChgPD0ke21heH1gKVxuICAgIH0gZWxzZSB7XG4gICAgICByYW5nZXMucHVzaChgJHttaW59IC0gJHttYXh9YClcbiAgICB9XG4gIH1cbiAgY29uc3Qgc2ltcGxpZmllZCA9IHJhbmdlcy5qb2luKCcgfHwgJylcbiAgY29uc3Qgb3JpZ2luYWwgPSB0eXBlb2YgcmFuZ2UucmF3ID09PSAnc3RyaW5nJyA/IHJhbmdlLnJhdyA6IFN0cmluZyhyYW5nZSlcbiAgcmV0dXJuIHNpbXBsaWZpZWQubGVuZ3RoIDwgb3JpZ2luYWwubGVuZ3RoID8gc2ltcGxpZmllZCA6IHJhbmdlXG59XG4iLCAiJ3VzZSBzdHJpY3QnXG5cbmNvbnN0IFJhbmdlID0gcmVxdWlyZSgnLi4vY2xhc3Nlcy9yYW5nZS5qcycpXG5jb25zdCBDb21wYXJhdG9yID0gcmVxdWlyZSgnLi4vY2xhc3Nlcy9jb21wYXJhdG9yLmpzJylcbmNvbnN0IHsgQU5ZIH0gPSBDb21wYXJhdG9yXG5jb25zdCBzYXRpc2ZpZXMgPSByZXF1aXJlKCcuLi9mdW5jdGlvbnMvc2F0aXNmaWVzLmpzJylcbmNvbnN0IGNvbXBhcmUgPSByZXF1aXJlKCcuLi9mdW5jdGlvbnMvY29tcGFyZS5qcycpXG5cbi8vIENvbXBsZXggcmFuZ2UgYHIxIHx8IHIyIHx8IC4uLmAgaXMgYSBzdWJzZXQgb2YgYFIxIHx8IFIyIHx8IC4uLmAgaWZmOlxuLy8gLSBFdmVyeSBzaW1wbGUgcmFuZ2UgYHIxLCByMiwgLi4uYCBpcyBhIG51bGwgc2V0LCBPUlxuLy8gLSBFdmVyeSBzaW1wbGUgcmFuZ2UgYHIxLCByMiwgLi4uYCB3aGljaCBpcyBub3QgYSBudWxsIHNldCBpcyBhIHN1YnNldCBvZlxuLy8gICBzb21lIGBSMSwgUjIsIC4uLmBcbi8vXG4vLyBTaW1wbGUgcmFuZ2UgYGMxIGMyIC4uLmAgaXMgYSBzdWJzZXQgb2Ygc2ltcGxlIHJhbmdlIGBDMSBDMiAuLi5gIGlmZjpcbi8vIC0gSWYgYyBpcyBvbmx5IHRoZSBBTlkgY29tcGFyYXRvclxuLy8gICAtIElmIEMgaXMgb25seSB0aGUgQU5ZIGNvbXBhcmF0b3IsIHJldHVybiB0cnVlXG4vLyAgIC0gRWxzZSBpZiBpbiBwcmVyZWxlYXNlIG1vZGUsIHJldHVybiBmYWxzZVxuLy8gICAtIGVsc2UgcmVwbGFjZSBjIHdpdGggYFs+PTAuMC4wXWBcbi8vIC0gSWYgQyBpcyBvbmx5IHRoZSBBTlkgY29tcGFyYXRvclxuLy8gICAtIGlmIGluIHByZXJlbGVhc2UgbW9kZSwgcmV0dXJuIHRydWVcbi8vICAgLSBlbHNlIHJlcGxhY2UgQyB3aXRoIGBbPj0wLjAuMF1gXG4vLyAtIExldCBFUSBiZSB0aGUgc2V0IG9mID0gY29tcGFyYXRvcnMgaW4gY1xuLy8gLSBJZiBFUSBpcyBtb3JlIHRoYW4gb25lLCByZXR1cm4gdHJ1ZSAobnVsbCBzZXQpXG4vLyAtIExldCBHVCBiZSB0aGUgaGlnaGVzdCA+IG9yID49IGNvbXBhcmF0b3IgaW4gY1xuLy8gLSBMZXQgTFQgYmUgdGhlIGxvd2VzdCA8IG9yIDw9IGNvbXBhcmF0b3IgaW4gY1xuLy8gLSBJZiBHVCBhbmQgTFQsIGFuZCBHVC5zZW12ZXIgPiBMVC5zZW12ZXIsIHJldHVybiB0cnVlIChudWxsIHNldClcbi8vIC0gSWYgYW55IEMgaXMgYSA9IHJhbmdlLCBhbmQgR1Qgb3IgTFQgYXJlIHNldCwgcmV0dXJuIGZhbHNlXG4vLyAtIElmIEVRXG4vLyAgIC0gSWYgR1QsIGFuZCBFUSBkb2VzIG5vdCBzYXRpc2Z5IEdULCByZXR1cm4gdHJ1ZSAobnVsbCBzZXQpXG4vLyAgIC0gSWYgTFQsIGFuZCBFUSBkb2VzIG5vdCBzYXRpc2Z5IExULCByZXR1cm4gdHJ1ZSAobnVsbCBzZXQpXG4vLyAgIC0gSWYgRVEgc2F0aXNmaWVzIGV2ZXJ5IEMsIHJldHVybiB0cnVlXG4vLyAgIC0gRWxzZSByZXR1cm4gZmFsc2Vcbi8vIC0gSWYgR1Rcbi8vICAgLSBJZiBHVC5zZW12ZXIgaXMgbG93ZXIgdGhhbiBhbnkgPiBvciA+PSBjb21wIGluIEMsIHJldHVybiBmYWxzZVxuLy8gICAtIElmIEdUIGlzID49LCBhbmQgR1Quc2VtdmVyIGRvZXMgbm90IHNhdGlzZnkgZXZlcnkgQywgcmV0dXJuIGZhbHNlXG4vLyAgIC0gSWYgR1Quc2VtdmVyIGhhcyBhIHByZXJlbGVhc2UsIGFuZCBub3QgaW4gcHJlcmVsZWFzZSBtb2RlXG4vLyAgICAgLSBJZiBubyBDIGhhcyBhIHByZXJlbGVhc2UgYW5kIHRoZSBHVC5zZW12ZXIgdHVwbGUsIHJldHVybiBmYWxzZVxuLy8gLSBJZiBMVFxuLy8gICAtIElmIExULnNlbXZlciBpcyBncmVhdGVyIHRoYW4gYW55IDwgb3IgPD0gY29tcCBpbiBDLCByZXR1cm4gZmFsc2Vcbi8vICAgLSBJZiBMVCBpcyA8PSwgYW5kIExULnNlbXZlciBkb2VzIG5vdCBzYXRpc2Z5IGV2ZXJ5IEMsIHJldHVybiBmYWxzZVxuLy8gICAtIElmIExULnNlbXZlciBoYXMgYSBwcmVyZWxlYXNlLCBhbmQgbm90IGluIHByZXJlbGVhc2UgbW9kZVxuLy8gICAgIC0gSWYgbm8gQyBoYXMgYSBwcmVyZWxlYXNlIGFuZCB0aGUgTFQuc2VtdmVyIHR1cGxlLCByZXR1cm4gZmFsc2Vcbi8vIC0gRWxzZSByZXR1cm4gdHJ1ZVxuXG5jb25zdCBzdWJzZXQgPSAoc3ViLCBkb20sIG9wdGlvbnMgPSB7fSkgPT4ge1xuICBpZiAoc3ViID09PSBkb20pIHtcbiAgICByZXR1cm4gdHJ1ZVxuICB9XG5cbiAgc3ViID0gbmV3IFJhbmdlKHN1Yiwgb3B0aW9ucylcbiAgZG9tID0gbmV3IFJhbmdlKGRvbSwgb3B0aW9ucylcbiAgbGV0IHNhd05vbk51bGwgPSBmYWxzZVxuXG4gIE9VVEVSOiBmb3IgKGNvbnN0IHNpbXBsZVN1YiBvZiBzdWIuc2V0KSB7XG4gICAgZm9yIChjb25zdCBzaW1wbGVEb20gb2YgZG9tLnNldCkge1xuICAgICAgY29uc3QgaXNTdWIgPSBzaW1wbGVTdWJzZXQoc2ltcGxlU3ViLCBzaW1wbGVEb20sIG9wdGlvbnMpXG4gICAgICBzYXdOb25OdWxsID0gc2F3Tm9uTnVsbCB8fCBpc1N1YiAhPT0gbnVsbFxuICAgICAgaWYgKGlzU3ViKSB7XG4gICAgICAgIGNvbnRpbnVlIE9VVEVSXG4gICAgICB9XG4gICAgfVxuICAgIC8vIHRoZSBudWxsIHNldCBpcyBhIHN1YnNldCBvZiBldmVyeXRoaW5nLCBidXQgbnVsbCBzaW1wbGUgcmFuZ2VzIGluXG4gICAgLy8gYSBjb21wbGV4IHJhbmdlIHNob3VsZCBiZSBpZ25vcmVkLiAgc28gaWYgd2Ugc2F3IGEgbm9uLW51bGwgcmFuZ2UsXG4gICAgLy8gdGhlbiB3ZSBrbm93IHRoaXMgaXNuJ3QgYSBzdWJzZXQsIGJ1dCBpZiBFVkVSWSBzaW1wbGUgcmFuZ2Ugd2FzIG51bGwsXG4gICAgLy8gdGhlbiBpdCBpcyBhIHN1YnNldC5cbiAgICBpZiAoc2F3Tm9uTnVsbCkge1xuICAgICAgcmV0dXJuIGZhbHNlXG4gICAgfVxuICB9XG4gIHJldHVybiB0cnVlXG59XG5cbmNvbnN0IG1pbmltdW1WZXJzaW9uV2l0aFByZVJlbGVhc2UgPSBbbmV3IENvbXBhcmF0b3IoJz49MC4wLjAtMCcpXVxuY29uc3QgbWluaW11bVZlcnNpb24gPSBbbmV3IENvbXBhcmF0b3IoJz49MC4wLjAnKV1cblxuY29uc3Qgc2ltcGxlU3Vic2V0ID0gKHN1YiwgZG9tLCBvcHRpb25zKSA9PiB7XG4gIGlmIChzdWIgPT09IGRvbSkge1xuICAgIHJldHVybiB0cnVlXG4gIH1cblxuICBpZiAoc3ViLmxlbmd0aCA9PT0gMSAmJiBzdWJbMF0uc2VtdmVyID09PSBBTlkpIHtcbiAgICBpZiAoZG9tLmxlbmd0aCA9PT0gMSAmJiBkb21bMF0uc2VtdmVyID09PSBBTlkpIHtcbiAgICAgIHJldHVybiB0cnVlXG4gICAgfSBlbHNlIGlmIChvcHRpb25zLmluY2x1ZGVQcmVyZWxlYXNlKSB7XG4gICAgICBzdWIgPSBtaW5pbXVtVmVyc2lvbldpdGhQcmVSZWxlYXNlXG4gICAgfSBlbHNlIHtcbiAgICAgIHN1YiA9IG1pbmltdW1WZXJzaW9uXG4gICAgfVxuICB9XG5cbiAgaWYgKGRvbS5sZW5ndGggPT09IDEgJiYgZG9tWzBdLnNlbXZlciA9PT0gQU5ZKSB7XG4gICAgaWYgKG9wdGlvbnMuaW5jbHVkZVByZXJlbGVhc2UpIHtcbiAgICAgIHJldHVybiB0cnVlXG4gICAgfSBlbHNlIHtcbiAgICAgIGRvbSA9IG1pbmltdW1WZXJzaW9uXG4gICAgfVxuICB9XG5cbiAgY29uc3QgZXFTZXQgPSBuZXcgU2V0KClcbiAgbGV0IGd0LCBsdFxuICBmb3IgKGNvbnN0IGMgb2Ygc3ViKSB7XG4gICAgaWYgKGMub3BlcmF0b3IgPT09ICc+JyB8fCBjLm9wZXJhdG9yID09PSAnPj0nKSB7XG4gICAgICBndCA9IGhpZ2hlckdUKGd0LCBjLCBvcHRpb25zKVxuICAgIH0gZWxzZSBpZiAoYy5vcGVyYXRvciA9PT0gJzwnIHx8IGMub3BlcmF0b3IgPT09ICc8PScpIHtcbiAgICAgIGx0ID0gbG93ZXJMVChsdCwgYywgb3B0aW9ucylcbiAgICB9IGVsc2Uge1xuICAgICAgZXFTZXQuYWRkKGMuc2VtdmVyKVxuICAgIH1cbiAgfVxuXG4gIGlmIChlcVNldC5zaXplID4gMSkge1xuICAgIHJldHVybiBudWxsXG4gIH1cblxuICBsZXQgZ3RsdENvbXBcbiAgaWYgKGd0ICYmIGx0KSB7XG4gICAgZ3RsdENvbXAgPSBjb21wYXJlKGd0LnNlbXZlciwgbHQuc2VtdmVyLCBvcHRpb25zKVxuICAgIGlmIChndGx0Q29tcCA+IDApIHtcbiAgICAgIHJldHVybiBudWxsXG4gICAgfSBlbHNlIGlmIChndGx0Q29tcCA9PT0gMCAmJiAoZ3Qub3BlcmF0b3IgIT09ICc+PScgfHwgbHQub3BlcmF0b3IgIT09ICc8PScpKSB7XG4gICAgICByZXR1cm4gbnVsbFxuICAgIH1cbiAgfVxuXG4gIC8vIHdpbGwgaXRlcmF0ZSBvbmUgb3IgemVybyB0aW1lc1xuICBmb3IgKGNvbnN0IGVxIG9mIGVxU2V0KSB7XG4gICAgaWYgKGd0ICYmICFzYXRpc2ZpZXMoZXEsIFN0cmluZyhndCksIG9wdGlvbnMpKSB7XG4gICAgICByZXR1cm4gbnVsbFxuICAgIH1cblxuICAgIGlmIChsdCAmJiAhc2F0aXNmaWVzKGVxLCBTdHJpbmcobHQpLCBvcHRpb25zKSkge1xuICAgICAgcmV0dXJuIG51bGxcbiAgICB9XG5cbiAgICBmb3IgKGNvbnN0IGMgb2YgZG9tKSB7XG4gICAgICBpZiAoIXNhdGlzZmllcyhlcSwgU3RyaW5nKGMpLCBvcHRpb25zKSkge1xuICAgICAgICByZXR1cm4gZmFsc2VcbiAgICAgIH1cbiAgICB9XG5cbiAgICByZXR1cm4gdHJ1ZVxuICB9XG5cbiAgbGV0IGhpZ2hlciwgbG93ZXJcbiAgbGV0IGhhc0RvbUxULCBoYXNEb21HVFxuICAvLyBpZiB0aGUgc3Vic2V0IGhhcyBhIHByZXJlbGVhc2UsIHdlIG5lZWQgYSBjb21wYXJhdG9yIGluIHRoZSBzdXBlcnNldFxuICAvLyB3aXRoIHRoZSBzYW1lIHR1cGxlIGFuZCBhIHByZXJlbGVhc2UsIG9yIGl0J3Mgbm90IGEgc3Vic2V0XG4gIGxldCBuZWVkRG9tTFRQcmUgPSBsdCAmJlxuICAgICFvcHRpb25zLmluY2x1ZGVQcmVyZWxlYXNlICYmXG4gICAgbHQuc2VtdmVyLnByZXJlbGVhc2UubGVuZ3RoID8gbHQuc2VtdmVyIDogZmFsc2VcbiAgbGV0IG5lZWREb21HVFByZSA9IGd0ICYmXG4gICAgIW9wdGlvbnMuaW5jbHVkZVByZXJlbGVhc2UgJiZcbiAgICBndC5zZW12ZXIucHJlcmVsZWFzZS5sZW5ndGggPyBndC5zZW12ZXIgOiBmYWxzZVxuICAvLyBleGNlcHRpb246IDwxLjIuMy0wIGlzIHRoZSBzYW1lIGFzIDwxLjIuM1xuICBpZiAobmVlZERvbUxUUHJlICYmIG5lZWREb21MVFByZS5wcmVyZWxlYXNlLmxlbmd0aCA9PT0gMSAmJlxuICAgICAgbHQub3BlcmF0b3IgPT09ICc8JyAmJiBuZWVkRG9tTFRQcmUucHJlcmVsZWFzZVswXSA9PT0gMCkge1xuICAgIG5lZWREb21MVFByZSA9IGZhbHNlXG4gIH1cblxuICBmb3IgKGNvbnN0IGMgb2YgZG9tKSB7XG4gICAgaGFzRG9tR1QgPSBoYXNEb21HVCB8fCBjLm9wZXJhdG9yID09PSAnPicgfHwgYy5vcGVyYXRvciA9PT0gJz49J1xuICAgIGhhc0RvbUxUID0gaGFzRG9tTFQgfHwgYy5vcGVyYXRvciA9PT0gJzwnIHx8IGMub3BlcmF0b3IgPT09ICc8PSdcbiAgICBpZiAoZ3QpIHtcbiAgICAgIGlmIChuZWVkRG9tR1RQcmUpIHtcbiAgICAgICAgaWYgKGMuc2VtdmVyLnByZXJlbGVhc2UgJiYgYy5zZW12ZXIucHJlcmVsZWFzZS5sZW5ndGggJiZcbiAgICAgICAgICAgIGMuc2VtdmVyLm1ham9yID09PSBuZWVkRG9tR1RQcmUubWFqb3IgJiZcbiAgICAgICAgICAgIGMuc2VtdmVyLm1pbm9yID09PSBuZWVkRG9tR1RQcmUubWlub3IgJiZcbiAgICAgICAgICAgIGMuc2VtdmVyLnBhdGNoID09PSBuZWVkRG9tR1RQcmUucGF0Y2gpIHtcbiAgICAgICAgICBuZWVkRG9tR1RQcmUgPSBmYWxzZVxuICAgICAgICB9XG4gICAgICB9XG4gICAgICBpZiAoYy5vcGVyYXRvciA9PT0gJz4nIHx8IGMub3BlcmF0b3IgPT09ICc+PScpIHtcbiAgICAgICAgaGlnaGVyID0gaGlnaGVyR1QoZ3QsIGMsIG9wdGlvbnMpXG4gICAgICAgIGlmIChoaWdoZXIgPT09IGMgJiYgaGlnaGVyICE9PSBndCkge1xuICAgICAgICAgIHJldHVybiBmYWxzZVxuICAgICAgICB9XG4gICAgICB9IGVsc2UgaWYgKGd0Lm9wZXJhdG9yID09PSAnPj0nICYmICFjLnRlc3QoZ3Quc2VtdmVyKSkge1xuICAgICAgICByZXR1cm4gZmFsc2VcbiAgICAgIH1cbiAgICB9XG4gICAgaWYgKGx0KSB7XG4gICAgICBpZiAobmVlZERvbUxUUHJlKSB7XG4gICAgICAgIGlmIChjLnNlbXZlci5wcmVyZWxlYXNlICYmIGMuc2VtdmVyLnByZXJlbGVhc2UubGVuZ3RoICYmXG4gICAgICAgICAgICBjLnNlbXZlci5tYWpvciA9PT0gbmVlZERvbUxUUHJlLm1ham9yICYmXG4gICAgICAgICAgICBjLnNlbXZlci5taW5vciA9PT0gbmVlZERvbUxUUHJlLm1pbm9yICYmXG4gICAgICAgICAgICBjLnNlbXZlci5wYXRjaCA9PT0gbmVlZERvbUxUUHJlLnBhdGNoKSB7XG4gICAgICAgICAgbmVlZERvbUxUUHJlID0gZmFsc2VcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgaWYgKGMub3BlcmF0b3IgPT09ICc8JyB8fCBjLm9wZXJhdG9yID09PSAnPD0nKSB7XG4gICAgICAgIGxvd2VyID0gbG93ZXJMVChsdCwgYywgb3B0aW9ucylcbiAgICAgICAgaWYgKGxvd2VyID09PSBjICYmIGxvd2VyICE9PSBsdCkge1xuICAgICAgICAgIHJldHVybiBmYWxzZVxuICAgICAgICB9XG4gICAgICB9IGVsc2UgaWYgKGx0Lm9wZXJhdG9yID09PSAnPD0nICYmICFjLnRlc3QobHQuc2VtdmVyKSkge1xuICAgICAgICByZXR1cm4gZmFsc2VcbiAgICAgIH1cbiAgICB9XG4gICAgaWYgKCFjLm9wZXJhdG9yICYmIChsdCB8fCBndCkgJiYgZ3RsdENvbXAgIT09IDApIHtcbiAgICAgIHJldHVybiBmYWxzZVxuICAgIH1cbiAgfVxuXG4gIC8vIGlmIHRoZXJlIHdhcyBhIDwgb3IgPiwgYW5kIG5vdGhpbmcgaW4gdGhlIGRvbSwgdGhlbiBtdXN0IGJlIGZhbHNlXG4gIC8vIFVOTEVTUyBpdCB3YXMgbGltaXRlZCBieSBhbm90aGVyIHJhbmdlIGluIHRoZSBvdGhlciBkaXJlY3Rpb24uXG4gIC8vIEVnLCA+MS4wLjAgPDEuMC4xIGlzIHN0aWxsIGEgc3Vic2V0IG9mIDwyLjAuMFxuICBpZiAoZ3QgJiYgaGFzRG9tTFQgJiYgIWx0ICYmIGd0bHRDb21wICE9PSAwKSB7XG4gICAgcmV0dXJuIGZhbHNlXG4gIH1cblxuICBpZiAobHQgJiYgaGFzRG9tR1QgJiYgIWd0ICYmIGd0bHRDb21wICE9PSAwKSB7XG4gICAgcmV0dXJuIGZhbHNlXG4gIH1cblxuICAvLyB3ZSBuZWVkZWQgYSBwcmVyZWxlYXNlIHJhbmdlIGluIGEgc3BlY2lmaWMgdHVwbGUsIGJ1dCBkaWRuJ3QgZ2V0IG9uZVxuICAvLyB0aGVuIHRoaXMgaXNuJ3QgYSBzdWJzZXQuICBlZyA+PTEuMi4zLXByZSBpcyBub3QgYSBzdWJzZXQgb2YgPj0xLjAuMCxcbiAgLy8gYmVjYXVzZSBpdCBpbmNsdWRlcyBwcmVyZWxlYXNlcyBpbiB0aGUgMS4yLjMgdHVwbGVcbiAgaWYgKG5lZWREb21HVFByZSB8fCBuZWVkRG9tTFRQcmUpIHtcbiAgICByZXR1cm4gZmFsc2VcbiAgfVxuXG4gIHJldHVybiB0cnVlXG59XG5cbi8vID49MS4yLjMgaXMgbG93ZXIgdGhhbiA+MS4yLjNcbmNvbnN0IGhpZ2hlckdUID0gKGEsIGIsIG9wdGlvbnMpID0+IHtcbiAgaWYgKCFhKSB7XG4gICAgcmV0dXJuIGJcbiAgfVxuICBjb25zdCBjb21wID0gY29tcGFyZShhLnNlbXZlciwgYi5zZW12ZXIsIG9wdGlvbnMpXG4gIHJldHVybiBjb21wID4gMCA/IGFcbiAgICA6IGNvbXAgPCAwID8gYlxuICAgIDogYi5vcGVyYXRvciA9PT0gJz4nICYmIGEub3BlcmF0b3IgPT09ICc+PScgPyBiXG4gICAgOiBhXG59XG5cbi8vIDw9MS4yLjMgaXMgaGlnaGVyIHRoYW4gPDEuMi4zXG5jb25zdCBsb3dlckxUID0gKGEsIGIsIG9wdGlvbnMpID0+IHtcbiAgaWYgKCFhKSB7XG4gICAgcmV0dXJuIGJcbiAgfVxuICBjb25zdCBjb21wID0gY29tcGFyZShhLnNlbXZlciwgYi5zZW12ZXIsIG9wdGlvbnMpXG4gIHJldHVybiBjb21wIDwgMCA/IGFcbiAgICA6IGNvbXAgPiAwID8gYlxuICAgIDogYi5vcGVyYXRvciA9PT0gJzwnICYmIGEub3BlcmF0b3IgPT09ICc8PScgPyBiXG4gICAgOiBhXG59XG5cbm1vZHVsZS5leHBvcnRzID0gc3Vic2V0XG4iLCAiJ3VzZSBzdHJpY3QnXG5cbi8vIGp1c3QgcHJlLWxvYWQgYWxsIHRoZSBzdHVmZiB0aGF0IGluZGV4LmpzIGxhemlseSBleHBvcnRzXG5jb25zdCBpbnRlcm5hbFJlID0gcmVxdWlyZSgnLi9pbnRlcm5hbC9yZScpXG5jb25zdCBjb25zdGFudHMgPSByZXF1aXJlKCcuL2ludGVybmFsL2NvbnN0YW50cycpXG5jb25zdCBTZW1WZXIgPSByZXF1aXJlKCcuL2NsYXNzZXMvc2VtdmVyJylcbmNvbnN0IGlkZW50aWZpZXJzID0gcmVxdWlyZSgnLi9pbnRlcm5hbC9pZGVudGlmaWVycycpXG5jb25zdCBwYXJzZSA9IHJlcXVpcmUoJy4vZnVuY3Rpb25zL3BhcnNlJylcbmNvbnN0IHZhbGlkID0gcmVxdWlyZSgnLi9mdW5jdGlvbnMvdmFsaWQnKVxuY29uc3QgY2xlYW4gPSByZXF1aXJlKCcuL2Z1bmN0aW9ucy9jbGVhbicpXG5jb25zdCBpbmMgPSByZXF1aXJlKCcuL2Z1bmN0aW9ucy9pbmMnKVxuY29uc3QgZGlmZiA9IHJlcXVpcmUoJy4vZnVuY3Rpb25zL2RpZmYnKVxuY29uc3QgbWFqb3IgPSByZXF1aXJlKCcuL2Z1bmN0aW9ucy9tYWpvcicpXG5jb25zdCBtaW5vciA9IHJlcXVpcmUoJy4vZnVuY3Rpb25zL21pbm9yJylcbmNvbnN0IHBhdGNoID0gcmVxdWlyZSgnLi9mdW5jdGlvbnMvcGF0Y2gnKVxuY29uc3QgcHJlcmVsZWFzZSA9IHJlcXVpcmUoJy4vZnVuY3Rpb25zL3ByZXJlbGVhc2UnKVxuY29uc3QgY29tcGFyZSA9IHJlcXVpcmUoJy4vZnVuY3Rpb25zL2NvbXBhcmUnKVxuY29uc3QgcmNvbXBhcmUgPSByZXF1aXJlKCcuL2Z1bmN0aW9ucy9yY29tcGFyZScpXG5jb25zdCBjb21wYXJlTG9vc2UgPSByZXF1aXJlKCcuL2Z1bmN0aW9ucy9jb21wYXJlLWxvb3NlJylcbmNvbnN0IGNvbXBhcmVCdWlsZCA9IHJlcXVpcmUoJy4vZnVuY3Rpb25zL2NvbXBhcmUtYnVpbGQnKVxuY29uc3Qgc29ydCA9IHJlcXVpcmUoJy4vZnVuY3Rpb25zL3NvcnQnKVxuY29uc3QgcnNvcnQgPSByZXF1aXJlKCcuL2Z1bmN0aW9ucy9yc29ydCcpXG5jb25zdCBndCA9IHJlcXVpcmUoJy4vZnVuY3Rpb25zL2d0JylcbmNvbnN0IGx0ID0gcmVxdWlyZSgnLi9mdW5jdGlvbnMvbHQnKVxuY29uc3QgZXEgPSByZXF1aXJlKCcuL2Z1bmN0aW9ucy9lcScpXG5jb25zdCBuZXEgPSByZXF1aXJlKCcuL2Z1bmN0aW9ucy9uZXEnKVxuY29uc3QgZ3RlID0gcmVxdWlyZSgnLi9mdW5jdGlvbnMvZ3RlJylcbmNvbnN0IGx0ZSA9IHJlcXVpcmUoJy4vZnVuY3Rpb25zL2x0ZScpXG5jb25zdCBjbXAgPSByZXF1aXJlKCcuL2Z1bmN0aW9ucy9jbXAnKVxuY29uc3QgY29lcmNlID0gcmVxdWlyZSgnLi9mdW5jdGlvbnMvY29lcmNlJylcbmNvbnN0IHRydW5jYXRlID0gcmVxdWlyZSgnLi9mdW5jdGlvbnMvdHJ1bmNhdGUnKVxuY29uc3QgQ29tcGFyYXRvciA9IHJlcXVpcmUoJy4vY2xhc3Nlcy9jb21wYXJhdG9yJylcbmNvbnN0IFJhbmdlID0gcmVxdWlyZSgnLi9jbGFzc2VzL3JhbmdlJylcbmNvbnN0IHNhdGlzZmllcyA9IHJlcXVpcmUoJy4vZnVuY3Rpb25zL3NhdGlzZmllcycpXG5jb25zdCB0b0NvbXBhcmF0b3JzID0gcmVxdWlyZSgnLi9yYW5nZXMvdG8tY29tcGFyYXRvcnMnKVxuY29uc3QgbWF4U2F0aXNmeWluZyA9IHJlcXVpcmUoJy4vcmFuZ2VzL21heC1zYXRpc2Z5aW5nJylcbmNvbnN0IG1pblNhdGlzZnlpbmcgPSByZXF1aXJlKCcuL3Jhbmdlcy9taW4tc2F0aXNmeWluZycpXG5jb25zdCBtaW5WZXJzaW9uID0gcmVxdWlyZSgnLi9yYW5nZXMvbWluLXZlcnNpb24nKVxuY29uc3QgdmFsaWRSYW5nZSA9IHJlcXVpcmUoJy4vcmFuZ2VzL3ZhbGlkJylcbmNvbnN0IG91dHNpZGUgPSByZXF1aXJlKCcuL3Jhbmdlcy9vdXRzaWRlJylcbmNvbnN0IGd0ciA9IHJlcXVpcmUoJy4vcmFuZ2VzL2d0cicpXG5jb25zdCBsdHIgPSByZXF1aXJlKCcuL3Jhbmdlcy9sdHInKVxuY29uc3QgaW50ZXJzZWN0cyA9IHJlcXVpcmUoJy4vcmFuZ2VzL2ludGVyc2VjdHMnKVxuY29uc3Qgc2ltcGxpZnlSYW5nZSA9IHJlcXVpcmUoJy4vcmFuZ2VzL3NpbXBsaWZ5JylcbmNvbnN0IHN1YnNldCA9IHJlcXVpcmUoJy4vcmFuZ2VzL3N1YnNldCcpXG5tb2R1bGUuZXhwb3J0cyA9IHtcbiAgcGFyc2UsXG4gIHZhbGlkLFxuICBjbGVhbixcbiAgaW5jLFxuICBkaWZmLFxuICBtYWpvcixcbiAgbWlub3IsXG4gIHBhdGNoLFxuICBwcmVyZWxlYXNlLFxuICBjb21wYXJlLFxuICByY29tcGFyZSxcbiAgY29tcGFyZUxvb3NlLFxuICBjb21wYXJlQnVpbGQsXG4gIHNvcnQsXG4gIHJzb3J0LFxuICBndCxcbiAgbHQsXG4gIGVxLFxuICBuZXEsXG4gIGd0ZSxcbiAgbHRlLFxuICBjbXAsXG4gIGNvZXJjZSxcbiAgdHJ1bmNhdGUsXG4gIENvbXBhcmF0b3IsXG4gIFJhbmdlLFxuICBzYXRpc2ZpZXMsXG4gIHRvQ29tcGFyYXRvcnMsXG4gIG1heFNhdGlzZnlpbmcsXG4gIG1pblNhdGlzZnlpbmcsXG4gIG1pblZlcnNpb24sXG4gIHZhbGlkUmFuZ2UsXG4gIG91dHNpZGUsXG4gIGd0cixcbiAgbHRyLFxuICBpbnRlcnNlY3RzLFxuICBzaW1wbGlmeVJhbmdlLFxuICBzdWJzZXQsXG4gIFNlbVZlcixcbiAgcmU6IGludGVybmFsUmUucmUsXG4gIHNyYzogaW50ZXJuYWxSZS5zcmMsXG4gIHRva2VuczogaW50ZXJuYWxSZS50LFxuICBTRU1WRVJfU1BFQ19WRVJTSU9OOiBjb25zdGFudHMuU0VNVkVSX1NQRUNfVkVSU0lPTixcbiAgUkVMRUFTRV9UWVBFUzogY29uc3RhbnRzLlJFTEVBU0VfVFlQRVMsXG4gIGNvbXBhcmVJZGVudGlmaWVyczogaWRlbnRpZmllcnMuY29tcGFyZUlkZW50aWZpZXJzLFxuICByY29tcGFyZUlkZW50aWZpZXJzOiBpZGVudGlmaWVycy5yY29tcGFyZUlkZW50aWZpZXJzLFxufVxuIiwgIi8qKlxuICogV0JCdXMgXHUyMDE0IFx1OEZEQlx1N0EwQlx1N0VBN1x1NEU4Qlx1NEVGNlx1NjAzQlx1N0VCRlx1RkYwOGluZnJhIFx1NTdGQVx1NUVGQVx1RkYwOVx1MzAwMlxuICpcbiAqIFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFxuICogXHU4QkJFXHU4QkExXHU2NUI5XHU2ODQ4XG4gKiBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcbiAqXG4gKiAxLiBcdTVCOUFcdTRGNERcdTRFMEVcdTgwNENcdThEMjNcdThGQjlcdTc1NENcbiAqICAgIFx1N0VBRlx1N0NCOVx1NzY4NCBpbmZyYSBcdTU3RkFcdTVFRkFcdTIwMTRcdTIwMTRcdTUzRUFcdTYzRDBcdTRGOUIgcHViL3N1YiBcdTUzOUZcdThCRURcdUZGMENcdTRFMERcdTYxMUZcdTc3RTVcdTRFRkJcdTRGNTVcdTRFMUFcdTUyQTFcdThCRURcdTRFNDlcdTMwMDJcbiAqICAgIFx1OTZGNlx1Njg0Nlx1NjdCNlx1NEY5RFx1OEQ1Nlx1RkYwQ1x1NkQ0Rlx1ODlDOFx1NTY2OCAvIE5vZGUgLyBcdTVDMEZcdTdBMEJcdTVFOEZcdTkwMUFcdTc1MjhcdTMwMDJcbiAqICAgIFx1NEUwQVx1NUM0Mlx1RkYwOFNES1x1MzAwMWRvbWFpblx1MzAwMVVJXHVGRjA5XHU1NzQ3XHU0RTNBXHU2RDg4XHU4RDM5XHU4MDA1XHVGRjBDYnVzIFx1NjcyQ1x1OEVBQlx1NEUwRFx1NTE3M1x1NUZDM1x1OEMwMVx1NTcyOFx1NzUyOFx1MzAwMlxuICpcbiAqIDIuIFx1NjgzOFx1NUZDM1x1OEJCRVx1OEJBMVx1NTFCM1x1N0I1NlxuICogICAgLSBNYXA8c3RyaW5nLCBTZXQ8SGFuZGxlcj4+IFx1NUI1OFx1NTBBOFx1N0NCRVx1Nzg2RVx1OEJBMlx1OTYwNVxuICogICAgLSBTZXQ8V2lsZGNhcmRIYW5kbGVyPiBcdTVCNThcdTUwQThcdTUxNjhcdTkxQ0ZcdThCQTJcdTk2MDVcdUZGMDhvbkFueVx1RkYwOVxuICogICAgLSBlbWl0IFx1OTA0RFx1NTM4Nlx1NjVGNiBzcHJlYWQgY29weVx1RkYwOFsuLi5zZXRdXHVGRjA5XHVGRjBDXHU5MDdGXHU1MTREXHU1NkRFXHU4QzAzXHU0RTJEIGFkZC9kZWxldGUgXHU1QkZDXHU4MUY0XHU4RkVEXHU0RUUzXHU1RjAyXHU1RTM4XG4gKiAgICAtIFx1NjVFMFx1NUYwMlx1NkI2NVx1OTYxRlx1NTIxN1x1MzAwMVx1NjVFMFx1NEYxOFx1NTE0OFx1N0VBN1x1MjAxNFx1MjAxNFx1NTQwQ1x1NkI2NVx1NTkxQVx1NjRBRFx1RkYwQ0tJU1NcbiAqXG4gKiAzLiBcdTc1MUZcdTU0N0RcdTU0NjhcdTY3MUZcbiAqICAgIC0gXHU5MDFBXHU4RkM3IGBnZXRCdXMoKWAgXHU4M0I3XHU1M0Q2XHU4RkRCXHU3QTBCXHU3RUE3XHU1NTJGXHU0RTAwXHU1MzU1XHU0RjhCXHVGRjA4XHU1REU1XHU1MzgyIGNyZWF0ZVh4eCBcdTVERjJcdTRFMEJcdTdFQkZcdUZGMDlcbiAqICAgIC0gXHU5MDFBXHU4RkM3IGBSdW50aW1lQ29udGV4dC5idXNgIFx1NkNFOFx1NTE2NVx1N0VEOVx1NjI0MFx1NjcwOSBkb21haW4gLyBzZXJ2aWNlXG4gKiAgICAtIFx1NEUwQVx1NUM0Mlx1NTNFRlx1NUMwNlx1NTQwQ1x1NEUwMFx1NUI5RVx1NEY4Qlx1NjZCNFx1OTczMlx1N0VEOSBTREtcdUZGMDhgd2Iub24vb2ZmYFx1RkYwOVx1NjIxNiBhZGFwdGVyXG4gKiAgICAtIFx1OEZEQlx1N0EwQlx1OTAwMFx1NTFGQSAvIFx1NzBFRFx1OTFDRFx1OEY3RFx1NjVGNlx1NTNFRlx1OEMwM1x1NzUyOCBgYnVzLmNsZWFyKClgIFx1OTFDQVx1NjUzRVx1NTE2OFx1OTBFOFx1OEJBMlx1OTYwNVx1RkYwOFx1NzUxRlx1NEVBN1x1Njc4MVx1NUMxMVx1NzUyOFx1RkYwOVxuICpcbiAqIDQuIFx1OERFOFx1OEZEQlx1N0EwQlx1Njg2NVx1NjNBNVx1RkYwOGJ1cyBcdTRFMERcdTdCQTFcdUZGMENcdTc1MzFcdTVCQkZcdTRFM0JcdTgxRUFcdTg4NENcdTY0MkRcdTY4NjVcdUZGMDlcbiAqICAgIGJ1cyBcdTUzRUFcdTUwNUFcdThGREJcdTdBMEJcdTUxODVcdTU5MUFcdTY0QURcdTMwMDJcdThERThcdThGREJcdTdBMEJcdTY2MkZcdTVCQkZcdTRFM0JcdTc2ODRcdThEMjNcdTRFRkJcdUZGMENcdTUxNzhcdTU3OEJcdTUwNUFcdTZDRDVcdUZGMUFcbiAqICAgIC0gXHU0RTNCXHU4RkRCXHU3QTBCXHVGRjFBYnVzLm9uQW55IFx1MjE5MiBJUEMgc2VuZCBcdTdFRDkgcmVuZGVyZXJcbiAqICAgIC0gUmVuZGVyZXJcdUZGMUFJUEMgcmVjZWl2ZSBcdTIxOTIgYnVzLmVtaXRcbiAqICAgIC0gV2ViXHVGRjFBXHU1MzU1XHU4RkRCXHU3QTBCXHVGRjBDXHU2NUUwXHU5NzAwXHU2ODY1XHU2M0E1XG4gKiAgICBidXMgXHU2NzJDXHU4RUFCXHU1QkY5IElQQyBcdTk2RjZcdTgwMjZcdTU0MDhcdTMwMDJcbiAqXG4gKiA1LiBcdTRFOEJcdTRFRjZcdTU0N0RcdTU0MERcdTdFQTZcdTVCOUFcdUZGMDhcdTYzQThcdTgzNTBcdUZGMENcdTk3NUUgYnVzIFx1NUYzQVx1NTIzNlx1RkYwOVxuICogICAgYDxuYW1lc3BhY2U+LjxyZXNvdXJjZT4uPGFjdGlvbj5gXG4gKiAgICAtIFx1NzJCNlx1NjAwMVx1NTNEOFx1NjZGNFx1RkYxQWBza2lsbHMubGlzdC5jaGFuZ2VkYFxuICogICAgLSBcdTUyQThcdTRGNUNcdUZGMUFgY29udmVyc2F0aW9ucy5tZXNzYWdlLnJlY2VpdmVkYFxuICogICAgRXZlbnRQcm9kdWNlclx1RkYwOFx1ODlDMSBldmVudC1wcm9kdWNlci50c1x1RkYwOVx1OEQxRlx1OEQyM1x1ODFFQVx1NTJBOFx1NjJGQ1x1NjNBNSBuYW1lc3BhY2UgXHU1MjREXHU3RjAwXHVGRjBDXG4gKiAgICBcdThCQTkgZG9tYWluIFx1NEVFM1x1NzgwMVx1NTNFQVx1NTE3M1x1NUZDMyBgZW1pdCgnY2hhbmdlZCcsIGRhdGEpYFx1MzAwMlxuICpcbiAqIDYuIFx1OTUxOVx1OEJFRlx1OTY5NFx1NzlCQlxuICogICAgXHU1MzU1XHU0RTJBIGhhbmRsZXIgXHU2MjlCXHU1RjAyXHU1RTM4XHU0RTBEXHU1RjcxXHU1NENEXHU1MTc2XHU0RUQ2XHU4QkEyXHU5NjA1XHU4MDA1XHUzMDAyXG4gKiAgICBlbWl0IFx1NkMzOFx1OEZEQ1x1NEUwRFx1NEYxQVx1NTQxMVx1OEMwM1x1NzUyOFx1NjVCOVx1NjI5Qlx1NTFGQVx1RkYwQ1x1NEZERFx1OEJDMSBkb21haW4gXHU1M0QxXHU1RTAzXHU0RThCXHU0RUY2XHU2NjJGXCJcdTVDMDRcdTU0MEVcdTRFMERcdTdCQTFcIlx1MzAwMlxuICpcbiAqIDcuIFx1NTE4NVx1NUI1OFx1NUI4OVx1NTE2OFxuICogICAgLSBvbigpIFx1OEZENFx1NTZERSBVbnN1YnNjcmliZSBcdTUxRkRcdTY1NzBcdUZGMENcdTdFQzRcdTRFRjYvc2VydmljZSBcdTk1MDBcdTZCQzFcdTY1RjZcdTVGQzVcdTk4N0JcdThDMDNcdTc1MjhcbiAqICAgIC0gaGFuZGxlciBTZXQgXHU0RTNBXHU3QTdBXHU2NUY2XHU4MUVBXHU1MkE4XHU0RUNFIE1hcCBcdTRFMkRcdTUyMjBcdTk2NjQga2V5XHVGRjBDXHU2NUUwXHU2Q0M0XHU2RjBGXG4gKiAgICAtIGNsZWFyKGV2ZW50PykgXHU2NTJGXHU2MzAxXHU1MzU1XHU0RThCXHU0RUY2XHU2MjE2XHU1MTY4XHU5MUNGXHU2RTA1XHU3QTdBXG4gKlxuICogOC4gXHU2RDg4XHU4RDM5XHU2NUI5XHU3OTNBXHU0RjhCXG4gKiAgICAtIFNES1x1RkYxQVx1NUMwNiBidXMgXHU1QjlFXHU0RjhCXHU3Njg0IG9uL29mZiBcdTY2MjBcdTVDMDRcdTRFM0EgYHdiLm9uKClgIC8gYHdiLm9mZigpYCBcdTVCRjlcdTU5MTZcdTY2QjRcdTk3MzJcbiAqICAgIC0gRG9tYWluXHVGRjFBXHU5MDFBXHU4RkM3IGBjb250ZXh0LmJ1cy5vbiguLi4pYCBcdTZEODhcdThEMzlcdTUxNzZcdTRFRDYgZG9tYWluIFx1NzY4NFx1NEU4Qlx1NEVGNlxuICogICAgLSBVSVx1RkYxQVx1OTAxQVx1OEZDNyBTREsgXHU2MjE2XHU3NkY0XHU2M0E1XHU2MzAxXHU2NzA5IGJ1cyBcdTVGMTVcdTc1MjhcdThCQTJcdTk2MDVcbiAqICAgIC0gSVBDIFx1Njg2NVx1NjNBNVx1NTY2OFx1RkYxQVx1OTAxQVx1OEZDNyBgYnVzLm9uQW55KC4uLilgIFx1NTE2OFx1OTFDRlx1OEY2Q1x1NTNEMVxuICpcbiAqIFx1MjZBMFx1RkUwRiBcdTUzNTVcdTRGOEJcdTdFQTZcdTY3NUZcbiAqICAgIC0gXHU1M0VBXHU1MTQxXHU4QkI4XHU5MDFBXHU4RkM3IGBnZXRCdXMoKWAgXHU2MkZGXHU1QjlFXHU0RjhCXHVGRjFCYFdCQnVzYCBjbGFzcyBcdTY3MkNcdThFQUIqKlx1NEUwRFx1NEVDRVx1NUJGOVx1NTkxNiBpbmRleCBcdTVCRkNcdTUxRkEqKlx1MzAwMlxuICogICAgLSBcdTc5ODFcdTZCNjJcdTRFMUFcdTUyQTEvXHU4OEM1XHU5MTREXHU1QzQyXHU1MDVBIGBuZXcgV0JCdXMoKWAgXHU5MDIwXHU1QjY0XHU3QUNCXHU1QjlFXHU0RjhCXHVGRjBDXHU1NDI2XHU1MjE5IElQQyAvIHRyYWNlIFx1OEJBMlx1OTYwNVx1NEYxQVx1OEQ3MFxuICogICAgICBcdTRFMjRcdTRFMkEgYnVzIFx1ODAwQ1x1NUY3Q1x1NkI2NFx1NjUzNlx1NEUwRFx1NTIzMFx1NkQ4OFx1NjA2Rlx1RkYwOFx1NTM4Nlx1NTNGMlx1OEUyOVx1NTc1MVx1NTkxQVx1NkIyMVx1RkYwOVx1MzAwMlxuICogICAgLSBcdTgwMDFcdTVERTVcdTUzODIgYGNyZWF0ZUV2ZW50QnVzKClgIFx1NURGMlx1NEUwQlx1N0VCRlx1MzAwMlx1NkQ0Qlx1OEJENVx1NTNFRlx1NzZGNFx1NjNBNSBgbmV3IFdCQnVzKClgIFx1NjJGRlx1NzJFQ1x1N0FDQlx1NUI5RVx1NEY4Qlx1RkYwQ1xuICpcbiAqIFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFxuICovXG5cbi8qKiBcdTdDQkVcdTc4NkVcdThCQTJcdTk2MDUgaGFuZGxlclx1RkYxQVx1NTNFQVx1NjJGRiBwYXlsb2FkXHUzMDAyICovXG5leHBvcnQgdHlwZSBXQkJ1c0hhbmRsZXI8VCA9IHVua25vd24+ID0gKHBheWxvYWQ6IFQpID0+IHZvaWQ7XG5cbi8qKiBcdTUxNjhcdTkxQ0ZcdTc2RDFcdTU0MkMgaGFuZGxlclx1RkYxQShldmVudCwgcGF5bG9hZCkgPT4gdm9pZCAqL1xuZXhwb3J0IHR5cGUgV0JXaWxkY2FyZEhhbmRsZXIgPSAoZXZlbnQ6IHN0cmluZywgcGF5bG9hZDogdW5rbm93bikgPT4gdm9pZDtcblxuLyoqIG9uKCkgXHU4RkQ0XHU1NkRFXHU3Njg0XHU1M0Q2XHU2RDg4XHU4QkEyXHU5NjA1XHU1MUZEXHU2NTcwICovXG5leHBvcnQgdHlwZSBVbnN1YnNjcmliZSA9ICgpID0+IHZvaWQ7XG5cbi8qKlxuICogXHU4RkRCXHU3QTBCXHU3RUE3XHU0RThCXHU0RUY2XHU2MDNCXHU3RUJGXHUzMDAyXG4gKlxuICogXHU0RUM1XHU1NzI4IGluZnJhL2J1cyBcdTUxODVcdTkwRThcdTRFMEVcdTZENEJcdThCRDVcdTc2RjRcdTYzQTVcdTVCOUVcdTRGOEJcdTUzMTZcdUZGMUJcdTRFMUFcdTUyQTEvXHU4OEM1XHU5MTREXHU1QzQyXHU0RTAwXHU1RjhCXHU4RDcwIGBnZXRCdXMoKWAgXHU1MzU1XHU0RjhCXHUzMDAyXG4gKi9cbmV4cG9ydCBjbGFzcyBXQkJ1cyB7XG4gICAgcHJpdmF0ZSByZWFkb25seSBoYW5kbGVycyA9IG5ldyBNYXA8c3RyaW5nLCBTZXQ8V0JCdXNIYW5kbGVyPj4oKTtcbiAgICBwcml2YXRlIHJlYWRvbmx5IHdpbGRjYXJkSGFuZGxlcnMgPSBuZXcgU2V0PFdCV2lsZGNhcmRIYW5kbGVyPigpO1xuXG4gICAgLyoqIFx1OEJBMlx1OTYwNVx1NEU4Qlx1NEVGNlx1RkYwQ1x1OEZENFx1NTZERVx1NTNENlx1NkQ4OFx1NTFGRFx1NjU3MCAqL1xuICAgIG9uPFQgPSB1bmtub3duPihldmVudDogc3RyaW5nLCBoYW5kbGVyOiBXQkJ1c0hhbmRsZXI8VD4pOiBVbnN1YnNjcmliZSB7XG4gICAgICAgIGxldCBzZXQgPSB0aGlzLmhhbmRsZXJzLmdldChldmVudCk7XG4gICAgICAgIGlmICghc2V0KSB7XG4gICAgICAgICAgICBzZXQgPSBuZXcgU2V0KCk7XG4gICAgICAgICAgICB0aGlzLmhhbmRsZXJzLnNldChldmVudCwgc2V0KTtcbiAgICAgICAgfVxuICAgICAgICBzZXQuYWRkKGhhbmRsZXIgYXMgV0JCdXNIYW5kbGVyKTtcbiAgICAgICAgcmV0dXJuICgpID0+IHtcbiAgICAgICAgICAgIHNldC5kZWxldGUoaGFuZGxlciBhcyBXQkJ1c0hhbmRsZXIpO1xuICAgICAgICAgICAgaWYgKHNldC5zaXplID09PSAwKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5oYW5kbGVycy5kZWxldGUoZXZlbnQpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9O1xuICAgIH1cblxuICAgIC8qKiBcdTUzRDZcdTZEODhcdThCQTJcdTk2MDVcdUZGMDhcdTk3MDBcdTRGMjBcdTUxNjVcdTRFMEUgb24gXHU3NkY4XHU1NDBDXHU3Njg0IGhhbmRsZXIgXHU1RjE1XHU3NTI4XHVGRjA5ICovXG4gICAgb2ZmPFQgPSB1bmtub3duPihldmVudDogc3RyaW5nLCBoYW5kbGVyOiBXQkJ1c0hhbmRsZXI8VD4pOiB2b2lkIHtcbiAgICAgICAgY29uc3Qgc2V0ID0gdGhpcy5oYW5kbGVycy5nZXQoZXZlbnQpO1xuICAgICAgICBpZiAoIXNldCkge3JldHVybjt9XG4gICAgICAgIHNldC5kZWxldGUoaGFuZGxlciBhcyBXQkJ1c0hhbmRsZXIpO1xuICAgICAgICBpZiAoc2V0LnNpemUgPT09IDApIHtcbiAgICAgICAgICAgIHRoaXMuaGFuZGxlcnMuZGVsZXRlKGV2ZW50KTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIC8qKiBcdTZEM0VcdTUzRDFcdTRFOEJcdTRFRjZcdTMwMDJcdTUzNTVcdTRFMkEgaGFuZGxlciBcdTYyOUJcdTk1MTlcdTRFMERcdTVGNzFcdTU0Q0RcdTUxNzZcdTRFRDZcdThCQTJcdTk2MDVcdTgwMDVcdTMwMDIgKi9cbiAgICBlbWl0PFQgPSB1bmtub3duPihldmVudDogc3RyaW5nLCBwYXlsb2FkOiBUKTogdm9pZCB7XG4gICAgICAgIC8vIFx1N0NCRVx1Nzg2RVx1NTMzOVx1OTE0RFx1OEJBMlx1OTYwNVx1ODAwNVxuICAgICAgICBjb25zdCBzZXQgPSB0aGlzLmhhbmRsZXJzLmdldChldmVudCk7XG4gICAgICAgIGlmIChzZXQgJiYgc2V0LnNpemUgPiAwKSB7XG4gICAgICAgICAgICBmb3IgKGNvbnN0IGhhbmRsZXIgb2YgWy4uLnNldF0pIHtcbiAgICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgICAgICBoYW5kbGVyKHBheWxvYWQpO1xuICAgICAgICAgICAgICAgIH0gY2F0Y2gge1xuICAgICAgICAgICAgICAgICAgICAvLyBcdTY1NDVcdTYxMEZcdTU0MUVcdTYzODlcdTIwMTRcdTIwMTRcdTk1MTlcdThCRUZcdTk2OTRcdTc5QkJcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgLy8gXHU1MTY4XHU5MUNGXHU4QkEyXHU5NjA1XHU4MDA1XHVGRjA4SVBDIFx1OEY2Q1x1NTNEMVx1NTY2OFx1N0I0OVx1RkYwOVxuICAgICAgICBpZiAodGhpcy53aWxkY2FyZEhhbmRsZXJzLnNpemUgPiAwKSB7XG4gICAgICAgICAgICBmb3IgKGNvbnN0IHdoIG9mIFsuLi50aGlzLndpbGRjYXJkSGFuZGxlcnNdKSB7XG4gICAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAgICAgd2goZXZlbnQsIHBheWxvYWQpO1xuICAgICAgICAgICAgICAgIH0gY2F0Y2gge1xuICAgICAgICAgICAgICAgICAgICAvLyBcdTU0MENcdTRFMEFcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBcdTUxNjhcdTkxQ0ZcdTc2RDFcdTU0MkNcdTYyNDBcdTY3MDlcdTRFOEJcdTRFRjZcdUZGMDhcdTkwMUFcdTkxNERcdTdCMjZcdThCQTJcdTk2MDVcdUZGMDlcdTMwMDJcbiAgICAgKiBcdTUxNzhcdTU3OEJcdTc1MjhcdTkwMTRcdUZGMUFJUEMgXHU4RjZDXHU1M0QxXHU1NjY4IFx1MjAxNFx1MjAxNCBcdTRFM0JcdThGREJcdTdBMEIgYnVzIFx1NEUwQVx1NjMwMlx1NEUwMFx1NEUyQSBvbkFueVx1RkYwQ1x1NjI4QVx1NjI0MFx1NjcwOVx1NEU4Qlx1NEVGNlx1NjNBOFx1NTIzMCByZW5kZXJlclx1MzAwMlxuICAgICAqL1xuICAgIG9uQW55KGhhbmRsZXI6IFdCV2lsZGNhcmRIYW5kbGVyKTogVW5zdWJzY3JpYmUge1xuICAgICAgICB0aGlzLndpbGRjYXJkSGFuZGxlcnMuYWRkKGhhbmRsZXIpO1xuICAgICAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgICAgICAgdGhpcy53aWxkY2FyZEhhbmRsZXJzLmRlbGV0ZShoYW5kbGVyKTtcbiAgICAgICAgfTtcbiAgICB9XG5cbiAgICAvKiogXHU2RTA1XHU3QTdBXHU2N0QwXHU0RThCXHU0RUY2XHU3Njg0XHU1MTY4XHU5MEU4XHU4QkEyXHU5NjA1XHVGRjBDXHU0RTBEXHU0RjIwIGV2ZW50IFx1NTIxOVx1NkUwNVx1N0E3QVx1NjI0MFx1NjcwOVx1RkYwOFx1NTQyQiB3aWxkY2FyZFx1RkYwOSAqL1xuICAgIGNsZWFyKGV2ZW50Pzogc3RyaW5nKTogdm9pZCB7XG4gICAgICAgIGlmIChldmVudCA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICB0aGlzLmhhbmRsZXJzLmNsZWFyKCk7XG4gICAgICAgICAgICB0aGlzLndpbGRjYXJkSGFuZGxlcnMuY2xlYXIoKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHRoaXMuaGFuZGxlcnMuZGVsZXRlKGV2ZW50KTtcbiAgICAgICAgfVxuICAgIH1cbn1cblxuLy8gXHUyNTAwXHUyNTAwXHUyNTAwIFx1OEZEQlx1N0EwQlx1N0VBN1x1NTM1NVx1NEY4QiBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcbi8vXG4vLyBcdTg4QzVcdTkxNERcdTVDNDIgLyBTREsgXHU1MTg1XHU5MEU4IC8gaHR0cC51cGxvYWQgXHU4RkRCXHU1RUE2XHU4QkEyXHU5NjA1XHU3QjQ5KipcdThERThcdTZBMjFcdTU3NTdcdTUxNzFcdTRFQUJcdTRFOEJcdTRFRjYqKlx1NzY4NFx1NTczQVx1NjY2RlxuLy8gXHU1RTk0XHU4QkU1XHU4RDcwIGdldEJ1cygpIFx1NjJGRlx1NTQwQ1x1NEUwMFx1NUI5RVx1NEY4Qlx1RkYxQlx1Nzk4MVx1NkI2MiBgbmV3IFdCQnVzKClgIFx1OTAyMFx1NUI2NFx1N0FDQlx1NUI5RVx1NEY4Qlx1RkYwQ1x1NTQyNlx1NTIxOVxuLy8gSVBDIC8gdHJhY2UgXHU4QkEyXHU5NjA1XHU0RjFBXHU4RDcwXHU0RTI0XHU0RTJBIGJ1cyBcdTgwMENcdTVGN0NcdTZCNjRcdTY1MzZcdTRFMERcdTUyMzBcdTZEODhcdTYwNkZcdUZGMDhcdTUzODZcdTUzRjJcdThFMjlcdTU3NTFcdTU5MUFcdTZCMjFcdUZGMDlcdTMwMDJcblxubGV0IGluc3RhbmNlOiBXQkJ1cyB8IG51bGwgPSBudWxsO1xuXG4vKiogXHU4M0I3XHU1M0Q2XHU4RkRCXHU3QTBCXHU3RUE3XHU1NTJGXHU0RTAwIEJ1cyBcdTVCOUVcdTRGOEJcdTMwMDIgKi9cbmV4cG9ydCBmdW5jdGlvbiBnZXRCdXMoKTogV0JCdXMge1xuICAgIGlmICghaW5zdGFuY2UpIHtcbiAgICAgICAgaW5zdGFuY2UgPSBuZXcgV0JCdXMoKTtcbiAgICB9XG4gICAgcmV0dXJuIGluc3RhbmNlO1xufVxuXG4vKiogXHU0RUM1XHU2RDRCXHU4QkQ1XHU3NTI4XHVGRjFBXHU2RTA1XHU3QTdBXHU1RTc2XHU5MUNEXHU3RjZFXHU1MzU1XHU0RjhCXHUzMDAyXHU3NTFGXHU0RUE3XHU0RUUzXHU3ODAxXHU3OTgxXHU2QjYyXHU4QzAzXHU3NTI4XHUzMDAyICovXG5leHBvcnQgZnVuY3Rpb24gcmVzZXRCdXNGb3JUZXN0cygpOiB2b2lkIHtcbiAgICBpbnN0YW5jZT8uY2xlYXIoKTtcbiAgICBpbnN0YW5jZSA9IG51bGw7XG59XG4iLCAiLyoqXG4gKiBcdThERThcdThGQjlcdTc1NENcdTk1MTlcdThCRUZcdTRGRTFcdTVDMDEgXHUyMDE0XHUyMDE0IFx1NjI0MFx1NjcwOVx1OERFOFx1OEZEQlx1N0EwQiAvIFx1OERFOCB3aW5kb3cgLyBcdThERTggb3JpZ2luIFx1NzY4NCBUcmFuc3BvcnQgXHU5MEZEXHU5NzAwXHU4OTgxXHU1QjgzXHUzMDAyXG4gKlxuICogXHU0RTNBXHU0RUMwXHU0RTQ4XHU1NzI4IGNvcmVcdUZGMUFcbiAqIC0gRXJyb3IgXHU1QkY5XHU4QzYxXHU2NUUwXHU2Q0Q1XHU1QjhDXHU2NTc0XHU3QTdGXHU4RDhBIElQQyAvIHBvc3RNZXNzYWdlIC8gc3RydWN0dXJlZCBjbG9uZVx1RkYwOFx1ODFFQVx1NUI5QVx1NEU0OVx1NUI1N1x1NkJCNVx1NEYxQVx1NEUyMlx1RkYwOVxuICogLSBcdTYyNDBcdTY3MDkgVHJhbnNwb3J0IFx1NUI5RVx1NzNCMFx1RkYwOElQQyAvIHBvc3RNZXNzYWdlIC8gd29ya2VyXHVGRjA5XHU5MEZEXHU5NzAwXHU4OTgxKipcdTU0MENcdTRFMDBcdTU5NTcqKlx1OTUxOVx1OEJFRlx1NEZFMVx1NUMwMVx1NjgzQ1x1NUYwRlxuICogLSBgY3JlYXRlR3Vlc3RQcm94eWAgXHU2NTM2XHU1MjMwXHU4RkQ0XHU1NkRFXHU1MDNDXHU2NUY2XHU2MzA5XHU1NDBDXHU0RTAwXHU1OTU3XHU4OUM0XHU1MjE5XHU1M0NEXHU1RThGXHU1MjE3XHU1MzE2XHVGRjBDXHU2MjREXHU4MEZEXHU0RkREXHU4QkMxXHU0RTFBXHU1MkExXHU1QzQyIGNhdGNoIFx1NjJGRlx1NTIzMFx1NkI2M1x1Nzg2RVx1NzY4NCBFcnJvclxuICpcbiAqIFx1NEY3Rlx1NzUyOFx1N0VBNlx1NUI5QVx1RkYxQVxuICogLSBTZXJ2ZXIgXHU0RkE3IFRyYW5zcG9ydFx1RkYxQWhhbmRsZXIgXHU2MjlCXHU5NTE5XHU2NUY2XHU3NTI4IGBzZXJpYWxpemVCcmlkZ2VFcnJvcihlcnIpYCBcdTUzMDVcdTg4QzVcdTU0MEVcdThGRDRcdTU2REVcbiAqIC0gQ2xpZW50IFx1NEZBNyBUcmFuc3BvcnRcdUZGMUFcdThGRDRcdTU2REVcdTUwM0NcdTdFQ0YgYGRlc2VyaWFsaXplUmVzdWx0KHJlc3VsdClgXHVGRjBDXHU2OEMwXHU2RDRCXHU1MjMwXHU0RkUxXHU1QzAxXHU1QzMxXHU2MjlCXHU4RkQ4XHU1MzlGXHU1NDBFXHU3Njg0IEVycm9yXG4gKi9cblxuLy8gXHUyNTAwXHUyNTAwXHUyNTAwIFx1N0M3Qlx1NTc4QiBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblxuLyoqIFx1OERFOFx1OEZCOVx1NzU0Q1x1OTUxOVx1OEJFRlx1NEZFMVx1NUMwMVx1MzAwMlx1NzUyOCBgX193YkVycm9yOiB0cnVlYCBcdTRGNUNcdTRFM0FcdTlCNTRcdTZDRDVcdTY4MDdcdThCQzZcdTMwMDIgKi9cbmV4cG9ydCBpbnRlcmZhY2UgU2VyaWFsaXplZEJyaWRnZUVycm9yIHtcbiAgICBfX3diRXJyb3I6IHRydWU7XG4gICAgbWVzc2FnZTogc3RyaW5nO1xuICAgIGNvZGU/OiBzdHJpbmc7XG4gICAgc291cmNlPzogc3RyaW5nO1xuICAgIGh0dHBTdGF0dXM/OiBudW1iZXI7XG4gICAgZGF0YT86IHVua25vd247XG4gICAgLyoqXG4gICAgICogXHU5ODg2XHU1N0RGXHU4MUVBXHU1QjlBXHU0RTQ5XHU0RTFBXHU1MkExXHU3ODAxXHU1MzlGXHU1OUNCXHU1MDNDXHVGRjA4XHU1OTgyIHNjaGVkdWxlciBcdTc2ODQgYENST05fSU5URVJWQUxfVE9PX1NIT1JUYFx1RkYwOVx1MzAwMlxuICAgICAqXG4gICAgICogXHUzMDEwXHU0RTNBXHU0RUMwXHU0RTQ4XHU1RkM1XHU5ODdCXHU1MzU1XHU1MjE3XHUzMDExYGNvZGVgIFx1N0VDRiBgd3JhcEZhY2FkZWAgXHUyMTkyIGBXQkVycm9yLmZyb21gIFx1NUY1Mlx1NEUwMFx1NTMxNlx1NTQwRVx1NjYyRlx1NUMwMVx1OTVFRFx1NzY4NFx1OTAxQVx1NzUyOFx1NTIwNlx1N0M3QlxuICAgICAqIFx1RkYwOGBVTktOT1dOYCAvIGBORVRXT1JLYCAvIGBUSU1FT1VUYCAuLi5cdUZGMDlcdUZGMENkb21haW4gXHU4MUVBXHU1QjlBXHU0RTQ5XHU3ODAxXHU1OTI5XHU3MTM2XHU4NDNEXHU0RTBEXHU4RkRCXHU1M0JCXHVGRjBDXHU1M0VBXHU1MjY5IGBVTktOT1dOYFx1MzAwMlxuICAgICAqIFx1ODAwQyBkYWVtb24gXHU3Njg0IGB3YjppbnZva2VgIGhhbmRsZXIgXHU2NjJGICoqY2F0Y2ggXHU1NDBFIHJldHVybiBcdTRGRTFcdTVDMDEqKlx1RkYwOFx1NEUwRCB0aHJvd1x1RkYwQ1x1ODlDMVxuICAgICAqIGBhcHBzL3dvcmtidWRkeS1kZXNrdG9wL3NyYy9tYWluL2ZlYXR1cmVzL3diL3JlZ2lzdGVyLXdiLWJyaWRnZS1jaGFubmVscy50c2AgXHU3Njg0XG4gICAgICogYHNlcnZlci5oYW5kbGUoJ3diOmludm9rZScsIC4uLilgXHVGRjA5XHUyMDE0XHUyMDE0XHU4RkQ5XHU2MTBGXHU1NDczXHU3NzQwXHU4RDcwXHU3Njg0XHU2NjJGIGBycGMtcmVzdWx0YCBcdTgwMENcdTRFMERcdTY2MkYgYHJwYy1lcnJvcmBcdUZGMENcbiAgICAgKiBgc3RkaW8tc2VydmVyLnRzYCAvIGBzdGRpby1jb25uZWN0aW9uLnRzYCBcdTc2ODQgYGV4dHJhY3RCaXpEZXRhaWxgIFx1NEUwRSBtYWluIFx1NEZBN1xuICAgICAqIGBkaXNwYXRjaFdiSW52b2tlYCBjYXRjaCBcdTkxQ0NcdTc2ODQgYml6Q29kZSBcdTYzRDBcdTUzNDcqKlx1NTE2OFx1OTBGRFx1NEUwRFx1NEYxQVx1NjI2N1x1ODg0QyoqXHUzMDAyXHU2NzJDXHU0RkUxXHU1QzAxXHU2NjJGXHU4RkQ5XHU2NzYxXHU4REVGXHU1Rjg0XHU0RTBBXG4gICAgICogXHU0RTFBXHU1MkExXHU3ODAxXHU1NTJGXHU0RTAwXHU3Njg0XHU4RjdEXHU0RjUzXHVGRjBDXHU3RjNBXHU0RTg2XHU1QjgzIFVJIFx1NUM0Mlx1NTNFQVx1ODBGRFx1NjJGRlx1NTIzMCBgVU5LTk9XTmBcdUZGMENcdTUzRUFcdTgwRkRcdTkwMDBcdTU2REVcdTVDNTVcdTc5M0FcdTU0MEVcdTdBRUZcdTgyRjFcdTY1ODdcdTUzOUZcdTY1ODdcbiAgICAgKiBcdUZGMDhpc3N1ZSAjMTI5NjU4XHVGRjFBXHU4MUVBXHU1MkE4XHU1MzE2XHU0RUZCXHU1MkExIGNyb24gXHU5ODkxXHU3Mzg3XHU5NTE5XHU4QkVGXHU2M0QwXHU3OTNBXHU0RTBEXHU3RkZCXHU4QkQxXHVGRjA5XHUzMDAyXG4gICAgICovXG4gICAgYml6Q29kZT86IHN0cmluZyB8IG51bWJlcjtcbiAgICAvKipcbiAgICAgKiBheGlvcyBlcnJvciBcdTcyNzlcdTVGODFcdTkwMEZcdTRGMjAgXHUyMDE0XHUyMDE0IFx1NEZERFx1NzU1OVx1NjcwRFx1NTJBMVx1N0FFRlx1OEZENFx1NTZERVx1NEY1M1x1NTQ4Q1x1OEJGN1x1NkM0Mlx1OTE0RFx1N0Y2RVx1RkYwQ1x1OEJBOVx1OERFOFx1OEZCOVx1NzU0Q1x1NzY4NFx1NkQ4OFx1OEQzOVx1NjVCOVx1RkYwOGV4dGVuc2lvbiAvXG4gICAgICogaWZyYW1lIC8gd2Vidmlld1x1RkYwOVx1ODBGRFx1NTBDRlx1OEMwM1x1NzUyOFx1NTM5Rlx1NzUxRiBheGlvcyBcdTRFMDBcdTY4MzdcdTYzMDkgYGVyci5yZXNwb25zZS5zdGF0dXMgLyBlcnIucmVzcG9uc2UuZGF0YSAvXG4gICAgICogZXJyLmNvbmZpZy51cmxgIFx1NUI5QVx1NEY0RCBIVFRQIFx1OTUxOVx1OEJFRlx1OEJFNlx1NjBDNVx1MzAwMlxuICAgICAqXG4gICAgICogXHUzMDEwXHU0RTNBXHU0RUMwXHU0RTQ4XHU1MkEwXHUzMDExXHU4MDAxXHU1QjlFXHU3M0IwXHU1M0VBXHU0RkREXHU3NTU5IGBtZXNzYWdlYFx1RkYwQ1x1OERFOFx1OEZCOVx1NzU0Q1x1NTQwRSBheGlvcyBlcnJvciBcdTRFQ0VcbiAgICAgKiBge21lc3NhZ2UsIHJlc3BvbnNlOiB7c3RhdHVzOjQwMCwgZGF0YTp7Y29kZToxMDAwLCBtc2c6Jy4uLid9fSwgY29uZmlnOnt1cmw6Jy92Mi8uLi4nfX1gXG4gICAgICogXHU1ODRDXHU2MjEwIGBFcnJvcignUmVxdWVzdCBmYWlsZWQgd2l0aCBzdGF0dXMgY29kZSA0MDAnKWAgXHUyMDE0XHUyMDE0IFx1NjcwRFx1NTJBMVx1N0FFRlx1OEZENFx1NTZERVx1NzY4NCBjb2RlL21zZy9ib2R5IFx1NTE2OFx1NEUyMlx1RkYwQ1xuICAgICAqIGV4dGVuc2lvbiBcdTRGQTdcdTUzRUFcdTgwRkRcdTc3MEJcdTUyMzAgYG1zZz1SZXF1ZXN0IGZhaWxlZCB3aXRoIHN0YXR1cyBjb2RlIDQwMCBib2R5PXVuZGVmaW5lZGBcdUZGMDhlZGdlLXN5bmNcbiAgICAgKiBgaGFuZGxlR2V0QXJ0aWZhY3RgIFx1OTFDQyBTTUggXHU0RTBBXHU0RjIwIDQwMCBcdTVDMzFcdTY2MkZcdThGRDlcdTRFMkFcdTk1RUVcdTk4OThcdUZGMDlcdUZGMENcdTVCOENcdTUxNjhcdTY1RTBcdTZDRDVcdTVCOUFcdTRGNERcdTY3MERcdTUyQTFcdTdBRUZcdTYyRDJcdTY1MzZcdTUzOUZcdTU2RTBcdTMwMDJcbiAgICAgKlxuICAgICAqIFx1MzAxMFx1NUI1N1x1NkJCNVx1Njc2NVx1NkU5MFx1MzAxMXNlcmlhbGl6ZUJyaWRnZUVycm9yIFx1NjNBMlx1NkQ0QiBheGlvcyBlcnJvciBcdTcyNzlcdTVGODFcdUZGMDhcdTY3MDkgYGVyci5yZXNwb25zZWAgXHU2MjE2IGBlcnIuY29uZmlnYFxuICAgICAqIFx1NjVGNlx1ODlDNlx1NEUzQSBheGlvcyBlcnJvclx1RkYwOVx1RkYwQ1x1NjI4QVx1NTE3M1x1OTUyRVx1NUI1N1x1NkJCNVx1NjI0MVx1NUU3M1x1NTMxNlx1NjUzNlx1OEZEQlx1NEZFMVx1NUMwMVx1MzAwMmRlc2VyaWFsaXplUmVzdWx0IFx1NEZBN1x1NTE4RFx1NjI4QVx1NUI4M1x1OEZEOFx1NTM5Rlx1NjIxMFxuICAgICAqIGBlcnIucmVzcG9uc2UgPSB7Li4ufWAgLyBgZXJyLmNvbmZpZyA9IHsuLi59YCAvIGBlcnIuY29kZWAgXHU0RTA5XHU1OTA0XHU2MzAyXHU3MEI5XHVGRjBDXHU4RERGIGF4aW9zIFx1NTM5Rlx1NzUxRlx1N0VEM1x1Njc4NFx1NUJGOVx1OUY1MFx1MzAwMlxuICAgICAqXG4gICAgICogXHUzMDEwXHU1Qjg5XHU1MTY4XHU4RkI5XHU3NTRDXHUzMDExXHU1NENEXHU1RTk0XHU0RjUzXHVGRjA4YHJlc3BvbnNlRGF0YWBcdUZGMDlcdTUzRUZcdTgwRkRcdTVGODhcdTU5MjdcdUZGMDhcdTZCRDRcdTU5ODJcdTY3RDBcdTRFOUIgQVBJIFx1OEZENFx1NTZERSBIVE1MIFx1OTUxOVx1OEJFRlx1OTg3NVx1RkYwOVx1RkYwQ1xuICAgICAqIFx1NUU4Rlx1NTIxN1x1NTMxNlx1NjVGNlx1NjMwOVx1NTkyN1x1NUMwRiBjbGFtcFx1RkYwOFx1OUVEOFx1OEJBNCA0S0IgXHU2MjJBXHU2NUFEXHVGRjA5XHVGRjBDXHU5MDdGXHU1MTREIElQQyBcdTRGMjBcdTU5MjcgcGF5bG9hZCAvIFx1NjU0Rlx1NjExRlx1NjU3MFx1NjM2RVx1NkNDNFx1NkYwRlx1MzAwMlxuICAgICAqIFx1OEJGN1x1NkM0MiBib2R5XHVGRjA4YGVyci5jb25maWcuZGF0YWBcdUZGMDkqKlx1NEUwRFx1OTAwRlx1NEYyMCoqIFx1MjAxNFx1MjAxNCBcdTkxQ0NcdTk3NjJcdTUzRUZcdTgwRkRcdTY3MDkgdG9rZW4gLyB1c2VyIGNvbnRlbnQgXHU3QjQ5XHU2NTRGXHU2MTFGXHU2NTcwXHU2MzZFXHUzMDAyXG4gICAgICovXG4gICAgYXhpb3M/OiB7XG4gICAgICAgIHJlc3BvbnNlPzoge1xuICAgICAgICAgICAgc3RhdHVzPzogbnVtYmVyO1xuICAgICAgICAgICAgc3RhdHVzVGV4dD86IHN0cmluZztcbiAgICAgICAgICAgIC8qKiBcdTY3MERcdTUyQTFcdTdBRUZcdThGRDRcdTU2REVcdTRGNTNcdUZGMDhjbGFtcCBcdTUyMzAgXHUyMjY0NEtCXHVGRjBDXHU4RDg1XHU4RkM3XHU2MjJBXHU2NUFEXHVGRjA5ICovXG4gICAgICAgICAgICBkYXRhPzogdW5rbm93bjtcbiAgICAgICAgfTtcbiAgICAgICAgY29uZmlnPzoge1xuICAgICAgICAgICAgdXJsPzogc3RyaW5nO1xuICAgICAgICAgICAgbWV0aG9kPzogc3RyaW5nO1xuICAgICAgICB9O1xuICAgICAgICAvKiogYXhpb3MgXHU3Njg0XHU5NTE5XHU4QkVGXHU3ODAxXHVGRjA4RUNPTk5SRVNFVCAvIEVUSU1FRE9VVCAvIEVSUl9CQURfUkVRVUVTVCBcdTdCNDlcdUZGMDkgKi9cbiAgICAgICAgY29kZT86IHN0cmluZztcbiAgICB9O1xufVxuXG4vLyBheGlvcyByZXNwb25zZS5kYXRhIFx1NUU4Rlx1NTIxN1x1NTMxNlx1NEUwQVx1OTY1MFx1RkYwOFx1OTA3Rlx1NTE0RFx1NTkyNyBib2R5IFx1NTg1RVx1NkVFMSBJUENcdUZGMDlcbmNvbnN0IEFYSU9TX0JPRFlfTUFYX0JZVEVTID0gNCAqIDEwMjQ7XG5cbi8vIFx1MjUwMFx1MjUwMFx1MjUwMCBcdTVFOEZcdTUyMTdcdTUzMTZcdUZGMDhTZXJ2ZXIgXHU0RkE3XHU3NTI4XHVGRjA5XHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cbi8qKlxuICogXHU2MjhBXHU0RUZCXHU2MTBGXHU2MjlCXHU1MUZBXHU3Njg0XHU5NTE5XHU4QkVGXHU1MzA1XHU2MjEwIGBTZXJpYWxpemVkQnJpZGdlRXJyb3JgXHUzMDAyXG4gKlxuICogXHU0RkREXHU3NTU5XHU1RTM4XHU4OUMxXHU3Njg0IFdCRXJyb3IgXHU1MTQzXHU2NTcwXHU2MzZFXHU1QjU3XHU2QkI1XHVGRjA4Y29kZSAvIGJpekNvZGUgLyBzb3VyY2UgLyBodHRwU3RhdHVzIC8gZGF0YVx1RkYwOVx1MzAwMlxuICogXHU2NzJBXHU2NzY1XHU1MkEwXHU1QjU3XHU2QkI1XHU3NkY0XHU2M0E1XHU2MjY5XHU1QzU1XHU4RkQ5XHU5MUNDICsgYGRlc2VyaWFsaXplUmVzdWx0YFx1MzAwMlxuICovXG5leHBvcnQgZnVuY3Rpb24gc2VyaWFsaXplQnJpZGdlRXJyb3IoZXJyb3I6IHVua25vd24pOiBTZXJpYWxpemVkQnJpZGdlRXJyb3Ige1xuICAgIGNvbnN0IGVyciA9IGVycm9yIGFzIHtcbiAgICAgICAgbWVzc2FnZT86IHN0cmluZztcbiAgICAgICAgY29kZT86IHN0cmluZztcbiAgICAgICAgYml6Q29kZT86IHN0cmluZyB8IG51bWJlcjtcbiAgICAgICAgc291cmNlPzogc3RyaW5nO1xuICAgICAgICBodHRwU3RhdHVzPzogbnVtYmVyO1xuICAgICAgICBkYXRhPzogdW5rbm93bjtcbiAgICAgICAgLy8gYXhpb3MgZXJyb3IgXHU3Mjc5XHU1RjgxXHU1QjU3XHU2QkI1XG4gICAgICAgIHJlc3BvbnNlPzoge1xuICAgICAgICAgICAgc3RhdHVzPzogbnVtYmVyO1xuICAgICAgICAgICAgc3RhdHVzVGV4dD86IHN0cmluZztcbiAgICAgICAgICAgIGRhdGE/OiB1bmtub3duO1xuICAgICAgICAgICAgaGVhZGVycz86IHVua25vd247XG4gICAgICAgIH07XG4gICAgICAgIGNvbmZpZz86IHtcbiAgICAgICAgICAgIHVybD86IHN0cmluZztcbiAgICAgICAgICAgIG1ldGhvZD86IHN0cmluZztcbiAgICAgICAgfTtcbiAgICAgICAgaXNBeGlvc0Vycm9yPzogYm9vbGVhbjtcbiAgICB9O1xuXG4gICAgLy8gXHUyNTAwXHUyNTAwIGF4aW9zIGVycm9yIFx1NzI3OVx1NUY4MVx1NjNBMlx1NkQ0QiArIFx1NjI0MVx1NUU3M1x1NTMxNiBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcbiAgICAvLyBcdTUzRUFcdTg5ODFcdTY3MDkgYHJlc3BvbnNlYCBcdTYyMTYgYGNvbmZpZ2AgXHU1QzMxXHU1RjUzIGF4aW9zIGVycm9yIFx1NTkwNFx1NzQwNlx1RkYwOGBpc0F4aW9zRXJyb3JgIFx1NjgwN1x1OEJCMFx1NEUwRFx1NEUwMFx1NUI5QVx1NTNFRlx1OTc2MCBcdTIwMTRcdTIwMTRcbiAgICAvLyBcdTY3MDlcdTRFOUJcdTUzMDVcdTg4QzVcdTVDNDJcdTRGMUEgcmV0aHJvdyBcdTY1RjZcdTRFMjJcdTYzODlcdThGRDlcdTRFMkFcdTY4MDdcdThCQjBcdUZGMENcdTRGNDYgcmVzcG9uc2UvY29uZmlnIFx1N0VEM1x1Njc4NFx1NkJENFx1OEY4M1x1N0EzM1x1NUI5QVx1RkYwOVx1MzAwMlxuICAgIGxldCBheGlvc0VudmVsb3BlOiBTZXJpYWxpemVkQnJpZGdlRXJyb3JbJ2F4aW9zJ107XG4gICAgaWYgKGVycj8ucmVzcG9uc2UgfHwgZXJyPy5jb25maWcgfHwgZXJyPy5pc0F4aW9zRXJyb3IpIHtcbiAgICAgICAgYXhpb3NFbnZlbG9wZSA9IHt9O1xuICAgICAgICBpZiAoZXJyLnJlc3BvbnNlKSB7XG4gICAgICAgICAgICBheGlvc0VudmVsb3BlLnJlc3BvbnNlID0ge1xuICAgICAgICAgICAgICAgIC4uLihlcnIucmVzcG9uc2Uuc3RhdHVzICE9PSB1bmRlZmluZWQgPyB7IHN0YXR1czogZXJyLnJlc3BvbnNlLnN0YXR1cyB9IDoge30pLFxuICAgICAgICAgICAgICAgIC4uLihlcnIucmVzcG9uc2Uuc3RhdHVzVGV4dCA/IHsgc3RhdHVzVGV4dDogZXJyLnJlc3BvbnNlLnN0YXR1c1RleHQgfSA6IHt9KSxcbiAgICAgICAgICAgICAgICAuLi4oZXJyLnJlc3BvbnNlLmRhdGEgIT09IHVuZGVmaW5lZFxuICAgICAgICAgICAgICAgICAgICA/IHsgZGF0YTogY2xhbXBBeGlvc0JvZHkoZXJyLnJlc3BvbnNlLmRhdGEpIH1cbiAgICAgICAgICAgICAgICAgICAgOiB7fSksXG4gICAgICAgICAgICB9O1xuICAgICAgICB9XG4gICAgICAgIGlmIChlcnIuY29uZmlnKSB7XG4gICAgICAgICAgICBheGlvc0VudmVsb3BlLmNvbmZpZyA9IHtcbiAgICAgICAgICAgICAgICAuLi4oZXJyLmNvbmZpZy51cmwgPyB7IHVybDogZXJyLmNvbmZpZy51cmwgfSA6IHt9KSxcbiAgICAgICAgICAgICAgICAuLi4oZXJyLmNvbmZpZy5tZXRob2QgPyB7IG1ldGhvZDogZXJyLmNvbmZpZy5tZXRob2QgfSA6IHt9KSxcbiAgICAgICAgICAgIH07XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGVyci5jb2RlKSB7XG4gICAgICAgICAgICBheGlvc0VudmVsb3BlLmNvZGUgPSBlcnIuY29kZTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIHJldHVybiB7XG4gICAgICAgIF9fd2JFcnJvcjogdHJ1ZSxcbiAgICAgICAgbWVzc2FnZTogZXJyPy5tZXNzYWdlID8/IFN0cmluZyhlcnJvciksXG4gICAgICAgIC4uLihlcnI/LmNvZGUgPyB7IGNvZGU6IGVyci5jb2RlIH0gOiB7fSksXG4gICAgICAgIC4uLihlcnI/LmJpekNvZGUgIT09IHVuZGVmaW5lZCA/IHsgYml6Q29kZTogZXJyLmJpekNvZGUgfSA6IHt9KSxcbiAgICAgICAgLi4uKGVycj8uc291cmNlID8geyBzb3VyY2U6IGVyci5zb3VyY2UgfSA6IHt9KSxcbiAgICAgICAgLi4uKGVycj8uaHR0cFN0YXR1cyAhPT0gdW5kZWZpbmVkID8geyBodHRwU3RhdHVzOiBlcnIuaHR0cFN0YXR1cyB9IDoge30pLFxuICAgICAgICAvLyBheGlvcyByZXNwb25zZS5zdGF0dXMgXHU0RTVGXHU5ODdBXHU2MjRCXHU2MzAyXHU1MjMwXHU5ODc2XHU1QzQyIGh0dHBTdGF0dXNcdUZGMDhcdTU5ODJcdTY3OUNcdTRFMUFcdTUyQTFcdTZDQTFcdTY2M0VcdTVGMEZcdThCQkUgaHR0cFN0YXR1cyBcdTc2ODRcdThCRERcdUZGMDlcbiAgICAgICAgLy8gXHUyMDE0XHUyMDE0IFx1NjVCOVx1NEZCRlx1NjMwOSBgZXJyLmh0dHBTdGF0dXNgIFx1NzZGNFx1NjNBNVx1NTIyNFx1NUI5QVx1RkYwQ1x1NjVFMFx1OTcwMFx1NkRGMVx1NTE2NSBlcnIucmVzcG9uc2VcbiAgICAgICAgLi4uKGVycj8uaHR0cFN0YXR1cyA9PT0gdW5kZWZpbmVkICYmIGVycj8ucmVzcG9uc2U/LnN0YXR1cyAhPT0gdW5kZWZpbmVkXG4gICAgICAgICAgICA/IHsgaHR0cFN0YXR1czogZXJyLnJlc3BvbnNlLnN0YXR1cyB9XG4gICAgICAgICAgICA6IHt9KSxcbiAgICAgICAgLi4uKGVycj8uZGF0YSAhPT0gdW5kZWZpbmVkID8geyBkYXRhOiBlcnIuZGF0YSB9IDoge30pLFxuICAgICAgICAuLi4oYXhpb3NFbnZlbG9wZSA/IHsgYXhpb3M6IGF4aW9zRW52ZWxvcGUgfSA6IHt9KSxcbiAgICB9O1xufVxuXG4vKipcbiAqIFx1NjI4QSBheGlvcyByZXNwb25zZS5kYXRhIFx1NUU4Rlx1NTIxN1x1NTMxNlx1NTQwRSBjbGFtcCBcdTUyMzAgYEFYSU9TX0JPRFlfTUFYX0JZVEVTYCBcdTRFRTVcdTUxODVcdTMwMDJcbiAqXG4gKiAtIHN0cmluZyAvIG9iamVjdCBcdTkwRkRcdTYzMDkgSlNPTiBcdTk1N0ZcdTVFQTZcdTYyMkFcdTY1QURcbiAqIC0gXHU0RThDXHU4RkRCXHU1MjM2IC8gXHU2NUUwXHU2Q0Q1IEpTT04gXHU1RThGXHU1MjE3XHU1MzE2XHU3Njg0IFx1MjE5MiBcdThGRDRcdTU2REUgYCcodW5zZXJpYWxpemFibGUgYm9keSknYCBcdTUxNUNcdTVFOTVcbiAqIC0gXHU2MjJBXHU2NUFEXHU1NDBFXHU5NjQ0IGAuLi4odHJ1bmNhdGVkIE4gYnl0ZXMpYCBcdTYzRDBcdTc5M0FcbiAqXG4gKiBcdTc2RUVcdTc2ODRcdUZGMUFcdTkwN0ZcdTUxNERcdTU5MjdcdTU0Q0RcdTVFOTRcdTRGNTNcdUZGMDhIVE1MIFx1OTUxOVx1OEJFRlx1OTg3NSAvIFx1NTkyNyBKU09OXHVGRjA5XHU1ODVFXHU2RUUxIElQQyBwaXBlXHVGRjBDXHU1NDBDXHU2NUY2XHU0RkREXHU3NTU5XHU5NTE5XHU4QkVGXHU1QjlBXHU0RjREXHU0RkUxXHU2MDZGXHUzMDAyXG4gKi9cbmZ1bmN0aW9uIGNsYW1wQXhpb3NCb2R5KGJvZHk6IHVua25vd24pOiB1bmtub3duIHtcbiAgICB0cnkge1xuICAgICAgICBjb25zdCBzID0gdHlwZW9mIGJvZHkgPT09ICdzdHJpbmcnID8gYm9keSA6IEpTT04uc3RyaW5naWZ5KGJvZHkpO1xuICAgICAgICBpZiAodHlwZW9mIHMgIT09ICdzdHJpbmcnKSB7IHJldHVybiAnKHVuc2VyaWFsaXphYmxlIGJvZHkpJzsgfVxuICAgICAgICBpZiAoQnVmZmVyLmJ5dGVMZW5ndGgocywgJ3V0Zi04JykgPD0gQVhJT1NfQk9EWV9NQVhfQllURVMpIHtcbiAgICAgICAgICAgIC8vIFx1NjcyQVx1OEQ4NVx1OTY1MFx1RkYxQVx1NUI1N1x1N0IyNlx1NEUzMlx1NzZGNFx1NjNBNVx1OEZENFx1RkYwQ29iamVjdCBcdThGRDRcdTUzOUZcdTVCRjlcdThDNjFcdUZGMDhcdTVCQTJcdTYyMzdcdTdBRUZcdThGRDhcdTgwRkRcdTYzMDlcdTdFRDNcdTY3ODRcdThCQkZcdTk1RUVcdUZGMDlcbiAgICAgICAgICAgIHJldHVybiB0eXBlb2YgYm9keSA9PT0gJ3N0cmluZycgPyBzIDogYm9keTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCB0cnVuY2F0ZWQgPSBzLnNsaWNlKDAsIEFYSU9TX0JPRFlfTUFYX0JZVEVTKTtcbiAgICAgICAgcmV0dXJuIGAke3RydW5jYXRlZH0uLi4odHJ1bmNhdGVkICR7cy5sZW5ndGggLSBBWElPU19CT0RZX01BWF9CWVRFU30gY2hhcnMpYDtcbiAgICB9IGNhdGNoIHtcbiAgICAgICAgcmV0dXJuICcodW5zZXJpYWxpemFibGUgYm9keSknO1xuICAgIH1cbn1cblxuLy8gXHUyNTAwXHUyNTAwXHUyNTAwIFx1NTNDRFx1NUU4Rlx1NTIxN1x1NTMxNlx1RkYwOENsaWVudCBcdTRGQTdcdTc1MjhcdUZGMDlcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblxuLyoqXG4gKiBcdTY4QzBcdTZENEJcdTY2MkZcdTU0MjZcdTRFM0FcdThERThcdThGQjlcdTc1NENcdTk1MTlcdThCRUZcdTRGRTFcdTVDMDFcdTMwMDJcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGlzU2VyaWFsaXplZEJyaWRnZUVycm9yKHZhbHVlOiB1bmtub3duKTogdmFsdWUgaXMgU2VyaWFsaXplZEJyaWRnZUVycm9yIHtcbiAgICByZXR1cm4gKFxuICAgICAgICB2YWx1ZSAhPT0gbnVsbFxuICAgICAgICAmJiB0eXBlb2YgdmFsdWUgPT09ICdvYmplY3QnXG4gICAgICAgICYmICh2YWx1ZSBhcyB7IF9fd2JFcnJvcj86IHVua25vd24gfSkuX193YkVycm9yID09PSB0cnVlXG4gICAgKTtcbn1cblxuLyoqXG4gKiBcdTUzQ0RcdTVFOEZcdTUyMTdcdTUzMTYgU2VydmVyIFx1OEZENFx1NTZERVx1NTAzQyBcdTIwMTRcdTIwMTQgXHU1OTgyXHU2NzlDXHU2NjJGXHU5NTE5XHU4QkVGXHU0RkUxXHU1QzAxXHU1QzMxXHU4RkQ4XHU1MzlGXHU0RTNBIEVycm9yIFx1NUU3Nlx1NjI5Qlx1NTFGQVx1RkYwQ1x1NTQyNlx1NTIxOVx1NTM5Rlx1NjgzN1x1OEZENFx1NTZERVx1MzAwMlxuICpcbiAqIFRyYW5zcG9ydCBcdTc2ODQgYGludm9rZWAgXHU0RTBFIEJyaWRnZSBDbGllbnQgXHU3Njg0XHU4RkQ0XHU1NkRFXHU1MDNDXHU1OTA0XHU3NDA2XHU5MEZEXHU1RTk0XHU4QkU1IHBpcGUgXHU1MjMwXHU4RkQ5XHU5MUNDXHVGRjFBXG4gKiBgYGB0c1xuICogdHJhbnNwb3J0Lmludm9rZSguLi4pLnRoZW4oZGVzZXJpYWxpemVSZXN1bHQpXG4gKiBgYGBcbiAqXG4gKiBcdThGRDhcdTUzOUZcdTU0MEVcdTc2ODQgRXJyb3IgXHU0RjFBXHU1RTI2IGBuYW1lID0gJ1dCRXJyb3InYFx1RkYwQ1x1NEUxQVx1NTJBMVx1NUM0Mlx1NTNFRlx1NzUyOCBgZXJyLm5hbWUgPT09ICdXQkVycm9yJ2AgXHU2MjE2XG4gKiBgZXJyLmNvZGVgIFx1NTIyNFx1NjVBRFx1NjYyRlx1NTQyNlx1NEUzQVx1OERFOFx1OEZCOVx1NzU0Q1x1NEUxQVx1NTJBMVx1OTUxOVx1OEJFRlx1MzAwMlxuICovXG5leHBvcnQgZnVuY3Rpb24gZGVzZXJpYWxpemVSZXN1bHQocmVzdWx0OiB1bmtub3duKTogdW5rbm93biB7XG4gICAgaWYgKCFpc1NlcmlhbGl6ZWRCcmlkZ2VFcnJvcihyZXN1bHQpKSB7XG4gICAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgfVxuICAgIGNvbnN0IHsgbWVzc2FnZSwgY29kZSwgYml6Q29kZSwgc291cmNlLCBodHRwU3RhdHVzLCBkYXRhLCBheGlvcyB9ID0gcmVzdWx0O1xuICAgIGNvbnN0IGVyciA9IG5ldyBFcnJvcihtZXNzYWdlKSBhcyBFcnJvciAmIHtcbiAgICAgICAgY29kZT86IHN0cmluZztcbiAgICAgICAgYml6Q29kZT86IHN0cmluZyB8IG51bWJlcjtcbiAgICAgICAgc291cmNlPzogc3RyaW5nO1xuICAgICAgICBodHRwU3RhdHVzPzogbnVtYmVyO1xuICAgICAgICBkYXRhPzogdW5rbm93bjtcbiAgICAgICAgLy8gXHU4RkQ4XHU1MzlGIGF4aW9zIGVycm9yIFx1NzI3OVx1NUY4MVx1NUI1N1x1NkJCNSBcdTIwMTRcdTIwMTQgXHU4QkE5XHU4REU4XHU4RkI5XHU3NTRDXHU2RDg4XHU4RDM5XHU2NUI5XHU2MzA5IGF4aW9zIFx1NjBFRlx1NEY4Qlx1OEJCRlx1OTVFRVxuICAgICAgICByZXNwb25zZT86IHsgc3RhdHVzPzogbnVtYmVyOyBzdGF0dXNUZXh0Pzogc3RyaW5nOyBkYXRhPzogdW5rbm93biB9O1xuICAgICAgICBjb25maWc/OiB7IHVybD86IHN0cmluZzsgbWV0aG9kPzogc3RyaW5nIH07XG4gICAgICAgIGlzQXhpb3NFcnJvcj86IGJvb2xlYW47XG4gICAgfTtcbiAgICAvLyBcdTdFREZcdTRFMDAgbmFtZSBcdTRGQkZcdTRFOEVcdTRFMUFcdTUyQTFcdTVDNDJcdThCQzZcdTUyMkJcdThERThcdThGQjlcdTc1NENcdTRFMUFcdTUyQTFcdTk1MTlcdThCRUZcbiAgICBlcnIubmFtZSA9ICdXQkVycm9yJztcbiAgICBpZiAoY29kZSkge2Vyci5jb2RlID0gY29kZTt9XG4gICAgaWYgKGJpekNvZGUgIT09IHVuZGVmaW5lZCkge2Vyci5iaXpDb2RlID0gYml6Q29kZTt9XG4gICAgaWYgKHNvdXJjZSkge2Vyci5zb3VyY2UgPSBzb3VyY2U7fVxuICAgIGlmIChodHRwU3RhdHVzICE9PSB1bmRlZmluZWQpIHtlcnIuaHR0cFN0YXR1cyA9IGh0dHBTdGF0dXM7fVxuICAgIGlmIChkYXRhICE9PSB1bmRlZmluZWQpIHtlcnIuZGF0YSA9IGRhdGE7fVxuXG4gICAgLy8gXHUyNTAwXHUyNTAwIGF4aW9zIFx1N0VEM1x1Njc4NFx1OEZEOFx1NTM5RiBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcbiAgICAvLyBcdTYyOEEgYXhpb3MgZW52ZWxvcGUgXHU2MzAyXHU1NkRFIGVyci5yZXNwb25zZSAvIGVyci5jb25maWcgLyBlcnIuY29kZVx1RkYwQ1x1OEJBOVx1NEUxQVx1NTJBMVx1NUM0Mlx1NTE5OVx1NzY4NFxuICAgIC8vIGBjYXRjaCAoZXJyKSB7IGVyci5yZXNwb25zZT8uc3RhdHVzIH1gIFx1OERFOFx1OEZCOVx1NzU0Q1x1NTQwRVx1NEVDRFx1NTNFRlx1NzUyOFx1MzAwMlxuICAgIGlmIChheGlvcykge1xuICAgICAgICBpZiAoYXhpb3MucmVzcG9uc2UpIHtcbiAgICAgICAgICAgIGVyci5yZXNwb25zZSA9IHsgLi4uYXhpb3MucmVzcG9uc2UgfTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoYXhpb3MuY29uZmlnKSB7XG4gICAgICAgICAgICBlcnIuY29uZmlnID0geyAuLi5heGlvcy5jb25maWcgfTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoYXhpb3MuY29kZSAmJiAhZXJyLmNvZGUpIHtcbiAgICAgICAgICAgIGVyci5jb2RlID0gYXhpb3MuY29kZTtcbiAgICAgICAgfVxuICAgICAgICAvLyBcdTY4MDdcdThCQjAgYXhpb3MgZXJyb3IgXHU3Mjc5XHU1RjgxXHVGRjBDXHU0RTFBXHU1MkExXHU0RkE3XHU1M0VGXHU3NTI4IGBlcnIuaXNBeGlvc0Vycm9yYCBcdTUyMjRcdTVCOUEgXHUyMDE0XHUyMDE0IFx1OERERlx1NTM5Rlx1NzUxRlx1ODg0Q1x1NEUzQVx1NEUwMFx1ODFGNFxuICAgICAgICBlcnIuaXNBeGlvc0Vycm9yID0gdHJ1ZTtcbiAgICB9XG5cbiAgICB0aHJvdyBlcnI7XG59XG4iLCAiLy8gVE9ETzogXHU2QjY0XHU3QzdCXHU1NzhCXHU2NTg3XHU0RUY2XHU1REYyXHU4RDg1XHU4RkM3IDI1MCBcdTg4NENcdUZGMENcdTgwMDNcdTg2NTFcdTYyQzZcdTUyMDZcdTU3RkFcdTc4NDBcdTRFOEJcdTRFRjZcdTRFMEUgUmVxdWVzdCBcdTRFOEJcdTRFRjZcdThGN0RcdTgzNzdcdTMwMDJcbi8qKiBUeXBlZCBDb252ZXJzYXRpb24gZXZlbnQgbmFtZXMsIHBheWxvYWRzLCBhbmQgY2FsbGJhY2sgc2lnbmF0dXJlcy4gKi9cblxuaW1wb3J0IHR5cGUge1xuICAgIEJsb2NrLFxuICAgIENvbnZlcnNhdGlvblR1cm5JbnRlcnJ1cHRpb24sXG4gICAgUGVuZGluZ1JlcXVlc3QsXG4gICAgUmVxdWVzdCxcbiAgICBSZXF1ZXN0TW9kZWxJbmZvLFxuICAgIFVzYWdlLFxuICAgIFVzYWdlQnlDYXRlZ29yeSxcbiAgICBVc2FnZUNvc3QsXG4gICAgVXNhZ2VFc3RpbWF0ZSxcbiAgICBXYXJuaW5nSW5mbyxcbn0gZnJvbSAnLi9jb252ZXJzYXRpb24tc3VwcG9ydC10eXBlcyc7XG5pbXBvcnQgdHlwZSB7IENvbnZlcnNhdGlvblRlcm1pbmFsRXJyb3IgfSBmcm9tICcuL2NvbnZlcnNhdGlvbi10ZXJtaW5hbC1lcnJvcic7XG5pbXBvcnQgdHlwZSB7XG4gICAgQ29udmVyc2F0aW9uQ2xvdWRTZXJ2aWNlQ29uZmlybWF0aW9uLFxuICAgIENvbnZlcnNhdGlvbkluZm8sXG4gICAgQ29udmVyc2F0aW9uUGx1Z2luUmVjb21tZW5kYXRpb24sXG4gICAgQ29udmVyc2F0aW9uUHJvbXB0UmVzcG9uc2VNZXRhLFxuICAgIENvbnZlcnNhdGlvblN0YXRlLFxuICAgIENvbnZlcnNhdGlvblR1cm5SZXN1bHQsXG59IGZyb20gJy4vZW50aXR5LXR5cGVzJztcbmltcG9ydCB0eXBlIHsgQ2FwYWNpdHlRdWV1ZVNuYXBzaG90IH0gZnJvbSAnLi9tb2RlbC9jYXBhY2l0eS1xdWV1ZSc7XG5pbXBvcnQgdHlwZSB7IFBlcnNpc3RlZFl1YW5iYW9Ub29sVHJhY2UgfSBmcm9tICcuL21vZGVsL3JlcXVlc3QtcHJvamVjdGlvbi95dWFuYmFvLXRvb2wtdHJhY2UtbWV0YSc7XG5pbXBvcnQgdHlwZSB7IEZpbmFsUmVxdWVzdFN0YXRlIH0gZnJvbSAnLi9tb2RlbC9zdGF0ZS1tYWNoaW5lJztcblxuLyoqIFx1OTk5Nlx1OEY2RSBNQ1AgXHU2NzBEXHU1MkExXHU4RkRFXHU2M0E1XHU3Njg0XHU1MzU1XHU2NzBEXHU1MkExXHU3MkI2XHU2MDAxXHUzMDAyICovXG5leHBvcnQgdHlwZSBDb252ZXJzYXRpb25NY3BTdGFydHVwU2VydmVyU3RhdGUgPSAnY29ubmVjdGluZycgfCAncmVhZHknIHwgJ2ZhaWxlZCcgfCAndGltZW91dCc7XG5cbi8qKiBBQ1AgXHU5OTk2XHU4RjZFIE1DUCBcdThGREVcdTYzQTVcdThGREJcdTVFQTZcdTU3MjggQ29udmVyc2F0aW9uIFx1NUM0Mlx1NzY4NFx1N0M3Qlx1NTc4Qlx1NTMxNlx1NEU4Qlx1NEVGNlx1MzAwMiAqL1xuZXhwb3J0IHR5cGUgQ29udmVyc2F0aW9uTWNwU3RhcnR1cFN0YXR1cyA9XG4gICAgfCB7XG4gICAgICAgIHJlYWRvbmx5IGtpbmQ6ICdzdGFydCc7XG4gICAgICAgIHJlYWRvbmx5IHNlcnZlcnM6IHJlYWRvbmx5IHN0cmluZ1tdO1xuICAgICAgICByZWFkb25seSB0b3RhbENvdW50OiBudW1iZXI7XG4gICAgfVxuICAgIHwge1xuICAgICAgICByZWFkb25seSBraW5kOiAnc2VydmVyJztcbiAgICAgICAgcmVhZG9ubHkgbmFtZTogc3RyaW5nO1xuICAgICAgICByZWFkb25seSBzdGF0ZTogQ29udmVyc2F0aW9uTWNwU3RhcnR1cFNlcnZlclN0YXRlO1xuICAgICAgICByZWFkb25seSBlcnJvcj86IHN0cmluZztcbiAgICAgICAgcmVhZG9ubHkgY29tcGxldGVkOiBudW1iZXI7XG4gICAgICAgIHJlYWRvbmx5IHRvdGFsOiBudW1iZXI7XG4gICAgfVxuICAgIHwge1xuICAgICAgICByZWFkb25seSBraW5kOiAnZmluaXNoJztcbiAgICAgICAgcmVhZG9ubHkgZmFpbGVkOiByZWFkb25seSBzdHJpbmdbXTtcbiAgICAgICAgcmVhZG9ubHkgdGltZWRPdXQ6IHJlYWRvbmx5IHN0cmluZ1tdO1xuICAgIH07XG5cbi8qKlxuICogQ29udmVyc2F0aW9uIFx1NEU4Qlx1NEVGNlx1Njc5QVx1NEUzRVx1RkYwOFx1N0VERlx1NEUwMFx1OEJBMlx1OTYwNVx1NTE2NVx1NTNFMyB7QGxpbmsgQ29udmVyc2F0aW9uLm9ufSBcdTc2ODQga2V5XHVGRjA5XHUzMDAyXG4gKi9cbmV4cG9ydCBlbnVtIENvbnZlcnNhdGlvbkV2ZW50IHtcbiAgICAvKiogXHU2RDQxXHU1RjBGIG5vdGlmaWNhdGlvblx1RkYxQWAocmVxdWVzdElkLCBtZXNzYWdlSWQsIGNodW5rLCBwYXRjaGVzKWBcdUZGMUJcdTZEODhcdTYwNkZcdTYyOTVcdTVGNzFcdTRFRTUgdHlwZWQgcGF0Y2hlcyBcdTRFM0FcdTUxQzZcdTMwMDIgKi9cbiAgICBSZXF1ZXN0VXBkYXRlID0gJ3JlcXVlc3RVcGRhdGUnLFxuICAgIC8qKiBcdTRGMUFcdThCRERcdTcyQjZcdTYwMDFcdTY3M0FcdTUzRDhcdThGQzFcdUZGMUFgKGZyb20sIHRvLCBmaW5hbFN0YXRlPylgXHUzMDAyICovXG4gICAgU3RhdGVDaGFuZ2UgPSAnc3RhdGVDaGFuZ2UnLFxuICAgIC8qKlxuICAgICAqIFx1NEYxQVx1OEJERFx1NTE0M1x1NEZFMVx1NjA2Rlx1RkYwOHRpdGxlIFx1N0I0OSoqXHU5NzVFIHN0YXRlIFx1NUI1N1x1NkJCNSoqXHVGRjA5XHU1M0Q4XHU1MzE2XHVGRjFBYChpbmZvKWBcdUZGMENcdTRGMjBcdTUzRDhcdTUzMTZcdTU0MEVcdTc2ODRcdTVCOENcdTY1NzQgYENvbnZlcnNhdGlvbkluZm9gIFx1NUZFQlx1NzE2N1x1MzAwMlxuICAgICAqXG4gICAgICogXHU0RTBFIHtAbGluayBTdGF0ZUNoYW5nZX0gXHU4OUUzXHU4MDI2XHVGRjFBc3RhdGUgXHU4RDcwXHU3MkI2XHU2MDAxXHU2NzNBIFN0YXRlQ2hhbmdlXHVGRjBDdGl0bGUgXHU3QjQ5XHU5NzU5XHU2MDAxXHU1MTQzXHU0RkUxXHU2MDZGXHU4RDcwXHU2NzJDXHU0RThCXHU0RUY2XHVGRjBDXG4gICAgICogXHU5MDdGXHU1MTREXHU2MjhBIHRpdGxlIFx1NTg1RVx1OEZEQiBTdGF0ZUNoYW5nZSBwYXlsb2FkIFx1NUJGQ1x1ODFGNFx1OEJFRFx1NEU0OVx1NkRGN1x1Njc0Mlx1RkYwOFx1NTk4MiBDTEkgdHVybiBcdTdFRDNcdTY3NUZcdTYzQThcdTkwMDFcdTY4MDdcdTk4OThcdTY2RjRcdTY1QjBcdUZGMDlcdTMwMDJcbiAgICAgKi9cbiAgICBJbmZvQ2hhbmdlID0gJ2luZm9DaGFuZ2UnLFxuICAgIC8qKiBcdTk2MUZcdTUyMTdcdTUzRDhcdTUzMTZcdUZGMDhcdTY1RTAgcGF5bG9hZFx1RkYwOVx1MzAwMiAqL1xuICAgIFF1ZXVlVXBkYXRlID0gJ3F1ZXVlVXBkYXRlJyxcbiAgICAvKiogXHU2NzBEXHU1MkExXHU3QUVGXHU1QkI5XHU5MUNGXHU2MzkyXHU5NjFGXHU3MkI2XHU2MDAxXHU1M0Q4XHU1MzE2XHVGRjFBYChzbmFwc2hvdClgXHUzMDAyICovXG4gICAgQ2FwYWNpdHlRdWV1ZVVwZGF0ZSA9ICdjYXBhY2l0eVF1ZXVlVXBkYXRlJyxcbiAgICAvKiogXHU0RUE3XHU3MjY5XHU1M0Q4XHU1MzE2XHVGRjA4XHU2NUUwIHBheWxvYWRcdUZGMDlcdTMwMDIgKi9cbiAgICBBcnRpZmFjdFVwZGF0ZSA9ICdhcnRpZmFjdFVwZGF0ZScsXG4gICAgLyoqXG4gICAgICogQWdlbnQgXHU2MjY5XHU1QzU1XHU1MzU1XHU1NDExXHU5MDFBXHU3N0U1XHU3Njg0XHU0RTFBXHU1MkExXHU1MUZBXHU1M0UzXHVGRjFBXHU0RUM1XHU2MjdGXHU2M0E1IGNoZWNrcG9pbnQgLyBjb21tYW5kIC8gYXV0aFVybFx1MzAwMlxuICAgICAqIFx1NTZERVx1OEMwM1x1NjNBNVx1NjUzNiBDb252ZXJzYXRpb24gXHU4QkVEXHU0RTQ5XHU2NzlBXHU0RTNFXHU0RTBFXHU1QkY5XHU1RTk0XHU0RTFBXHU1MkExXHU1M0MyXHU2NTcwXHVGRjBDXHU0RTBEXHU2NkI0XHU5NzMyIEFDUCBtZXRob2QgXHU2MjE2IHRyYW5zcG9ydCBcdTVCNTdcdTZCQjVcdTMwMDJcbiAgICAgKiBgYXJ0aWZhY3RgIFx1NEZERFx1NjMwMVx1NzJFQ1x1N0FDQlx1NzY4NCBBcnRpZmFjdFVwZGF0ZSBcdTYyOTVcdTVGNzFcdUZGMUJyZXF1ZXN0L3Jlc3BvbnNlIFx1NTc4Qlx1NjI2OVx1NUM1NVx1NEUwRFx1NUM1RVx1NEU4RVx1NkI2NFx1NEU4Qlx1NEVGNlx1MzAwMlxuICAgICAqL1xuICAgIEV4dGVuc2lvbk1ldGhvZCA9ICdleHRlbnNpb25NZXRob2QnLFxuICAgIC8qKiBcdTU0NEFcdThCNjZcdUZGMDhcdTU5ODIgd29ya2VyIFx1NjVFMFx1NTRDRFx1NUU5NFx1ODlDMlx1NkQ0Qlx1RkYwOVx1RkYxQWAoaW5mbylgXHVGRjBDKipcdTRFMERcdTY1MzkqKiBDb252ZXJzYXRpb25TdGF0ZVx1MzAwMiAqL1xuICAgIFdhcm5pbmcgPSAnd2FybmluZycsXG4gICAgLyoqXG4gICAgICogd29ya2VyIGxhdW5jaC1zcGVjIC8gTUNQIHJlc29sdmUgXHU1MUM2XHU1OTA3XHU2MDAxXHVGRjFBYChzdGF0dXMpYFx1MzAwMlxuICAgICAqIGBzdGF0dXNgIFx1NEUzQVx1NTE3N1x1NEY1M1x1OTYzNlx1NkJCNVx1NEUwRVx1NjcwRFx1NTJBMVx1NTQwRFx1RkYxQmBudWxsYCBcdTg4NjhcdTc5M0FcdTZFMDVcdTk2NjRcdUZGMDhyZXNvbHZlIFx1N0VEM1x1Njc1Rlx1RkYwOVx1MzAwMlx1NEUwRFx1NjUzOSBDb252ZXJzYXRpb25TdGF0ZVx1MzAwMlxuICAgICAqL1xuICAgIFByZXBhcmVTdGF0dXMgPSAncHJlcGFyZVN0YXR1cycsXG4gICAgLyoqXG4gICAgICogXHU5OTk2XHU4RjZFIE1DUCBcdTY3MERcdTUyQTFcdThGREVcdTYzQTVcdThGREJcdTVFQTZcdUZGMUFgKHN0YXR1cylgXHUzMDAyXG4gICAgICpcbiAgICAgKiBcdTc1MzEgQUNQIGBzZXNzaW9uX2luZm9fdXBkYXRlLl9tZXRhWydjb2RlYnVkZHkuYWkvbWNwRmlyc3RSdW5TdGF0dXMnXWAgXHU1RjUyXHU0RTAwXHU1MzE2XHVGRjBDXG4gICAgICogXHU0RUM1XHU2M0NGXHU4RkYwXHU0RTM0XHU2NUY2XHU1NDJGXHU1MkE4XHU4RkRCXHU1RUE2XHVGRjBDXHU0RTBEXHU4RkRCXHU1MTY1IFJlcXVlc3QgXHU2MjE2XHU1Mzg2XHU1M0YyXHU2RDg4XHU2MDZGXHUzMDAyXG4gICAgICovXG4gICAgTWNwU3RhcnR1cFN0YXR1cyA9ICdtY3BTdGFydHVwU3RhdHVzJyxcbiAgICAvKipcbiAgICAgKiBcdTUzRUZcdTc1MjhcdTY1OUNcdTY3NjBcdTU0N0RcdTRFRTQvc2tpbGwgXHU1MjE3XHU4ODY4XHU1M0Q4XHU1MzE2XHVGRjFBYChjb21tYW5kcylgXHUzMDAyXG4gICAgICogQ0xJIFx1NjNBOFx1OTAwMSBgYXZhaWxhYmxlX2NvbW1hbmRzX3VwZGF0ZWAgXHU2NUY2XHU4OUU2XHU1M0QxXHVGRjBDVUkgXHU0RkE3XHU2MzZFXHU2QjY0XHU1MjM3XHU2NUIwXHU4RjkzXHU1MTY1XHU2ODQ2XHU4MUVBXHU1MkE4XHU4ODY1XHU1MTY4XHUzMDAyXG4gICAgICovXG4gICAgQ29tbWFuZHNVcGRhdGUgPSAnY29tbWFuZHNVcGRhdGUnLFxuICAgIC8qKlxuICAgICAqIFx1NUY1M1x1NTI0RFx1Njc0M1x1OTY1MFx1NkEyMVx1NUYwRlx1NTNEOFx1NTMxNlx1RkYxQWAobW9kZSlgXHUzMDAyXG4gICAgICogQ0xJIFx1NjNBOFx1OTAwMSBgY3VycmVudF9tb2RlX3VwZGF0ZWAgXHU2NUY2XHU4OUU2XHU1M0QxXHVGRjBDVUkgXHU2MzZFXHU2QjY0XHU1MjM3XHU2NUIwXHU1RjUzXHU1MjREXHU2QTIxXHU1RjBGXHU2ODA3XHU3QjdFXHUzMDAyXG4gICAgICovXG4gICAgTW9kZUNoYW5nZSA9ICdtb2RlQ2hhbmdlJyxcbiAgICAvKipcbiAgICAgKiBcdTkxNERcdTdGNkVcdTkwMDlcdTk4NzlcdTUzRDhcdTUzMTZcdUZGMUFgKG9wdGlvbnMpYFx1MzAwMlxuICAgICAqIENMSSBcdTYzQThcdTkwMDEgYGNvbmZpZ19vcHRpb25fdXBkYXRlYCBcdTY1RjZcdTg5RTZcdTUzRDFcdTMwMDJcbiAgICAgKi9cbiAgICBDb25maWdVcGRhdGUgPSAnY29uZmlnVXBkYXRlJyxcbiAgICAvKipcbiAgICAgKiBcdTUzRUZcdTc1MjhcdTZBMjFcdTU3OEJcdTUyMTdcdTg4NjggKyBcdTVGNTNcdTUyNERcdTZBMjFcdTU3OEJcdTUzRDhcdTUzMTZcdUZGMUFgKHVwZGF0ZSlgXHUzMDAyXG4gICAgICogQ0xJIFx1NjNBOFx1OTAwMSBgbW9kZWxfdXBkYXRlYCBcdTY1RjZcdTg5RTZcdTUzRDFcdUZGMENVSSBcdTYzNkVcdTZCNjRcdTUyMzdcdTY1QjBcdTZBMjFcdTU3OEJcdTkwMDlcdTYyRTlcdTU2NjhcdTMwMDJcbiAgICAgKi9cbiAgICBNb2RlbENoYW5nZSA9ICdtb2RlbENoYW5nZScsXG4gICAgLyoqIGNvbXBhY3QgLyBzZXNzaW9uIGJvdW5kYXJ5IFx1N0I0OVx1OTc1RSBSZXF1ZXN0IFx1NjVGNlx1OTVGNFx1N0VCRlx1NEU4Qlx1NUI5RVx1MzAwMiAqL1xuICAgIFRpbWVsaW5lRXZlbnQgPSAndGltZWxpbmVFdmVudCcsXG4gICAgLyoqXG4gICAgICogXHU1M0VGXHU3NTI4XHU2QTIxXHU1RjBGXHU1MjE3XHU4ODY4XHU1M0Q4XHU1MzE2XHVGRjFBYChtb2RlcylgXHUzMDAyXG4gICAgICogQ0xJIFx1NjNBOFx1OTAwMSBgbW9kZV91cGRhdGVgIFx1NjVGNlx1ODlFNlx1NTNEMVx1RkYwQ1VJIFx1NjM2RVx1NkI2NFx1NTIzN1x1NjVCMFx1NkEyMVx1NUYwRlx1OTAwOVx1NjJFOVx1NTY2OFx1NTNFRlx1OTAwOVx1NTIxN1x1ODg2OFx1MzAwMlxuICAgICAqL1xuICAgIE1vZGVzVXBkYXRlID0gJ21vZGVzVXBkYXRlJyxcbiAgICAvKipcbiAgICAgKiBUT0RPIFx1OEJBMVx1NTIxMlx1NjZGNFx1NjVCMFx1RkYxQWAocGxhbilgXHUzMDAyXG4gICAgICogQ0xJIFx1NjNBOFx1OTAwMSBgcGxhbmAgc2Vzc2lvblVwZGF0ZSBcdTY1RjZcdTg5RTZcdTUzRDFcdUZGMENVSSBcdTYzNkVcdTZCNjRcdTZFMzJcdTY3RDMgcGxhbi90b2RvIFx1OTc2Mlx1Njc3Rlx1MzAwMlxuICAgICAqL1xuICAgIFBsYW5VcGRhdGUgPSAncGxhblVwZGF0ZScsXG4gICAgLyoqXG4gICAgICogXHU2NzQzXHU5NjUwL1x1OTVFRVx1N0I1NFx1NjMwMlx1OEQ3N1x1OEJGN1x1NkM0Mlx1RkYxQWAocGVuZGluZ1JlcXVlc3QpYFx1MzAwMlxuICAgICAqXG4gICAgICogKipkYWVtb24gXHU1MTg1XHU5MEU4XHU2NzNBXHU1MjM2KipcdUZGMENcdTRGOUIgYENvbnZlcnNhdGlvblBvb2xgIFx1OEY2Q1x1NTNEMVx1NTIzMCBldmVudEJ1cyBcdTc1MjhcdTMwMDJVSSBcdTRGQTcqKlx1NEUwRFx1OEJBMlx1OTYwNSoqXHU2QjY0XHU0RThCXHU0RUY2XG4gICAgICogXHVGRjA4XHU1NDBFXHU1M0YwXHU1M0VGXHU4MEZEXHU2NTM2XHU0RTBEXHU1MjMwIHB1c2hcdUZGMDlcdUZGMENcdTY1MzlcdTc1MjggcHVsbCBcdTZBMjFcdTVGMEYgYGdldFBlbmRpbmdJbmZvKClgXHUzMDAyXG4gICAgICogQGludGVybmFsXG4gICAgICovXG4gICAgUGVuZGluZ1JlcXVlc3QgPSAncGVuZGluZ1JlcXVlc3QnLFxuICAgIC8qKlxuICAgICAqIFx1NEVBN1x1NTRDMVx1N0VBNyBQbHVnaW4vRXhwZXJ0IFx1NjNBOFx1ODM1MFx1NUZFQlx1NzE2N1x1NTNEOFx1NTMxNlx1RkYxQWAocmVjb21tZW5kYXRpb24pYFx1MzAwMlxuICAgICAqIGB1bmRlZmluZWRgIFx1ODg2OFx1NzkzQVx1NUY1M1x1NTI0RFx1NjNBOFx1ODM1MFx1NURGMlx1N0VEM1x1N0I5N1x1RkYxQlx1NUJGOVx1NUU5NFx1NzY4NFx1NUY4NVx1Nzg2RVx1OEJBNFx1NzJCNlx1NjAwMVx1NzUzMSBTdGF0ZUNoYW5nZSBcdTU0MENcdTZCNjVcdTMwMDJcbiAgICAgKi9cbiAgICBQbHVnaW5SZWNvbW1lbmRhdGlvbkNoYW5nZWQgPSAncGx1Z2luUmVjb21tZW5kYXRpb25DaGFuZ2VkJyxcbiAgICAvKiogXHU0RTkxXHU2NzBEXHU1MkExXHU1RjAwXHU5MDFBXHU1M0VGXHU0RkUxXHU3ODZFXHU4QkE0XHU2Mjk1XHU1RjcxXHU1M0Q4XHU1MzE2XHVGRjFCdW5kZWZpbmVkIFx1ODg2OFx1NzkzQVx1NURGMlx1N0VEM1x1N0I5N1x1MzAwMiAqL1xuICAgIENsb3VkU2VydmljZUNvbmZpcm1hdGlvbkNoYW5nZWQgPSAnY2xvdWRTZXJ2aWNlQ29uZmlybWF0aW9uQ2hhbmdlZCcsXG4gICAgLyoqXG4gICAgICogXHU1Mzg2XHU1M0YyXHU1NkRFXHU2NTNFXHVGRjA4YHNlc3Npb24vbG9hZGBcdUZGMDlcdTVCOENcdTYyMTBcdTRGRTFcdTUzRjdcdUZGMDhcdTY1RTAgcGF5bG9hZFx1RkYwOVx1MzAwMlxuICAgICAqXG4gICAgICogXHU4ODY4XHU3OTNBXHU1NkRFXHU2NTNFXHU1REYyXHU4NDNEXHU1NzMwXHU0RTNBXHU3RUM4XHU2MDAxXHVGRjA4YGVuZEhpc3RvcnlSZXBsYXlgIFx1NURGMlx1NUI4Q1x1NjIxMCB1bnNoaWZ0L1x1NjM5Mlx1NUU4Rlx1RkYwOVx1MzAwMlx1NUM1RSoqXHU1MTg1XHU5MEU4XHU5MUNDXHU3QTBCXHU3ODkxXHU0RkUxXHU1M0Y3KipcdUZGMENcbiAgICAgKiBcdTRFNUZcdTY2MkYge0BsaW5rIFJlcXVlc3RzQ2hhbmdlZH0gXHU3Njg0XHU4OUU2XHU1M0QxXHU3MEI5XHU0RTRCXHU0RTAwXHUzMDAyVUkgXHU0RkE3XHU0RTAwXHU4MjJDXHU3NkY0XHU2M0E1XHU2RDg4XHU4RDM5IHtAbGluayBSZXF1ZXN0c0NoYW5nZWR9XG4gICAgICogXHU2MkZGXHU1MTY4XHU5MUNGXHU1MjE3XHU4ODY4XHVGRjBDXHU0RTBEXHU1RkM1XHU1MzU1XHU3MkVDXHU4QkEyXHU5NjA1XHU2NzJDXHU0RThCXHU0RUY2XHUzMDAyXG4gICAgICovXG4gICAgSGlzdG9yeUxvYWRlZCA9ICdoaXN0b3J5TG9hZGVkJyxcbiAgICAvKipcbiAgICAgKiAqKlx1NTE2OFx1OTFDRiBSZXF1ZXN0IFx1NTIxN1x1ODg2OFx1NUZFQlx1NzE2N1x1NTNEOFx1NjZGNCoqXHVGRjFBYChyZXF1ZXN0cylgXHVGRjBDXHU2NDNBXHU1RTI2XHU1RjUzXHU1MjREXHU0RjFBXHU4QkREXHU1QjhDXHU2NTc0XHU3Njg0IGBSZXF1ZXN0W11gXHUzMDAyXG4gICAgICpcbiAgICAgKiBcdTc1MjhcdTkwMTRcdUZGMUFcdTg5RTNcdTUxQjNcdTMwMENcdTU5MUFcdTc2RDFcdTU0MkNcdTdBN0FcdTdBOTdcdTY3MUZcdTMwMERcdTRFMTQqKlx1NjVFMFx1OTcwMCBVSSBcdTYyRkMgY2h1bmsgLyBcdTYyNEJcdTUyQThcdTg4NjVcdTYyQzkqKlx1MjAxNFx1MjAxNFNESyBcdTUxODVcdTkwRThcdTU3MjgqKlx1OTFDQ1x1N0EwQlx1Nzg5MSoqXG4gICAgICogXHVGRjA4XHU1Mzg2XHU1M0YyXHU1NkRFXHU2NTNFXHU4NDNEXHU1NzMwIC8gdHVybiBcdTdFQzhcdTYwMDFcdTVCOENcdTdFRDNcdUZGMDlcdTY1RjZcdTgxRUFcdTUyQThcdTUxQkJcdTdFRDNcdTUxNjhcdTkxQ0ZcdTVGRUJcdTcxNjdcdTVFNzZcdTZEM0VcdTUzRDFcdTMwMDJcdTZEODhcdThEMzlcdTY1QjlcdUZGMDhcdTU0MkJcdTU0MEVcdTY3NjVcdTYyNTNcdTVGMDBcdTU0MENcdTRFMDBcbiAgICAgKiBcdTRGMUFcdThCRERcdTc2ODRcdTk4NzVcdTk3NjJcdUZGMDlcdTY1MzZcdTUyMzBcdTUzNzNcdTYyRkZcdTUyMzAqKlx1NUI4Q1x1NjU3NFx1N0VDOFx1NjAwMVx1NTIxN1x1ODg2OCoqXHVGRjBDXHU3NkY0XHU2M0E1XHU2NTc0XHU0RjUzXHU2NkZGXHU2MzYyXHU2RTMyXHU2N0QzXHVGRjBDXHU1OTI5XHU3MTM2XHU0RTBEXHU2RjBGXHU1Mzg2XHU1M0YyXHUzMDAxXHU2NUUwXHU3QTdBXHU3QTk3XHUzMDAyXG4gICAgICpcbiAgICAgKiBcdTRFMEUge0BsaW5rIFJlcXVlc3RVcGRhdGV9IFx1NzY4NFx1NTIwNlx1NURFNVx1RkYxQVJlcXVlc3RVcGRhdGUgXHU2NjJGKipcdTlBRDhcdTk4OTFcdTVCOUVcdTY1RjZcdTU4OUVcdTkxQ0YgY2h1bmsqKlx1RkYwOFx1NjJGQ1x1NkQ0MVx1NUYwRlx1NkUzMlx1NjdEM1x1RkYwOVx1RkYxQlxuICAgICAqIFJlcXVlc3RzQ2hhbmdlZCBcdTY2MkYqKlx1NEY0RVx1OTg5MVx1OTFDQ1x1N0EwQlx1Nzg5MVx1NTE2OFx1OTFDRlx1NUZFQlx1NzE2NyoqXHVGRjA4XHU2NTc0XHU0RjUzXHU1QkY5XHU4RDI2XHVGRjA5XHUzMDAyVUkgXHU1M0VGXHU0RThDXHU5MDA5XHU0RTAwXHU2MjE2XHU1RTc2XHU3NTI4XHVGRjA4XHU1MTY4XHU5MUNGXHU2NkZGXHU2MzYyICtcbiAgICAgKiBcdTU4OUVcdTkxQ0ZcdTdFRURcdTYzQTVcdUZGMDlcdTMwMDJTREsgKipcdTRFMERcdTU3MjhcdTZCQ0ZcdTRFMkEgY2h1bmsqKiBcdTRFMEFcdTZEM0VcdTUzRDEgUmVxdWVzdHNDaGFuZ2VkXHVGRjBDXHU5MDdGXHU1MTREIElQQyBcdThGN0RcdTgzNzdcdTY1M0VcdTU5MjdcdTMwMDJcbiAgICAgKi9cbiAgICBSZXF1ZXN0c0NoYW5nZWQgPSAncmVxdWVzdHNDaGFuZ2VkJyxcbiAgICAvKiogXHU2MzA3XHU1QjlBIFJlcXVlc3QgXHU3Njg0XHU1QjlFXHU5NjQ1XHU3RDJGXHU4QkExIENyZWRpdCBcdTUzRDhcdTUzMTZcdUZGMUFgKHBheWxvYWQpYFx1MzAwMiAqL1xuICAgIENyZWRpdENoYW5nZWQgPSAnY3JlZGl0Q2hhbmdlZCcsXG4gICAgLyoqXG4gICAgICogKipcdTRGMUFcdThCRERcdTdFQTdcdTRFMEFcdTRFMEJcdTY1ODdcdTc1MjhcdTkxQ0ZcdTVGRUJcdTcxNjdcdTUzRDhcdTY2RjQqKlx1RkYxQWAocGF5bG9hZClgXHUzMDAyXG4gICAgICpcbiAgICAgKiBcdTRFMEUge0BsaW5rIENyZWRpdENoYW5nZWR9IFx1NzY4NFx1NTIwNlx1NURFNVx1RkYxQUNyZWRpdENoYW5nZWQgXHU2NjJGICoqUmVxdWVzdCBcdTdFRjRcdTVFQTZcdTc2ODRcdThCQTFcdThEMzkqKlx1NEU4Qlx1NUI5RVx1RkYxQlx1NjcyQ1x1NEU4Qlx1NEVGNlx1NjYyRlxuICAgICAqICoqXHU0RjFBXHU4QkREXHU3RUY0XHU1RUE2XHU3Njg0XHU0RTBBXHU0RTBCXHU2NTg3XHU1MzYwXHU3NTI4KipcdTRFOEJcdTVCOUVcdUZGMENcdTUzRUFcdTY0M0FcdTVFMjYgdG9rZW4gLyBjb250ZXh0V2luZG93IC8gYnlDYXRlZ29yeVx1RkYwQyoqXHU0RTBEXHU1NDJCIGNvc3QqKlx1RkYwQ1xuICAgICAqIFx1NEUwRFx1NTNDMlx1NEUwRVx1NEVGQlx1NEY1NVx1OEJBMVx1OEQzOVx1NTNFM1x1NUY4NFx1MzAwMlxuICAgICAqXG4gICAgICogXHU1QjU4XHU1NzI4XHU1MzlGXHU1NkUwXHVGRjFBYHVzYWdlX3VwZGF0ZWAgXHU1M0VGXHU4MEZEXHU1NzI4IHR1cm4gXHU3RUM4XHU2MDAxXHU0RTRCXHU1NDBFXHU4RkRGXHU1MjMwXHVGRjA4Q0xJIFx1NEU4RSBgcmVzdW1lX3Nlc3Npb25gIC9cbiAgICAgKiBgbG9hZF9zZXNzaW9uYCBcdTg4NjVcdTYzQThcdUZGMDlcdUZGMENcdTZCNjRcdTY1RjZcdTY1RTJcdTY1RTAgYGN1cnJlbnRSZXF1ZXN0SWRgXHUzMDAxXHU1RTI3XHU0RTBBXHU0RTVGXHU2Q0ExXHU2NzA5IHJlcXVlc3RJZFx1RkYwQ1x1NjVFMFx1NkNENVx1NUY1Mlx1NUM1RVx1NTIzMFxuICAgICAqIFx1NEVGQlx1NEY1NSBSZXF1ZXN0XHVGRjFCXHU4MDBDXHU1QjgzXHU2NjJGIGB1c2FnZUJ5Q2F0ZWdvcnlgXHVGRjA4XHU3NTI4XHU5MUNGXHU2NjBFXHU3RUM2XHVGRjA5XHU3Njg0XHU1NTJGXHU0RTAwXHU2NzY1XHU2RTkwXHUzMDAyXHU4RkQ5XHU3QzdCXHU1RTI3XHU0RTBEXHU0RjFBXHU2RDNFXHU1M0QxXG4gICAgICoge0BsaW5rIFJlcXVlc3RVcGRhdGV9XHVGRjA4YHVzYWdlX3VwZGF0ZWAgXHU0RTBEXHU1QzVFIHJlcXVlc3QgY29udGVudFx1RkYwQ1x1NEUxNFx1Nzk4MVx1NkI2Mlx1NEYyQVx1OTAyMCByZXF1ZXN0SWRcbiAgICAgKiBcdTRFRTVcdTUxNERcdTRFQTdcdTc1MUZcdTVFN0RcdTcwNzUgQXNzaXN0YW50XHVGRjA5XHVGRjBDXHU2NTQ1XHU1MzU1XHU1RjAwXHU0RjFBXHU4QkREXHU3RUY0XHU1RUE2XHU0RThCXHU0RUY2XHU2MjdGXHU4RjdEXHVGRjBDXHU2RDg4XHU4RDM5XHU2NUI5XHU2MzA5XHU0RjFBXHU4QkREXHU4QkEyXHU5NjA1XHU1MzczXHU1M0VGXHUzMDAyXG4gICAgICovXG4gICAgQ29udGV4dFVzYWdlQ2hhbmdlZCA9ICdjb250ZXh0VXNhZ2VDaGFuZ2VkJyxcbiAgICAvKiogXHU2MzA3XHU1QjlBIFJlcXVlc3QgXHU3Njg0XHU5ODg0XHU4QkExXHU2MDNCXHU2RDg4XHU4MDE3XHU1MzNBXHU5NUY0XHU1M0Q4XHU1MzE2XHVGRjFBYChwYXlsb2FkKWBcdTMwMDIgKi9cbiAgICBFc3RpbWF0ZWRDb3N0Q2hhbmdlZCA9ICdlc3RpbWF0ZWRDb3N0Q2hhbmdlZCcsXG4gICAgLyoqIFx1ODFFQVx1NTJBOFx1NTMxNiBSZXF1ZXN0IFx1NjIxMFx1NTI5Rlx1N0VDOFx1N0VEM1x1MzAwMiAqL1xuICAgIEF1dG9tYXRpb25Db21wbGV0ZWQgPSAnYXV0b21hdGlvbkNvbXBsZXRlZCcsXG4gICAgLyoqIFx1ODFFQVx1NTJBOFx1NTMxNiBSZXF1ZXN0IFx1NTkzMVx1OEQyNVx1N0VDOFx1N0VEM1x1MzAwMiAqL1xuICAgIEF1dG9tYXRpb25GYWlsZWQgPSAnYXV0b21hdGlvbkZhaWxlZCcsXG4gICAgLyoqIFx1ODFFQVx1NTJBOFx1NTMxNiBSZXF1ZXN0IFx1ODhBQlx1NjYzRVx1NUYwRlx1NTNENlx1NkQ4OFx1MzAwMiAqL1xuICAgIEF1dG9tYXRpb25DYW5jZWxsZWQgPSAnYXV0b21hdGlvbkNhbmNlbGxlZCcsXG4gICAgLyoqIFx1ODFFQVx1NTJBOFx1NTMxNiBSZXF1ZXN0IFx1OEQ4NVx1NjVGNlx1NUU3Nlx1ODlFNlx1NTNEMVx1NTNENlx1NkQ4OFx1MzAwMiAqL1xuICAgIEF1dG9tYXRpb25UaW1lZE91dCA9ICdhdXRvbWF0aW9uVGltZWRPdXQnLFxufVxuXG5leHBvcnQgY29uc3QgQ29udmVyc2F0aW9uQXV0b21hdGlvbkV2ZW50ID0ge1xuICAgIENvbXBsZXRlZDogQ29udmVyc2F0aW9uRXZlbnQuQXV0b21hdGlvbkNvbXBsZXRlZCxcbiAgICBGYWlsZWQ6IENvbnZlcnNhdGlvbkV2ZW50LkF1dG9tYXRpb25GYWlsZWQsXG4gICAgQ2FuY2VsbGVkOiBDb252ZXJzYXRpb25FdmVudC5BdXRvbWF0aW9uQ2FuY2VsbGVkLFxuICAgIFRpbWVkT3V0OiBDb252ZXJzYXRpb25FdmVudC5BdXRvbWF0aW9uVGltZWRPdXQsXG59IGFzIGNvbnN0O1xuXG4vKipcbiAqIFdvcmtCdWRkeSBcdTU0MkZcdTUyQThcdTUyNERcdTc2ODRcdTRGMUFcdThCRERcdTUxQzZcdTU5MDdcdTYwMDFcdUZGMUJcdTRFMERcdTg4NjhcdTc5M0EgQ0xJIFx1NTE4NVx1NzY4NFx1NzcxRlx1NUI5RSBNQ1AgXHU4RkRFXHU2M0E1XHU4RkRCXHU1RUE2XHUzMDAyXG4gKiBgc2VydmVyc2AgXHU1M0VBXHU1QzVFXHU0RThFIE1DUCBcdTkxNERcdTdGNkVcdTk4ODRcdTYyQTVcdUZGMUJudWxsIFx1NkUwNVx1OTY2NFx1NTFDNlx1NTkwN1x1NjAwMVx1MzAwMlxuICovXG5leHBvcnQgdHlwZSBDb252ZXJzYXRpb25QcmVwYXJlU3RhdHVzID1cbiAgICB8IHsgcmVhZG9ubHkgc3RhZ2U6ICdtY3AnOyByZWFkb25seSBzZXJ2ZXJzOiByZWFkb25seSBzdHJpbmdbXSB9XG4gICAgfCB7IHJlYWRvbmx5IHN0YWdlOiAnZXhwZXJ0JyB9XG4gICAgfCB7IHJlYWRvbmx5IHN0YWdlOiAncmVhZGluZ19jb252ZXJzYXRpb25fc2V0dGluZ3MnIH1cbiAgICB8IHsgcmVhZG9ubHkgc3RhZ2U6ICdyZXNvbHZpbmdfc3lzdGVtX3Byb21wdCcgfVxuICAgIHwgeyByZWFkb25seSBzdGFnZTogJ2NvbmZpZ3VyaW5nX21vZGVsX2FuZF90b29scycgfVxuICAgIHwgeyByZWFkb25seSBzdGFnZTogJ3Jlc29sdmluZ19za2lsbF9yZXF1aXJlbWVudHMnIH1cbiAgICB8IHsgcmVhZG9ubHkgc3RhZ2U6ICdyZXNvbHZpbmdfcGx1Z2luX3JlcXVpcmVtZW50cycgfVxuICAgIHwgeyByZWFkb25seSBzdGFnZTogJ3ByZXBhcmluZ19lbnZpcm9ubWVudCcgfVxuICAgIHwgeyByZWFkb25seSBzdGFnZTogJ2NoZWNraW5nX2xhdW5jaF9jb25maWcnIH1cbiAgICB8IHsgcmVhZG9ubHkgc3RhZ2U6ICdhY3F1aXJpbmdfcnVudGltZScgfVxuICAgIHwgbnVsbDtcblxuLyoqIGBDcmVkaXRDaGFuZ2VkYCBcdTRFOEJcdTRFRjYgcGF5bG9hZFx1RkYxQVx1NjMwN1x1NUI5QSBSZXF1ZXN0IFx1NUY1M1x1NTI0RFx1N0QyRlx1OEJBMVx1NzY4NFx1NUI5RVx1OTY0NSBDcmVkaXRcdTMwMDIgKi9cbmV4cG9ydCBpbnRlcmZhY2UgQ29udmVyc2F0aW9uQ3JlZGl0Q2hhbmdlZFBheWxvYWQge1xuICAgIHJlYWRvbmx5IHJlcXVlc3RJZDogc3RyaW5nO1xuICAgIHJlYWRvbmx5IGNvc3Q6IFJlYWRvbmx5PFVzYWdlQ29zdD47XG59XG5cbi8qKiBgRXN0aW1hdGVkQ29zdENoYW5nZWRgIFx1NEU4Qlx1NEVGNiBwYXlsb2FkXHVGRjFBXHU2MzA3XHU1QjlBIFJlcXVlc3QgXHU1RjUzXHU1MjREXHU5ODg0XHU4QkExXHU2MDNCIENyZWRpdCBcdTUzM0FcdTk1RjRcdTMwMDIgKi9cbmV4cG9ydCBpbnRlcmZhY2UgQ29udmVyc2F0aW9uRXN0aW1hdGVkQ29zdENoYW5nZWRQYXlsb2FkIHtcbiAgICByZWFkb25seSByZXF1ZXN0SWQ6IHN0cmluZztcbiAgICByZWFkb25seSBlc3RpbWF0ZWRDb3N0OiBSZWFkb25seTxVc2FnZUVzdGltYXRlPjtcbn1cblxuLyoqXG4gKiBgQ29udGV4dFVzYWdlQ2hhbmdlZGAgXHU0RThCXHU0RUY2IHBheWxvYWRcdUZGMUFcdTRGMUFcdThCRERcdTVGNTNcdTUyNERcdTc2ODRcdTRFMEFcdTRFMEJcdTY1ODdcdTUzNjBcdTc1MjhcdTVGRUJcdTcxNjdcdTMwMDJcbiAqXG4gKiBcdTUyM0JcdTYxMEYqKlx1NEUwRFx1NTQyQiBjb3N0L2NyZWRpdCoqXHVGRjFBXHU2NzJDXHU0RThCXHU0RUY2XHU1M0VBXHU2M0NGXHU4RkYwXHU0RTBBXHU0RTBCXHU2NTg3XHU3QTk3XHU1M0UzXHU1MzYwXHU3NTI4XHVGRjBDXHU4QkExXHU4RDM5XHU1M0UzXHU1Rjg0XHU0RTAwXHU1RjhCXHU3RUNGIGBDcmVkaXRDaGFuZ2VkYFx1MzAwMlxuICovXG5leHBvcnQgaW50ZXJmYWNlIENvbnZlcnNhdGlvbkNvbnRleHRVc2FnZUNoYW5nZWRQYXlsb2FkIHtcbiAgICAvKiogXHU1REYyXHU1MzYwXHU3NTI4IHRva2VuIFx1NjU3MFx1RkYwOFx1NUJGOVx1NUU5NCBBQ1AgYHVzYWdlX3VwZGF0ZS51c2VkYFx1RkYwOVx1MzAwMiAqL1xuICAgIHJlYWRvbmx5IHRvdGFsVG9rZW5zOiBudW1iZXI7XG4gICAgLyoqIFx1NUY1M1x1NTI0RFx1NkEyMVx1NTc4Qlx1NEUwQVx1NEUwQlx1NjU4N1x1N0E5N1x1NTNFM1x1NEUwQVx1OTY1MFx1RkYwOFx1NUJGOVx1NUU5NCBBQ1AgYHVzYWdlX3VwZGF0ZS5zaXplYFx1RkYwOVx1MzAwMiAqL1xuICAgIHJlYWRvbmx5IGNvbnRleHRXaW5kb3c6IG51bWJlcjtcbiAgICAvKiogXHU1MjA2XHU3QzdCXHU3NTI4XHU5MUNGXHU2NjBFXHU3RUM2XHVGRjFCQ0xJIFx1NjcyQVx1NEUwQlx1NTNEMVx1NjVGNlx1NEUzQSB1bmRlZmluZWRcdUZGMENcdTZEODhcdThEMzlcdTY1QjlcdTVFOTRcdTRGRERcdTc1NTlcdTRFMEFcdTRFMDBcdTZCMjFcdTc2ODRcdTUwM0NcdUZGMDhcdTdDOThcdTYwMjdcdThCRURcdTRFNDlcdUZGMDlcdTMwMDIgKi9cbiAgICByZWFkb25seSBieUNhdGVnb3J5PzogUmVhZG9ubHk8VXNhZ2VCeUNhdGVnb3J5Pjtcbn1cblxuLyoqIENvcmUgXHU1REYyXHU4OUUzXHU2NzkwXHU3Njg0IFJlcXVlc3QgXHU1ODlFXHU5MUNGXHU0RTBBXHU0RTBCXHU2NTg3XHVGRjFCcmVuZGVyZXIgXHU0RTBEXHU1MThEXHU4QkZCXHU1M0Q2IEFDUCBgX21ldGFgXHUzMDAyICovXG5leHBvcnQgaW50ZXJmYWNlIENvbnZlcnNhdGlvblJlcXVlc3RQYXRjaENvbnRleHQge1xuICAgIHJlYWRvbmx5IHRyYWNlSWQ/OiBzdHJpbmc7XG4gICAgcmVhZG9ubHkgY29udmVyc2F0aW9uUmVxdWVzdElkPzogc3RyaW5nO1xuICAgIC8qKiBcdTY3MkNcdThGNkVcdTUzRDFcdTkwMDFcdTY1RjZcdTc1MjhcdTYyMzdcdTkwMDlcdTYyRTlcdTc2ODRcdTkwM0JcdThGOTFcdTZBMjFcdTU3OEJcdTVGRUJcdTcxNjdcdTMwMDIgKi9cbiAgICByZWFkb25seSByZXF1ZXN0ZWRNb2RlbD86IFJlYWRvbmx5PFJlcXVlc3RNb2RlbEluZm8+O1xuICAgIC8qKiBQcm92aWRlciBcdTVCOUVcdTk2NDVcdTU0Q0RcdTVFOTRcdTc2ODRcdTcyNjlcdTc0MDZcdTZBMjFcdTU3OEJcdTMwMDIgKi9cbiAgICByZWFkb25seSByZXNwb25zZU1vZGVsPzogUmVhZG9ubHk8UmVxdWVzdE1vZGVsSW5mbz47XG4gICAgcmVhZG9ubHkgdGltZXN0YW1wPzogbnVtYmVyO1xuICAgIHJlYWRvbmx5IHF1ZXVlT3JkZXJBdD86IG51bWJlcjtcbiAgICByZWFkb25seSBxdWV1ZU9yZGVyU2VxdWVuY2U/OiBudW1iZXI7XG4gICAgLyoqXG4gICAgICogXHU2NzJDXHU4RjZFXHU2NjJGXHU1NDI2XHU0RTNBXHU1RkVCXHU5MDFGXHU5NUVFXHU3QjU0XHVGRjA4aXNzdWUgIzEwMDYxOFx1RkYwOVx1MzAwMlxuICAgICAqXG4gICAgICogXHU2RDQxXHU1RjBGXHU2NzFGXHU5NUY0XHU1QzMxXHU4OTgxXHU2MzA5XHU2RDg4XHU2MDZGXHU3QzkyXHU1RUE2XHU5NjkwXHU4NUNGIHRvb2wgY2FsbFx1RkYwQ1x1NEUwRFx1ODBGRFx1N0I0OVx1NTM4Nlx1NTNGMlx1NUZFQlx1NzE2NyBcdTIwMTRcdTIwMTQgXHU1NDI2XHU1MjE5XHU1MTQzXHU1QjlEXHU3Njg0XHU1REU1XHU1MTc3XHU4QzAzXHU3NTI4XHU0RjFBXG4gICAgICogXHU1MTQ4XHU5NUVBXHU3M0IwXHU1MThEXHU2RDg4XHU1OTMxXHUzMDAyXHU3NTMxIENvcmUgXHU0RUNFIFJlcXVlc3QgYF9tZXRhYCBcdTg5RTNcdTY3OTBcdTU0MEVcdTRFMEJcdTUzRDFcdUZGMENyZW5kZXJlciBcdTRFMERcdTgxRUFcdTVERjFcdThCRkIgYF9tZXRhYFx1MzAwMlxuICAgICAqL1xuICAgIHJlYWRvbmx5IHF1aWNrUWE/OiB0cnVlO1xuICAgIC8qKlxuICAgICAqIFx1NjcyQ1x1OEY2RVx1NTE0M1x1NUI5RFx1NURFNVx1NTE3N1x1OEY2OFx1OEZGOVx1NTM5Rlx1NjU4N1x1RkYwOGlzc3VlICMxMDA2MThcdUZGMDlcdTMwMDJcbiAgICAgKlxuICAgICAqIFx1NzUzMSBDb3JlIFx1NEVDRSBSZXF1ZXN0IGBfbWV0YWAgXHU4OUUzXHU2NzkwXHU1NDBFXHU0RTBCXHU1M0QxXHVGRjBDcmVuZGVyZXIgXHU0RTBEXHU4MUVBXHU1REYxXHU4QkZCIGBfbWV0YWBcdTMwMDJcbiAgICAgKiBDb3JlICoqXHU1M0VBXHU1MDVBXHU5NzVFXHU3QTdBXHU1QkY5XHU4QzYxXHU2ODIxXHU5QThDXHUzMDAxXHU0RTBEXHU1MDVBXHU3RUQzXHU2Nzg0XHU2NTM2XHU3QTg0KipcdUZGMUFcdThGRDlcdTRFRkRcdTUzOUZcdTY1ODdcdTU0MEVcdTdFRURcdTg5ODFcdTU2REVcdTRGMjBcdTdFRDlcdTZBMjFcdTU3OEJcdTU0MEVcdTdBRUYgYXBpXHVGRjBDXG4gICAgICogXHU4OEMxXHU1MjZBXHU0RjFBXHU4QkE5XHU1NkRFXHU0RjIwXHU1MTg1XHU1QkI5XHU1OTMxXHU3NzFGXHUzMDAyXHU1M0Q2XHU2NDFDXHU3RDIyXHU3RUQzXHU2NzlDXHU2QkI1XHU2RTMyXHU2N0QzXHU0RTBFIFVSTCBcdTVCODlcdTUxNjhcdTY4MjFcdTlBOENcdTkwRkRcdTc1MzFcdTZFMzJcdTY3RDNcdTRGQTdcdThEMUZcdThEMjNcdTMwMDJcbiAgICAgKi9cbiAgICByZWFkb25seSB5dWFuYmFvVG9vbFRyYWNlPzogUmVhZG9ubHk8UGVyc2lzdGVkWXVhbmJhb1Rvb2xUcmFjZT47XG59XG5cbi8qKlxuICogQ29yZSBcdTIxOTIgcmVuZGVyZXIgXHU3Njg0XHU3QTMzXHU1QjlBIFJlcXVlc3QgXHU2Mjk1XHU1RjcxXHU1OTUxXHU3RUE2XHUzMDAyXG4gKlxuICogQUNQIGNodW5rIFx1NzY4NFx1NTIwNlx1NkJCNVx1MzAwMVx1NjU4N1x1NjcyQyBtZXRhZGF0YVx1MzAwMXRvb2wgXHU1ODlFXHU5MUNGXHU0RTBFIHVzZXIgYmxvY2tzIFx1NTc0N1x1NTE0OFx1NTcyOCBSZXF1ZXN0QXNzZW1ibGVyXG4gKiBcdTY1MzZcdTY1NUJcdUZGMUJyZW5kZXJlciBcdTUzRUFcdTYzMDkgaW5kZXggXHU2NkZGXHU2MzYyIENvcmUgXHU3RUQ5XHU1MUZBXHU3Njg0XHU2NzQzXHU1QTAxIGJsb2NrXHVGRjBDXHU0RTBEXHU1MThEXHU4OUUzXHU5MUNBIHNlc3Npb25VcGRhdGVcdTMwMDJcbiAqL1xuZXhwb3J0IHR5cGUgQ29udmVyc2F0aW9uUmVxdWVzdFBhdGNoID1cbiAgICB8IHtcbiAgICAgICAgcmVhZG9ubHkga2luZDogJ3VzZXItY29udGVudC1yZXBsYWNlZCc7XG4gICAgICAgIHJlYWRvbmx5IHJlcXVlc3RJZDogc3RyaW5nO1xuICAgICAgICByZWFkb25seSBjb250ZW50OiByZWFkb25seSBCbG9ja1tdO1xuICAgICAgICByZWFkb25seSBjb250ZXh0PzogUmVhZG9ubHk8Q29udmVyc2F0aW9uUmVxdWVzdFBhdGNoQ29udGV4dD47XG4gICAgfVxuICAgIHwge1xuICAgICAgICByZWFkb25seSBraW5kOiAnYXNzaXN0YW50LWJsb2NrLXVwc2VydGVkJztcbiAgICAgICAgcmVhZG9ubHkgcmVxdWVzdElkOiBzdHJpbmc7XG4gICAgICAgIHJlYWRvbmx5IGluZGV4OiBudW1iZXI7XG4gICAgICAgIHJlYWRvbmx5IGJsb2NrOiBSZWFkb25seTxCbG9jaz47XG4gICAgICAgIHJlYWRvbmx5IGNvbnRleHQ/OiBSZWFkb25seTxDb252ZXJzYXRpb25SZXF1ZXN0UGF0Y2hDb250ZXh0PjtcbiAgICB9XG4gICAgfCB7XG4gICAgICAgIHJlYWRvbmx5IGtpbmQ6ICdhc3Npc3RhbnQtdXNhZ2UtdXBkYXRlZCc7XG4gICAgICAgIHJlYWRvbmx5IHJlcXVlc3RJZDogc3RyaW5nO1xuICAgICAgICByZWFkb25seSB1c2FnZTogUmVhZG9ubHk8VXNhZ2U+O1xuICAgICAgICByZWFkb25seSBjb250ZXh0PzogUmVhZG9ubHk8Q29udmVyc2F0aW9uUmVxdWVzdFBhdGNoQ29udGV4dD47XG4gICAgfTtcblxuLy8gXHUyNTAwXHUyNTAwIHNlc3Npb25VcGRhdGUgXHU0RThCXHU0RUY2IHBheWxvYWQgXHU3QzdCXHU1NzhCXHVGRjA4XHU1QkY5XHU1RTk0IGFnZW50LWNsaSBcdTYzQThcdTkwMDFcdTdFRDNcdTY3ODRcdUZGMDkgXHUyNTAwXHUyNTAwXG4vLyBcdTZCQ0ZcdTRFMkEgcGF5bG9hZCBcdTkwRkRcdTY2MEVcdTc4NkVcdTU4RjBcdTY2MEVcdTVGNTJcdTVDNUVcdTRFMEFcdTRFMEJcdTY1ODdcdUZGMUFcdTRGMUFcdThCRERcdTdFQTdcdTVFMjYgY29udmVyc2F0aW9uSWRcdUZGMENyZXF1ZXN0IFx1N0VBN1x1NUUyNiByZXF1ZXN0SWRcdTMwMDJcblxuLyoqIGBhdmFpbGFibGVfY29tbWFuZHNfdXBkYXRlYCBcdTc2ODRcdTUzNTVcdTY3NjFcdTU0N0RcdTRFRTRcdTYzQ0ZcdThGRjBcdTMwMDIgKi9cbmV4cG9ydCBpbnRlcmZhY2UgQXZhaWxhYmxlQ29tbWFuZCB7XG4gICAgbmFtZTogc3RyaW5nO1xuICAgIGRlc2NyaXB0aW9uOiBzdHJpbmc7XG4gICAgaW5wdXQ/OiB7IGhpbnQ6IHN0cmluZyB9O1xuICAgIF9tZXRhPzogUmVjb3JkPHN0cmluZywgdW5rbm93bj47XG59XG5cbi8qKiBgQ29tbWFuZHNVcGRhdGVgIFx1NEU4Qlx1NEVGNiBwYXlsb2FkXHVGRjFBXHU1M0VGXHU3NTI4XHU2NTlDXHU2NzYwXHU1NDdEXHU0RUU0L3NraWxsIFx1NTIxN1x1ODg2OFx1NTNEOFx1NTMxNlx1RkYwOFx1NEYxQVx1OEJERFx1N0VBN1x1RkYwOVx1MzAwMiAqL1xuZXhwb3J0IGludGVyZmFjZSBDb21tYW5kc1VwZGF0ZVBheWxvYWQge1xuICAgIGNvbnZlcnNhdGlvbklkOiBzdHJpbmc7XG4gICAgY29tbWFuZHM6IEF2YWlsYWJsZUNvbW1hbmRbXTtcbn1cblxuLyoqIGBNb2RlQ2hhbmdlYCBcdTRFOEJcdTRFRjYgcGF5bG9hZFx1RkYxQVx1NUY1M1x1NTI0RFx1Njc0M1x1OTY1MFx1NkEyMVx1NUYwRlx1NTNEOFx1NTMxNlx1RkYwOFx1NEYxQVx1OEJERFx1N0VBN1x1RkYwOVx1MzAwMiAqL1xuZXhwb3J0IGludGVyZmFjZSBNb2RlQ2hhbmdlUGF5bG9hZCB7XG4gICAgY29udmVyc2F0aW9uSWQ6IHN0cmluZztcbiAgICBzbHVnOiBzdHJpbmc7XG4gICAgbmFtZT86IHN0cmluZztcbiAgICB0b29scz86IHN0cmluZ1tdO1xuICAgIFtrZXk6IHN0cmluZ106IHVua25vd247XG59XG5cbi8qKiBgTW9kZWxDaGFuZ2VgIFx1NEU4Qlx1NEVGNiBwYXlsb2FkXHVGRjFBXHU1M0VGXHU3NTI4XHU2QTIxXHU1NzhCXHU1MjE3XHU4ODY4ICsgXHU1RjUzXHU1MjREXHU2QTIxXHU1NzhCXHU1M0Q4XHU1MzE2XHVGRjA4XHU0RjFBXHU4QkREXHU3RUE3XHVGRjA5XHUzMDAyICovXG5leHBvcnQgaW50ZXJmYWNlIE1vZGVsQ2hhbmdlUGF5bG9hZCB7XG4gICAgY29udmVyc2F0aW9uSWQ6IHN0cmluZztcbiAgICBtb2RlbHM/OiBBcnJheTx7IGlkOiBzdHJpbmc7IG5hbWU/OiBzdHJpbmc7IFtrZXk6IHN0cmluZ106IHVua25vd24gfT47XG4gICAgY3VycmVudE1vZGVsPzogc3RyaW5nO1xufVxuXG5leHBvcnQgdHlwZSBDb252ZXJzYXRpb25UaW1lbGluZUV2ZW50S2luZCA9ICdjb250ZXh0LWNvbXBhY3Rpb24nIHwgJ3Nlc3Npb24tYm91bmRhcnknO1xuXG4vKipcbiAqIFx1NjI5NVx1NUY3MVx1NTIzMFx1NkQ4OFx1NjA2Rlx1NjVGNlx1OTVGNFx1N0VCRlx1NzY4NFx1OTg4Nlx1NTdERlx1NEU4Qlx1NEVGNlx1N0M3Qlx1NTc4Qlx1MzAwMlxuICpcbiAqIGBtb2RlbC1jaGFuZ2VgIFx1OEQ3MFx1NzJFQ1x1N0FDQlx1NzY4NCBNb2RlbENoYW5nZSBcdTRFOEJcdTRFRjZcdUZGMENcdTRGNDYgVUkgXHU1NDBDXHU2ODM3XHU2MjhBXHU1QjgzXHU2RTMyXHU2N0QzXHU0RTNBXHU2NUY2XHU5NUY0XHU3RUJGXHU4MjgyXHU3MEI5XHVGRjBDXG4gKiBcdTU2RTBcdTZCNjRcdTRFMEUgVGltZWxpbmVFdmVudCBcdTc2ODRcdTRFMjRcdTdDN0JcdTk4ODZcdTU3REZcdTRFOEJcdTVCOUVcdTUxNzFcdTc1MjhcdTRFMDBcdTRFMkFcdTdFRDNcdTY3ODRcdTUzMTZcdTZEODhcdTYwNkZcdTY4MDdcdThCQjBcdTMwMDJcbiAqL1xuZXhwb3J0IHR5cGUgQ29udmVyc2F0aW9uVGltZWxpbmVNZXNzYWdlS2luZCA9IENvbnZlcnNhdGlvblRpbWVsaW5lRXZlbnRLaW5kIHwgJ21vZGVsLWNoYW5nZSc7XG5cbi8qKlxuICogVGltZWxpbmUgbWVzc2FnZSBraW5kIFx1NzY4NFx1OEZEMFx1ODg0Q1x1NjVGNlx1NzcxRlx1NkU5MFx1MzAwMlxuICogYHNhdGlzZmllcyBSZWNvcmQ8Li4uPmAgXHU0RkREXHU4QkMxXHU4MDU0XHU1NDA4XHU3QzdCXHU1NzhCXHU2NUIwXHU1ODlFXHU2MjEwXHU1NDU4XHU2NUY2XHVGRjBDXHU4RkQ5XHU5MUNDXHU2RjBGXHU3NjdCXHU4QkIwXHU0RjFBXHU3NkY0XHU2M0E1XHU3RjE2XHU4QkQxXHU1OTMxXHU4RDI1XHUzMDAyXG4gKi9cbmV4cG9ydCBjb25zdCBDT05WRVJTQVRJT05fVElNRUxJTkVfTUVTU0FHRV9LSU5EX01BUCA9IHtcbiAgICAnY29udGV4dC1jb21wYWN0aW9uJzogdHJ1ZSxcbiAgICAnc2Vzc2lvbi1ib3VuZGFyeSc6IHRydWUsXG4gICAgJ21vZGVsLWNoYW5nZSc6IHRydWUsXG59IGFzIGNvbnN0IHNhdGlzZmllcyBSZWNvcmQ8Q29udmVyc2F0aW9uVGltZWxpbmVNZXNzYWdlS2luZCwgdHJ1ZT47XG5cbi8qKiBVSSBcdTZEODhcdTYwNkZcdTY0M0FcdTVFMjZcdTc2ODRcdTY1RjZcdTk1RjRcdTdFQkZcdTRFOEJcdTRFRjZcdThFQUJcdTRFRkRcdUZGMUJcdTZEODhcdThEMzlcdTY1QjlcdTRFMERcdTVFOTRcdTRFQ0UgbWVzc2FnZSBpZCBcdTYyMTYgbWVzc2FnZVR5cGUgXHU1M0NEXHU2M0E4XHUzMDAyICovXG5leHBvcnQgaW50ZXJmYWNlIENvbnZlcnNhdGlvblRpbWVsaW5lTWVzc2FnZU1ldGFkYXRhIHtcbiAgICBraW5kOiBDb252ZXJzYXRpb25UaW1lbGluZU1lc3NhZ2VLaW5kO1xuICAgIGFuY2hvclJlcXVlc3RJZD86IHN0cmluZztcbiAgICAvKipcbiAgICAgKiBUaW1lbGluZSBcdTU3MjhcdTYyNDBcdTVDNUUgUmVxdWVzdCBcdTc2ODQgYXNzaXN0YW50IGNhbm9uaWNhbCBjb250ZW50IFx1NEUyRFx1NzY4NFx1NjNEMlx1NTE2NVx1OEZCOVx1NzU0Q1x1MzAwMlxuICAgICAqIFx1NjU3MFx1NTAzQ1x1ODg2OFx1NzkzQVx1NEU4Qlx1NEVGNlx1NTNEMVx1NzUxRlx1NTI0RFx1NURGMlx1N0VDRlx1NUI1OFx1NTcyOFx1NzY4NCBDb3JlIGNvbnRlbnQgYmxvY2sgXHU2NTcwXHU5MUNGXHVGRjFCXHU1NDBFXHU3RUVEXHU1RkVCXHU3MTY3XHU2NkZGXHU2MzYyXHU2NUY2XG4gICAgICogUmVuZGVyZXIgXHU1RkM1XHU5ODdCXHU1OTBEXHU3NTI4XHU4QkU1XHU4RkI5XHU3NTRDXHVGRjBDXHU0RTBEXHU4MEZEXHU1MThEXHU2ODM5XHU2MzZFXHU1M0VGXHU5MDA5XHU3Njg0XHU1NzU3XHU3RUE3XHU2NUY2XHU5NUY0XHU2MjMzXHU5MUNEXHU2NUIwXHU3MzFDXHU2RDRCXHU0RjREXHU3RjZFXHUzMDAyXG4gICAgICovXG4gICAgYW5jaG9yQ29udGVudEluZGV4PzogbnVtYmVyO1xufVxuXG4vKiogXHU0RTBEXHU0RjlEXHU4RDU2XHU1MTc3XHU0RjUzIFVJIE1lc3NhZ2UgXHU3QzdCXHU1NzhCXHU3Njg0XHU3RUQzXHU2Nzg0XHU1MzE2XHU2NUY2XHU5NUY0XHU3RUJGXHU0RThCXHU0RUY2XHU4RjdEXHU0RjUzXHUzMDAyICovXG5leHBvcnQgaW50ZXJmYWNlIENvbnZlcnNhdGlvblRpbWVsaW5lRXZlbnRDYXJyaWVyIHtcbiAgICBleHRyYT86IHtcbiAgICAgICAgdGltZWxpbmVFdmVudD86IENvbnZlcnNhdGlvblRpbWVsaW5lTWVzc2FnZU1ldGFkYXRhO1xuICAgIH07XG59XG5cbi8qKiBcdTY3MDBcdTVDMEZcdTZEODhcdTYwNkZcdThFQUJcdTRFRkRcdUZGMUJcdTc1MjhcdTRFOEVcdTUxN0NcdTVCQjlcdTVDMUFcdTY3MkFcdTY0M0FcdTVFMjZcdTdFRDNcdTY3ODRcdTUzMTYgbWV0YWRhdGEgXHU3Njg0XHU2NUU3IFVJIFx1NUZFQlx1NzE2N1x1MzAwMiAqL1xuZXhwb3J0IGludGVyZmFjZSBDb252ZXJzYXRpb25UaW1lbGluZU1lc3NhZ2VMaWtlIGV4dGVuZHMgQ29udmVyc2F0aW9uVGltZWxpbmVFdmVudENhcnJpZXIge1xuICAgIGlkPzogdW5rbm93bjtcbn1cblxuLyoqIFx1NTIyNFx1NjVBRFx1NjI5NVx1NUY3MVx1NTQwRVx1NzY4NFx1NkQ4OFx1NjA2Rlx1NjYyRlx1NTQyNlx1NjI3Rlx1OEY3RFx1NjVGNlx1OTVGNFx1N0VCRlx1NEU4Qlx1NEVGNlx1OEVBQlx1NEVGRFx1MzAwMiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGlzQ29udmVyc2F0aW9uVGltZWxpbmVFdmVudENhcnJpZXIoXG4gICAgdmFsdWU6IHVua25vd24sXG4pOiB2YWx1ZSBpcyBDb252ZXJzYXRpb25UaW1lbGluZUV2ZW50Q2FycmllciAmIHtcbiAgICBleHRyYTogeyB0aW1lbGluZUV2ZW50OiBDb252ZXJzYXRpb25UaW1lbGluZU1lc3NhZ2VNZXRhZGF0YSB9O1xufSB7XG4gICAgaWYgKCF2YWx1ZSB8fCB0eXBlb2YgdmFsdWUgIT09ICdvYmplY3QnKSB7IHJldHVybiBmYWxzZTsgfVxuICAgIGNvbnN0IG1ldGFkYXRhID0gKHZhbHVlIGFzIENvbnZlcnNhdGlvblRpbWVsaW5lRXZlbnRDYXJyaWVyKS5leHRyYT8udGltZWxpbmVFdmVudDtcbiAgICBpZiAoIW1ldGFkYXRhIHx8IHR5cGVvZiBtZXRhZGF0YSAhPT0gJ29iamVjdCcpIHsgcmV0dXJuIGZhbHNlOyB9XG4gICAgcmV0dXJuIE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChcbiAgICAgICAgQ09OVkVSU0FUSU9OX1RJTUVMSU5FX01FU1NBR0VfS0lORF9NQVAsXG4gICAgICAgIG1ldGFkYXRhLmtpbmQsXG4gICAgKTtcbn1cblxuLyoqXG4gKiBcdTUyMjRcdTY1QURcdTZEODhcdTYwNkZcdTY2MkZcdTU0MjZcdTRFM0FcdTY1RjZcdTk1RjRcdTdFQkZcdTRFOEJcdTRFRjZcdTMwMDJcbiAqXG4gKiBcdTdFRDNcdTY3ODRcdTUzMTYgYGV4dHJhLnRpbWVsaW5lRXZlbnRgIFx1NjYyRlx1NEUzQlx1NTk1MVx1N0VBNlx1RkYxQmB0aW1lbGluZTpgIElEIFx1NEVDNVx1NTE3Q1x1NUJCOVx1NjVFNyBVSSBcdTVGRUJcdTcxNjdcdUZGMENcbiAqIFx1NjI0MFx1NjcwOVx1NkQ4OFx1OEQzOVx1NjVCOVx1NUZDNVx1OTg3Qlx1OEMwM1x1NzUyOFx1NkI2NFx1NjVCOVx1NkNENVx1RkYwQ1x1Nzk4MVx1NkI2Mlx1NTQwNFx1ODFFQVx1NTkwRFx1NTIzNlx1NTI0RFx1N0YwMFx1NTIyNFx1NjVBRFx1MzAwMlxuICovXG5leHBvcnQgZnVuY3Rpb24gaXNDb252ZXJzYXRpb25UaW1lbGluZU1lc3NhZ2UodmFsdWU6IHVua25vd24pOiBib29sZWFuIHtcbiAgICBpZiAoaXNDb252ZXJzYXRpb25UaW1lbGluZUV2ZW50Q2Fycmllcih2YWx1ZSkpIHsgcmV0dXJuIHRydWU7IH1cbiAgICBpZiAoIXZhbHVlIHx8IHR5cGVvZiB2YWx1ZSAhPT0gJ29iamVjdCcpIHsgcmV0dXJuIGZhbHNlOyB9XG4gICAgY29uc3QgaWQgPSAodmFsdWUgYXMgQ29udmVyc2F0aW9uVGltZWxpbmVNZXNzYWdlTGlrZSkuaWQ7XG4gICAgcmV0dXJuIHR5cGVvZiBpZCA9PT0gJ3N0cmluZycgJiYgaWQuc3RhcnRzV2l0aCgndGltZWxpbmU6Jyk7XG59XG5cbi8qKiBcdTk3NUUgUmVxdWVzdCBcdTc2ODRcdTRGMUFcdThCRERcdTY1RjZcdTk1RjRcdTdFQkZcdTRFOEJcdTVCOUVcdUZGMUJcdTVCOUVcdTY1RjZcdTYzQTdcdTUyMzZcdTVFMjdcdTRFMEVcdTUzODZcdTUzRjJcdTZFOTBcdTUxNzFcdTRFQUJcdTU0MENcdTRFMDBcdTU5NTFcdTdFQTZcdTMwMDIgKi9cbmV4cG9ydCBpbnRlcmZhY2UgQ29udmVyc2F0aW9uVGltZWxpbmVFdmVudFBheWxvYWQge1xuICAgIGNvbnZlcnNhdGlvbklkOiBzdHJpbmc7XG4gICAgaWQ6IHN0cmluZztcbiAgICBraW5kOiBDb252ZXJzYXRpb25UaW1lbGluZUV2ZW50S2luZDtcbiAgICBjcmVhdGVkQXQ6IG51bWJlcjtcbiAgICBoaXN0b3J5OiBib29sZWFuO1xuICAgIC8qKlxuICAgICAqIFRpbWVsaW5lIFx1NjI0MFx1NUM1RVx1NzY4NCBjYW5vbmljYWwgUmVxdWVzdFx1MzAwMkNvcmUgXHU3NTI4XHU1QjgzXHU2MjhBXHU0RThCXHU0RUY2XHU5NjUwXHU1MjM2XHU1NzI4XHU1QkY5XHU1RTk0IFJlcXVlc3QgXHU5ODc1XHU1MTg1XHVGRjFCXG4gICAgICogXHU4MDAxXHU2MzAxXHU0RTQ1XHU1MzE2XHU2NTcwXHU2MzZFXHU3RjNBXHU1OTMxXHU2NUY2XHU3NTMxIHJlcXVlc3RFbnRyaWVzIFx1NzY4NFx1NjVGNlx1OTVGNFx1N0E5N1x1NTNFM1x1NTE3Q1x1NUJCOVx1OTAzQlx1OEY5MVx1NTE1Q1x1NUU5NVx1MzAwMlxuICAgICAqL1xuICAgIGFuY2hvclJlcXVlc3RJZD86IHN0cmluZztcbiAgICAvKipcbiAgICAgKiBcdTRFOEJcdTRFRjZcdTUzRDFcdTc1MUZcdTUyNERcdTYyNDBcdTVDNUUgUmVxdWVzdCBcdTVERjJcdTcyNjlcdTUzMTZcdTc2ODQgYXNzaXN0YW50IGNhbm9uaWNhbCBjb250ZW50IGJsb2NrIFx1NjU3MFx1OTFDRlx1MzAwMlxuICAgICAqIFx1NEVDNVx1OEY2RVx1NTE4NSBUaW1lbGluZVx1RkYwOFx1NUY1M1x1NTI0RFx1NEUzQVx1ODFFQVx1NTJBOCBjb21wYWN0XHVGRjA5XHU5NzAwXHU4OTgxXHVGRjFCXHU4RjZFXHU2QjIxXHU3RUQzXHU2NzVGXHU1NDBFXHU3Njg0IHN0YW5kYWxvbmVcbiAgICAgKiBUaW1lbGluZVx1RkYwOFx1NEY4Qlx1NTk4Mlx1NjI0Qlx1NTJBOCBjb21wYWN0XHVGRjA5XHU0RTBEXHU4QkJFXHU3RjZFXHUzMDAyXG4gICAgICovXG4gICAgYW5jaG9yQ29udGVudEluZGV4PzogbnVtYmVyO1xuICAgIGRhdGE/OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPjtcbn1cblxuLyoqIGBNb2Rlc1VwZGF0ZWAgXHU0RThCXHU0RUY2IHBheWxvYWRcdUZGMUFcdTUzRUZcdTc1MjhcdTZBMjFcdTVGMEZcdTUyMTdcdTg4NjhcdTUzRDhcdTUzMTZcdUZGMDhcdTRGMUFcdThCRERcdTdFQTdcdUZGMDlcdTMwMDIgKi9cbmV4cG9ydCBpbnRlcmZhY2UgTW9kZXNVcGRhdGVQYXlsb2FkIHtcbiAgICBjb252ZXJzYXRpb25JZDogc3RyaW5nO1xuICAgIG1vZGVzPzogQXJyYXk8eyBzbHVnOiBzdHJpbmc7IG5hbWU/OiBzdHJpbmc7IFtrZXk6IHN0cmluZ106IHVua25vd24gfT47XG59XG5cbi8qKiBgcGxhbmAgc2Vzc2lvblVwZGF0ZSBcdTc2ODQgVE9ETyBcdTY3NjFcdTc2RUVcdTMwMDIgKi9cbmV4cG9ydCBpbnRlcmZhY2UgUGxhblRvZG8ge1xuICAgIGlkOiBzdHJpbmc7XG4gICAgY29udGVudDogc3RyaW5nO1xuICAgIGFjdGl2ZUZvcm0/OiBzdHJpbmc7XG4gICAgc3RhdHVzOiBzdHJpbmc7XG4gICAgcHJpb3JpdHk/OiBzdHJpbmc7XG4gICAgY3JlYXRlZEF0PzogbnVtYmVyO1xuICAgIHVwZGF0ZWRBdD86IG51bWJlcjtcbiAgICBkZXBlbmRlbmNpZXM/OiBzdHJpbmdbXTtcbiAgICBvcmRlcj86IG51bWJlcjtcbiAgICBba2V5OiBzdHJpbmddOiB1bmtub3duO1xufVxuXG4vKiogYFBsYW5VcGRhdGVgIFx1NEU4Qlx1NEVGNiBwYXlsb2FkXHVGRjFBVE9ETyBcdThCQTFcdTUyMTJcdTY2RjRcdTY1QjBcdUZGMDhyZXF1ZXN0IFx1N0VBN1x1RkYwOVx1MzAwMiAqL1xuZXhwb3J0IGludGVyZmFjZSBQbGFuVXBkYXRlUGF5bG9hZCB7XG4gICAgY29udmVyc2F0aW9uSWQ6IHN0cmluZztcbiAgICByZXF1ZXN0SWQ6IHN0cmluZztcbiAgICB0b2Rvcz86IFBsYW5Ub2RvW107XG59XG5cbi8qKiBDb252ZXJzYXRpb24gXHU1QkY5XHU1OTE2XHU2NkI0XHU5NzMyXHU3Njg0XHU2MjY5XHU1QzU1XHU0RThCXHU0RUY2XHU3OUNEXHU3QzdCXHVGRjFCXHU0RTBFIEFDUCBgX2NvZGVidWRkeS5haS8qYCB3aXJlIG1ldGhvZCBcdTg5RTNcdTgwMjZcdTMwMDIgKi9cbmV4cG9ydCBlbnVtIENvbnZlcnNhdGlvbkV4dGVuc2lvbk1ldGhvZCB7XG4gICAgQ2hlY2twb2ludCA9ICdjaGVja3BvaW50JyxcbiAgICBDb21tYW5kID0gJ2NvbW1hbmQnLFxuICAgIEF1dGhVcmwgPSAnYXV0aFVybCcsXG4gICAgLyoqIFRlYW1zIFx1OTYxRlx1NTIxNy9cdTUzNEZcdTRGNUNcdTkwMUFcdTc3RTVcdUZGMDhjb2xsYWIgdGFzay1jaGF0IFx1NUI5RVx1NjVGNlx1NzJCNlx1NjAwMVx1NkU5MFx1RkYwOVx1MzAwMiAqL1xuICAgIFRlYW1zID0gJ3RlYW1zJyxcbn1cblxuLyoqIENoZWNrcG9pbnQgXHU3Njg0XHU2NTg3XHU0RUY2XHU1M0Q4XHU2NkY0XHU2NDU4XHU4OTgxXHUzMDAyICovXG5leHBvcnQgaW50ZXJmYWNlIENvbnZlcnNhdGlvbkNoZWNrcG9pbnRGaWxlQ2hhbmdlcyB7XG4gICAgZmlsZXM6IEFycmF5PHtcbiAgICAgICAgdXJpOiBzdHJpbmc7XG4gICAgICAgIGNoYW5nZVR5cGU6ICdjcmVhdGVkJyB8ICdtb2RpZmllZCcgfCAnZGVsZXRlZCc7XG4gICAgICAgIGFkZGl0aW9uczogbnVtYmVyO1xuICAgICAgICBkZWxldGlvbnM6IG51bWJlcjtcbiAgICAgICAgZGlmZj86IHN0cmluZztcbiAgICAgICAgbGFuZ3VhZ2U/OiBzdHJpbmc7XG4gICAgICAgIGNyZWF0ZWRBdD86IG51bWJlcjtcbiAgICAgICAgdXBkYXRlZEF0PzogbnVtYmVyO1xuICAgICAgICBkaWZmU3RhdHVzPzogJ3RpbWVvdXQnO1xuICAgIH0+O1xuICAgIHRvdGFsQWRkaXRpb25zOiBudW1iZXI7XG4gICAgdG90YWxEZWxldGlvbnM6IG51bWJlcjtcbn1cblxuLyoqIENvbnZlcnNhdGlvbiBcdTZEODhcdThEMzlcdTY1QjlcdTUzRUZcdTg5QzFcdTc2ODQgY2hlY2twb2ludFx1RkYxQlx1NkNBMVx1NjcwOSBBQ1Agc2Vzc2lvbklkIFx1N0I0OSB0cmFuc3BvcnQgXHU1QjU3XHU2QkI1XHUzMDAyICovXG5leHBvcnQgaW50ZXJmYWNlIENvbnZlcnNhdGlvbkNoZWNrcG9pbnQge1xuICAgIGlkOiBzdHJpbmc7XG4gICAgLyoqIGNoZWNrcG9pbnQgXHU2MjQwXHU1QzVFXHU0RTFBXHU1MkExIFJlcXVlc3RcdUZGMUJcdTc1MjhcdTRFOEUgVUkgXHU1QjlBXHU0RjREXHU0RTBFXHU1NkRFXHU5MDAwXHVGRjBDXHU3OTgxXHU2QjYyXHU3NTI4IG1lc3NhZ2VJZCBcdTRFRTNcdTY2RkZcdTMwMDIgKi9cbiAgICByZXF1ZXN0SWQ6IHN0cmluZztcbiAgICBsYWJlbD86IHN0cmluZztcbiAgICBjcmVhdGVkQXQ6IG51bWJlcjtcbiAgICBmaWxlQ2hhbmdlczogQ29udmVyc2F0aW9uQ2hlY2twb2ludEZpbGVDaGFuZ2VzO1xufVxuXG4vKiogXHU1NDA0XHU2MjY5XHU1QzU1XHU0RThCXHU0RUY2XHU3OUNEXHU3QzdCXHU1QkY5XHU1RTk0XHU3Njg0XHU0RTFBXHU1MkExXHU1M0MyXHU2NTcwXHUzMDAyICovXG5leHBvcnQgaW50ZXJmYWNlIENvbnZlcnNhdGlvbkV4dGVuc2lvbk1ldGhvZFBhcmFtcyB7XG4gICAgW0NvbnZlcnNhdGlvbkV4dGVuc2lvbk1ldGhvZC5DaGVja3BvaW50XToge1xuICAgICAgICBldmVudDogJ2NyZWF0ZWQnIHwgJ3VwZGF0ZWQnO1xuICAgICAgICBjaGVja3BvaW50OiBDb252ZXJzYXRpb25DaGVja3BvaW50O1xuICAgIH07XG4gICAgW0NvbnZlcnNhdGlvbkV4dGVuc2lvbk1ldGhvZC5Db21tYW5kXToge1xuICAgICAgICBhY3Rpb246IHN0cmluZztcbiAgICAgICAgcGFyYW1zPzogUmVjb3JkPHN0cmluZywgdW5rbm93bj47XG4gICAgfTtcbiAgICBbQ29udmVyc2F0aW9uRXh0ZW5zaW9uTWV0aG9kLkF1dGhVcmxdOiB7XG4gICAgICAgIGF1dGhVcmw6IHN0cmluZztcbiAgICAgICAgcHJvdmlkZXI/OiBzdHJpbmc7XG4gICAgfTtcbiAgICBbQ29udmVyc2F0aW9uRXh0ZW5zaW9uTWV0aG9kLlRlYW1zXTogUmVjb3JkPHN0cmluZywgdW5rbm93bj47XG59XG5cbi8qKiBcdTY1QjlcdTZDRDVcdTRFMEVcdTUzQzJcdTY1NzBcdTc2ODRcdTUzRDdcdTdFQTZcdTY3NUZcdTdFQzRcdTU0MDhcdUZGMENcdTRGOUJcdThERTggSVBDIFx1OEY2Q1x1NTNEMVx1NEY3Rlx1NzUyOFx1MzAwMiAqL1xuZXhwb3J0IHR5cGUgQ29udmVyc2F0aW9uRXh0ZW5zaW9uTWV0aG9kRXZlbnQgPSB7XG4gICAgW00gaW4gQ29udmVyc2F0aW9uRXh0ZW5zaW9uTWV0aG9kXToge1xuICAgICAgICBtZXRob2Q6IE07XG4gICAgICAgIHBhcmFtczogQ29udmVyc2F0aW9uRXh0ZW5zaW9uTWV0aG9kUGFyYW1zW01dO1xuICAgIH1cbn1bQ29udmVyc2F0aW9uRXh0ZW5zaW9uTWV0aG9kXTtcblxuLyoqIGBvbihDb252ZXJzYXRpb25FdmVudC5FeHRlbnNpb25NZXRob2QpYCBcdTc2ODRcdTU2REVcdThDMDNcdUZGMUJtZXRob2QgXHU0RjFBXHU2NTM2XHU3QTg0XHU1QkY5XHU1RTk0XHU3Njg0IHBhcmFtc1x1MzAwMiAqL1xuZXhwb3J0IHR5cGUgQ29udmVyc2F0aW9uRXh0ZW5zaW9uTWV0aG9kSGFuZGxlciA9ICguLi5hcmdzOiB7XG4gICAgW00gaW4gQ29udmVyc2F0aW9uRXh0ZW5zaW9uTWV0aG9kXTogW21ldGhvZDogTSwgcGFyYW1zOiBDb252ZXJzYXRpb25FeHRlbnNpb25NZXRob2RQYXJhbXNbTV1dXG59W0NvbnZlcnNhdGlvbkV4dGVuc2lvbk1ldGhvZF0pID0+IHZvaWQ7XG5cbi8qKiBcdThERTggSVBDIFx1NTg5RVx1NTJBMFx1NEYxQVx1OEJERFx1NUY1Mlx1NUM1RVx1RkYwQ0NvbnZlcnNhdGlvbiBcdTVCOUVcdTRGOEJcdTU2REVcdThDMDNcdTRFMERcdTY2QjRcdTk3MzJcdThCRTVcdTVCNTdcdTZCQjVcdTMwMDIgKi9cbmV4cG9ydCB0eXBlIENvbnZlcnNhdGlvbkV4dGVuc2lvbk1ldGhvZFBheWxvYWQgPSB7XG4gICAgY29udmVyc2F0aW9uSWQ6IHN0cmluZztcbn0gJiBDb252ZXJzYXRpb25FeHRlbnNpb25NZXRob2RFdmVudDtcblxuLyoqIGBDb25maWdVcGRhdGVgIFx1NEU4Qlx1NEVGNiBwYXlsb2FkXHVGRjFBXHU5MTREXHU3RjZFXHU5MDA5XHU5ODc5XHU1M0Q4XHU1MzE2XHVGRjA4XHU0RjFBXHU4QkREXHU3RUE3XHVGRjA5XHUzMDAyICovXG5leHBvcnQgaW50ZXJmYWNlIENvbmZpZ1VwZGF0ZVBheWxvYWQge1xuICAgIGNvbnZlcnNhdGlvbklkOiBzdHJpbmc7XG4gICAgb3B0aW9ucz86IEFycmF5PHsga2V5OiBzdHJpbmc7IHZhbHVlPzogdW5rbm93bjsgW2tleTogc3RyaW5nXTogdW5rbm93biB9Pjtcbn1cblxuLyoqXG4gKiBcdTRFOEJcdTRFRjYgXHUyMTkyIFx1NTZERVx1OEMwM1x1N0I3RVx1NTQwRFx1NjYyMFx1NUMwNFx1MzAwMmBDb252ZXJzYXRpb24ub24oZXZlbnQsIGNiKWAgXHU2MzZFXHU2QjY0XHU1QkY5IGBjYmAgXHU1MDVBXHU3QzdCXHU1NzhCXHU2NTM2XHU3QTg0XHVGRjBDXG4gKiBcdTRGRERcdThCQzFcdTRFMERcdTU0MEMgYGV2ZW50YCBcdTUwM0NcdTVCRjlcdTVFOTRcdTZCNjNcdTc4NkVcdTc2ODQgYGNiYCBcdTUzQzJcdTY1NzBcdTdDN0JcdTU3OEJcdTMwMDJcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBDb252ZXJzYXRpb25FdmVudENhbGxiYWNrTWFwIHtcbiAgICBbQ29udmVyc2F0aW9uRXZlbnQuUmVxdWVzdFVwZGF0ZV06IChcbiAgICAgICAgcmVxdWVzdElkOiBzdHJpbmcsXG4gICAgICAgIG1lc3NhZ2VJZDogc3RyaW5nLFxuICAgICAgICBjaHVuazogdW5rbm93bixcbiAgICAgICAgcGF0Y2hlczogcmVhZG9ubHkgQ29udmVyc2F0aW9uUmVxdWVzdFBhdGNoW10sXG4gICAgKSA9PiB2b2lkO1xuICAgIFtDb252ZXJzYXRpb25FdmVudC5TdGF0ZUNoYW5nZV06IChcbiAgICAgICAgZnJvbTogQ29udmVyc2F0aW9uU3RhdGUsXG4gICAgICAgIHRvOiBDb252ZXJzYXRpb25TdGF0ZSxcbiAgICAgICAgZmluYWxTdGF0ZT86IEZpbmFsUmVxdWVzdFN0YXRlLFxuICAgICAgICB0ZXJtaW5hbEVycm9yPzogQ29udmVyc2F0aW9uVGVybWluYWxFcnJvcixcbiAgICAgICAgaW50ZXJydXB0aW9uPzogQ29udmVyc2F0aW9uVHVybkludGVycnVwdGlvbixcbiAgICAgICAgcHJvbXB0UmVzcG9uc2VNZXRhPzogQ29udmVyc2F0aW9uUHJvbXB0UmVzcG9uc2VNZXRhLFxuICAgICkgPT4gdm9pZDtcbiAgICBbQ29udmVyc2F0aW9uRXZlbnQuSW5mb0NoYW5nZV06IChpbmZvOiBDb252ZXJzYXRpb25JbmZvKSA9PiB2b2lkO1xuICAgIFtDb252ZXJzYXRpb25FdmVudC5RdWV1ZVVwZGF0ZV06ICgpID0+IHZvaWQ7XG4gICAgW0NvbnZlcnNhdGlvbkV2ZW50LkNhcGFjaXR5UXVldWVVcGRhdGVdOiAoc25hcHNob3Q6IENhcGFjaXR5UXVldWVTbmFwc2hvdCkgPT4gdm9pZDtcbiAgICBbQ29udmVyc2F0aW9uRXZlbnQuQXJ0aWZhY3RVcGRhdGVdOiAoKSA9PiB2b2lkO1xuICAgIFtDb252ZXJzYXRpb25FdmVudC5FeHRlbnNpb25NZXRob2RdOiBDb252ZXJzYXRpb25FeHRlbnNpb25NZXRob2RIYW5kbGVyO1xuICAgIFtDb252ZXJzYXRpb25FdmVudC5XYXJuaW5nXTogKGluZm86IFdhcm5pbmdJbmZvKSA9PiB2b2lkO1xuICAgIFtDb252ZXJzYXRpb25FdmVudC5QcmVwYXJlU3RhdHVzXTogKHN0YXR1czogQ29udmVyc2F0aW9uUHJlcGFyZVN0YXR1cykgPT4gdm9pZDtcbiAgICBbQ29udmVyc2F0aW9uRXZlbnQuTWNwU3RhcnR1cFN0YXR1c106IChzdGF0dXM6IENvbnZlcnNhdGlvbk1jcFN0YXJ0dXBTdGF0dXMpID0+IHZvaWQ7XG4gICAgW0NvbnZlcnNhdGlvbkV2ZW50LkNvbW1hbmRzVXBkYXRlXTogKHBheWxvYWQ6IENvbW1hbmRzVXBkYXRlUGF5bG9hZCkgPT4gdm9pZDtcbiAgICBbQ29udmVyc2F0aW9uRXZlbnQuTW9kZUNoYW5nZV06IChwYXlsb2FkOiBNb2RlQ2hhbmdlUGF5bG9hZCkgPT4gdm9pZDtcbiAgICBbQ29udmVyc2F0aW9uRXZlbnQuQ29uZmlnVXBkYXRlXTogKHBheWxvYWQ6IENvbmZpZ1VwZGF0ZVBheWxvYWQpID0+IHZvaWQ7XG4gICAgW0NvbnZlcnNhdGlvbkV2ZW50Lk1vZGVsQ2hhbmdlXTogKHBheWxvYWQ6IE1vZGVsQ2hhbmdlUGF5bG9hZCkgPT4gdm9pZDtcbiAgICBbQ29udmVyc2F0aW9uRXZlbnQuVGltZWxpbmVFdmVudF06IChwYXlsb2FkOiBDb252ZXJzYXRpb25UaW1lbGluZUV2ZW50UGF5bG9hZCkgPT4gdm9pZDtcbiAgICBbQ29udmVyc2F0aW9uRXZlbnQuTW9kZXNVcGRhdGVdOiAocGF5bG9hZDogTW9kZXNVcGRhdGVQYXlsb2FkKSA9PiB2b2lkO1xuICAgIFtDb252ZXJzYXRpb25FdmVudC5QbGFuVXBkYXRlXTogKHBheWxvYWQ6IFBsYW5VcGRhdGVQYXlsb2FkKSA9PiB2b2lkO1xuICAgIC8qKiBAaW50ZXJuYWwgZGFlbW9uIHBvb2wgXHU4RjZDXHU1M0QxXHU3NTI4XHVGRjBDVUkgXHU0RkE3XHU4RDcwIGdldFBlbmRpbmdJbmZvKCkgcHVsbFx1MzAwMiAqL1xuICAgIFtDb252ZXJzYXRpb25FdmVudC5QZW5kaW5nUmVxdWVzdF06IChwZW5kaW5nUmVxdWVzdDogUGVuZGluZ1JlcXVlc3QpID0+IHZvaWQ7XG4gICAgLyoqIFx1NEVBN1x1NTRDMVx1N0VBN1x1NjNBOFx1ODM1MFx1NUZFQlx1NzE2N1x1NTNEOFx1NTMxNlx1RkYxQnVuZGVmaW5lZCBcdTg4NjhcdTc5M0FcdTVGNTNcdTUyNERcdTYzQThcdTgzNTBcdTVERjJcdTdFRDNcdTdCOTdcdTMwMDIgKi9cbiAgICBbQ29udmVyc2F0aW9uRXZlbnQuUGx1Z2luUmVjb21tZW5kYXRpb25DaGFuZ2VkXTogKFxuICAgICAgICByZWNvbW1lbmRhdGlvbjogQ29udmVyc2F0aW9uUGx1Z2luUmVjb21tZW5kYXRpb24gfCB1bmRlZmluZWQsXG4gICAgKSA9PiB2b2lkO1xuICAgIC8qKiBcdTRFOTFcdTY3MERcdTUyQTFcdTVGMDBcdTkwMUFcdTUzRUZcdTRGRTFcdTc4NkVcdThCQTRcdTYyOTVcdTVGNzFcdTUzRDhcdTUzMTZcdUZGMUJ1bmRlZmluZWQgXHU4ODY4XHU3OTNBXHU1REYyXHU3RUQzXHU3Qjk3XHUzMDAyICovXG4gICAgW0NvbnZlcnNhdGlvbkV2ZW50LkNsb3VkU2VydmljZUNvbmZpcm1hdGlvbkNoYW5nZWRdOiAoXG4gICAgICAgIGNvbmZpcm1hdGlvbjogQ29udmVyc2F0aW9uQ2xvdWRTZXJ2aWNlQ29uZmlybWF0aW9uIHwgdW5kZWZpbmVkLFxuICAgICkgPT4gdm9pZDtcbiAgICAvKiogXHU1Mzg2XHU1M0YyXHU1NkRFXHU2NTNFXHU1QjhDXHU2MjEwXHVGRjA4XHU2NUUwIHBheWxvYWRcdUZGMDlcdUZGMUFcdTUxODVcdTkwRThcdTkxQ0NcdTdBMEJcdTc4OTFcdTRGRTFcdTUzRjdcdUZGMENcdTRFNUZcdTY2MkYgUmVxdWVzdHNDaGFuZ2VkIFx1ODlFNlx1NTNEMVx1NzBCOVx1NEU0Qlx1NEUwMFx1MzAwMiAqL1xuICAgIFtDb252ZXJzYXRpb25FdmVudC5IaXN0b3J5TG9hZGVkXTogKCkgPT4gdm9pZDtcbiAgICAvKiogXHU1MTY4XHU5MUNGIFJlcXVlc3QgXHU1MjE3XHU4ODY4XHU1RkVCXHU3MTY3XHU1M0Q4XHU2NkY0XHVGRjFBXHU2NDNBXHU1RTI2XHU1QjhDXHU2NTc0IFJlcXVlc3RbXVx1RkYwQ1x1NkQ4OFx1OEQzOVx1NjVCOVx1NjU3NFx1NEY1M1x1NjZGRlx1NjM2Mlx1NkUzMlx1NjdEM1x1MzAwMiAqL1xuICAgIFtDb252ZXJzYXRpb25FdmVudC5SZXF1ZXN0c0NoYW5nZWRdOiAocmVxdWVzdHM6IFJlcXVlc3RbXSkgPT4gdm9pZDtcbiAgICAvKiogXHU2MzA3XHU1QjlBIFJlcXVlc3QgXHU3Njg0XHU1QjlFXHU5NjQ1XHU3RDJGXHU4QkExIENyZWRpdCBcdTUzRDhcdTUzMTZcdTMwMDIgKi9cbiAgICBbQ29udmVyc2F0aW9uRXZlbnQuQ3JlZGl0Q2hhbmdlZF06IChwYXlsb2FkOiBDb252ZXJzYXRpb25DcmVkaXRDaGFuZ2VkUGF5bG9hZCkgPT4gdm9pZDtcbiAgICAvKiogXHU0RjFBXHU4QkREXHU3RUE3XHU0RTBBXHU0RTBCXHU2NTg3XHU3NTI4XHU5MUNGXHU1RkVCXHU3MTY3XHU1M0Q4XHU1MzE2XHVGRjA4XHU0RTBEXHU1NDJCIGNvc3RcdUZGMENcdTRFMERcdTUzQzJcdTRFMEVcdThCQTFcdThEMzlcdUZGMDlcdTMwMDIgKi9cbiAgICBbQ29udmVyc2F0aW9uRXZlbnQuQ29udGV4dFVzYWdlQ2hhbmdlZF06IChwYXlsb2FkOiBDb252ZXJzYXRpb25Db250ZXh0VXNhZ2VDaGFuZ2VkUGF5bG9hZCkgPT4gdm9pZDtcbiAgICAvKiogXHU2MzA3XHU1QjlBIFJlcXVlc3QgXHU3Njg0XHU5ODg0XHU4QkExXHU2MDNCIENyZWRpdCBcdTUzM0FcdTk1RjRcdTUzRDhcdTUzMTZcdTMwMDIgKi9cbiAgICBbQ29udmVyc2F0aW9uRXZlbnQuRXN0aW1hdGVkQ29zdENoYW5nZWRdOiAocGF5bG9hZDogQ29udmVyc2F0aW9uRXN0aW1hdGVkQ29zdENoYW5nZWRQYXlsb2FkKSA9PiB2b2lkO1xuICAgIFtDb252ZXJzYXRpb25FdmVudC5BdXRvbWF0aW9uQ29tcGxldGVkXTogKHJlc3VsdDogQ29udmVyc2F0aW9uVHVyblJlc3VsdCkgPT4gdm9pZDtcbiAgICBbQ29udmVyc2F0aW9uRXZlbnQuQXV0b21hdGlvbkZhaWxlZF06IChyZXN1bHQ6IENvbnZlcnNhdGlvblR1cm5SZXN1bHQpID0+IHZvaWQ7XG4gICAgW0NvbnZlcnNhdGlvbkV2ZW50LkF1dG9tYXRpb25DYW5jZWxsZWRdOiAocmVzdWx0OiBDb252ZXJzYXRpb25UdXJuUmVzdWx0KSA9PiB2b2lkO1xuICAgIFtDb252ZXJzYXRpb25FdmVudC5BdXRvbWF0aW9uVGltZWRPdXRdOiAocmVzdWx0OiBDb252ZXJzYXRpb25UdXJuUmVzdWx0KSA9PiB2b2lkO1xufVxuIiwgIi8qKiBTdXBwb3J0aW5nIHZhbHVlLW9iamVjdCBhbmQgbWFuYWdlciBjb250cmFjdHMgZm9yIENvbnZlcnNhdGlvbiBlbnRpdGllcy4gKi9cblxuaW1wb3J0IHR5cGUgeyBBcnRpZmFjdCB9IGZyb20gJy4uLy4uLy4uL2RvbWFpbnMvYXJ0aWZhY3QvY29tbW9uL2ZhY2FkZSc7XG5pbXBvcnQgdHlwZSB7IENoYW5nZSB9IGZyb20gJy4uLy4uLy4uL2RvbWFpbnMvY2hhbmdlcy9jb21tb24vZmFjYWRlJztcbmltcG9ydCB0eXBlIHsgQ29udGVudEJsb2NrIH0gZnJvbSAnLi9jaGFubmVsLXR5cGVzJztcbmltcG9ydCB0eXBlIHsgQ29udmVyc2F0aW9uVGVybWluYWxFcnJvciB9IGZyb20gJy4vY29udmVyc2F0aW9uLXRlcm1pbmFsLWVycm9yJztcblxuZXhwb3J0IHR5cGUgeyBBcnRpZmFjdCB9IGZyb20gJy4uLy4uLy4uL2RvbWFpbnMvYXJ0aWZhY3QvY29tbW9uL2ZhY2FkZSc7XG5cbmV4cG9ydCB0eXBlIFVuc3Vic2NyaWJlID0gKCkgPT4gdm9pZDtcbmV4cG9ydCBpbnRlcmZhY2UgQXBpRXJyb3IgeyBlcnJvckNvZGU6IHN0cmluZzsgbWVzc2FnZTogc3RyaW5nOyBkYXRhPzogdW5rbm93biB9XG5cbi8qKiBDb252ZXJzYXRpb24gRW5naW5lIFx1NjMwMVx1NjcwOVx1NzY4NFx1NTQwRVx1NTNGMFx1N0VDOFx1N0FFRlx1Njc0M1x1NUEwMVx1NUZFQlx1NzE2N1x1MzAwMiAqL1xuZXhwb3J0IGludGVyZmFjZSBDb252ZXJzYXRpb25CYWNrZ3JvdW5kVGVybWluYWwge1xuICAgIHRlcm1pbmFsSWQ6IHN0cmluZztcbiAgICBjb21tYW5kPzogc3RyaW5nO1xuICAgIGN3ZD86IHN0cmluZztcbiAgICAvKiogXHU1MjFCXHU1RUZBXHU4QkU1XHU3RUM4XHU3QUVGXHU3Njg0XHU1NDBFXHU1M0YwXHU1REU1XHU1MTc3XHU4QkVEXHU0RTQ5XHU2ODA3XHU5ODk4XHVGRjFCXHU0RTBEXHU0RjlEXHU4RDU2IFJlcXVlc3QgXHU1Mzg2XHU1M0YyXHU2NjJGXHU1NDI2XHU0RUNEXHU1NzI4XHU1MTg1XHU1QjU4XHU0RTJEXHUzMDAyICovXG4gICAgZGVzY3JpcHRpb24/OiBzdHJpbmc7XG4gICAgLyoqIFx1NUI1N1x1NkJCNVx1NUI1OFx1NTcyOFx1NTM3M1x1ODg2OFx1NzkzQVx1N0VDOFx1N0FFRlx1NURGMlx1N0VDRlx1OTAwMFx1NTFGQVx1MzAwMiAqL1xuICAgIGV4aXRTdGF0dXM/OiB7IGV4aXRDb2RlOiBudW1iZXIgfCBudWxsOyBzaWduYWw6IHN0cmluZyB8IG51bGwgfTtcbiAgICBzdGFydGVkQXQ/OiBudW1iZXI7XG4gICAgZW5kZWRBdD86IG51bWJlcjtcbiAgICAvKiogXHU1REYyXHU3N0U1XHU2NUY2XHU1MTczXHU4MDU0XHU1MjMwXHU1MjFCXHU1RUZBXHU4QkU1XHU3RUM4XHU3QUVGXHU3Njg0XHU1REU1XHU1MTc3XHU4QzAzXHU3NTI4XHUzMDAyICovXG4gICAgdG9vbENhbGxJZD86IHN0cmluZztcbn1cblxuLyoqXG4gKiBDb252ZXJzYXRpb24gRW5naW5lIFx1NTM1NVx1NEYxQVx1OEJERFx1NjcwMFx1NTkxQVx1NEZERFx1NzU1OVx1NzY4NFx1NUY4NVx1NTNEMVx1OTAwMSBwcm9tcHQgXHU2NTcwXHU5MUNGXHUzMDAyXG4gKiBcdTVGNTNcdTUyNERcdTYyNjdcdTg4NENcdTRFMkRcdTc2ODQgdHVybiBcdTRFMERcdThCQTFcdTUxNjVcdThCRTVcdTUwM0NcdUZGMENcdTU2RTBcdTZCNjRcdTYwM0JcdTUzNjBcdTc1MjhcdTRFMEFcdTk2NTBcdTRFM0EgMSBcdTRFMkFcdTYyNjdcdTg4NENcdTRFMkQgKyAxOSBcdTRFMkFcdTdCNDlcdTVGODVcdTRFMkRcdTMwMDJcbiAqL1xuZXhwb3J0IGNvbnN0IENPTlZFUlNBVElPTl9QUk9NUFRfUVVFVUVfTUFYX1BFTkRJTkcgPSAxOTtcblxuLyoqIGBzZW5kUHJvbXB0YCBcdTU2RTBcdTVGODVcdTUzRDFcdTkwMDFcdTk2MUZcdTUyMTdcdThGQkVcdTUyMzBcdTVCQjlcdTkxQ0ZcdTRFMEFcdTk2NTBcdTgwMENcdTYyRDJcdTdFRERcdTMwMDIgKi9cbmV4cG9ydCBjb25zdCBDT05WRVJTQVRJT05fUFJPTVBUX1FVRVVFX0ZVTEwgPSAnQ09OVkVSU0FUSU9OX1BST01QVF9RVUVVRV9GVUxMJztcblxuLyoqXG4gKiBSZXF1ZXN0IFx1NTM4Nlx1NTNGMlx1NTM1NVx1OTg3NVx1OEY2Rlx1OTg4NFx1N0I5N1x1MzAwMlx1OTk5Nlx1NUM0RiBwcmVsb2FkXHUzMDAxXHU2NzAwXHU2NUIwXHU1QzNFXHU5ODc1XHU1MjM3XHU2NUIwXHU0RTBFXHU1NDExXHU1MjREXHU1MjA2XHU5ODc1XHU3RURGXHU0RTAwXHU0RjdGXHU3NTI4IDUgTWlCXHVGRjBDXG4gKiBcdTRFRTVcdTVCOENcdTY1NzQgUmVxdWVzdCBcdTRFM0FcdThGQjlcdTc1NENcdUZGMUJcdTUzNTVcdTRFMkFcdThEODVcdTU5MjcgUmVxdWVzdCBcdTRFQ0RcdTRGMUFcdTVCOENcdTY1NzRcdThGRDRcdTU2REVcdTMwMDJcbiAqL1xuZXhwb3J0IGNvbnN0IFJFUVVFU1RfSElTVE9SWV9QQUdFX0JZVEVfTEVOR1RIID0gNSAqIDEwMjQgKiAxMDI0O1xuXG4vKiogcmVzZW5kIFx1NURGMlx1NjNEMFx1NEVBNCByb2xsYmFjayBcdTU0MEVcdTc2ODQgYWN0aXZlIGJyYW5jaCBcdTUzRDhcdTY2RjRcdTdFRDNcdTY3OUNcdTMwMDIgKi9cbmV4cG9ydCBpbnRlcmZhY2UgQ29udmVyc2F0aW9uUmVzZW5kUmVzdWx0IHtcbiAgICBicmFuY2hDaGFuZ2VkOiB0cnVlO1xuICAgIHRydW5jYXRlZEZyb21SZXF1ZXN0SWQ6IHN0cmluZztcbiAgICByZW1vdmVkUmVxdWVzdElkczogc3RyaW5nW107XG59XG5cbmV4cG9ydCB0eXBlIENvbnZlcnNhdGlvbkJhY2tncm91bmRUYXNrQ2FuY2VsT3V0Y29tZSA9XG4gICAgfCAnY2FuY2VsbGVkJ1xuICAgIHwgJ2FscmVhZHlfZXhpdGVkJ1xuICAgIHwgJ25vdF9mb3VuZCdcbiAgICB8ICdjYW5jZWxfZmFpbGVkJztcblxuZXhwb3J0IGludGVyZmFjZSBDb252ZXJzYXRpb25CYWNrZ3JvdW5kVGFza0NhbmNlbFJlc3VsdCB7XG4gICAgb3V0Y29tZTogQ29udmVyc2F0aW9uQmFja2dyb3VuZFRhc2tDYW5jZWxPdXRjb21lO1xuICAgIHRlcm1pbmFsSWQ6IHN0cmluZztcbn1cbmV4cG9ydCBpbnRlcmZhY2UgUGFnZWQ8VD4ge1xuICAgIHRvdGFsOiBudW1iZXI7XG4gICAgcGFnZTogbnVtYmVyO1xuICAgIGl0ZW1zOiBUW107XG4gICAgLyoqIFx1NUY1M1x1NTI0RFx1NTIxN1x1ODg2OFx1NEU0Qlx1NTI0RFx1NEVDRFx1NjcwOVx1NjZGNFx1NjVFOVx1NTM4Nlx1NTNGMlx1RkYxQnJlbmRlcmVyIFx1OTg3Nlx1OTBFOFx1NTRFOFx1NTE3NVx1NTNFRlx1NjM2RVx1NkI2NFx1N0VFN1x1N0VFRFx1NTQxMVx1NEUwQVx1NkVEQVx1NTJBOFx1NTJBMFx1OEY3RFx1MzAwMiAqL1xuICAgIGhhc09sZGVyPzogYm9vbGVhbjtcbn1cblxuZXhwb3J0IGludGVyZmFjZSBSZXF1ZXN0SGlzdG9yeVF1ZXJ5IHtcbiAgICAvKiogTG9hZCBoaXN0b3J5IHN0cmljdGx5IGJlZm9yZSB0aGlzIHJlcXVlc3QuIE9taXQgaXQgdG8gbG9hZCB0aGUgbGF0ZXN0IHBhZ2UuICovXG4gICAgYmVmb3JlUmVxdWVzdElkPzogc3RyaW5nO1xuICAgIC8qKiBUYXJnZXQgcGFnZSBzaXplIGluIGJ5dGVzLiBBIHNpbmdsZSByZXF1ZXN0IGlzIG5ldmVyIHNwbGl0LiAqL1xuICAgIGJ5dGVMZW5ndGg/OiBudW1iZXI7XG4gICAgLyoqXG4gICAgICogYHBhZ2VgIFx1NEVDNVx1OEZENFx1NTZERVx1NjcyQ1x1NkIyMVx1NUJGOVx1NUU5NFx1NzY4NFx1NjMwMVx1NEU0NVx1NTMxNlx1OTg3NVx1RkYxQmBhbGwtbG9hZGVkYCBcdThGRDRcdTU2REUgU3RvcmUgXHU0RTJEXHU2MjQwXHU2NzA5XHU1REYyXHU3MjY5XHU1MzE2XHU1Mzg2XHU1M0YyXHUzMDAyXG4gICAgICogXHU3RjNBXHU3NzAxXHU0RTNBIGBhbGwtbG9hZGVkYFx1RkYwQ1x1NEZERFx1NzU1OSBsb2FkQWxsIC8gXHU1Mzg2XHU1M0YyXHU4REYzXHU4RjZDXHU2MjQwXHU5NzAwXHU3Njg0XHU1QjhDXHU2NTc0XHU1REYyXHU1MkEwXHU4RjdEXHU3RUQzXHU2NzlDXHUzMDAyXG4gICAgICovXG4gICAgcmVzdWx0U2NvcGU/OiAncGFnZScgfCAnYWxsLWxvYWRlZCc7XG59XG5cbi8qKlxuICogXHU3NTI4XHU2MjM3XHU1NzI4XHU1MjIwXHU5NjY0XHU3ODZFXHU4QkE0XHU2ODQ2XHU5MUNDXHU5MDA5XHU0RTg2XHU1M0Q2XHU2RDg4XHUzMDAyXG4gKlxuICogXHU4RkQ5XHU2NjJGKipcdTZCNjNcdTVFMzhcdTZENDFcdTdBMEIqKlx1ODAwQ1x1OTc1RVx1NTkzMVx1OEQyNVx1RkYxQVx1OEMwM1x1NzUyOFx1NjVCOVx1NUU5NFx1NUY1M1x1NEUyRFx1NjVBRFx1NjI3OVx1OTFDRlx1NTIyMFx1OTY2NFx1MzAwMVx1NEZERFx1NjMwMVx1Nzg2RVx1OEJBNFx1NUYzOVx1N0E5N1x1NjI1M1x1NUYwMFx1RkYwQ1xuICogXHU0RTE0XHU0RTBEXHU4OTgxXHU2MjhBXHU1QjgzXHU1RjUzXHU5NTE5XHU4QkVGXHU2M0QwXHU3OTNBXHU3RUQ5XHU3NTI4XHU2MjM3XHUzMDAyXHU3NTI4IHtAbGluayBpc0NvbnZlcnNhdGlvbkRlbGV0ZUNhbmNlbGxlZH0gXHU1MjI0XHU1MjJCXHUzMDAyXG4gKi9cbmV4cG9ydCBjb25zdCBDT05WRVJTQVRJT05fREVMRVRFX0NBTkNFTExFRCA9ICdDT05WRVJTQVRJT05fREVMRVRFX0NBTkNFTExFRCc7XG5cbi8qKiBcdTUyMjRcdTUyMkIgYGRlbGV0ZSgpYCBcdTc2ODRcdThGRDRcdTU2REVcdTUwM0NcdTY2MkZcdTU0MjZcdTRFM0FcdTMwMENcdTc1MjhcdTYyMzdcdTUzRDZcdTZEODhcdTMwMERcdUZGMENcdTUzM0FcdTUyMkJcdTRFOEVcdTc3MUZcdTVCOUVcdTU5MzFcdThEMjVcdTMwMDIgKi9cbmV4cG9ydCBmdW5jdGlvbiBpc0NvbnZlcnNhdGlvbkRlbGV0ZUNhbmNlbGxlZChyZXN1bHQ6IHZvaWQgfCBBcGlFcnJvcik6IHJlc3VsdCBpcyBBcGlFcnJvciB7XG4gICAgcmV0dXJuIEJvb2xlYW4ocmVzdWx0KSAmJiAocmVzdWx0IGFzIEFwaUVycm9yKS5lcnJvckNvZGUgPT09IENPTlZFUlNBVElPTl9ERUxFVEVfQ0FOQ0VMTEVEO1xufVxuXG5leHBvcnQgdHlwZSBNb2RlID0gc3RyaW5nO1xuZXhwb3J0IHR5cGUgQmxvY2sgPSBDb250ZW50QmxvY2s7XG5leHBvcnQgaW50ZXJmYWNlIE1jcFNlcnZlckNvbmZpZyB7IFtrZXk6IHN0cmluZ106IHVua25vd247IH1cbmV4cG9ydCBpbnRlcmZhY2UgQ29ubmVjdG9yIHsgaWQ/OiBzdHJpbmc7IG5hbWU6IHN0cmluZzsgW2tleTogc3RyaW5nXTogdW5rbm93bjsgfVxuZXhwb3J0IGludGVyZmFjZSBRdWV1ZVByb21wdCB7XG4gICAgaWQ6IHN0cmluZztcbiAgICBjb250ZW50PzogQmxvY2tbXTtcbiAgICAvKiogXHU0RTFBXHU1MkExXHU0RkE3XHU1RTQyXHU3QjQ5XHU4QkY3XHU2QzQyIElEXHVGRjFCXHU2MzkyXHU5NjFGXHU1NDBFXHU0RUNEXHU5NjhGXHU1QkY5XHU1RTk0IFByb21wdCBcdTRGMjBcdTkwMTJcdTMwMDIgKi9cbiAgICBjbGllbnRSZXF1ZXN0SWQ/OiBzdHJpbmc7XG4gICAgLyoqIFByb21wdCBcdTg4QUIgQ29yZSBcdTYzQTVcdTUzRDdcdThGREJcdTUxNjVcdTk2MUZcdTUyMTdcdTc2ODRcdTY1RjZcdTk1RjRcdUZGMUJcdTc1MjhcdTRFOEVcdThERThcdThGREJcdTdBMEJcdTYyOTVcdTVGNzFcdTRGRERcdTYzMDEgRklGTyBcdTk4N0FcdTVFOEZcdTMwMDIgKi9cbiAgICBhY2NlcHRlZEF0PzogbnVtYmVyO1xuICAgIC8qKiBcdTU0MENcdTRFMDAgQ29udmVyc2F0aW9uIFx1NTE4NVx1NTM1NVx1OEMwM1x1OTAxMlx1NTg5RVx1NzY4NFx1NjNBNVx1NTNEN1x1NUU4Rlx1NTNGN1x1RkYxQmFjY2VwdGVkQXQgXHU1NDBDXHU2QkVCXHU3OUQyXHU2NUY2XHU3NTI4XHU0RThFXHU3QTMzXHU1QjlBXHU2MzkyXHU1RThGXHUzMDAyICovXG4gICAgYWNjZXB0ZWRTZXF1ZW5jZT86IG51bWJlcjtcbiAgICAvKiogU0RLIFx1NTE4NVx1OTBFOFx1NEYxQVx1OEJERFx1NjNBN1x1NTIzNlx1NjMwN1x1NEVFNFx1RkYxQlx1NEUwRFx1NEYxQVx1NEY1Q1x1NEUzQVx1NjY2RVx1OTAxQVx1NzUyOFx1NjIzN1x1NjU4N1x1NjcyQ1x1NTNEMVx1OTAwMVx1N0VEOVx1NkEyMVx1NTc4Qlx1MzAwMiAqL1xuICAgIHNlc3Npb25Db250cm9sPzogJ2NsZWFyJyB8ICdjb21wYWN0JztcbiAgICBba2V5OiBzdHJpbmddOiB1bmtub3duO1xufVxuLyoqIGBzZW5kTm93YCBcdTc2ODRcdTUzOUZcdTVCNTBcdTU5MDRcdTdGNkVcdTdFRDNcdTY3OUNcdUZGMUJcdTZEODhcdThEMzlcdTRGQTdcdTY1RTBcdTk3MDBcdTY4MzlcdTYzNkVcdTUzRUZcdTgwRkRcdThGQzdcdTY3MUZcdTc2ODRcdTVGRDlcdTk1RjJcdTVGRUJcdTcxNjdcdTYzQThcdTY1QURcdTdFRDNcdTY3OUNcdTMwMDIgKi9cbmV4cG9ydCB0eXBlIFF1ZXVlU2VuZE5vd0Rpc3Bvc2l0aW9uID0gJ21pc3NpbmcnIHwgJ3N0YXJ0ZWQnIHwgJ3N0ZWVyZWQnIHwgJ3F1ZXVlZCcgfCAnYWNjZXB0ZWQnIHwgJ2Jsb2NrZWQnO1xuLyoqIFx1OTYxRlx1NTIxN1x1NjY4Mlx1NTA1Q1x1NTM5Rlx1NTZFMFx1RkYxQmNhbmNlbCBcdTY2ODJcdTUwNUNcdTc1MzEgVUkgXHU4OUU2XHU1M0QxXHVGRjBDbWFudWFsL2Vycm9yIFx1NzUzMVx1NzUyOFx1NjIzN1x1NjIxNlx1OTUxOVx1OEJFRlx1ODlFNlx1NTNEMVx1MzAwMiAqL1xuZXhwb3J0IHR5cGUgQ29udmVyc2F0aW9uUHJvbXB0UXVldWVQYXVzZVJlYXNvbiA9ICdjYW5jZWwnIHwgJ21hbnVhbCcgfCAnZXJyb3InO1xuZXhwb3J0IGludGVyZmFjZSBQYWdlIHsgcGFnZT86IG51bWJlcjsgc2l6ZT86IG51bWJlcjsgb2Zmc2V0PzogbnVtYmVyOyBsaW1pdD86IG51bWJlcjsgfVxuZXhwb3J0IGludGVyZmFjZSBDb252ZXJzYXRpb25GaWxlIHsgcGF0aDogc3RyaW5nOyBuYW1lPzogc3RyaW5nOyBba2V5OiBzdHJpbmddOiB1bmtub3duOyB9XG5cbi8qKiBcdTVCQTJcdTYyMzdcdTdBRUZcdTU0MTEgYWdlbnQgXHU1OEYwXHU2NjBFXHU3Njg0XHU1M0VGXHU1OUQ0XHU2MjU4XHU1REU1XHU1MTc3XHU1QjlBXHU0RTQ5XHVGRjFCXHU1M0VBXHU1NDJCXHU1M0VGXHU4REU4XHU4RkRCXHU3QTBCXHU0RjIwXHU4RjkzXHU3Njg0IHNjaGVtYVx1MzAwMiAqL1xuZXhwb3J0IGludGVyZmFjZSBDbGllbnRUb29sRGVmaW5pdGlvbiB7XG4gICAgaWQ6IHN0cmluZztcbiAgICBuYW1lOiBzdHJpbmc7XG4gICAgZGVzY3JpcHRpb246IHN0cmluZztcbiAgICBpbnB1dFNjaGVtYTogUmVjb3JkPHN0cmluZywgdW5rbm93bj47XG4gICAgY2F0ZWdvcnk/OiBzdHJpbmc7XG4gICAgcmVxdWlyZXNBcHByb3ZhbD86IGJvb2xlYW47XG4gICAgbWV0YWRhdGE/OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPjtcbn1cblxuLyoqIGFnZW50IFx1OEJGN1x1NkM0Mlx1NUJBMlx1NjIzN1x1N0FFRlx1NjI2N1x1ODg0Q1x1NURFNVx1NTE3N1x1NjVGNlx1RkYwQ1x1OTY4Rlx1OEMwM1x1NzUyOFx1NEYyMFx1OTAxMlx1NzY4NFx1NEYxQVx1OEJERFx1NEUwRVx1OEZGRFx1OEUyQVx1NEUwQVx1NEUwQlx1NjU4N1x1MzAwMiAqL1xuZXhwb3J0IGludGVyZmFjZSBDbGllbnRUb29sSW52b2NhdGlvbiB7XG4gICAgY29udmVyc2F0aW9uSWQ6IHN0cmluZztcbiAgICB0b29sQ2FsbElkOiBzdHJpbmc7XG4gICAgdGltZW91dD86IG51bWJlcjtcbn1cblxuLyoqIFx1NUJBMlx1NjIzN1x1N0FFRlx1NURFNVx1NTE3N1x1NzY4NFx1NjgwN1x1NTFDNlx1NjI2N1x1ODg0Q1x1N0VEM1x1Njc5Q1x1RkYxQlx1NEYxQVx1NTM5Rlx1NjgzN1x1NTZERVx1NTE5OVx1N0VEOSBBQ1AgZGVsZWdhdGVUb29sIFx1OEJGN1x1NkM0Mlx1MzAwMiAqL1xuZXhwb3J0IGludGVyZmFjZSBDbGllbnRUb29sUmVzdWx0IHtcbiAgICBzdGF0dXM6ICdzdWNjZXNzJyB8ICdlcnJvcicgfCAndGltZW91dCcgfCAnY2FuY2VsbGVkJztcbiAgICBvdXRwdXQ/OiB1bmtub3duO1xuICAgIGVycm9yPzogeyBtZXNzYWdlOiBzdHJpbmc7IGNvZGU/OiBzdHJpbmc7IGRldGFpbHM/OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiB9O1xuICAgIGR1cmF0aW9uPzogbnVtYmVyO1xuICAgIG1ldGFkYXRhPzogUmVjb3JkPHN0cmluZywgdW5rbm93bj47XG59XG5cbi8qKiBcdTVCQTJcdTYyMzdcdTdBRUZcdTVERTVcdTUxNzdcdThGRDBcdTg4NENcdTY1RjZcdTVCRjlcdThDNjFcdUZGMUJleGVjdXRlIFx1NkMzOFx1NEUwRFx1OERFOCBJUEMgXHU1RThGXHU1MjE3XHU1MzE2XHVGRjBDXHU0RUM1XHU1NzI4XHU1REU1XHU1MTc3XHU2MkU1XHU2NzA5XHU2NUI5XHU4RkRCXHU3QTBCXHU2MjY3XHU4ODRDXHUzMDAyICovXG5leHBvcnQgaW50ZXJmYWNlIENsaWVudFRvb2wgZXh0ZW5kcyBDbGllbnRUb29sRGVmaW5pdGlvbiB7XG4gICAgZXhlY3V0ZShpbnB1dDogUmVjb3JkPHN0cmluZywgdW5rbm93bj4sIGNvbnRleHQ6IENsaWVudFRvb2xJbnZvY2F0aW9uKTogUHJvbWlzZTxDbGllbnRUb29sUmVzdWx0Pjtcbn1cblxuZXhwb3J0IGludGVyZmFjZSBNZXNzYWdlQ2h1bmsgeyB0eXBlOiBzdHJpbmc7IHRleHQ/OiBzdHJpbmc7IFtrZXk6IHN0cmluZ106IHVua25vd247IH1cblxuLyoqXG4gKiBcdTYzMDJcdThENzdcdTRFQTRcdTRFOTJcdThCRjdcdTZDNDJcdTc2ODQqKlx1OEJFRFx1NEU0OVx1NTIwNlx1N0M3QioqXHVGRjBDXHU0RjlCIFVJIFx1OTAwOVx1NjJFOVx1NURFRVx1NUYwMlx1NTMxNlx1OTc2Mlx1Njc3Rlx1RkYwOFx1NjVCMFx1NTg5RVx1NEVBNFx1NEU5Mlx1NURFNVx1NTE3N1x1NTNFQVx1OTcwMFx1NjI2OVx1OEZEOVx1NEUyQVx1Njc5QVx1NEUzRSArIFx1NkQzRVx1NzUxRlx1NTFGRFx1NjU3MFx1RkYwOVx1MzAwMlxuICogLSBgdG9vbGAgICAgIFx1NjY2RVx1OTAxQVx1NURFNVx1NTE3N1x1NjM4OFx1Njc0M1x1RkYwOFdyaXRlL0VkaXQvQmFzaFx1MjAyNlx1RkYwOVxuICogLSBgcXVlc3Rpb25gIEFza1VzZXJRdWVzdGlvbiBcdTU5MUFcdTk1RUVcdTk4OThcdTk1RUVcdTUzNzdcdUZGMDhcdTk3MDAgYW5zd2Vyc1x1RkYwOVxuICogLSBgcGxhbmAgICAgIEV4aXRQbGFuTW9kZSBcdThCQTFcdTUyMTJcdTc4NkVcdThCQTRcdUZGMDhcdTU5MUFcdTRFMDBcdTRFMkEgYHJlamVjdF9hbmRfZXhpdF9wbGFuYCBcdTkwMDlcdTk4NzlcdUZGMDlcbiAqIC0gYHNhbmRib3hgICBCYXNoIFx1NkM5OVx1N0JCMVx1NjJFNlx1NjIyQVx1RkYwOFx1NUUyNlx1NjJFNlx1NjIyQVx1OEJFNlx1NjBDNVx1RkYwOVxuICogLSBgbWNwVWlgICAgIE1DUCBVSSBcdTdCMkNcdTRFMDlcdTY1QjkgaWZyYW1lIFx1NTNDRFx1NTQxMVx1OEMwM1x1NURFNVx1NTE3N1x1NjM4OFx1Njc0M1xuICogLSBgaGlnaENyZWRpdGAgVmlkZW9HZW4vSW1hZ2VHZW4vQ29tcHV0ZXIgVXNlIFx1NUVGQVx1NEVGQlx1NTJBMVx1N0I0OVx1OUFEOFx1NzlFRlx1NTIwNlx1NURFNVx1NTE3N1x1NjM4OFx1Njc0M1xuICogLSBgcG9pX3BpY2tgICBwaWNrX2xvY2F0aW9uIFx1OTAwOVx1NzBCOVx1RkYwOFx1NTNFQVx1OEJDNlx1NTIyQlx1OEZEQiB3YWl0aW5nXHVGRjBDXHU1RTk0XHU3QjU0XHU4RDcwIENvbnZlcnNhdGlvbi5hbnN3ZXJQb2lRdWVzdGlvblx1RkYwOVxuICogLSBgbWNwQ29ubmVjdGlvbmAgXHU0RTEzXHU1QkI2XHU4RkQwXHU4ODRDXHU0RTJEXHU1NDdEXHU0RTJEXHU2NzJBXHU2Mzg4XHU2NzQzL1x1NjcyQVx1OTE0RFx1N0Y2RVx1NzY4NCBNQ1BcdUZGMDgqKmRhZW1vbiBcdTRGQTdcdTUzRDFcdThENzcqKlx1RkYwQ1x1ODlDMVxuICogICBNY3BDb25uZWN0aW9uR3VpZGFuY2VSZWdpc3RyeVx1RkYwOVx1RkYwQ1x1NUU5NFx1N0I1NFx1OEQ3MCBwZW5kaW5nIGBvcHRpb25JZGBcdUZGMDhjb25uZWN0ZWQgLyBza2lwcGVkXHVGRjA5XG4gKi9cbmV4cG9ydCB0eXBlIFBlbmRpbmdDYXRlZ29yeSA9ICd0b29sJyB8ICdxdWVzdGlvbicgfCAncGxhbicgfCAnc2FuZGJveCcgfCAnbWNwVWknIHwgJ2hpZ2hDcmVkaXQnIHwgJ3BvaV9waWNrJyB8ICdtY3BDb25uZWN0aW9uJztcblxuLyoqIFx1NjMwMlx1OEQ3N1x1OEJGN1x1NkM0Mlx1NjQzQVx1NUUyNlx1NzY4NFx1NEUwMFx1NEUyQVx1NTNFRlx1OTAwOVx1OTg3OVx1RkYwOFx1NTM5Rlx1NjgzN1x1OTAwRlx1NEYyMCBhZ2VudC1jbGkgXHU3Njg0IFBlcm1pc3Npb25PcHRpb25cdUZGMENVSSBcdTc2RjRcdTYzQTVcdTZFMzJcdTY3RDNcdTYzMDlcdTk0QUVcdUZGMDlcdTMwMDIgKi9cbmV4cG9ydCBpbnRlcmZhY2UgUGVuZGluZ09wdGlvbiB7XG4gICAgLyoqIFx1NUU5NFx1N0I1NFx1NjVGNlx1NTZERVx1NEYyMFx1NzY4NCBpZFx1RkYwOGFsbG93IC8gYWxsb3dfYWx3YXlzIC8gcmVqZWN0IC8gcmVqZWN0X2FuZF9leGl0X3BsYW5cdTIwMjZcdUZGMDlcdTMwMDIgKi9cbiAgICBvcHRpb25JZDogc3RyaW5nO1xuICAgIC8qKiBhbGxvd19hbHdheXMgLyBhbGxvd19vbmNlIC8gcmVqZWN0X29uY2UgXHU3QjQ5XHVGRjA4XHU3NTI4XHU0RThFIFVJIFx1NTIwNlx1N0VDNC9cdTY4MzdcdTVGMEZcdUZGMDlcdTMwMDIgKi9cbiAgICBraW5kPzogc3RyaW5nO1xuICAgIC8qKiBcdTVDNTVcdTc5M0FcdTU0MERcdUZGMDhcdTU5ODIgQWx3YXlzIEFsbG93IC8gQWxsb3cgLyBSZWplY3QgLyBFeGl0IHBsYW4gbW9kZVx1RkYwOVx1MzAwMiAqL1xuICAgIG5hbWU/OiBzdHJpbmc7XG59XG5cbi8qKiBTYW5kYm94IFx1NjI3OVx1OTFDRlx1NTIyMFx1OTY2NFx1NjJFNlx1NjIyQVx1NzY4NFx1NzY3RFx1NTQwRFx1NTM1NVx1OEJFNlx1NjBDNVx1MzAwMiAqL1xuZXhwb3J0IGludGVyZmFjZSBTYW5kYm94QnVsa0RlbGV0ZUluZm8ge1xuICAgIGNvdW50OiBudW1iZXI7XG4gICAgdGhyZXNob2xkOiBudW1iZXI7XG59XG5cbi8qKiBcdTYzMDJcdThENzdcdThCRjdcdTZDNDJcdTc2ODRcdTVERUVcdTVGMDJcdTUzMTZcdTUxNDNcdTRGRTFcdTYwNkZcdUZGMDhcdTYzMDkgY2F0ZWdvcnkgXHU2NDNBXHU1RTI2XHVGRjBDVUkgXHU2RTMyXHU2N0QzXHU3NTI4XHVGRjFCXHU3NTMxIGFnZW50IFx1OTAwRlx1NEYyMFx1NUI1N1x1NkJCNVx1NzY3RFx1NTQwRFx1NTM1NVx1NkQzRVx1NzUxRlx1RkYwOVx1MzAwMiAqL1xuZXhwb3J0IGludGVyZmFjZSBQZW5kaW5nTWV0YWRhdGEge1xuICAgIC8qKiBgY2F0ZWdvcnk9PT0nc2FuZGJveCdgXHVGRjFBXHU1M0VBXHU2NkI0XHU5NzMyXHU1MzYxXHU3MjQ3XHU0RTBFXHU1QkExXHU4QkExXHU2MjQwXHU5NzAwXHU1QjU3XHU2QkI1XHVGRjBDXHU0RTBEXHU5MDBGXHU0RjIwXHU1QjhDXHU2NTc0IHJhd0lucHV0XHUzMDAyICovXG4gICAgc2FuZGJveD86IHtcbiAgICAgICAgcmVxdWVzdElkPzogc3RyaW5nO1xuICAgICAgICBpbnRlcmNlcHRUeXBlPzogc3RyaW5nO1xuICAgICAgICB0YXJnZXQ/OiBzdHJpbmc7XG4gICAgICAgIG9wZXJhdGlvbj86IHN0cmluZztcbiAgICAgICAgZGVzY3JpcHRpb24/OiBzdHJpbmc7XG4gICAgICAgIGFwcHJvdmFsTW9kZT86IHN0cmluZztcbiAgICAgICAgYnlwYXNzSGludD86IHN0cmluZztcbiAgICAgICAgY29tbWFuZD86IHN0cmluZztcbiAgICAgICAgZGV0YWlscz86IHsgYnVsa0RlbGV0ZUluZm8/OiBTYW5kYm94QnVsa0RlbGV0ZUluZm8gfTtcbiAgICB9O1xuICAgIC8qKiB0ZWFtIG1lbWJlciBcdTVERTVcdTUxNzdcdTYzODhcdTY3NDNcdUZGMUFcdThERUZcdTc1MzFcdTUyMzBcdTYyMTBcdTU0NThcdTk3NjJcdTY3N0YgKyBcdTVDNTVcdTc5M0FcdTVGNTJcdTVDNUVcdTMwMDIgKi9cbiAgICB0ZWFtTWVtYmVyPzogeyBuYW1lPzogc3RyaW5nOyBjb2xvcj86IHN0cmluZyB9O1xuICAgIC8qKiBgY2F0ZWdvcnk9PT0nbWNwVWknYFx1RkYxQVx1N0IyQ1x1NEUwOVx1NjVCOSBVSSBcdTUzQ0RcdTU0MTFcdThDMDNcdTVERTVcdTUxNzdcdThCRTZcdTYwQzVcdTMwMDIgKi9cbiAgICBtY3BVaT86IHsgdGFyZ2V0Pzogc3RyaW5nOyBvcGVyYXRpb24/OiBzdHJpbmc7IGRlc2NyaXB0aW9uPzogc3RyaW5nIH07XG4gICAgLyoqIEFnZW50IENMSSBcdTc2N0RcdTU0MERcdTUzNTVcdTkwMEZcdTRGMjBcdTc2ODRcdTkwMUFcdTc1MjhcdTVCQTFcdTYyNzlcdTY4MDdcdThCQzZcdUZGMENVSSBcdTY1RTBcdTk3MDBcdTRGOURcdThENTZcdTVERTVcdTUxNzdcdTMwMDFTa2lsbCBcdTYyMTZcdTZBMjFcdTU3OEJcdTU0MERcdTc5RjBcdTUyMjRcdTY1QURcdTMwMDIgKi9cbiAgICBhcHByb3ZhbD86IHtcbiAgICAgICAgcG9saWN5SWQ6IHN0cmluZztcbiAgICAgICAgY2F0ZWdvcnk6IHN0cmluZztcbiAgICAgICAga2luZDogc3RyaW5nO1xuICAgICAgICBzY29wZT86ICdvbmNlJyB8ICdzZXNzaW9uJztcbiAgICB9O1xuICAgIC8qKiBgZWxpY2l0YXRpb24vY3JlYXRlYCBcdTVGQUVcdTRGRTFcdTY1MkZcdTRFRDhcdTUzNjFcdTcyNDdcdUZGMUFcdTRGOUIgUmVuZGVyZXIgXHU0RUNFIGdldFBlbmRpbmdJbmZvKCkgXHU1ODlFXHU5MUNGXHU2Mjk1XHU1RjcxXHUzMDAyICovXG4gICAgd2VpeGlucGF5Pzoge1xuICAgICAgICBlbGljaXRhdGlvbklkOiBzdHJpbmc7XG4gICAgICAgIHJlcXVlc3RJZD86IHN0cmluZztcbiAgICAgICAgYmxvY2tJbmRleD86IG51bWJlcjtcbiAgICAgICAgdG9vbENhbGxJZD86IHN0cmluZztcbiAgICAgICAgbW9kZT86IHN0cmluZztcbiAgICAgICAgbWVzc2FnZT86IHN0cmluZztcbiAgICAgICAgY29uZmlnPzogUmVjb3JkPHN0cmluZywgdW5rbm93bj47XG4gICAgfTtcbiAgICAvKiogXHU0RjAxXHU0RTFBXHU4RkQwXHU4ODRDXHU2NUY2XHU1Qjg5XHU1MTY4XHU4QkUyXHU5NUVFXHU1MzYxXHVGRjFBXHU4RDcwXHU2NjZFXHU5MDFBIHRvb2wgcGVuZGluZyBcdTkwMUFcdTkwNTNcdUZGMENcdTRFMERcdTVFNzZcdTUxNjUgc2FuZGJveFx1MzAwMiAqL1xuICAgIHJ1bnRpbWVTZWN1cml0eT86IHtcbiAgICAgICAgYWN0aW9uPzogc3RyaW5nO1xuICAgICAgICBzY2VuZT86IHN0cmluZztcbiAgICAgICAgcnVsZU5hbWU/OiBzdHJpbmc7XG4gICAgICAgIGhpdENvbnRlbnQ/OiBzdHJpbmc7XG4gICAgICAgIGF1ZGl0SWQ/OiBzdHJpbmc7XG4gICAgICAgIGRlZmF1bHREZWNpc2lvbj86IHN0cmluZztcbiAgICB9O1xufVxuXG4vKiogQXNrVXNlclF1ZXN0aW9uIFx1NzY4NFx1NEUwMFx1NEUyQVx1OTVFRVx1OTg5OFx1RkYwOFx1NTQyQlx1NTNFRlx1OTAwOVx1OTg3OVx1RkYwOVx1MzAwMiAqL1xuZXhwb3J0IGludGVyZmFjZSBQZW5kaW5nUXVlc3Rpb24ge1xuICAgIC8qKiBcdTk1RUVcdTk4OTggaWRcdUZGMDhcdTVFOTRcdTdCNTQgYW5zd2VycyBtYXAgXHU3Njg0XHU5NTJFXHVGRjA5XHUzMDAyICovXG4gICAgaWQ6IHN0cmluZztcbiAgICAvKiogXHU5NUVFXHU5ODk4XHU2NTg3XHU2NzJDXHUzMDAyICovXG4gICAgcXVlc3Rpb246IHN0cmluZztcbiAgICAvKiogXHU3N0VEXHU2ODA3XHU5ODk4XHUzMDAyICovXG4gICAgaGVhZGVyPzogc3RyaW5nO1xuICAgIC8qKiBcdTUzRUZcdTkwMDlcdTk4NzlcdUZGMDhsYWJlbCBcdTUzNzNcdTVFOTRcdTdCNTRcdTY1RjZcdTYzRDBcdTRFQTRcdTc2ODRcdTUwM0NcdUZGMDlcdTMwMDIgKi9cbiAgICBvcHRpb25zOiBBcnJheTx7IGxhYmVsOiBzdHJpbmc7IGRlc2NyaXB0aW9uPzogc3RyaW5nIH0+O1xuICAgIC8qKiBcdTY2MkZcdTU0MjZcdTU5MUFcdTkwMDlcdTMwMDIgKi9cbiAgICBtdWx0aVNlbGVjdD86IGJvb2xlYW47XG59XG4vKiogXHU3NTI4XHU2MjM3XHU3QjU0XHU2ODQ4XHVGRjFBXHU2MzA5IHF1ZXN0aW9uSWQgXHU5NTJFXHU2M0E3XHVGRjBDXHU1MDNDID0gXHU5MDA5XHU0RTJEXHU3Njg0IG9wdGlvbiBsYWJlbFx1RkYwOFx1NTkxQVx1OTAwOVx1NEUzQVx1NjU3MFx1N0VDNFx1RkYwOVx1MzAwMiAqL1xuZXhwb3J0IHR5cGUgUXVlc3Rpb25BbnN3ZXJzID0gUmVjb3JkPHN0cmluZywgc3RyaW5nIHwgc3RyaW5nW10+O1xuXG4vKiogYHJlc29sdmVQZW5kaW5nYCBcdTc2ODRcdTVFOTRcdTdCNTRcdTkwMDlcdTk4NzlcdTMwMDIgKi9cbmV4cG9ydCBpbnRlcmZhY2UgUmVzb2x2ZVBlbmRpbmdPcHRpb25zIHtcbiAgICAvKipcbiAgICAgKiBVSSBcdTkwMDlcdTRFMkRcdTc2ODQgb3B0aW9uSWRcdUZGMDhgYWxsb3dgIC8gYGFsbG93X2Fsd2F5c2AgLyBgcmVqZWN0YCAvIGByZWplY3RfYW5kX2V4aXRfcGxhbmBcdTIwMjZcdUZGMDlcdTMwMDJcbiAgICAgKiBhZ2VudC1jbGkgXHU4MUVBXHU4ODRDIG1hcCBcdTYyMTAgZGVjaXNpb25cdUZGMENTREsgXHU2NUUwXHU5NzAwXHU1MTczXHU1RkMzIGRlY2lzaW9uIFx1Njc5QVx1NEUzRVx1MzAwMlxuICAgICAqL1xuICAgIG9wdGlvbklkOiBzdHJpbmc7XG4gICAgLyoqIFx1NEVDNSBgY2F0ZWdvcnk9PT0ncXVlc3Rpb24nYFx1RkYxQVx1NzUyOFx1NjIzN1x1NUJGOVx1NTQwNFx1OTVFRVx1OTg5OFx1NzY4NFx1NEY1Q1x1N0I1NFx1RkYwOFx1N0VDRiByZXNvbHZlSW50ZXJydXB0aW9uIFx1OTAwMVx1OEZCRVx1RkYwOVx1MzAwMiAqL1xuICAgIGFuc3dlcnM/OiBRdWVzdGlvbkFuc3dlcnM7XG4gICAgLyoqXG4gICAgICogXHU3NTI4XHU2MjM3XHU5NjQ0XHU4QTAwXHVGRjA4XHU1OTgyIEV4aXRQbGFuTW9kZSBcdThDMDNcdTY1NzRcdThCQTFcdTUyMTJcdTY1RjZcdTc2ODRcdTg4NjVcdTUxNDVcdTYzQ0ZcdThGRjBcdUZGMDlcdTMwMDJcbiAgICAgKiBcdTdFQ0YgcmVxdWVzdFBlcm1pc3Npb24gXHU1RTk0XHU3QjU0XHU5MDBGXHU0RjIwXHU3RUQ5IGFnZW50XHVGRjBDXHU0RTBFIG9wdGlvbklkIFx1NTQwQ1x1NjVGNlx1OTAwMVx1OEZCRVx1MzAwMlxuICAgICAqL1xuICAgIHVzZXJNZXNzYWdlPzogc3RyaW5nO1xufVxuXG4vKipcbiAqIGBnZXRQZW5kaW5nSW5mbygpYCBcdThGRDRcdTU2REVcdTc2ODRcdTVGNTNcdTUyNERcdTYzMDJcdThENzdcdThCRjdcdTZDNDJcdUZGMDgqKlx1ODlDNFx1ODMwM1x1NTMxNlx1NUJGOVx1OEM2MSoqXHVGRjBDXHU0RTAwXHU2QjIxXHU2MjEwXHU1NzhCXHU4OTg2XHU3NkQ2XHU1MTY4XHU5MEU4XHU0RUE0XHU0RTkyXHU3QzdCXHU1NzhCXHVGRjA5XHUzMDAyXG4gKiBVSSBcdTc1MjggYGNhdGVnb3J5YCBcdTkwMDlcdTk3NjJcdTY3N0ZcdTMwMDFgb3B0aW9uc2AgXHU2RTMyXHU2N0QzXHU2MzA5XHU5NEFFXHUzMDAxYHF1ZXN0aW9uc2AvYG1ldGFkYXRhYCBcdTZFMzJcdTY3RDNcdTVERUVcdTVGMDJcdTUzMTZcdTUxODVcdTVCQjlcdUZGMENcbiAqIFx1NUU5NFx1N0I1NFx1N0VERlx1NEUwMFx1OEQ3MCBgcmVzb2x2ZVBlbmRpbmcoaWQsIHsgb3B0aW9uSWQsIGFuc3dlcnM/IH0pYFx1MzAwMlxuICovXG5leHBvcnQgaW50ZXJmYWNlIFBlbmRpbmdSZXF1ZXN0IHtcbiAgICAvKiogXHU3NzFGXHU1QjlFIHRvb2xDYWxsSWRcdUZGMDg9IHJlc29sdmVQZW5kaW5nIFx1NzY4NFx1NTMzOVx1OTE0RFx1OTUyRVx1RkYwOVx1MzAwMiAqL1xuICAgIGlkOiBzdHJpbmc7XG4gICAgLyoqIFx1OEJFRFx1NEU0OVx1NTIwNlx1N0M3Qlx1RkYwOFVJIFx1NjM2RVx1NkI2NFx1OTAwOVx1OTc2Mlx1Njc3Rlx1RkYwOVx1MzAwMiAqL1xuICAgIGNhdGVnb3J5PzogUGVuZGluZ0NhdGVnb3J5O1xuICAgIHRvb2xOYW1lPzogc3RyaW5nO1xuICAgIC8qKiBcdTUzRUZcdTkwMDlcdTk4NzlcdUZGMDhcdTUzOUZcdTY4MzdcdTkwMEZcdTRGMjAgYWdlbnQgXHU3Njg0IFBlcm1pc3Npb25PcHRpb25cdUZGMUJVSSBcdTc2RjRcdTYzQTVcdTZFMzJcdTY3RDNcdTYyMTBcdTYzMDlcdTk0QUVcdUZGMDlcdTMwMDIgKi9cbiAgICBvcHRpb25zPzogUGVuZGluZ09wdGlvbltdO1xuICAgIC8qKiBgY2F0ZWdvcnk9PT0ncXVlc3Rpb24nYCBcdTc2ODRcdTk1RUVcdTk4OThcdTUyMTdcdTg4NjhcdUZGMDhcdTU0MkJcdTkwMDlcdTk4NzlcdUZGMDlcdTMwMDIgKi9cbiAgICBxdWVzdGlvbnM/OiBQZW5kaW5nUXVlc3Rpb25bXTtcbiAgICAvKiogXHU1REVFXHU1RjAyXHU1MzE2XHU1MTQzXHU0RkUxXHU2MDZGXHVGRjA4c2FuZGJveCAvIHRlYW1NZW1iZXIgLyBtY3BVaVx1RkYwOVx1MzAwMiAqL1xuICAgIG1ldGFkYXRhPzogUGVuZGluZ01ldGFkYXRhO1xuICAgIC8qKiBwaWNrX2xvY2F0aW9uIFx1NEUwQlx1NjNBOFx1NjgwN1x1OEJCMFx1RkYxQlx1NEUwRSBgY2F0ZWdvcnk9PT0ncG9pX3BpY2snYCBcdTdCNDlcdTRFRjdcdThCQzZcdTUyMkJcdTMwMDIgKi9cbiAgICBpbnB1dFR5cGU/OiAncG9pX3BpY2snIHwgJ21jcF9jb25uZWN0aW9uJyB8IHN0cmluZztcbiAgICAvKiogcGlja19sb2NhdGlvbiBcdThCRjdcdTZDNDJcdThCRjRcdTY2MEVcdTMwMDIgKi9cbiAgICBwb2lQaWNrPzogeyByZWFzb24/OiBzdHJpbmcgfTtcbiAgICAvKipcbiAgICAgKiBgY2F0ZWdvcnk9PT0nbWNwQ29ubmVjdGlvbidgXHVGRjFBXHU2NzJDXHU4RjZFXHU1NDdEXHU0RTJEXHU3Njg0XHU2NzJBXHU2Mzg4XHU2NzQzL1x1NjcyQVx1OTE0RFx1N0Y2RSBNQ1AgXHU2RTA1XHU1MzU1XHUzMDAyXG4gICAgICpcbiAgICAgKiBcdTUzRUFcdTVFMjZcdTk3NTlcdTYwMDFcdTU4RjBcdTY2MEVcdTRGRTFcdTYwNkZcdUZGMDhcdTU0MERcdTVCNTdcdTRFMEVcdTVDNTVcdTc5M0FcdTY1ODdcdTY4NDhcdUZGMDlcdUZGMEMqKlx1NEUwRFx1NUUyNlx1OEZERVx1NjNBNVx1NzJCNlx1NjAwMSoqXHUyMDE0XHUyMDE0XHU3MkI2XHU2MDAxXHU3NTMxIFVJIFx1NEVDRVxuICAgICAqIGNvbm5lY3RvciBzdG9yZSBcdTVCOUVcdTY1RjZcdThCRkJcdTUzRDZcdUZGMENcdTkwN0ZcdTUxNERcdTVGRUJcdTcxNjdcdTRFMEVcdTVCOUVcdTY1RjZcdTYwMDFcdTRFMjRcdTRFRkRcdTc3MUZcdTc2RjhcdUZGMDhcdTU0MEMgdXNlRXhwZXJ0RGVwZW5kZW5jeUdhdGUgXHU1M0UzXHU1Rjg0XHVGRjA5XHUzMDAyXG4gICAgICovXG4gICAgbWNwQ29ubmVjdGlvbj86IHtcbiAgICAgICAgc2VydmVyczogQXJyYXk8e1xuICAgICAgICAgICAgLyoqIGNvbm5lY3RvciBcdTkxNERcdTdGNkUgaWRcdUZGMUJcdTVFOTRcdTdCNTRcdTY1RjZcdTYzMDlcdTVCODNcdTU2REVcdTRGMjBcdTdFRDNcdTY3OUNcdUZGMDhgb3B0aW9uSWRgIFx1NTQwRVx1N0YwMFx1NTM3M1x1NkI2NFx1NTAzQ1x1RkYwOVx1MzAwMiAqL1xuICAgICAgICAgICAgbmFtZTogc3RyaW5nO1xuICAgICAgICAgICAgLyoqXG4gICAgICAgICAgICAgKiBjb25uZWN0b3IgXHU3NkVFXHU1RjU1IGlkXHVGRjBDVUkgXHU3NTI4XHU1QjgzXHU1M0QxXHU4RDc3XHU4RkRFXHU2M0E1XHU1RTc2XHU2N0U1XHU1QjlFXHU2NUY2XHU3MkI2XHU2MDAxXHUzMDAyXG4gICAgICAgICAgICAgKlxuICAgICAgICAgICAgICogXHU0RTBFIGBuYW1lYCBcdTU0N0RcdTU0MERcdTdBN0FcdTk1RjRcdTRFMERcdTU0MENcdUZGMUFkYWVtb24gXHU3NTI4XHU1RTI2XHU1MjREXHU3RjAwXHU3Njg0IGNvbmZpZ0lkXHVGRjBDcmVuZGVyZXIgXHU3Njg0IGNvbm5lY3RvclxuICAgICAgICAgICAgICogc3RvcmUgXHU0RUU1XHU3NkVFXHU1RjU1IGlkIFx1NEUzQVx1OTUyRVx1MzAwMlx1NzZFRVx1NUY1NVx1OTFDQ1x1NjdFNVx1NEUwRFx1NTIzMFx1OEJFNVx1NjcwRFx1NTJBMVx1NjVGNlx1N0YzQVx1NzcwMVx1MzAwMlxuICAgICAgICAgICAgICovXG4gICAgICAgICAgICBjb25uZWN0b3JJZD86IHN0cmluZztcbiAgICAgICAgICAgIC8qKlxuICAgICAgICAgICAgICogY3VzdG9tIE1DUCBcdTc2ODRcdTUxNkNcdTVGMDAgc2VydmVyIG5hbWVcdUZGMUJVSSBcdTc1MjggZGFlbW9uIHJlY29ubmVjdCBcdTkwMUFcdThERUZcdThGREVcdTYzQTVcdTMwMDJcbiAgICAgICAgICAgICAqIFx1NEUwRFx1NjQzQVx1NUUyNlx1NTM5Rlx1NTlDQiBjb25maWdcdUZGMENcdTkwN0ZcdTUxNERcdTYyOEEgaGVhZGVycy9lbnYgXHU2Mjk1XHU1RjcxXHU1MjMwIHJlbmRlcmVyXHUzMDAyXG4gICAgICAgICAgICAgKi9cbiAgICAgICAgICAgIGN1c3RvbU1jcE5hbWU/OiBzdHJpbmc7XG4gICAgICAgICAgICAvKiogXHU1RjUzXHU1MjREIGxvY2FsZSBcdTc2ODRcdTVDNTVcdTc5M0FcdTU0MERcdTMwMDIgKi9cbiAgICAgICAgICAgIGRpc3BsYXlOYW1lPzogc3RyaW5nO1xuICAgICAgICAgICAgZGVzY3JpcHRpb24/OiBzdHJpbmc7XG4gICAgICAgICAgICAvKiogXHU1MzYxXHU3MjQ3XHU2QkNGXHU4ODRDXHU1REU2XHU0RkE3XHU3Njg0XHU1NkZFXHU2ODA3IFVSTFx1MzAwMiAqL1xuICAgICAgICAgICAgaWNvbj86IHN0cmluZztcbiAgICAgICAgICAgIC8qKiBcdTUxQjNcdTVCOUFcdTcwQjlcdTUxRkJcdTMwMENcdThGREVcdTYzQTVcdTMwMERcdTU0MEVcdTc2ODRcdTRFQTRcdTRFOTJcdUZGMUFvYXV0aCBcdTVGMDBcdTZENEZcdTg5QzhcdTU2NjhcdTMwMDF0b2tlbiBcdTVGMzlcdTg4NjhcdTUzNTVcdTMwMDFub25lIFx1NjVFMFx1OTcwMFx1NjM4OFx1Njc0M1x1MzAwMiAqL1xuICAgICAgICAgICAgYXV0aFR5cGU/OiAnb2F1dGgnIHwgJ3Rva2VuJyB8ICdub25lJztcbiAgICAgICAgfT47XG4gICAgfTtcbiAgICBba2V5OiBzdHJpbmddOiB1bmtub3duO1xufVxuXG4vKiogXHU1RjUzXHU1MjREIHBlbmRpbmcgXHU2NjJGXHU1NDI2XHU0RTNBIHBpY2tfbG9jYXRpb24gXHU5MDA5XHU3MEI5XHVGRjA4XHU5NUVFXHU3QjU0XHU5NzYyXHU2NzdGXHU1RkM1XHU5ODdCXHU1RkZEXHU3NTY1XHVGRjA5XHUzMDAyICovXG5leHBvcnQgZnVuY3Rpb24gaXNQb2lQaWNrUGVuZGluZyhwZW5kaW5nOiBQZW5kaW5nUmVxdWVzdCB8IHVuZGVmaW5lZCB8IG51bGwpOiBwZW5kaW5nIGlzIFBlbmRpbmdSZXF1ZXN0IHtcbiAgICByZXR1cm4gISFwZW5kaW5nICYmIChwZW5kaW5nLmNhdGVnb3J5ID09PSAncG9pX3BpY2snIHx8IHBlbmRpbmcuaW5wdXRUeXBlID09PSAncG9pX3BpY2snKTtcbn1cblxuLyoqIFx1NUY1M1x1NTI0RCBwZW5kaW5nIFx1NjYyRlx1NTQyNlx1NEUzQSBNQ1AgXHU4RkRFXHU2M0E1XHU1RjE1XHU1QkZDXHVGRjA4XHU1MzYwXHU2MzZFXHU4RjkzXHU1MTY1XHU1MzNBXHVGRjBDXHU5NUVFXHU3QjU0L1x1NURFNVx1NTE3N1x1OTc2Mlx1Njc3Rlx1NUZDNVx1OTg3Qlx1NUZGRFx1NzU2NVx1RkYwOVx1MzAwMiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGlzTWNwQ29ubmVjdGlvblBlbmRpbmcocGVuZGluZzogUGVuZGluZ1JlcXVlc3QgfCB1bmRlZmluZWQgfCBudWxsKTogcGVuZGluZyBpcyBQZW5kaW5nUmVxdWVzdCB7XG4gICAgcmV0dXJuICEhcGVuZGluZyAmJiAocGVuZGluZy5jYXRlZ29yeSA9PT0gJ21jcENvbm5lY3Rpb24nIHx8IHBlbmRpbmcuaW5wdXRUeXBlID09PSAnbWNwX2Nvbm5lY3Rpb24nKTtcbn1cblxuLyoqIENFIC8gcmVuZGVyZXIgXHU0RjdGXHU3NTI4XHU3Njg0XHU0RTkxXHU2NzBEXHU1MkExXHU1RjAwXHU5MDFBXHU3ODZFXHU4QkE0XHU1QzU1XHU3OTNBXHU4RjdEXHU4Mzc3XHUzMDAyICovXG5leHBvcnQgaW50ZXJmYWNlIENvbnZlcnNhdGlvbkNsb3VkU2VydmljZUNvbmZpcm1hdGlvblBheWxvYWQge1xuICAgIGFjdGlvbjogJ2FjdGl2YXRlJztcbiAgICBhcHBsaWNhdGlvbk5hbWU/OiBzdHJpbmc7XG4gICAgdGl0bGU6IHN0cmluZztcbiAgICBxdW90YT86IHsgdXNlZDogbnVtYmVyOyBsaW1pdDogbnVtYmVyOyByZW1haW5pbmc6IG51bWJlciB9O1xuICAgIGVmZmVjdHM/OiBzdHJpbmc7XG59XG5cbi8qKiBDRSAvIHJlbmRlcmVyIFx1NTZERVx1NEYyMFx1NEU5MVx1NjcwRFx1NTJBMVx1NUYwMFx1OTAxQVx1NTNFRlx1NEZFMVx1Nzg2RVx1OEJBNFx1NzY4NFx1NjcwMFx1NUMwRlx1ODA1NFx1NTQwOFx1MzAwMiAqL1xuZXhwb3J0IGludGVyZmFjZSBDb252ZXJzYXRpb25DbG91ZFNlcnZpY2VDb25maXJtYXRpb25SZXN1bHQge1xuICAgIGRlY2lzaW9uOiAnY29uZmlybWVkJyB8ICdkZWNsaW5lZCcgfCAnY2FuY2VsbGVkJztcbiAgICByZWFzb24/OiBzdHJpbmc7XG59XG5cbi8qKlxuICogQ0UgLyByZW5kZXJlciBcdTU2REVcdTRGMjAgcGlja19sb2NhdGlvbiBcdTc2ODRcdTY3MDBcdTVDMEZcdTgwNTRcdTU0MDhcdUZGMDhcdTRFMERcdTRFQ0Ugc2VydmVyIC8gYWdlbnQtdWkgaW1wb3J0XHVGRjA5XHUzMDAyXG4gKiBcdTVCNTdcdTZCQjVcdTVCRjlcdTlGNTAgYFBvaVBpY2tSZXN1bHRgXHUzMDAyXG4gKi9cbmV4cG9ydCB0eXBlIENvbnZlcnNhdGlvblBvaVBpY2tSZXN1bHQgPVxuICAgIHwge1xuICAgICAgICBzdGF0dXM6ICdjb21wbGV0ZWQnO1xuICAgICAgICBsb2NhdGlvbjogeyByZWdpb25QYXRoOiBzdHJpbmc7IGRldGFpbEFkZHJlc3M/OiBzdHJpbmc7IGxhdD86IG51bWJlcjsgbG5nPzogbnVtYmVyIH07XG4gICAgfVxuICAgIHwgeyBzdGF0dXM6ICdjYW5jZWxsZWQnOyByZWFzb24/OiBzdHJpbmcgfVxuICAgIHwgeyBzdGF0dXM6ICdkZW5pZWQnOyByZWFzb24/OiBzdHJpbmcgfTtcblxuLyoqXG4gKiBcdTU0NEFcdThCNjZcdTg5QzJcdTZENEJcdTRGRTFcdTUzRjdcdThGN0RcdTgzNzdcdUZGMDhcdTU5ODJcdTUzODZcdTUzRjJcdTUyQTBcdThGN0RcdTk2NERcdTdFQTdcdUZGMDlcdUZGMUFcbiAqIFx1OTAxQVx1OTA1M1x1NEVDRFx1NTcyOFx1RkYwQ1x1NEUwRFx1NEVFM1x1ODg2OFx1NTFGQVx1OTUxOVx1MjAxNFx1MjAxNGBvbihDb252ZXJzYXRpb25FdmVudC5XYXJuaW5nKWAgXHU1M0VBXHU4RjZDXHU1M0QxXHU0RkUxXHU1M0Y3XHVGRjBDXHU0RTBEXHU2NTM5IGBDb252ZXJzYXRpb25TdGF0ZWBcdTMwMDJcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBXYXJuaW5nSW5mbyB7XG4gICAgaWRsZU1zPzogbnVtYmVyO1xuICAgIGNvZGU/OiAnSElTVE9SWV9MT0FEX0ZBSUxFRCc7XG4gICAgbWVzc2FnZT86IHN0cmluZztcbiAgICAvKiogXHU1NDRBXHU4QjY2XHU2MjQwXHU1QzVFXHU5NEZFXHU4REVGXHU3Njg0XHU4QkNBXHU2NUFEIHRyYWNlSWRcdUZGMENcdTUzRUZcdTVCODlcdTUxNjhcdThERTggSVBDIFx1NUM1NVx1NzkzQVx1NEUwRVx1NjNEMFx1NEVBNFx1NTNDRFx1OTk4OFx1MzAwMiAqL1xuICAgIHRyYWNlSWQ/OiBzdHJpbmc7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgRXhwZXJ0U2VsZWN0aW9uIHtcbiAgICBpZDogc3RyaW5nO1xuICAgIG1hcmtldEV4cGVydElkPzogc3RyaW5nO1xuICAgIG1hcmtldHBsYWNlPzogc3RyaW5nO1xuICAgIHJ1bnRpbWVJZGVudGl0eT86IHN0cmluZztcbiAgICBsb2NhbGU/OiBzdHJpbmc7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgQ29uZmlnTWFuYWdlciB7XG4gICAgcmVhZG9ubHkgbW9kZTogTW9kZTtcbiAgICByZWFkb25seSBtb2RlbDogc3RyaW5nO1xuICAgIHJlYWRvbmx5IGNvbm5lY3RvcnM6IENvbm5lY3RvcltdO1xuICAgIHJlYWRvbmx5IGV4cGVydElkOiBzdHJpbmc7XG4gICAgcmVhZG9ubHkgZXhwZXJ0PzogRXhwZXJ0U2VsZWN0aW9uO1xuICAgIHJlYWRvbmx5IHBlcm1pc3Npb25Nb2RlOiBzdHJpbmc7XG4gICAgLyoqIFx1NUY1M1x1NTI0RFx1NEYxQVx1OEJERFx1NjYyRlx1NTQyNlx1NTQyRlx1NzUyOCBDTEkgXHU2Qzk5XHU3QkIxXHVGRjFCdW5kZWZpbmVkIFx1ODg2OFx1NzkzQVx1NkNCRlx1NzUyOFx1OEZEMFx1ODg0Q1x1NjVGNlx1OUVEOFx1OEJBNFx1NTAzQ1x1MzAwMiAqL1xuICAgIHJlYWRvbmx5IHVzZVNhbmRib3hDTEk/OiBib29sZWFuO1xuICAgIC8qKiBcdTYwMURcdTgwMDNcdTVGM0FcdTVFQTZcdThGRDBcdTg4NENcdTY1RjYgb3ZlcnJpZGUgXHU1RjUzXHU1MjREXHU1MDNDIFx1MDBCNyBJc3N1ZSAjODc5NTdcdTMwMDJ1bmRlZmluZWQgXHU4ODY4XHU3OTNBXHU3NTI4XHU2MjM3XHU2NzJBXHU2NjNFXHU1RjBGXHU5MDA5XHU2MkU5XHU4RkM3XHUzMDAyICovXG4gICAgcmVhZG9ubHkgdGhvdWdodExldmVsPzogc3RyaW5nO1xuICAgIC8qKlxuICAgICAqIE1heCBNb2RlIFx1OEZEMFx1ODg0Q1x1NjVGNiBvdmVycmlkZSBcdTVGNTNcdTUyNERcdTUwM0MgXHUwMEI3IElzc3VlICM5MDk1NVx1MzAwMlxuICAgICAqIGAnMCdgIFx1ODg2OFx1NzkzQVx1NUYwMFx1NTQyRlx1RkYwOFx1NTE3M1x1OTVFRCBwcmUtbWVzc2FnZSBjb21wYWN0XHVGRjA5XHVGRjFCYCcnYCBcdTg4NjhcdTc5M0FcdTUxNzNcdTk1RURcdUZGMUJ1bmRlZmluZWQgXHU4ODY4XHU3OTNBXHU2NzJBXHU2NjNFXHU1RjBGXHU5MDA5XHU2MkU5XHUzMDAyXG4gICAgICovXG4gICAgcmVhZG9ubHkgcHJlTWVzc2FnZUNvbXBhY3RQY3Q/OiBzdHJpbmc7XG4gICAgLyoqXG4gICAgICogXHU0RTBBXHU0RTBCXHU2NTg3XHU5ODg0XHU3Qjk3XHU2ODYzXHU0RjREXHU4RkQwXHU4ODRDXHU2NUY2IG92ZXJyaWRlIFx1NUY1M1x1NTI0RFx1NTAzQyBcdTAwQjcgSXNzdWUgIzkwNzY5IC8gIzU3NDEzXHUzMDAyXG4gICAgICogXHU2NTcwXHU1QjU3XHU1QjU3XHU3QjI2XHU0RTMyXHVGRjA4XHU1OTgyIGAnMjAwMDAwJ2AgLyBgJzEwMDAwMDAnYFx1RkYwOVx1RkYxQnVuZGVmaW5lZCBcdTg4NjhcdTc5M0FcdTY3MkFcdTY2M0VcdTVGMEZcdTkwMDlcdTYyRTlcdUZGMDhcdTc1MjhcdTZBMjFcdTU3OEJcdTlFRDhcdThCQTRcdTY4NjNcdUZGMDlcdTMwMDJcbiAgICAgKi9cbiAgICByZWFkb25seSBjb250ZXh0V2luZG93Pzogc3RyaW5nO1xuICAgIHNldE1vZGUobW9kZTogTW9kZSk6IFByb21pc2U8dm9pZCB8IEFwaUVycm9yPjtcbiAgICBzZXRNb2RlbChtb2RlbDogc3RyaW5nKTogUHJvbWlzZTx2b2lkIHwgQXBpRXJyb3I+O1xuICAgIHNldENvbm5lY3RvcnMoY29ubmVjdG9yczogQ29ubmVjdG9yW10pOiBQcm9taXNlPHZvaWQgfCBBcGlFcnJvcj47XG4gICAgc2V0RXhwZXJ0KGV4cGVydDogRXhwZXJ0U2VsZWN0aW9uIHwgbnVsbCk6IFByb21pc2U8dm9pZCB8IEFwaUVycm9yPjtcbiAgICBzZXRFeHBlcnRJZChpZDogc3RyaW5nLCBvcHRpb25zPzoge1xuICAgICAgICBsb2NhbGU/OiBzdHJpbmc7XG4gICAgICAgIG1hcmtldHBsYWNlPzogc3RyaW5nO1xuICAgICAgICBtYXJrZXRFeHBlcnRJZD86IHN0cmluZztcbiAgICAgICAgcnVudGltZUlkZW50aXR5Pzogc3RyaW5nO1xuICAgIH0pOiBQcm9taXNlPHZvaWQgfCBBcGlFcnJvcj47XG4gICAgc2V0UGVybWlzc2lvbk1vZGUobW9kZTogc3RyaW5nKTogUHJvbWlzZTx2b2lkIHwgQXBpRXJyb3I+O1xuICAgIC8qKiBcdTYzMDFcdTRFNDVcdTUzMTZcdTZDOTlcdTdCQjFcdTUwNEZcdTU5N0RcdUZGMENcdTVFNzZcdTVCOUVcdTY1RjZcdTU0MENcdTZCNjVcdTUyMzBcdTVERjJcdThGREVcdTYzQTVcdTc2ODRcdTY3MkNcdTU3MzAgQ0xJIFx1NEYxQVx1OEJERFx1MzAwMiAqL1xuICAgIHNldFNhbmRib3hNb2RlKGVuYWJsZWQ6IGJvb2xlYW4pOiBQcm9taXNlPHZvaWQgfCBBcGlFcnJvcj47XG4gICAgLyoqXG4gICAgICogXHU4QkJFXHU3RjZFXHU2MDFEXHU4MDAzXHU1RjNBXHU1RUE2XHVGRjA4cmVhc29uaW5nIGVmZm9ydFx1RkYwOVx1MDBCNyBJc3N1ZSAjODc5NTdcdTMwMDJcbiAgICAgKiB2YWx1ZSBcdTRFM0FcdTUxNzdcdTRGNTNcdTY4NjNcdTRGNEQgJ2xvdyd8J21lZGl1bSd8J2hpZ2gnfCd4aGlnaCd8J21heCdcdUZGMENcdTYyMTYgJ2Rpc2FibGVkJ1x1RkYwOFx1NTE3M1x1OTVFRFx1NjAxRFx1ODAwM1x1RkYwOS9cbiAgICAgKiAnZW5hYmxlZCdcdUZGMDhcdTVGMDBcdTU0MkZcdTRGNDZcdTRFMERcdTYzMDdcdTVCOUFcdTY4NjNcdTRGNERcdUZGMDlcdTMwMDJcdTVCRjlcdTlGNTAgQ0xJIFx1NzY4NCBgc2Vzc2lvbi9zZXRfY29uZmlnX29wdGlvbmAgXHUyMTkyIGB0aG91Z2h0X2xldmVsYFxuICAgICAqIHNlc3Npb24gb3ZlcnJpZGVcdTMwMDJcdTY3MkNcdTU3MzBcdTRGMUFcdThCRERcdTc1MzFcdTY1QjBcdTVGMTVcdTY0Q0VcdTYzMDFcdTRFNDVcdTUzMTZcdUZGMENcdTkxQ0RcdTVFRkFcdTU0MEVcdTU3MjhcdTk5OTZcdTY3NjEgcHJvbXB0IFx1NTI0RFx1OTFDRFx1NjVCMFx1NEUwQlx1NTNEMVx1MzAwMlxuICAgICAqL1xuICAgIHNldFRob3VnaHRMZXZlbCh2YWx1ZTogc3RyaW5nKTogUHJvbWlzZTx2b2lkIHwgQXBpRXJyb3I+O1xuICAgIC8qKlxuICAgICAqIFx1OEJCRVx1N0Y2RSBNYXggTW9kZVx1RkYwOHByZS1tZXNzYWdlIGNvbXBhY3QgXHU5NjA4XHU1MDNDXHVGRjA5XHUwMEI3IElzc3VlICM5MDk1NVx1MzAwMlxuICAgICAqIHZhbHVlIFx1NEUzQVx1NUI1N1x1N0IyNlx1NEUzMlx1RkYxQVx1NUYwMCBgJzAnYFx1RkYwQ1x1NTE3MyBgJydgXHUzMDAyXHU3OTgxXHU2QjYyIGJvb2xlYW4vbnVtYmVyXHUzMDAyXG4gICAgICogXHU1QkY5XHU5RjUwIENMSSBcdTc2ODQgYHNlc3Npb24vc2V0X2NvbmZpZ19vcHRpb25gIFx1MjE5MiBgcHJlTWVzc2FnZUNvbXBhY3RQY3RgIHNlc3Npb24gb3ZlcnJpZGVcdUZGMENcbiAgICAgKiBcdTdFQUZcdThGRDBcdTg4NENcdTY1RjZcdTRFMERcdTYzMDFcdTRFNDVcdTUzMTZcdTIwMTRcdTIwMTRcdTkxQ0RcdTVGMDBcdTRGMUFcdThCRERcdTc1MzEgVUkgXHU5MUNEXHU2NUIwXHU0RTBCXHU1M0QxXHUzMDAyXG4gICAgICovXG4gICAgc2V0UHJlTWVzc2FnZUNvbXBhY3RQY3QodmFsdWU6IHN0cmluZyk6IFByb21pc2U8dm9pZCB8IEFwaUVycm9yPjtcbiAgICAvKipcbiAgICAgKiBcdThCQkVcdTdGNkVcdTRFMEFcdTRFMEJcdTY1ODdcdTk4ODRcdTdCOTdcdTY4NjNcdTRGNERcdUZGMDhjb250ZXh0IHdpbmRvd1x1RkYwOVx1MDBCNyBJc3N1ZSAjOTA3NjkgLyAjNTc0MTNcdTMwMDJcbiAgICAgKiB2YWx1ZSBcdTRFM0FcdTY1NzBcdTVCNTdcdTVCNTdcdTdCMjZcdTRFMzJcdUZGMDhcdTU5ODIgYCcyMDAwMDAnYCAvIGAnMTAwMDAwMCdgXHVGRjA5XHVGRjFCYCcnYCBcdTZFMDVcdTk2NjQgb3ZlcnJpZGUgXHU1NkRFXHU5MDAwXHU2QTIxXHU1NzhCXHU3MjY5XHU3NDA2XHU5ODg0XHU3Qjk3XHUzMDAyXG4gICAgICogXHU1QkY5XHU5RjUwIENMSSBcdTc2ODQgYHNlc3Npb24vc2V0X2NvbmZpZ19vcHRpb25gIFx1MjE5MiBgY29udGV4dF93aW5kb3dgIHNlc3Npb24gb3ZlcnJpZGVcdTMwMDJcbiAgICAgKiBcdTY3MkNcdTU3MzBcdTRGMUFcdThCRERcdTc1MzFcdTY1QjBcdTVGMTVcdTY0Q0VcdTYzMDFcdTRFNDVcdTUzMTZcdUZGMENcdTkxQ0RcdTVFRkFcdTU0MEVcdTU3MjhcdTk5OTZcdTY3NjEgcHJvbXB0IFx1NTI0RFx1OTFDRFx1NjVCMFx1NEUwQlx1NTNEMVx1MzAwMlxuICAgICAqL1xuICAgIHNldENvbnRleHRXaW5kb3codmFsdWU6IHN0cmluZyk6IFByb21pc2U8dm9pZCB8IEFwaUVycm9yPjtcbn1cblxuZXhwb3J0IGludGVyZmFjZSBRdWV1ZU1hbmFnZXIge1xuICAgIC8qKiBcdThGRDRcdTU2REVcdTVGNTNcdTUyNERcdTk2MUZcdTUyMTdcdTVGRUJcdTcxNjdcdTMwMDIgKi9cbiAgICBpdGVtcygpOiBRdWV1ZVByb21wdFtdO1xuICAgIC8qKiBcdTY2ODJcdTUwNUNcdTgxRUFcdTUyQThcdTUxRkFcdTk2MUZcdUZGMUJcdTRGRERcdTc1NTlcdTczQjBcdTY3MDlcdTk2MUZcdTUyMTdcdTk4NzlcdTMwMDJyZWFzb24gXHU1MzNBXHU1MjA2XHU1M0Q2XHU2RDg4L1x1NjI0Qlx1NTJBOC9cdTk1MTlcdThCRUZcdTY2ODJcdTUwNUNcdTMwMDIgKi9cbiAgICBwYXVzZShyZWFzb24/OiBDb252ZXJzYXRpb25Qcm9tcHRRdWV1ZVBhdXNlUmVhc29uKTogUHJvbWlzZTx2b2lkPjtcbiAgICAvKiogXHU2MDYyXHU1OTBEXHU4MUVBXHU1MkE4XHU1MUZBXHU5NjFGXHVGRjFCXHU1RjUzXHU1MjREXHU3QTdBXHU5NUYyXHU2NUY2XHU3QUNCXHU1MzczXHU2RDNFXHU1M0QxXHU0RTBCXHU0RTAwXHU5ODc5XHUzMDAyICovXG4gICAgcmVzdW1lKCk6IFByb21pc2U8dm9pZD47XG4gICAgLyoqIFx1NjMwOVx1OTYxRlx1NTIxN1x1OTg3OSBJRCBcdTUyMjBcdTk2NjRcdTMwMDIgKi9cbiAgICBkZWxldGUoaXRlbUlkOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+O1xuICAgIC8qKiBcdTVDMDZcdTk2MUZcdTUyMTdcdTk4NzlcdTc5RkJcdTUyQThcdTUyMzBcdTc2RUVcdTY4MDdcdTRFMEJcdTY4MDdcdTMwMDIgKi9cbiAgICBtb3ZlKGl0ZW1JZDogc3RyaW5nLCBpbmRleDogbnVtYmVyKTogUHJvbWlzZTx2b2lkPjtcbiAgICBzZW5kTm93KGlkOiBzdHJpbmcpOiBQcm9taXNlPFF1ZXVlU2VuZE5vd0Rpc3Bvc2l0aW9uPjtcbn1cblxuLyoqIENvbnZlcnNhdGlvbiBcdTUxNzNcdTgwNTRcdTY1ODdcdTRFRjZcdTMwMDFcdTRFQTdcdTcyNjlcdTRFMEVcdTUzRDhcdTY2RjRcdTc2ODRcdTdFREZcdTRFMDBcdThCRkJcdTUzRDZcdTUxNjVcdTUzRTNcdTMwMDIgKi9cbmV4cG9ydCBpbnRlcmZhY2UgRmlsZU1hbmFnZXIge1xuICAgIGFydGlmYWN0cyhwYWdlOiBQYWdlKTogUHJvbWlzZTxQYWdlZDxBcnRpZmFjdD4+O1xuICAgIC8qKiBcdThCRkJcdTUzRDZcdTVGNTNcdTUyNERcdTRGMUFcdThCREQgQXJ0aWZhY3QgXHU1MTg1XHU1QkI5XHVGRjFCXHU2RDg4XHU4RDM5XHU0RkE3XHU1OUQ0XHU2MjU4IHdiLmFydGlmYWN0c1x1MzAwMiAqL1xuICAgIHJlYWRBcnRpZmFjdD8odXJpOiBzdHJpbmcsIGZvcm1hdDogJ3RleHQnIHwgJ2J5dGVzJyk6IFByb21pc2U8e1xuICAgICAgICBkYXRhOiBzdHJpbmc7XG4gICAgICAgIGVuY29kaW5nOiAndXRmOCcgfCAnYmFzZTY0JztcbiAgICAgICAgY29udGVudFR5cGU/OiBzdHJpbmc7XG4gICAgfSB8IHVuZGVmaW5lZD47XG4gICAgLyoqIFx1OEZENFx1NTZERVx1NUY1M1x1NTI0RFx1NEYxQVx1OEJERFx1NTE3M1x1ODA1NFx1NjU4N1x1NEVGNlx1NzY4NFx1NjI0MVx1NUU3M1x1NTIxN1x1ODg2OFx1RkYwQ1x1NEUwRFx1ODg2OFx1OEZCRVx1NzZFRVx1NUY1NVx1NUM0Mlx1N0VBN1x1MzAwMiAqL1xuICAgIGZpbGVzKCk6IFByb21pc2U8Q29udmVyc2F0aW9uRmlsZVtdPjtcbiAgICAvKiogXHU4QkZCXHU1M0Q2XHU1REYyXHU4QkIwXHU1RjU1XHU3Njg0XHU0RjFBXHU4QkREXHU1M0Q4XHU2NkY0XHU1RkVCXHU3MTY3XHVGRjFCXHU2NzJDXHU2NUI5XHU2Q0Q1XHU0RTBEXHU3NkQxXHU1NDJDXHU2NTg3XHU0RUY2XHU3Q0ZCXHU3RURGXHVGRjBDXHU0RTVGXHU0RTBEXHU0RTNCXHU1MkE4XHU4QkIwXHU1RjU1XHU1M0Q4XHU2NkY0XHUzMDAyICovXG4gICAgY2hhbmdlcygpOiBQcm9taXNlPENoYW5nZVtdPjtcbn1cblxuZXhwb3J0IHR5cGUgeyBDaGFuZ2UgfTtcblxuLyoqIFx1NkEyMVx1NTc4Qlx1NUZFQlx1NzE2N1x1RkYxQVx1OEJCMFx1NUY1NVx1NEUwMFx1NkIyMSBSZXF1ZXN0IFx1NzY4NFx1OTAzQlx1OEY5MVx1OEJGN1x1NkM0Mlx1NkEyMVx1NTc4Qlx1NjIxNlx1NUI5RVx1OTY0NVx1NTRDRFx1NUU5NFx1NzI2OVx1NzQwNlx1NkEyMVx1NTc4Qlx1MzAwMiAqL1xuZXhwb3J0IGludGVyZmFjZSBSZXF1ZXN0TW9kZWxJbmZvIHtcbiAgICAvKiogXHU2QTIxXHU1NzhCIElEXHVGRjA4XHU1OTgyIFwiYXV0b1wiXHUzMDAxXCJjbGF1ZGUtc29ubmV0LTQtMjAyNTA1MTRcIlx1RkYwOVx1MzAwMiAqL1xuICAgIGlkOiBzdHJpbmc7XG4gICAgLyoqIFx1NTNFRlx1OTAwOVx1NzY4NFx1NjYzRVx1NzkzQVx1NTQwRFx1NzlGMFx1RkYxQlx1ODlFM1x1Njc5MFx1NEUwRFx1NTIzMFx1NjVGNlx1NTNFQVx1NEZERFx1NzU1OSBJRFx1MzAwMiAqL1xuICAgIG5hbWU/OiBzdHJpbmc7XG59XG5cbi8qKlxuICogUmVxdWVzdCBcdTc2ODRcdThERTggUHJvdmlkZXIgXHU3QTMzXHU1QjlBXHU4RUFCXHU0RUZEXHU0RTBFXHU2NzJDXHU1NzMwIFByb3ZpZGVyIFx1NUI5QVx1NEY0RFx1N0IyNlx1MzAwMlxuICpcbiAqIGByZXF1ZXN0SWRgIFx1NjYyRiBDb252ZXJzYXRpb24gXHU3Njg0IGNhbm9uaWNhbCBJRFx1RkYxQmBmb3JrTWVzc2FnZUlkYCBcdTU0OEMgYGZvcmtSZXF1ZXN0SWRgXG4gKiBcdTUyMDZcdTUyMkJcdTVCRjlcdTVFOTQgTG9jYWwgQ0xJIHJvbGxiYWNrIFx1NzY4NCBgdGFyZ2V0TWVzc2FnZUlkYCBcdTRFMEUgYHRhcmdldFJlcXVlc3RJZGBcdUZGMENcdTRFMERcdTVGOTdcdTZERjdcdTc1MjhcdTMwMDJcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBDb252ZXJzYXRpb25SZXF1ZXN0SWRlbnRpdHkge1xuICAgIHJlcXVlc3RJZDogc3RyaW5nO1xuICAgIGZvcmtNZXNzYWdlSWQ/OiBzdHJpbmc7XG4gICAgZm9ya1JlcXVlc3RJZD86IHN0cmluZztcbn1cblxuLyoqXG4gKiBcdTVGNTNcdTUyNEQgdHVybiBcdTc2ODRcdTRFMkRcdTY1QURcdTRFMEFcdTRFMEJcdTY1ODdcdTMwMDJcbiAqXG4gKiBgcHJlc2VudGF0aW9uOiAnc2lsZW50J2AgXHU0RUM1XHU5NjkwXHU4NUNGXHU1QkJGXHU0RTNCIFVJIFx1NzY4NFx1NTNENlx1NkQ4OFx1NjNEMFx1NzkzQVx1RkYwQ1x1NEUwRFx1NjUzOVx1NTNEOFx1NUU5NVx1NUM0MiBjYW5jZWxcdTMwMDFSZXF1ZXN0XG4gKiBgY2FuY2VsbGVkYCBcdTdFQzhcdTYwMDFcdTYyMTZcdTU0MEVcdTdFRUQgY29udGludWF0aW9uIFx1NzY4NFx1NzUxRlx1NTQ3RFx1NTQ2OFx1NjcxRlx1OEJFRFx1NEU0OVx1MzAwMlxuICovXG5leHBvcnQgaW50ZXJmYWNlIENvbnZlcnNhdGlvblR1cm5JbnRlcnJ1cHRpb24ge1xuICAgIHJlYXNvbj86IHN0cmluZztcbiAgICBwcmVzZW50YXRpb24/OiAnZGVmYXVsdCcgfCAnc2lsZW50Jztcbn1cblxuZXhwb3J0IGludGVyZmFjZSBSZXF1ZXN0IHtcbiAgICByZWFkb25seSBpZDogc3RyaW5nO1xuICAgIC8qKiBQcm92aWRlciBcdTRFM0FcdTY3MkNcdThGNkVcdTc1MUZcdTYyMTBcdTc2ODRcdTk0RkVcdThERUZcdThGRkRcdThFMkEgSURcdUZGMUJcdTUzODZcdTUzRjJcdTYwNjJcdTU5MERcdTU0MEVcdTRFQ0RcdTRGRERcdTYzMDFcdTUzOUZcdTUwM0NcdUZGMENcdTc5ODFcdTZCNjJcdTc1MjggUmVxdWVzdC5pZCBcdTg5ODZcdTc2RDZcdTMwMDIgKi9cbiAgICByZWFkb25seSB0cmFjZUlkPzogc3RyaW5nO1xuICAgIC8qKlxuICAgICAqIFx1NjcyQ1x1OEY2RSB0dXJuIFx1OEVBQlx1NEVGRFx1MzAwMlx1NjVCMFx1NTNEMVx1OTAwMVx1OERFRlx1NUY4NFx1NEUwRSBgUmVxdWVzdC5pZGAgXHU2MDUyXHU3QjQ5XHVGRjBDXHU1NzQ3XHU0RTNBXHU5ODg0XHU2RDNFL0NvcmUgXHU3NTFGXHU2MjEwXHU3Njg0XG4gICAgICogYGNvbnZlcnNhdGlvblJlcXVlc3RJZGBcdTMwMDJcdTY1RTdcdTUzODZcdTUzRjJcdTYzMDkgb3BhcXVlIHN0cmluZyBcdTUzOUZcdTY4MzdcdTRGRERcdTc1NTlcdUZGMENcdTRFMERcdTVGOTdcdTU2REVcdTUxOTlcdTYyMTBcdTY1QjAgVVVJRFx1MzAwMlxuICAgICAqL1xuICAgIHJlYWRvbmx5IGNvbnZlcnNhdGlvblJlcXVlc3RJZD86IHN0cmluZztcbiAgICAvKiogXHU4REU4XHU1QjlFXHU2NUY2XHU0RTBFXHU1Mzg2XHU1M0YyXHU2MDYyXHU1OTBEXHU3Njg0IFJlcXVlc3QgXHU4RUFCXHU0RUZEXHVGRjFCTG9jYWwgZm9yayBcdTVCOUFcdTRGNERcdTdCMjZcdTRFQzVcdTU3MjhcdTVCRjlcdTVFOTQgUHJvdmlkZXIgXHU1M0VGXHU3NTI4XHU2NUY2XHU1QjU4XHU1NzI4XHUzMDAyICovXG4gICAgcmVhZG9ubHkgaWRlbnRpdHk/OiBDb252ZXJzYXRpb25SZXF1ZXN0SWRlbnRpdHk7XG4gICAgLyoqXG4gICAgICogXHU2NzJDXHU4RjZFXHU3NTMxXHU1NDBFXHU1M0YwXHU5MDFBXHU3N0U1XHU3QjQ5XHU1MTg1XHU5MEU4XHU0RThCXHU0RUY2XHU4MUVBXHU1MkE4XHU3RUVEXHU4REQxXHU2NUY2XHVGRjBDXHU2MzA3XHU1NDExXHU1RTk0XHU4OEFCXHU5MUNEXHU2NUIwXHU3NTFGXHU2MjEwXHU3Njg0XHU2ODM5XHU3NTI4XHU2MjM3IFJlcXVlc3RcdTMwMDJcbiAgICAgKiBcdTdGM0FcdTc3MDFcdTg4NjhcdTc5M0FcdTY3MkNcdThGNkVcdTgxRUFcdThFQUJcdTVDMzFcdTY2MkZcdTkxQ0RcdTUzRDFcdTY3NjVcdTZFOTBcdUZGMUJcdTZEODhcdThEMzlcdTRGQTdcdTRFMERcdTVGOTdcdTk3NjBcdTZEODhcdTYwNkZcdTkwQkJcdTYzQTVcdTUxNzNcdTdDRkJcdTczMUNcdTZENEJcdTMwMDJcbiAgICAgKi9cbiAgICByZWFkb25seSByZWdlbmVyYXRpb25Tb3VyY2VSZXF1ZXN0SWQ/OiBzdHJpbmc7XG4gICAgLyoqIFx1NzUyOFx1NjIzN1x1NjNEMFx1OTVFRVx1NjVGNlx1OTVGNFx1NjIzM1x1RkYwOFx1NkJFQlx1NzlEMlx1RkYwOVx1RkYxQlx1NTM4Nlx1NTNGMlx1NjI5NVx1NUY3MVx1NTNENlx1OEJFNSByZXF1ZXN0IFx1OTk5Nlx1Njc2MSB1c2VyIG1lc3NhZ2VcdUZGMENcdTVCOUVcdTY1RjZcdThCRjdcdTZDNDJcdTUzRDZcdTUyMUJcdTVFRkFcdTY1RjZcdTk1RjRcdTMwMDIgKi9cbiAgICByZWFkb25seSB0aW1lc3RhbXA/OiBudW1iZXI7XG4gICAgLyoqIFx1NjcyQ1x1OEY2RVx1NjcwMFx1NTQwRVx1NEUwMFx1NEUyQVx1NTNFRlx1NTZERVx1NjUzRVx1OEY5M1x1NTFGQVx1NzY4NFx1NjVGNlx1OTVGNFx1NjIzM1x1RkYwOFx1NkJFQlx1NzlEMlx1RkYwOVx1RkYxQlx1NUI5RVx1NjVGNlx1NEUwRVx1NTM4Nlx1NTNGMlx1NjI5NVx1NUY3MVx1OTY4Rlx1OEY5M1x1NTFGQVx1NjZGNFx1NjVCMFx1MzAwMiAqL1xuICAgIHJlYWRvbmx5IGZpbmlzaFRpbWVzdGFtcD86IG51bWJlcjtcbiAgICByZWFkb25seSB1c2VyTWVzc2FnZTogTWVzc2FnZTtcbiAgICByZWFkb25seSBhc3Npc3RhbnRNZXNzYWdlPzogTWVzc2FnZTtcbiAgICByZWFkb25seSBzeXN0ZW1NZXNzYWdlPzogTWVzc2FnZTtcbiAgICByZWFkb25seSBzdGF0ZTogUmVxdWVzdFN0YXRlO1xuICAgIC8qKiBcdTY3MkNcdThGNkVcdTdFQzhcdTYwMDFcdTk1MTlcdThCRUZcdUZGMUJcdTVCOUVcdTY1RjYgU3RhdGVDaGFuZ2UgXHU0RTBFXHU2NzJDXHU1NzMwIEpTT05MIFx1NTM4Nlx1NTNGMlx1NjA2Mlx1NTkwRFx1NTE3MVx1NzUyOFx1MzAwMiAqL1xuICAgIHJlYWRvbmx5IHRlcm1pbmFsRXJyb3I/OiBDb252ZXJzYXRpb25UZXJtaW5hbEVycm9yO1xuICAgIHJlYWRvbmx5IHVzYWdlPzogVXNhZ2U7XG4gICAgLyoqIFx1NjcyQ1x1OEY2RVx1NTNEMVx1OTAwMVx1NjVGNlx1NzUyOFx1NjIzN1x1OTAwOVx1NjJFOVx1NzY4NFx1OTAzQlx1OEY5MVx1NkEyMVx1NTc4Qlx1NUZFQlx1NzE2N1x1RkYxQlx1NTM3M1x1NEY3Rlx1NTQwRVx1N0VFRFx1NEYxQVx1OEJERFx1NkEyMVx1NTc4Qlx1NTNEOFx1NTMxNlx1RkYwQ1x1NjcyQ1x1OEY2RVx1NTAzQ1x1NEU1Rlx1NEUwRFx1NTNEOFx1MzAwMiAqL1xuICAgIHJlYWRvbmx5IHJlcXVlc3RlZE1vZGVsPzogUmVxdWVzdE1vZGVsSW5mbztcbiAgICAvKiogUHJvdmlkZXIgXHU1QjlFXHU5NjQ1XHU1NENEXHU1RTk0XHU3Njg0XHU3MjY5XHU3NDA2XHU2QTIxXHU1NzhCXHVGRjFCXHU1NDBFXHU3QUVGXHU2Q0ExXHU2NzA5XHU0RTBCXHU1M0QxXHU2NUY2XHU1MTQxXHU4QkI4XHU3RjNBXHU1OTMxXHVGRjBDXHU0RTBEXHU4MEZEXHU3NTI4XHU4QkY3XHU2QzQyXHU2QTIxXHU1NzhCXHU0RjJBXHU5MDIwXHUzMDAyICovXG4gICAgcmVhZG9ubHkgcmVzcG9uc2VNb2RlbD86IFJlcXVlc3RNb2RlbEluZm87XG4gICAgLyoqIFJlcXVlc3QgXHU5OTk2XHU2QjIxXHU4RkRCXHU1MTY1XHU3RUM4XHU2MDAxXHVGRjA4Y29tcGxldGVkL2NhbmNlbGxlZC9lcnJvclx1RkYwOVx1NzY4NFx1NkJFQlx1NzlEMlx1NjVGNlx1OTVGNFx1NjIzM1x1RkYxQlx1NTNFQVx1NTE5OVx1NEUwMFx1NkIyMVx1RkYwQ1x1NEUwRFx1NTNFRlx1NjUzOVx1NTE5OVx1MzAwMiAqL1xuICAgIHJlYWRvbmx5IGNvbXBsZXRlZEF0PzogbnVtYmVyO1xuICAgIC8qKlxuICAgICAqIFx1NjcyQ1x1OEY2RVx1NTNEMVx1OTAwMVx1NjVGNlx1NTFCQlx1N0VEM1x1NzY4NFx1NTJBOVx1NzQwNlx1N0Y3Mlx1NTQwRFx1MzAwMlx1NTNFQVx1NEZERFx1NzU1OSBgY29kZWJ1ZGR5LmFpLmV4dHJhLmFzc2lzdGFudERpc3BsYXlgXG4gICAgICpcdUZGMDhcdTk3NUUgYHNvdXJjZT1kZWZhdWx0YFx1RkYwOVx1RkYwQ1x1NEUwRFx1NjJGN1x1OEQxRFx1NUI4Q1x1NjU3NCBzZW5kIGBfbWV0YWBcdTMwMDJcbiAgICAgKi9cbiAgICByZWFkb25seSBfbWV0YT86IFJlY29yZDxzdHJpbmcsIHVua25vd24+O1xuICAgIGdldEFydGlmYWN0cygpOiBBcnRpZmFjdFtdO1xuICAgIGxpa2UoKTogdm9pZDtcbiAgICBkaXNsaWtlKCk6IHZvaWQ7XG4gICAgc2hhcmUoKTogdm9pZDtcbn1cblxuZXhwb3J0IHR5cGUgUmVxdWVzdFN0YXRlID0gJ3BlbmRpbmcnIHwgJ3N0cmVhbWluZycgfCAnY29tcGxldGVkJyB8ICdjYW5jZWxsZWQnIHwgJ2Vycm9yJztcbmV4cG9ydCB0eXBlIE1lc3NhZ2VUeXBlID0gJ3RleHQnIHwgJ3Rvb2wnIHwgJ2FydGlmYWN0JyB8IHN0cmluZztcbmV4cG9ydCB0eXBlIE1lc3NhZ2VTdGF0ZSA9ICdwZW5kaW5nJyB8ICdzdHJlYW1pbmcnIHwgJ2NvbXBsZXRlZCcgfCAnZXJyb3InO1xuZXhwb3J0IGludGVyZmFjZSBNZXNzYWdlIHtcbiAgICB0eXBlOiBNZXNzYWdlVHlwZTtcbiAgICBjb250ZW50OiBCbG9ja1tdO1xuICAgIHN0YXRlOiBNZXNzYWdlU3RhdGU7XG4gICAgLyoqIFx1NjVCMFx1NjI5NVx1NUY3MVx1NjMwOVx1OTAzQlx1OEY5MVx1NkQ4OFx1NjA2Rlx1OEVBQlx1NEVGRFx1N0VDNFx1N0VDN1x1NkI2M1x1NjU4N1x1RkYxQlx1N0YzQVx1NzcwMVx1NEVDNVx1NEVFM1x1ODg2OFx1NjVFN1x1NUZFQlx1NzE2N1x1RkYwQ1x1NEUwRFx1NEVFM1x1ODg2OFx1OTAxMFx1NUUyN1x1OEVBQlx1NEVGRFx1MzAwMiAqL1xuICAgIGNvbnRlbnRJZGVudGl0eT86ICdtZXNzYWdlJztcbn1cbmV4cG9ydCBpbnRlcmZhY2UgVXNhZ2VDb3N0IHsgYW1vdW50OiBudW1iZXI7IGN1cnJlbmN5OiBzdHJpbmc7IH1cbmV4cG9ydCBpbnRlcmZhY2UgVXNhZ2VFc3RpbWF0ZSB7IG1pbjogbnVtYmVyOyBtYXg6IG51bWJlcjsgY3VycmVuY3k6IHN0cmluZzsgfVxuZXhwb3J0IGludGVyZmFjZSBVc2FnZUJ5Q2F0ZWdvcnkge1xuICAgIHN5c3RlbVByb21wdD86IG51bWJlcjtcbiAgICBjb252ZXJzYXRpb24/OiBudW1iZXI7XG4gICAgdG9vbHM/OiBudW1iZXI7XG4gICAgbWNwPzogbnVtYmVyO1xuICAgIHNraWxscz86IG51bWJlcjtcbiAgICB2ZXJzaW9uPzogbnVtYmVyO1xufVxuZXhwb3J0IGludGVyZmFjZSBVc2FnZURldGFpbHMge1xuICAgIHByb21wdFRva2Vucz86IG51bWJlcjtcbiAgICBjb21wbGV0aW9uVG9rZW5zPzogbnVtYmVyO1xuICAgIHByb21wdENhY2hlSGl0VG9rZW5zPzogbnVtYmVyO1xuICAgIHByb21wdENhY2hlTWlzc1Rva2Vucz86IG51bWJlcjtcbiAgICBwcm9tcHRDYWNoZVdyaXRlVG9rZW5zPzogbnVtYmVyO1xufVxuZXhwb3J0IGludGVyZmFjZSBVc2FnZSB7XG4gICAgLyoqIFx1NUY1M1x1NTI0RFx1NEUwQVx1NEUwQlx1NjU4N1x1NURGMlx1NEY3Rlx1NzUyOCB0b2tlblx1RkYwOEFDUCB1c2FnZV91cGRhdGUudXNlZFx1RkYwOVx1RkYwQ1x1NEUwRFx1NjYyRlx1N0QyRlx1OEJBMVx1OEY5M1x1NTE2NStcdThGOTNcdTUxRkFcdTMwMDIgKi9cbiAgICBpbnB1dFRva2Vucz86IG51bWJlcjtcbiAgICBvdXRwdXRUb2tlbnM/OiBudW1iZXI7XG4gICAgLyoqIFx1N0I0OVx1NEU4RSBBQ1AgdXNhZ2VfdXBkYXRlLnVzZWRcdUZGMENcdTRFMERcdTY2MkYgaW5wdXQrb3V0cHV0IFx1NkM0N1x1NjAzQlx1RkYwOFx1NUY1M1x1NTI0RCBTREsgXHU0RTBCXHU2RTM4XHU2NUUwXHU2RDg4XHU4RDM5XHU2NUI5XHU1MDVBXHU2QzQ3XHU2MDNCXHVGRjA5XHUzMDAyICovXG4gICAgdG90YWxUb2tlbnM/OiBudW1iZXI7XG4gICAgLyoqIFx1NkEyMVx1NTc4Qlx1NjcwMFx1NTkyN1x1NEUwQVx1NEUwQlx1NjU4N1x1N0E5N1x1NTNFM1x1NTkyN1x1NUMwRlx1RkYwOEFDUCB1c2FnZV91cGRhdGUuc2l6ZVx1RkYwOVx1MzAwMiAqL1xuICAgIGNvbnRleHRXaW5kb3c/OiBudW1iZXI7XG4gICAgLyoqIFx1NUY1M1x1NTI0RCBSZXF1ZXN0IFx1NURGMlx1NUI5RVx1OTY0NVx1NkQ4OFx1ODAxN1x1NzY4NFx1N0QyRlx1OEJBMVx1NzlFRlx1NTIwNlx1MzAwMiAqL1xuICAgIGNvc3Q/OiBVc2FnZUNvc3Q7XG4gICAgLyoqIFx1OTg4NFx1NkQ0Qlx1NjcwRFx1NTJBMVx1OEZENFx1NTZERVx1NzY4NFx1NjcyQ1x1NkIyMSBSZXF1ZXN0IFx1NjAzQlx1NkQ4OFx1ODAxN1x1NTMzQVx1OTVGNFx1MzAwMiAqL1xuICAgIGVzdGltYXRlZENvc3Q/OiBVc2FnZUVzdGltYXRlO1xuICAgIC8qKiBBQ1AgYF9tZXRhLnVzYWdlYCBcdTc2ODRcdTZBMjFcdTU3OEJcdThDMDNcdTc1MjhcdTY2MEVcdTdFQzZcdTMwMDIgKi9cbiAgICBkZXRhaWxzPzogVXNhZ2VEZXRhaWxzO1xuICAgIC8qKiBBQ1AgYF9tZXRhWydjb2RlYnVkZHkuYWkvdXNhZ2VCeUNhdGVnb3J5J11gIFx1NzY4NFx1NEUwQVx1NEUwQlx1NjU4N1x1NTIwNlx1N0M3Qlx1MzAwMiAqL1xuICAgIGJ5Q2F0ZWdvcnk/OiBVc2FnZUJ5Q2F0ZWdvcnk7XG4gICAgW2tleTogc3RyaW5nXTogdW5rbm93bjtcbn1cblxuLyoqIFRvb2wgYmxvY2sgXHU0RTJEXHU2NDNBXHU1RTI2XHU3Njg0XHU3MkVDXHU3QUNCXHU3NTI4XHU5MUNGXHVGRjFCXHU2NzY1XHU2RTkwXHU0RThFIHRvb2xfY2FsbF91cGRhdGUgcmF3UmVzcG9uc2UvcmVzdWx0IHVzYWdlXHUzMDAyICovXG5leHBvcnQgaW50ZXJmYWNlIFRvb2xVc2FnZSBleHRlbmRzIFVzYWdlIHtcbiAgICB0b29sQ2FsbElkPzogc3RyaW5nO1xufVxuIiwgImltcG9ydCAqIGFzIGhhc2hKcyBmcm9tICdoYXNoLmpzJztcblxuZXhwb3J0IGNvbnN0IEJVRERZX0FQUF9TTkFQU0hPVF9GT1JNQVRfVkVSU0lPTiA9IDEgYXMgY29uc3Q7XG5leHBvcnQgY29uc3QgQlVERFlfU0VTU0lPTl9CSU5ESU5HX0ZPUk1BVF9WRVJTSU9OID0gMSBhcyBjb25zdDtcbmV4cG9ydCBjb25zdCBCVUREWV9BUFBfU05BUFNIT1RfTUFYX0pTT05fTEVOR1RIID0gNTEyICogMTAyNDtcbmV4cG9ydCBjb25zdCBCVUREWV9TRVNTSU9OX0JJTkRJTkdfTUFYX0pTT05fTEVOR1RIID0gMTI4ICogMTAyNDtcblxuY29uc3QgQlVERFlfU05BUFNIT1RfSURfUEFUVEVSTiA9IC9eYnNfW2EtZjAtOV17NjR9JC87XG5jb25zdCBGT1JCSURERU5fT0JKRUNUX0tFWVMgPSBuZXcgU2V0KFsnX19wcm90b19fJywgJ2NvbnN0cnVjdG9yJywgJ3Byb3RvdHlwZSddKTtcbmNvbnN0IFNFTlNJVElWRV9PQkpFQ1RfS0VZUyA9IG5ldyBTZXQoW1xuICAgICdhY2Nlc3N0b2tlbicsXG4gICAgJ2FwaWtleScsXG4gICAgJ2F1dGhvcml6YXRpb24nLFxuICAgICdjb29raWUnLFxuICAgICdjcmVkZW50aWFsJyxcbiAgICAnY3JlZGVudGlhbHMnLFxuICAgICdncmFudGlkJyxcbiAgICAnaGVhZGVycycsXG4gICAgJ2h0dHBoZWFkZXJzJyxcbiAgICAnaWR0b2tlbicsXG4gICAgJ2xvZ2luc3RhdGUnLFxuICAgICdvYXV0aHRva2VuJyxcbiAgICAncGFzc3dvcmQnLFxuICAgICdwcml2YXRla2V5JyxcbiAgICAncmVmcmVzaHRva2VuJyxcbiAgICAnc2VjcmV0JyxcbiAgICAnc2Vzc2lvbnRva2VuJyxcbl0pO1xuY29uc3QgTUFYX0pTT05fREVQVEggPSA2NDtcblxuZXhwb3J0IHR5cGUgQnVkZHlKc29uUHJpbWl0aXZlID0gc3RyaW5nIHwgbnVtYmVyIHwgYm9vbGVhbiB8IG51bGw7XG5leHBvcnQgdHlwZSBCdWRkeUpzb25WYWx1ZSA9IEJ1ZGR5SnNvblByaW1pdGl2ZSB8IEJ1ZGR5SnNvbk9iamVjdCB8IEJ1ZGR5SnNvblZhbHVlW107XG5leHBvcnQgaW50ZXJmYWNlIEJ1ZGR5SnNvbk9iamVjdCB7XG4gICAgW2tleTogc3RyaW5nXTogQnVkZHlKc29uVmFsdWU7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgQnVkZHlBcHBTbmFwc2hvdElkZW50aXR5VjEge1xuICAgIGFwcGxpY2F0aW9uSWQ6IHN0cmluZztcbiAgICB0ZW1wbGF0ZUlkOiBzdHJpbmc7XG4gICAgc2NoZW1hVmVyc2lvbjogbnVtYmVyO1xuICAgIHRlbXBsYXRlVmVyc2lvbjogbnVtYmVyO1xufVxuXG4vKipcbiAqIEJ1ZGR5IFx1NUU5NFx1NzUyOFx1NEUwMFx1NEUyQVx1NEUwRFx1NTNFRlx1NTNEOFx1NzY4NFx1NUI4Q1x1NjU3NFx1NEUxQVx1NTJBMVx1OTE0RFx1N0Y2RVx1NzI0OFx1NjcyQ1x1MzAwMlxuICpcbiAqIGBjb25maWdgIFx1NUZDNVx1OTg3Qlx1Njc2NVx1ODFFQVx1NURGMlx1N0VDRlx1NUI4Q1x1NjIxMFx1NTM0Rlx1OEJBRVx1NjgyMVx1OUE4Q1x1NzY4NCBCdWRkeSBcdTkxNERcdTdGNkVcdUZGMENcdTVFNzZcdTRFMTRcdTUzRUFcdTUzMDVcdTU0MkJcdTk3NUVcdTY1NEZcdTYxMUYgSlNPTiBcdTY1NzBcdTYzNkVcdTMwMDJcbiAqIE9BdXRoIHRva2VuXHUzMDAxTUNQIGhlYWRlcnNcdTMwMDFncmFudElkIFx1NTQ4Q1x1NzY3Qlx1NUY1NVx1NjAwMVx1NEUwRFx1NUY5N1x1OEZEQlx1NTE2NVx1NjcyQ1x1NUJGOVx1OEM2MVx1MzAwMlxuICovXG5leHBvcnQgaW50ZXJmYWNlIEJ1ZGR5QXBwU25hcHNob3RWMSB7XG4gICAgdmVyc2lvbjogdHlwZW9mIEJVRERZX0FQUF9TTkFQU0hPVF9GT1JNQVRfVkVSU0lPTjtcbiAgICBzbmFwc2hvdElkOiBzdHJpbmc7XG4gICAgY29uZmlnRGlnZXN0OiBzdHJpbmc7XG4gICAgY3JlYXRlZEF0OiBudW1iZXI7XG4gICAgaWRlbnRpdHk6IEJ1ZGR5QXBwU25hcHNob3RJZGVudGl0eVYxO1xuICAgIGNvbmZpZzogQnVkZHlKc29uT2JqZWN0O1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIEJ1ZGR5U2Vzc2lvbkJpbmRpbmdJbmR1c3RyeU1vZGVWMSB7XG4gICAgaWQ6IHN0cmluZztcbiAgICBzeXN0ZW1Qcm9tcHRBcHBlbmQ/OiBzdHJpbmc7XG4gICAgYXBwbGljYXRpb25JZDogc3RyaW5nO1xuICAgIHNjZW5lSWQ/OiBzdHJpbmc7XG4gICAgcmVzb3VyY2VTbmFwc2hvdEtleTogc3RyaW5nO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIEJ1ZGR5U2Vzc2lvbkJpbmRpbmdWMSB7XG4gICAgdmVyc2lvbjogdHlwZW9mIEJVRERZX1NFU1NJT05fQklORElOR19GT1JNQVRfVkVSU0lPTjtcbiAgICBzbmFwc2hvdElkOiBzdHJpbmc7XG4gICAgc2VsZWN0aW9uOiB7XG4gICAgICAgIG1vZGVJZD86IHN0cmluZztcbiAgICAgICAgc2NlbmVJZD86IHN0cmluZztcbiAgICAgICAgc2NoZW1hU2NlbmVJZD86IHN0cmluZztcbiAgICB9O1xuICAgIHJ1bnRpbWU6IHtcbiAgICAgICAgaW5kdXN0cnlNb2RlPzogQnVkZHlTZXNzaW9uQmluZGluZ0luZHVzdHJ5TW9kZVYxO1xuICAgICAgICB3ZWxjb21lTW9kZT86IHN0cmluZztcbiAgICAgICAgc2Vzc2lvblNldHRpbmdzPzogQnVkZHlKc29uT2JqZWN0O1xuICAgICAgICB0YWdzPzogUmVjb3JkPHN0cmluZywgc3RyaW5nPjtcbiAgICAgICAgZXhwZXJ0SWQ/OiBzdHJpbmc7XG4gICAgfTtcbiAgICBwcmVzZW50YXRpb246IHtcbiAgICAgICAgYnJhbmROYW1lPzogc3RyaW5nO1xuICAgICAgICBicmFuZExvZ28/OiBzdHJpbmc7XG4gICAgfTtcbiAgICBjb250aW51YXRpb246IHtcbiAgICAgICAgZGVmYXVsdFJ1bGU/OiBzdHJpbmc7XG4gICAgfTtcbiAgICByZXNvdXJjZXM6IHtcbiAgICAgICAgcmVzb3VyY2VTbmFwc2hvdEtleTogc3RyaW5nO1xuICAgIH07XG59XG5cbi8qKiBcdTRGMUFcdThCRERcdThCRTZcdTYwQzVcdTRFMkRcdTc2ODRcdTUzRUFcdThCRkIgQnVkZHkgXHU2Mjk1XHU1RjcxXHVGRjFCXHU1MjE3XHU4ODY4XHU2N0U1XHU4QkUyXHU0RTBEXHU1Rjk3XHU1MkEwXHU4RjdEXHU2QjY0XHU1QjU3XHU2QkI1XHUzMDAyICovXG5leHBvcnQgaW50ZXJmYWNlIEJ1ZGR5Q29udmVyc2F0aW9uU25hcHNob3RWMSB7XG4gICAgYXBwOiBCdWRkeUFwcFNuYXBzaG90VjE7XG4gICAgYmluZGluZzogQnVkZHlTZXNzaW9uQmluZGluZ1YxO1xufVxuXG5mdW5jdGlvbiBpc1JlY29yZCh2YWx1ZTogdW5rbm93bik6IHZhbHVlIGlzIFJlY29yZDxzdHJpbmcsIHVua25vd24+IHtcbiAgICByZXR1cm4gQm9vbGVhbih2YWx1ZSkgJiYgdHlwZW9mIHZhbHVlID09PSAnb2JqZWN0JyAmJiAhQXJyYXkuaXNBcnJheSh2YWx1ZSk7XG59XG5cbmZ1bmN0aW9uIG5vcm1hbGl6ZVJlcXVpcmVkU3RyaW5nKHZhbHVlOiB1bmtub3duLCBwYXRoOiBzdHJpbmcsIG1heExlbmd0aCA9IDUxMik6IHN0cmluZyB7XG4gICAgaWYgKHR5cGVvZiB2YWx1ZSAhPT0gJ3N0cmluZycpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKGAke3BhdGh9IG11c3QgYmUgYSBzdHJpbmdgKTtcbiAgICB9XG4gICAgY29uc3Qgbm9ybWFsaXplZCA9IHZhbHVlLnRyaW0oKTtcbiAgICBpZiAoIW5vcm1hbGl6ZWQpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKGAke3BhdGh9IG11c3QgYmUgYSBub24tZW1wdHkgc3RyaW5nYCk7XG4gICAgfVxuICAgIGlmIChub3JtYWxpemVkLmxlbmd0aCA+IG1heExlbmd0aCkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYCR7cGF0aH0gZXhjZWVkcyAke21heExlbmd0aH0gY2hhcmFjdGVyc2ApO1xuICAgIH1cbiAgICByZXR1cm4gbm9ybWFsaXplZDtcbn1cblxuZnVuY3Rpb24gbm9ybWFsaXplT3B0aW9uYWxTdHJpbmcoXG4gICAgdmFsdWU6IHVua25vd24sXG4gICAgcGF0aDogc3RyaW5nLFxuICAgIG1heExlbmd0aCA9IDE2XzAwMCxcbik6IHN0cmluZyB8IHVuZGVmaW5lZCB7XG4gICAgaWYgKHZhbHVlID09PSB1bmRlZmluZWQgfHwgdmFsdWUgPT09IG51bGwpIHtcbiAgICAgICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgICB9XG4gICAgcmV0dXJuIG5vcm1hbGl6ZVJlcXVpcmVkU3RyaW5nKHZhbHVlLCBwYXRoLCBtYXhMZW5ndGgpO1xufVxuXG5mdW5jdGlvbiBub3JtYWxpemVOb25OZWdhdGl2ZUludGVnZXIodmFsdWU6IHVua25vd24sIHBhdGg6IHN0cmluZyk6IG51bWJlciB7XG4gICAgaWYgKCFOdW1iZXIuaXNTYWZlSW50ZWdlcih2YWx1ZSkgfHwgTnVtYmVyKHZhbHVlKSA8IDApIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKGAke3BhdGh9IG11c3QgYmUgYSBub24tbmVnYXRpdmUgc2FmZSBpbnRlZ2VyYCk7XG4gICAgfVxuICAgIHJldHVybiBOdW1iZXIodmFsdWUpO1xufVxuXG5mdW5jdGlvbiBub3JtYWxpemVKc29uVmFsdWUodmFsdWU6IHVua25vd24sIHBhdGg6IHN0cmluZywgZGVwdGg6IG51bWJlcik6IEJ1ZGR5SnNvblZhbHVlIHtcbiAgICBpZiAoZGVwdGggPiBNQVhfSlNPTl9ERVBUSCkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYCR7cGF0aH0gZXhjZWVkcyB0aGUgbWF4aW11bSBKU09OIGRlcHRoYCk7XG4gICAgfVxuICAgIGlmICh2YWx1ZSA9PT0gbnVsbCB8fCB0eXBlb2YgdmFsdWUgPT09ICdzdHJpbmcnIHx8IHR5cGVvZiB2YWx1ZSA9PT0gJ2Jvb2xlYW4nKSB7XG4gICAgICAgIHJldHVybiB2YWx1ZTtcbiAgICB9XG4gICAgaWYgKHR5cGVvZiB2YWx1ZSA9PT0gJ251bWJlcicpIHtcbiAgICAgICAgaWYgKCFOdW1iZXIuaXNGaW5pdGUodmFsdWUpKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYCR7cGF0aH0gbXVzdCBjb250YWluIG9ubHkgZmluaXRlIG51bWJlcnNgKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdmFsdWU7XG4gICAgfVxuICAgIGlmIChBcnJheS5pc0FycmF5KHZhbHVlKSkge1xuICAgICAgICByZXR1cm4gdmFsdWUubWFwKChpdGVtLCBpbmRleCkgPT4gKFxuICAgICAgICAgICAgaXRlbSA9PT0gdW5kZWZpbmVkXG4gICAgICAgICAgICAgICAgPyBudWxsXG4gICAgICAgICAgICAgICAgOiBub3JtYWxpemVKc29uVmFsdWUoaXRlbSwgYCR7cGF0aH1bJHtpbmRleH1dYCwgZGVwdGggKyAxKVxuICAgICAgICApKTtcbiAgICB9XG4gICAgaWYgKCFpc1JlY29yZCh2YWx1ZSkpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKGAke3BhdGh9IG11c3QgY29udGFpbiBvbmx5IEpTT04gdmFsdWVzYCk7XG4gICAgfVxuICAgIGNvbnN0IG5vcm1hbGl6ZWQ6IEJ1ZGR5SnNvbk9iamVjdCA9IHt9O1xuICAgIGZvciAoY29uc3Qga2V5IG9mIE9iamVjdC5rZXlzKHZhbHVlKS5zb3J0KCkpIHtcbiAgICAgICAgaWYgKEZPUkJJRERFTl9PQkpFQ1RfS0VZUy5oYXMoa2V5KSkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGAke3BhdGh9LiR7a2V5fSBpcyBub3QgYWxsb3dlZGApO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IGNvbXBhcmFibGVLZXkgPSBrZXkudG9Mb3dlckNhc2UoKS5yZXBsYWNlKC9bXmEtejAtOV0vZywgJycpO1xuICAgICAgICBpZiAoU0VOU0lUSVZFX09CSkVDVF9LRVlTLmhhcyhjb21wYXJhYmxlS2V5KSkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGAke3BhdGh9LiR7a2V5fSBjb250YWlucyBzZW5zaXRpdmUgZGF0YSBhbmQgaXMgbm90IGFsbG93ZWRgKTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBpdGVtID0gdmFsdWVba2V5XTtcbiAgICAgICAgaWYgKGl0ZW0gIT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgbm9ybWFsaXplZFtrZXldID0gbm9ybWFsaXplSnNvblZhbHVlKGl0ZW0sIGAke3BhdGh9LiR7a2V5fWAsIGRlcHRoICsgMSk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIG5vcm1hbGl6ZWQ7XG59XG5cbmZ1bmN0aW9uIG5vcm1hbGl6ZUpzb25PYmplY3QodmFsdWU6IHVua25vd24sIHBhdGg6IHN0cmluZyk6IEJ1ZGR5SnNvbk9iamVjdCB7XG4gICAgY29uc3Qgbm9ybWFsaXplZCA9IG5vcm1hbGl6ZUpzb25WYWx1ZSh2YWx1ZSwgcGF0aCwgMCk7XG4gICAgaWYgKG5vcm1hbGl6ZWQgPT09IG51bGwgfHwgQXJyYXkuaXNBcnJheShub3JtYWxpemVkKSB8fCB0eXBlb2Ygbm9ybWFsaXplZCAhPT0gJ29iamVjdCcpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKGAke3BhdGh9IG11c3QgYmUgYSBKU09OIG9iamVjdGApO1xuICAgIH1cbiAgICByZXR1cm4gbm9ybWFsaXplZDtcbn1cblxuZnVuY3Rpb24gYXNzZXJ0U2VyaWFsaXplZFNpemUodmFsdWU6IHVua25vd24sIG1heExlbmd0aDogbnVtYmVyLCBwYXRoOiBzdHJpbmcpOiBzdHJpbmcge1xuICAgIGNvbnN0IHNlcmlhbGl6ZWQgPSBKU09OLnN0cmluZ2lmeSh2YWx1ZSk7XG4gICAgaWYgKHNlcmlhbGl6ZWQubGVuZ3RoID4gbWF4TGVuZ3RoKSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcihgJHtwYXRofSBleGNlZWRzIHRoZSAke21heExlbmd0aH0tY2hhcmFjdGVyIGxpbWl0YCk7XG4gICAgfVxuICAgIHJldHVybiBzZXJpYWxpemVkO1xufVxuXG5mdW5jdGlvbiBkZWVwRnJlZXplPFQ+KHZhbHVlOiBUKTogVCB7XG4gICAgaWYgKCF2YWx1ZSB8fCB0eXBlb2YgdmFsdWUgIT09ICdvYmplY3QnIHx8IE9iamVjdC5pc0Zyb3plbih2YWx1ZSkpIHtcbiAgICAgICAgcmV0dXJuIHZhbHVlO1xuICAgIH1cbiAgICBmb3IgKGNvbnN0IG5lc3RlZCBvZiBPYmplY3QudmFsdWVzKHZhbHVlIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+KSkge1xuICAgICAgICBkZWVwRnJlZXplKG5lc3RlZCk7XG4gICAgfVxuICAgIHJldHVybiBPYmplY3QuZnJlZXplKHZhbHVlKTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIG5vcm1hbGl6ZUJ1ZGR5QXBwU25hcHNob3RJZGVudGl0eShcbiAgICB2YWx1ZTogdW5rbm93bixcbik6IEJ1ZGR5QXBwU25hcHNob3RJZGVudGl0eVYxIHtcbiAgICBpZiAoIWlzUmVjb3JkKHZhbHVlKSkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ2J1ZGR5IHNuYXBzaG90IGlkZW50aXR5IG11c3QgYmUgYW4gb2JqZWN0Jyk7XG4gICAgfVxuICAgIHJldHVybiB7XG4gICAgICAgIGFwcGxpY2F0aW9uSWQ6IG5vcm1hbGl6ZVJlcXVpcmVkU3RyaW5nKFxuICAgICAgICAgICAgdmFsdWUuYXBwbGljYXRpb25JZCxcbiAgICAgICAgICAgICdidWRkeSBzbmFwc2hvdCBpZGVudGl0eS5hcHBsaWNhdGlvbklkJyxcbiAgICAgICAgKSxcbiAgICAgICAgdGVtcGxhdGVJZDogbm9ybWFsaXplUmVxdWlyZWRTdHJpbmcoXG4gICAgICAgICAgICB2YWx1ZS50ZW1wbGF0ZUlkLFxuICAgICAgICAgICAgJ2J1ZGR5IHNuYXBzaG90IGlkZW50aXR5LnRlbXBsYXRlSWQnLFxuICAgICAgICApLFxuICAgICAgICBzY2hlbWFWZXJzaW9uOiBub3JtYWxpemVOb25OZWdhdGl2ZUludGVnZXIoXG4gICAgICAgICAgICB2YWx1ZS5zY2hlbWFWZXJzaW9uLFxuICAgICAgICAgICAgJ2J1ZGR5IHNuYXBzaG90IGlkZW50aXR5LnNjaGVtYVZlcnNpb24nLFxuICAgICAgICApLFxuICAgICAgICB0ZW1wbGF0ZVZlcnNpb246IG5vcm1hbGl6ZU5vbk5lZ2F0aXZlSW50ZWdlcihcbiAgICAgICAgICAgIHZhbHVlLnRlbXBsYXRlVmVyc2lvbixcbiAgICAgICAgICAgICdidWRkeSBzbmFwc2hvdCBpZGVudGl0eS50ZW1wbGF0ZVZlcnNpb24nLFxuICAgICAgICApLFxuICAgIH07XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBjYW5vbmljYWxTZXJpYWxpemVCdWRkeVNuYXBzaG90Q29udGVudChcbiAgICBpZGVudGl0eTogQnVkZHlBcHBTbmFwc2hvdElkZW50aXR5VjEsXG4gICAgY29uZmlnOiBCdWRkeUpzb25PYmplY3QsXG4pOiBzdHJpbmcge1xuICAgIHJldHVybiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgIGNvbmZpZzogbm9ybWFsaXplSnNvbk9iamVjdChjb25maWcsICdidWRkeSBzbmFwc2hvdCBjb25maWcnKSxcbiAgICAgICAgaWRlbnRpdHk6IG5vcm1hbGl6ZUJ1ZGR5QXBwU25hcHNob3RJZGVudGl0eShpZGVudGl0eSksXG4gICAgfSk7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBjb21wdXRlQnVkZHlTbmFwc2hvdERpZ2VzdChcbiAgICBpZGVudGl0eTogQnVkZHlBcHBTbmFwc2hvdElkZW50aXR5VjEsXG4gICAgY29uZmlnOiBCdWRkeUpzb25PYmplY3QsXG4pOiBzdHJpbmcge1xuICAgIHJldHVybiBoYXNoSnMuc2hhMjU2KClcbiAgICAgICAgLnVwZGF0ZShjYW5vbmljYWxTZXJpYWxpemVCdWRkeVNuYXBzaG90Q29udGVudChpZGVudGl0eSwgY29uZmlnKSlcbiAgICAgICAgLmRpZ2VzdCgnaGV4Jyk7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBidWRkeVNuYXBzaG90SWRGcm9tRGlnZXN0KGNvbmZpZ0RpZ2VzdDogc3RyaW5nKTogc3RyaW5nIHtcbiAgICBjb25zdCBub3JtYWxpemVkID0gbm9ybWFsaXplUmVxdWlyZWRTdHJpbmcoY29uZmlnRGlnZXN0LCAnYnVkZHkgc25hcHNob3QgY29uZmlnRGlnZXN0JywgNjQpXG4gICAgICAgIC50b0xvd2VyQ2FzZSgpO1xuICAgIGlmICghL15bYS1mMC05XXs2NH0kLy50ZXN0KG5vcm1hbGl6ZWQpKSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcignYnVkZHkgc25hcHNob3QgY29uZmlnRGlnZXN0IG11c3QgYmUgYSBTSEEtMjU2IGhleCBkaWdlc3QnKTtcbiAgICB9XG4gICAgcmV0dXJuIGBic18ke25vcm1hbGl6ZWR9YDtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGNyZWF0ZUJ1ZGR5QXBwU25hcHNob3QoXG4gICAgaWRlbnRpdHlWYWx1ZTogQnVkZHlBcHBTbmFwc2hvdElkZW50aXR5VjEsXG4gICAgY29uZmlnVmFsdWU6IHVua25vd24sXG4gICAgY3JlYXRlZEF0ID0gRGF0ZS5ub3coKSxcbik6IEJ1ZGR5QXBwU25hcHNob3RWMSB7XG4gICAgY29uc3QgaWRlbnRpdHkgPSBub3JtYWxpemVCdWRkeUFwcFNuYXBzaG90SWRlbnRpdHkoaWRlbnRpdHlWYWx1ZSk7XG4gICAgY29uc3QgY29uZmlnID0gbm9ybWFsaXplSnNvbk9iamVjdChjb25maWdWYWx1ZSwgJ2J1ZGR5IHNuYXBzaG90IGNvbmZpZycpO1xuICAgIGNvbnN0IGNvbmZpZ0RpZ2VzdCA9IGNvbXB1dGVCdWRkeVNuYXBzaG90RGlnZXN0KGlkZW50aXR5LCBjb25maWcpO1xuICAgIGNvbnN0IHNuYXBzaG90OiBCdWRkeUFwcFNuYXBzaG90VjEgPSB7XG4gICAgICAgIHZlcnNpb246IEJVRERZX0FQUF9TTkFQU0hPVF9GT1JNQVRfVkVSU0lPTixcbiAgICAgICAgc25hcHNob3RJZDogYnVkZHlTbmFwc2hvdElkRnJvbURpZ2VzdChjb25maWdEaWdlc3QpLFxuICAgICAgICBjb25maWdEaWdlc3QsXG4gICAgICAgIGNyZWF0ZWRBdDogbm9ybWFsaXplTm9uTmVnYXRpdmVJbnRlZ2VyKGNyZWF0ZWRBdCwgJ2J1ZGR5IHNuYXBzaG90IGNyZWF0ZWRBdCcpLFxuICAgICAgICBpZGVudGl0eSxcbiAgICAgICAgY29uZmlnLFxuICAgIH07XG4gICAgYXNzZXJ0U2VyaWFsaXplZFNpemUoXG4gICAgICAgIHNuYXBzaG90LFxuICAgICAgICBCVUREWV9BUFBfU05BUFNIT1RfTUFYX0pTT05fTEVOR1RILFxuICAgICAgICAnYnVkZHkgYXBwbGljYXRpb24gc25hcHNob3QnLFxuICAgICk7XG4gICAgcmV0dXJuIGRlZXBGcmVlemUoc25hcHNob3QpO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gbm9ybWFsaXplQnVkZHlBcHBTbmFwc2hvdCh2YWx1ZTogdW5rbm93bik6IEJ1ZGR5QXBwU25hcHNob3RWMSB7XG4gICAgaWYgKCFpc1JlY29yZCh2YWx1ZSkgfHwgdmFsdWUudmVyc2lvbiAhPT0gQlVERFlfQVBQX1NOQVBTSE9UX0ZPUk1BVF9WRVJTSU9OKSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcigndW5zdXBwb3J0ZWQgQnVkZHkgYXBwbGljYXRpb24gc25hcHNob3QgdmVyc2lvbicpO1xuICAgIH1cbiAgICBjb25zdCBub3JtYWxpemVkID0gY3JlYXRlQnVkZHlBcHBTbmFwc2hvdChcbiAgICAgICAgbm9ybWFsaXplQnVkZHlBcHBTbmFwc2hvdElkZW50aXR5KHZhbHVlLmlkZW50aXR5KSxcbiAgICAgICAgdmFsdWUuY29uZmlnLFxuICAgICAgICBub3JtYWxpemVOb25OZWdhdGl2ZUludGVnZXIodmFsdWUuY3JlYXRlZEF0LCAnYnVkZHkgc25hcHNob3QgY3JlYXRlZEF0JyksXG4gICAgKTtcbiAgICBjb25zdCBzbmFwc2hvdElkID0gbm9ybWFsaXplUmVxdWlyZWRTdHJpbmcodmFsdWUuc25hcHNob3RJZCwgJ2J1ZGR5IHNuYXBzaG90IHNuYXBzaG90SWQnLCA2Nyk7XG4gICAgY29uc3QgY29uZmlnRGlnZXN0ID0gbm9ybWFsaXplUmVxdWlyZWRTdHJpbmcoXG4gICAgICAgIHZhbHVlLmNvbmZpZ0RpZ2VzdCxcbiAgICAgICAgJ2J1ZGR5IHNuYXBzaG90IGNvbmZpZ0RpZ2VzdCcsXG4gICAgICAgIDY0LFxuICAgICkudG9Mb3dlckNhc2UoKTtcbiAgICBpZiAoIUJVRERZX1NOQVBTSE9UX0lEX1BBVFRFUk4udGVzdChzbmFwc2hvdElkKSkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ2J1ZGR5IHNuYXBzaG90IHNuYXBzaG90SWQgaXMgaW52YWxpZCcpO1xuICAgIH1cbiAgICBpZiAoc25hcHNob3RJZCAhPT0gbm9ybWFsaXplZC5zbmFwc2hvdElkIHx8IGNvbmZpZ0RpZ2VzdCAhPT0gbm9ybWFsaXplZC5jb25maWdEaWdlc3QpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdidWRkeSBzbmFwc2hvdCBkaWdlc3QgaW50ZWdyaXR5IGNoZWNrIGZhaWxlZCcpO1xuICAgIH1cbiAgICByZXR1cm4gbm9ybWFsaXplZDtcbn1cblxuZnVuY3Rpb24gbm9ybWFsaXplU3RyaW5nUmVjb3JkKHZhbHVlOiB1bmtub3duLCBwYXRoOiBzdHJpbmcpOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+IHwgdW5kZWZpbmVkIHtcbiAgICBpZiAodmFsdWUgPT09IHVuZGVmaW5lZCB8fCB2YWx1ZSA9PT0gbnVsbCkge1xuICAgICAgICByZXR1cm4gdW5kZWZpbmVkO1xuICAgIH1cbiAgICBpZiAoIWlzUmVjb3JkKHZhbHVlKSkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYCR7cGF0aH0gbXVzdCBiZSBhbiBvYmplY3RgKTtcbiAgICB9XG4gICAgY29uc3QgZW50cmllcyA9IE9iamVjdC5lbnRyaWVzKHZhbHVlKVxuICAgICAgICAubWFwKChba2V5LCBpdGVtXSkgPT4gW1xuICAgICAgICAgICAgbm9ybWFsaXplUmVxdWlyZWRTdHJpbmcoa2V5LCBgJHtwYXRofSBrZXlgLCAyNTYpLFxuICAgICAgICAgICAgbm9ybWFsaXplUmVxdWlyZWRTdHJpbmcoaXRlbSwgYCR7cGF0aH0uJHtrZXl9YCwgNF8wOTYpLFxuICAgICAgICBdIGFzIGNvbnN0KVxuICAgICAgICAuc29ydCgoW2xlZnRdLCBbcmlnaHRdKSA9PiBsZWZ0LmxvY2FsZUNvbXBhcmUocmlnaHQpKTtcbiAgICByZXR1cm4gZW50cmllcy5sZW5ndGggPiAwID8gT2JqZWN0LmZyb21FbnRyaWVzKGVudHJpZXMpIDogdW5kZWZpbmVkO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gbm9ybWFsaXplQnVkZHlTZXNzaW9uQmluZGluZyh2YWx1ZTogdW5rbm93bik6IEJ1ZGR5U2Vzc2lvbkJpbmRpbmdWMSB7XG4gICAgaWYgKCFpc1JlY29yZCh2YWx1ZSkgfHwgdmFsdWUudmVyc2lvbiAhPT0gQlVERFlfU0VTU0lPTl9CSU5ESU5HX0ZPUk1BVF9WRVJTSU9OKSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcigndW5zdXBwb3J0ZWQgQnVkZHkgc2Vzc2lvbiBiaW5kaW5nIHZlcnNpb24nKTtcbiAgICB9XG4gICAgY29uc3Qgc25hcHNob3RJZCA9IG5vcm1hbGl6ZVJlcXVpcmVkU3RyaW5nKHZhbHVlLnNuYXBzaG90SWQsICdidWRkeSBiaW5kaW5nIHNuYXBzaG90SWQnLCA2Nyk7XG4gICAgaWYgKCFCVUREWV9TTkFQU0hPVF9JRF9QQVRURVJOLnRlc3Qoc25hcHNob3RJZCkpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdidWRkeSBiaW5kaW5nIHNuYXBzaG90SWQgaXMgaW52YWxpZCcpO1xuICAgIH1cbiAgICBjb25zdCBzZWxlY3Rpb24gPSBpc1JlY29yZCh2YWx1ZS5zZWxlY3Rpb24pID8gdmFsdWUuc2VsZWN0aW9uIDoge307XG4gICAgY29uc3QgcnVudGltZSA9IGlzUmVjb3JkKHZhbHVlLnJ1bnRpbWUpID8gdmFsdWUucnVudGltZSA6IHt9O1xuICAgIGNvbnN0IHByZXNlbnRhdGlvbiA9IGlzUmVjb3JkKHZhbHVlLnByZXNlbnRhdGlvbikgPyB2YWx1ZS5wcmVzZW50YXRpb24gOiB7fTtcbiAgICBjb25zdCBjb250aW51YXRpb24gPSBpc1JlY29yZCh2YWx1ZS5jb250aW51YXRpb24pID8gdmFsdWUuY29udGludWF0aW9uIDoge307XG4gICAgY29uc3QgcmVzb3VyY2VzID0gaXNSZWNvcmQodmFsdWUucmVzb3VyY2VzKSA/IHZhbHVlLnJlc291cmNlcyA6IHt9O1xuICAgIGNvbnN0IHJlc291cmNlU25hcHNob3RLZXkgPSBub3JtYWxpemVSZXF1aXJlZFN0cmluZyhcbiAgICAgICAgcmVzb3VyY2VzLnJlc291cmNlU25hcHNob3RLZXksXG4gICAgICAgICdidWRkeSBiaW5kaW5nIHJlc291cmNlcy5yZXNvdXJjZVNuYXBzaG90S2V5JyxcbiAgICAgICAgNjcsXG4gICAgKTtcbiAgICBpZiAocmVzb3VyY2VTbmFwc2hvdEtleSAhPT0gc25hcHNob3RJZCkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ2J1ZGR5IGJpbmRpbmcgcmVzb3VyY2VTbmFwc2hvdEtleSBtdXN0IGVxdWFsIHNuYXBzaG90SWQnKTtcbiAgICB9XG5cbiAgICBsZXQgaW5kdXN0cnlNb2RlOiBCdWRkeVNlc3Npb25CaW5kaW5nSW5kdXN0cnlNb2RlVjEgfCB1bmRlZmluZWQ7XG4gICAgaWYgKHJ1bnRpbWUuaW5kdXN0cnlNb2RlICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgaWYgKCFpc1JlY29yZChydW50aW1lLmluZHVzdHJ5TW9kZSkpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignYnVkZHkgYmluZGluZyBydW50aW1lLmluZHVzdHJ5TW9kZSBtdXN0IGJlIGFuIG9iamVjdCcpO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IG1vZGVSZXNvdXJjZUtleSA9IG5vcm1hbGl6ZVJlcXVpcmVkU3RyaW5nKFxuICAgICAgICAgICAgcnVudGltZS5pbmR1c3RyeU1vZGUucmVzb3VyY2VTbmFwc2hvdEtleSxcbiAgICAgICAgICAgICdidWRkeSBiaW5kaW5nIHJ1bnRpbWUuaW5kdXN0cnlNb2RlLnJlc291cmNlU25hcHNob3RLZXknLFxuICAgICAgICAgICAgNjcsXG4gICAgICAgICk7XG4gICAgICAgIGlmIChtb2RlUmVzb3VyY2VLZXkgIT09IHNuYXBzaG90SWQpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignYnVkZHkgYmluZGluZyBpbmR1c3RyeU1vZGUgcmVzb3VyY2VTbmFwc2hvdEtleSBtdXN0IGVxdWFsIHNuYXBzaG90SWQnKTtcbiAgICAgICAgfVxuICAgICAgICBpbmR1c3RyeU1vZGUgPSB7XG4gICAgICAgICAgICBpZDogbm9ybWFsaXplUmVxdWlyZWRTdHJpbmcocnVudGltZS5pbmR1c3RyeU1vZGUuaWQsICdidWRkeSBiaW5kaW5nIGluZHVzdHJ5TW9kZS5pZCcpLFxuICAgICAgICAgICAgYXBwbGljYXRpb25JZDogbm9ybWFsaXplUmVxdWlyZWRTdHJpbmcoXG4gICAgICAgICAgICAgICAgcnVudGltZS5pbmR1c3RyeU1vZGUuYXBwbGljYXRpb25JZCxcbiAgICAgICAgICAgICAgICAnYnVkZHkgYmluZGluZyBpbmR1c3RyeU1vZGUuYXBwbGljYXRpb25JZCcsXG4gICAgICAgICAgICApLFxuICAgICAgICAgICAgcmVzb3VyY2VTbmFwc2hvdEtleTogbW9kZVJlc291cmNlS2V5LFxuICAgICAgICAgICAgLi4uKG5vcm1hbGl6ZU9wdGlvbmFsU3RyaW5nKFxuICAgICAgICAgICAgICAgIHJ1bnRpbWUuaW5kdXN0cnlNb2RlLnN5c3RlbVByb21wdEFwcGVuZCxcbiAgICAgICAgICAgICAgICAnYnVkZHkgYmluZGluZyBpbmR1c3RyeU1vZGUuc3lzdGVtUHJvbXB0QXBwZW5kJyxcbiAgICAgICAgICAgICkgPyB7XG4gICAgICAgICAgICAgICAgICAgIHN5c3RlbVByb21wdEFwcGVuZDogbm9ybWFsaXplT3B0aW9uYWxTdHJpbmcoXG4gICAgICAgICAgICAgICAgICAgICAgICBydW50aW1lLmluZHVzdHJ5TW9kZS5zeXN0ZW1Qcm9tcHRBcHBlbmQsXG4gICAgICAgICAgICAgICAgICAgICAgICAnYnVkZHkgYmluZGluZyBpbmR1c3RyeU1vZGUuc3lzdGVtUHJvbXB0QXBwZW5kJyxcbiAgICAgICAgICAgICAgICAgICAgKSxcbiAgICAgICAgICAgICAgICB9IDoge30pLFxuICAgICAgICAgICAgLi4uKG5vcm1hbGl6ZU9wdGlvbmFsU3RyaW5nKFxuICAgICAgICAgICAgICAgIHJ1bnRpbWUuaW5kdXN0cnlNb2RlLnNjZW5lSWQsXG4gICAgICAgICAgICAgICAgJ2J1ZGR5IGJpbmRpbmcgaW5kdXN0cnlNb2RlLnNjZW5lSWQnLFxuICAgICAgICAgICAgICAgIDUxMixcbiAgICAgICAgICAgICkgPyB7XG4gICAgICAgICAgICAgICAgICAgIHNjZW5lSWQ6IG5vcm1hbGl6ZU9wdGlvbmFsU3RyaW5nKFxuICAgICAgICAgICAgICAgICAgICAgICAgcnVudGltZS5pbmR1c3RyeU1vZGUuc2NlbmVJZCxcbiAgICAgICAgICAgICAgICAgICAgICAgICdidWRkeSBiaW5kaW5nIGluZHVzdHJ5TW9kZS5zY2VuZUlkJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIDUxMixcbiAgICAgICAgICAgICAgICAgICAgKSxcbiAgICAgICAgICAgICAgICB9IDoge30pLFxuICAgICAgICB9O1xuICAgIH1cblxuICAgIGNvbnN0IGJpbmRpbmc6IEJ1ZGR5U2Vzc2lvbkJpbmRpbmdWMSA9IHtcbiAgICAgICAgdmVyc2lvbjogQlVERFlfU0VTU0lPTl9CSU5ESU5HX0ZPUk1BVF9WRVJTSU9OLFxuICAgICAgICBzbmFwc2hvdElkLFxuICAgICAgICBzZWxlY3Rpb246IHtcbiAgICAgICAgICAgIC4uLihub3JtYWxpemVPcHRpb25hbFN0cmluZyhzZWxlY3Rpb24ubW9kZUlkLCAnYnVkZHkgYmluZGluZyBzZWxlY3Rpb24ubW9kZUlkJywgNTEyKVxuICAgICAgICAgICAgICAgID8geyBtb2RlSWQ6IG5vcm1hbGl6ZU9wdGlvbmFsU3RyaW5nKHNlbGVjdGlvbi5tb2RlSWQsICdidWRkeSBiaW5kaW5nIHNlbGVjdGlvbi5tb2RlSWQnLCA1MTIpIH1cbiAgICAgICAgICAgICAgICA6IHt9KSxcbiAgICAgICAgICAgIC4uLihub3JtYWxpemVPcHRpb25hbFN0cmluZyhzZWxlY3Rpb24uc2NlbmVJZCwgJ2J1ZGR5IGJpbmRpbmcgc2VsZWN0aW9uLnNjZW5lSWQnLCA1MTIpXG4gICAgICAgICAgICAgICAgPyB7IHNjZW5lSWQ6IG5vcm1hbGl6ZU9wdGlvbmFsU3RyaW5nKHNlbGVjdGlvbi5zY2VuZUlkLCAnYnVkZHkgYmluZGluZyBzZWxlY3Rpb24uc2NlbmVJZCcsIDUxMikgfVxuICAgICAgICAgICAgICAgIDoge30pLFxuICAgICAgICAgICAgLi4uKG5vcm1hbGl6ZU9wdGlvbmFsU3RyaW5nKFxuICAgICAgICAgICAgICAgIHNlbGVjdGlvbi5zY2hlbWFTY2VuZUlkLFxuICAgICAgICAgICAgICAgICdidWRkeSBiaW5kaW5nIHNlbGVjdGlvbi5zY2hlbWFTY2VuZUlkJyxcbiAgICAgICAgICAgICAgICA1MTIsXG4gICAgICAgICAgICApID8ge1xuICAgICAgICAgICAgICAgICAgICBzY2hlbWFTY2VuZUlkOiBub3JtYWxpemVPcHRpb25hbFN0cmluZyhcbiAgICAgICAgICAgICAgICAgICAgICAgIHNlbGVjdGlvbi5zY2hlbWFTY2VuZUlkLFxuICAgICAgICAgICAgICAgICAgICAgICAgJ2J1ZGR5IGJpbmRpbmcgc2VsZWN0aW9uLnNjaGVtYVNjZW5lSWQnLFxuICAgICAgICAgICAgICAgICAgICAgICAgNTEyLFxuICAgICAgICAgICAgICAgICAgICApLFxuICAgICAgICAgICAgICAgIH0gOiB7fSksXG4gICAgICAgIH0sXG4gICAgICAgIHJ1bnRpbWU6IHtcbiAgICAgICAgICAgIC4uLihpbmR1c3RyeU1vZGUgPyB7IGluZHVzdHJ5TW9kZSB9IDoge30pLFxuICAgICAgICAgICAgLi4uKG5vcm1hbGl6ZU9wdGlvbmFsU3RyaW5nKHJ1bnRpbWUud2VsY29tZU1vZGUsICdidWRkeSBiaW5kaW5nIHJ1bnRpbWUud2VsY29tZU1vZGUnLCA1MTIpXG4gICAgICAgICAgICAgICAgPyB7IHdlbGNvbWVNb2RlOiBub3JtYWxpemVPcHRpb25hbFN0cmluZyhydW50aW1lLndlbGNvbWVNb2RlLCAnYnVkZHkgYmluZGluZyBydW50aW1lLndlbGNvbWVNb2RlJywgNTEyKSB9XG4gICAgICAgICAgICAgICAgOiB7fSksXG4gICAgICAgICAgICAuLi4ocnVudGltZS5zZXNzaW9uU2V0dGluZ3MgIT09IHVuZGVmaW5lZFxuICAgICAgICAgICAgICAgID8geyBzZXNzaW9uU2V0dGluZ3M6IG5vcm1hbGl6ZUpzb25PYmplY3QocnVudGltZS5zZXNzaW9uU2V0dGluZ3MsICdidWRkeSBiaW5kaW5nIHJ1bnRpbWUuc2Vzc2lvblNldHRpbmdzJykgfVxuICAgICAgICAgICAgICAgIDoge30pLFxuICAgICAgICAgICAgLi4uKG5vcm1hbGl6ZVN0cmluZ1JlY29yZChydW50aW1lLnRhZ3MsICdidWRkeSBiaW5kaW5nIHJ1bnRpbWUudGFncycpXG4gICAgICAgICAgICAgICAgPyB7IHRhZ3M6IG5vcm1hbGl6ZVN0cmluZ1JlY29yZChydW50aW1lLnRhZ3MsICdidWRkeSBiaW5kaW5nIHJ1bnRpbWUudGFncycpIH1cbiAgICAgICAgICAgICAgICA6IHt9KSxcbiAgICAgICAgICAgIC4uLihub3JtYWxpemVPcHRpb25hbFN0cmluZyhydW50aW1lLmV4cGVydElkLCAnYnVkZHkgYmluZGluZyBydW50aW1lLmV4cGVydElkJywgNTEyKVxuICAgICAgICAgICAgICAgID8geyBleHBlcnRJZDogbm9ybWFsaXplT3B0aW9uYWxTdHJpbmcocnVudGltZS5leHBlcnRJZCwgJ2J1ZGR5IGJpbmRpbmcgcnVudGltZS5leHBlcnRJZCcsIDUxMikgfVxuICAgICAgICAgICAgICAgIDoge30pLFxuICAgICAgICB9LFxuICAgICAgICBwcmVzZW50YXRpb246IHtcbiAgICAgICAgICAgIC4uLihub3JtYWxpemVPcHRpb25hbFN0cmluZyhcbiAgICAgICAgICAgICAgICBwcmVzZW50YXRpb24uYnJhbmROYW1lLFxuICAgICAgICAgICAgICAgICdidWRkeSBiaW5kaW5nIHByZXNlbnRhdGlvbi5icmFuZE5hbWUnLFxuICAgICAgICAgICAgICAgIDUxMixcbiAgICAgICAgICAgICkgPyB7XG4gICAgICAgICAgICAgICAgICAgIGJyYW5kTmFtZTogbm9ybWFsaXplT3B0aW9uYWxTdHJpbmcoXG4gICAgICAgICAgICAgICAgICAgICAgICBwcmVzZW50YXRpb24uYnJhbmROYW1lLFxuICAgICAgICAgICAgICAgICAgICAgICAgJ2J1ZGR5IGJpbmRpbmcgcHJlc2VudGF0aW9uLmJyYW5kTmFtZScsXG4gICAgICAgICAgICAgICAgICAgICAgICA1MTIsXG4gICAgICAgICAgICAgICAgICAgICksXG4gICAgICAgICAgICAgICAgfSA6IHt9KSxcbiAgICAgICAgICAgIC4uLihub3JtYWxpemVPcHRpb25hbFN0cmluZyhcbiAgICAgICAgICAgICAgICBwcmVzZW50YXRpb24uYnJhbmRMb2dvLFxuICAgICAgICAgICAgICAgICdidWRkeSBiaW5kaW5nIHByZXNlbnRhdGlvbi5icmFuZExvZ28nLFxuICAgICAgICAgICAgICAgIDRfMDk2LFxuICAgICAgICAgICAgKSA/IHtcbiAgICAgICAgICAgICAgICAgICAgYnJhbmRMb2dvOiBub3JtYWxpemVPcHRpb25hbFN0cmluZyhcbiAgICAgICAgICAgICAgICAgICAgICAgIHByZXNlbnRhdGlvbi5icmFuZExvZ28sXG4gICAgICAgICAgICAgICAgICAgICAgICAnYnVkZHkgYmluZGluZyBwcmVzZW50YXRpb24uYnJhbmRMb2dvJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIDRfMDk2LFxuICAgICAgICAgICAgICAgICAgICApLFxuICAgICAgICAgICAgICAgIH0gOiB7fSksXG4gICAgICAgIH0sXG4gICAgICAgIGNvbnRpbnVhdGlvbjoge1xuICAgICAgICAgICAgLi4uKG5vcm1hbGl6ZU9wdGlvbmFsU3RyaW5nKFxuICAgICAgICAgICAgICAgIGNvbnRpbnVhdGlvbi5kZWZhdWx0UnVsZSxcbiAgICAgICAgICAgICAgICAnYnVkZHkgYmluZGluZyBjb250aW51YXRpb24uZGVmYXVsdFJ1bGUnLFxuICAgICAgICAgICAgKSA/IHtcbiAgICAgICAgICAgICAgICAgICAgZGVmYXVsdFJ1bGU6IG5vcm1hbGl6ZU9wdGlvbmFsU3RyaW5nKFxuICAgICAgICAgICAgICAgICAgICAgICAgY29udGludWF0aW9uLmRlZmF1bHRSdWxlLFxuICAgICAgICAgICAgICAgICAgICAgICAgJ2J1ZGR5IGJpbmRpbmcgY29udGludWF0aW9uLmRlZmF1bHRSdWxlJyxcbiAgICAgICAgICAgICAgICAgICAgKSxcbiAgICAgICAgICAgICAgICB9IDoge30pLFxuICAgICAgICB9LFxuICAgICAgICByZXNvdXJjZXM6IHsgcmVzb3VyY2VTbmFwc2hvdEtleSB9LFxuICAgIH07XG4gICAgYXNzZXJ0U2VyaWFsaXplZFNpemUoXG4gICAgICAgIGJpbmRpbmcsXG4gICAgICAgIEJVRERZX1NFU1NJT05fQklORElOR19NQVhfSlNPTl9MRU5HVEgsXG4gICAgICAgICdidWRkeSBzZXNzaW9uIGJpbmRpbmcnLFxuICAgICk7XG4gICAgcmV0dXJuIGRlZXBGcmVlemUoYmluZGluZyk7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBjcmVhdGVCdWRkeVNlc3Npb25CaW5kaW5nKFxuICAgIHZhbHVlOiBPbWl0PEJ1ZGR5U2Vzc2lvbkJpbmRpbmdWMSwgJ3ZlcnNpb24nPixcbik6IEJ1ZGR5U2Vzc2lvbkJpbmRpbmdWMSB7XG4gICAgcmV0dXJuIG5vcm1hbGl6ZUJ1ZGR5U2Vzc2lvbkJpbmRpbmcoe1xuICAgICAgICB2ZXJzaW9uOiBCVUREWV9TRVNTSU9OX0JJTkRJTkdfRk9STUFUX1ZFUlNJT04sXG4gICAgICAgIC4uLnZhbHVlLFxuICAgIH0pO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gcGFyc2VCdWRkeUFwcFNuYXBzaG90SnNvbih2YWx1ZTogc3RyaW5nIHwgbnVsbCB8IHVuZGVmaW5lZCk6IEJ1ZGR5QXBwU25hcHNob3RWMSB8IHVuZGVmaW5lZCB7XG4gICAgaWYgKCF2YWx1ZSB8fCB2YWx1ZS5sZW5ndGggPiBCVUREWV9BUFBfU05BUFNIT1RfTUFYX0pTT05fTEVOR1RIKSB7XG4gICAgICAgIHJldHVybiB1bmRlZmluZWQ7XG4gICAgfVxuICAgIHRyeSB7XG4gICAgICAgIHJldHVybiBub3JtYWxpemVCdWRkeUFwcFNuYXBzaG90KEpTT04ucGFyc2UodmFsdWUpKTtcbiAgICB9IGNhdGNoIHtcbiAgICAgICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgICB9XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBwYXJzZUJ1ZGR5U2Vzc2lvbkJpbmRpbmdKc29uKFxuICAgIHZhbHVlOiBzdHJpbmcgfCBudWxsIHwgdW5kZWZpbmVkLFxuKTogQnVkZHlTZXNzaW9uQmluZGluZ1YxIHwgdW5kZWZpbmVkIHtcbiAgICBpZiAoIXZhbHVlIHx8IHZhbHVlLmxlbmd0aCA+IEJVRERZX1NFU1NJT05fQklORElOR19NQVhfSlNPTl9MRU5HVEgpIHtcbiAgICAgICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgICB9XG4gICAgdHJ5IHtcbiAgICAgICAgcmV0dXJuIG5vcm1hbGl6ZUJ1ZGR5U2Vzc2lvbkJpbmRpbmcoSlNPTi5wYXJzZSh2YWx1ZSkpO1xuICAgIH0gY2F0Y2gge1xuICAgICAgICByZXR1cm4gdW5kZWZpbmVkO1xuICAgIH1cbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHNlcmlhbGl6ZUJ1ZGR5QXBwU25hcHNob3QodmFsdWU6IEJ1ZGR5QXBwU25hcHNob3RWMSk6IHN0cmluZyB7XG4gICAgcmV0dXJuIGFzc2VydFNlcmlhbGl6ZWRTaXplKFxuICAgICAgICBub3JtYWxpemVCdWRkeUFwcFNuYXBzaG90KHZhbHVlKSxcbiAgICAgICAgQlVERFlfQVBQX1NOQVBTSE9UX01BWF9KU09OX0xFTkdUSCxcbiAgICAgICAgJ2J1ZGR5IGFwcGxpY2F0aW9uIHNuYXBzaG90JyxcbiAgICApO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gc2VyaWFsaXplQnVkZHlTZXNzaW9uQmluZGluZyh2YWx1ZTogQnVkZHlTZXNzaW9uQmluZGluZ1YxKTogc3RyaW5nIHtcbiAgICByZXR1cm4gYXNzZXJ0U2VyaWFsaXplZFNpemUoXG4gICAgICAgIG5vcm1hbGl6ZUJ1ZGR5U2Vzc2lvbkJpbmRpbmcodmFsdWUpLFxuICAgICAgICBCVUREWV9TRVNTSU9OX0JJTkRJTkdfTUFYX0pTT05fTEVOR1RILFxuICAgICAgICAnYnVkZHkgc2Vzc2lvbiBiaW5kaW5nJyxcbiAgICApO1xufVxuIiwgIi8qKlxuICogQ29udmVyc2F0aW9uIFx1OEZERVx1NjNBNVx1NjAwMVx1NEU4Qlx1NEVGNlx1NTQwRFx1NUUzOFx1OTFDRlx1MzAwMlxuICpcbiAqIGRhZW1vbiBcdTRGQTcgYENvbnZlcnNhdGlvblBvb2wuYWNxdWlyZSgpYCBcdThCQTJcdTk2MDUgYENvbnZlcnNhdGlvbmAgXHU3Njg0XHU4RkRFXHU2M0E1XHU2MDAxXHU0RThCXHU0RUY2XHU1NDBFXHVGRjBDXHU4RjZDXHU1M0QxXHU1MjMwXG4gKiBgV0JCdXNgXHVGRjA4XHU1RTI2IGBjb252ZXJzYXRpb25JZGAgXHU1MzNBXHU1MjA2XHVGRjA5XHVGRjFCcmVuZGVyZXIgXHU0RkE3IGBjb252ZXJzYXRpb25zLnByb3ZpZGUudHNgXG4gKiBcdTc2ODQgYHJlaHlkcmF0ZUNvbnZlcnNhdGlvbmAgXHU2MzA5IGBjb252ZXJzYXRpb25JZGAgXHU4RkM3XHU2RUU0XHU1NDBFXHU4RjZDXHU1NkRFIGBDb252ZXJzYXRpb25gIFx1NEU4Qlx1NEVGNlx1N0I3RVx1NTQwRFx1MzAwMlxuICpcbiAqIFx1N0VBRlx1NUI1N1x1N0IyNlx1NEUzMlx1NUUzOFx1OTFDRiArIHBheWxvYWQgXHU3QzdCXHU1NzhCXHVGRjBDXHU2RDRGXHU4OUM4XHU1NjY4XHU1Qjg5XHU1MTY4XHVGRjA4XHU0RTBEIHZhbHVlLWltcG9ydCBcdTRFRkJcdTRGNTUgTm9kZS9FbGVjdHJvbiBcdTRGOURcdThENTZcdUZGMDlcdTMwMDJcbiAqL1xuXG5pbXBvcnQgdHlwZSB7IFdCTGlzdFJlc3VsdCB9IGZyb20gJy4uLy4uL2luZnJhL3diLXNoYXBlL2luZGV4JztcbmltcG9ydCB0eXBlIHsgRmluYWxSZXF1ZXN0U3RhdGUgfSBmcm9tICcuL2NvcmUvbW9kZWwvc3RhdGUtbWFjaGluZSc7XG5pbXBvcnQgdHlwZSB7XG4gICAgQ2FwYWNpdHlRdWV1ZVNuYXBzaG90LFxuICAgIENoaWxkQWdlbnRQcm9qZWN0aW9uRXZlbnQsXG4gICAgQ2hpbGRBZ2VudFNuYXBzaG90LFxuICAgIENvbW1hbmRzVXBkYXRlUGF5bG9hZCxcbiAgICBDb25maWdVcGRhdGVQYXlsb2FkLFxuICAgIENvbnZlcnNhdGlvbkNsb3VkU2VydmljZUNvbmZpcm1hdGlvbixcbiAgICBDb252ZXJzYXRpb25Db250ZXh0VXNhZ2VDaGFuZ2VkUGF5bG9hZCxcbiAgICBDb252ZXJzYXRpb25DcmVkaXRDaGFuZ2VkUGF5bG9hZCxcbiAgICBDb252ZXJzYXRpb25Fc3RpbWF0ZWRDb3N0Q2hhbmdlZFBheWxvYWQsXG4gICAgQ29udmVyc2F0aW9uRXh0ZW5zaW9uTWV0aG9kUGF5bG9hZCxcbiAgICBDb252ZXJzYXRpb25JbmZvLFxuICAgIENvbnZlcnNhdGlvbkxpc3RTY29wZSxcbiAgICBDb252ZXJzYXRpb25NY3BTdGFydHVwU3RhdHVzLFxuICAgIENvbnZlcnNhdGlvblBsdWdpblJlY29tbWVuZGF0aW9uLFxuICAgIENvbnZlcnNhdGlvblByZXBhcmVTdGF0dXMsXG4gICAgQ29udmVyc2F0aW9uUHJvbXB0UmVzcG9uc2VNZXRhLFxuICAgIENvbnZlcnNhdGlvblJlcXVlc3RQYXRjaCxcbiAgICBDb252ZXJzYXRpb25TdGF0ZSxcbiAgICBDb252ZXJzYXRpb25UZXJtaW5hbEVycm9yLFxuICAgIENvbnZlcnNhdGlvblRpbWVsaW5lRXZlbnRQYXlsb2FkLFxuICAgIENvbnZlcnNhdGlvblR1cm5JbnRlcnJ1cHRpb24sXG4gICAgTW9kZUNoYW5nZVBheWxvYWQsXG4gICAgTW9kZWxDaGFuZ2VQYXlsb2FkLFxuICAgIE1vZGVzVXBkYXRlUGF5bG9hZCxcbiAgICBQZW5kaW5nUmVxdWVzdCxcbiAgICBQbGFuVXBkYXRlUGF5bG9hZCxcbiAgICBXYXJuaW5nSW5mbyxcbn0gZnJvbSAnLi90eXBlcyc7XG5cbi8qKiBgQ29udmVyc2F0aW9uLm9uU3RhdGVDaGFuZ2VgIFx1OEY2Q1x1NTNEMVx1NEU4Qlx1NEVGNlx1NTQwRFx1MzAwMiAqL1xuZXhwb3J0IGNvbnN0IFdCX0NPTlZFUlNBVElPTl9TVEFURV9DSEFOR0UgPSAnd2I6Y29udmVyc2F0aW9uOnN0YXRlQ2hhbmdlJztcbi8qKiBgQ29udmVyc2F0aW9uYCBcdTUxNDNcdTRGRTFcdTYwNkZcdUZGMDh0aXRsZSBcdTdCNDlcdTk3NUUgc3RhdGUgXHU1QjU3XHU2QkI1XHVGRjA5XHU1M0Q4XHU1MzE2XHU4RjZDXHU1M0QxXHU0RThCXHU0RUY2XHU1NDBEXHUzMDAyICovXG5leHBvcnQgY29uc3QgV0JfQ09OVkVSU0FUSU9OX0lORk9fQ0hBTkdFID0gJ3diOmNvbnZlcnNhdGlvbjppbmZvQ2hhbmdlJztcbi8qKiBgQ29udmVyc2F0aW9uLm9uUmVxdWVzdFVwZGF0ZWAgXHU3Njg0XHU2RTkwXHU0RThCXHU0RUY2XHU1NDBEXHVGRjA4ZGFlbW9uIFx1NUJDQ1x1NUJGOVx1OEM2MSBcdTIxOTIgY29tbW9uIHNjaGVkdWxlclx1RkYwOVx1MzAwMiAqL1xuZXhwb3J0IGNvbnN0IFdCX0NPTlZFUlNBVElPTl9SRVFVRVNUX1VQREFURSA9ICd3Yjpjb252ZXJzYXRpb246cmVxdWVzdFVwZGF0ZSc7XG4vKipcbiAqIERlc2t0b3AgdHJhbnNwb3J0IFx1NTE4NVx1OTBFOFx1NzY4NCBSZXF1ZXN0VXBkYXRlIFx1NjI3OVx1NkIyMVx1NEU4Qlx1NEVGNlx1RkYxQlx1NkJDRlx1OTg3OVx1NEZERFx1NjMwMVx1NTM5Rlx1NTlDQiBjaHVua1x1RkYwQ1x1NEUwRFx1NjUzOVx1NTNEOCBwdWJsaWNcbiAqIGBDb252ZXJzYXRpb24ub24oUmVxdWVzdFVwZGF0ZSlgIFx1NzY4NFx1NTM1NVx1Njc2MVx1NTZERVx1OEMwM1x1N0I3RVx1NTQwRFx1MzAwMlxuICovXG5leHBvcnQgY29uc3QgV0JfQ09OVkVSU0FUSU9OX1JFUVVFU1RfVVBEQVRFX0JBVENIID0gJ3diOmNvbnZlcnNhdGlvbjpyZXF1ZXN0VXBkYXRlQmF0Y2gnO1xuLyoqIGB3Yi5jb252ZXJzYXRpb25zLm9uKFJlcXVlc3RVcGRhdGUpYCBcdTUxODVcdTkwRThcdTRGN0ZcdTc1MjhcdTc2ODQgcmVuZGVyZXIgXHU4QkEyXHU5NjA1XHU2M0E3XHU1MjM2IGNoYW5uZWxcdUZGMENcdTk3NUVcdTUxNkNcdTVGMDAgU0RLIEFQSVx1MzAwMiAqL1xuZXhwb3J0IGNvbnN0IFdCX0NPTlZFUlNBVElPTl9FVkVOVF9TVUJTQ1JJUFRJT05fQ0hBTk5FTCA9ICd3YjppbnRlcm5hbDpjb252ZXJzYXRpb24tZXZlbnQtc3Vic2NyaXB0aW9uJztcbi8qKiBcdTY3NDNcdTk2NTAvXHU5NUVFXHU3QjU0XHU4QkY3XHU2QzQyXHU0RThCXHU0RUY2XHU1NDBEXHVGRjA4ZGFlbW9uIFx1NEZBNyBwb29sIFx1OEY2Q1x1NTNEMVx1NTIzMCBldmVudEJ1c1x1RkYxQnJlbmRlcmVyIFx1NEZBN1x1N0YxM1x1NUI1OFx1NTQwRVx1OTAxQVx1OEZDNyBgZ2V0UGVuZGluZ0luZm8oKWAgXHU2MkM5XHU1M0Q2XHVGRjA5XHUzMDAyICovXG5leHBvcnQgY29uc3QgV0JfQ09OVkVSU0FUSU9OX1BFUk1JU1NJT04gPSAnd2I6Y29udmVyc2F0aW9uOnBlcm1pc3Npb24nO1xuLyoqXG4gKiBwaWNrX2xvY2F0aW9uIFx1OTAwOVx1NzBCOVx1NEUwQlx1NjNBOFx1MzAwMnBheWxvYWQgXHU0RTBFIFBFUk1JU1NJT04gXHU1NDBDXHU1RjYyXHVGRjBDYHBlcm1pc3Npb24uaW5wdXRUeXBlID09PSAncG9pX3BpY2snYFx1MzAwMlxuICogXHU2NUUwIFNNIHNlc3Npb24gXHU3Njg0IENFIFx1NEYxQVx1OEJERFx1OEQ3MFx1NjcyQ1x1NEU4Qlx1NEVGNlx1RkYwOFx1NjIxNlx1NTkwRFx1NzUyOCBQRVJNSVNTSU9OXHVGRjA5XHU4RkRCXHU1MTY1IHdhaXRpbmdcdUZGMENcdTRFMERcdTVGOTcgY2FuY2VsbGVkXHUzMDAyXG4gKi9cbmV4cG9ydCBjb25zdCBXQl9DT05WRVJTQVRJT05fUE9JX1BJQ0sgPSAnd2I6Y29udmVyc2F0aW9uOnBvaVBpY2snO1xuLyoqIFx1NEVBN1x1NTRDMVx1N0VBNyBQbHVnaW4vRXhwZXJ0IFx1NjNBOFx1ODM1MFx1NUZFQlx1NzE2N1x1NTNEOFx1NTMxNlx1NEU4Qlx1NEVGNlx1NTQwRFx1RkYxQnVuZGVmaW5lZCBcdTg4NjhcdTc5M0FcdTVERjJcdTdFRDNcdTdCOTdcdTMwMDIgKi9cbmV4cG9ydCBjb25zdCBXQl9DT05WRVJTQVRJT05fUExVR0lOX1JFQ09NTUVOREFUSU9OX0NIQU5HRUQgPSAnd2I6Y29udmVyc2F0aW9uOnBsdWdpblJlY29tbWVuZGF0aW9uQ2hhbmdlZCc7XG4vKiogXHU0RTkxXHU2NzBEXHU1MkExXHU1RjAwXHU5MDFBXHU1M0VGXHU0RkUxXHU3ODZFXHU4QkE0XHU1RkVCXHU3MTY3XHU1M0Q4XHU1MzE2XHU0RThCXHU0RUY2XHU1NDBEXHVGRjFCdW5kZWZpbmVkIFx1ODg2OFx1NzkzQVx1NURGMlx1N0VEM1x1N0I5N1x1MzAwMiAqL1xuZXhwb3J0IGNvbnN0IFdCX0NPTlZFUlNBVElPTl9DTE9VRF9TRVJWSUNFX0NPTkZJUk1BVElPTl9DSEFOR0VEID1cbiAgICAnd2I6Y29udmVyc2F0aW9uOmNsb3VkU2VydmljZUNvbmZpcm1hdGlvbkNoYW5nZWQnO1xuLyoqIGBDb252ZXJzYXRpb25gIFdhcm5pbmcgXHU0RThCXHU0RUY2XHVGRjA4YG9uKENvbnZlcnNhdGlvbkV2ZW50Lldhcm5pbmcpYFx1RkYwOVx1OEY2Q1x1NTNEMVx1NEU4Qlx1NEVGNlx1NTQwRFx1MzAwMiAqL1xuZXhwb3J0IGNvbnN0IFdCX0NPTlZFUlNBVElPTl9XQVJOSU5HID0gJ3diOmNvbnZlcnNhdGlvbjp3YXJuaW5nJztcbi8qKiBgQ29udmVyc2F0aW9uYCBQcmVwYXJlU3RhdHVzIFx1NEU4Qlx1NEVGNlx1RkYwOGBvbihDb252ZXJzYXRpb25FdmVudC5QcmVwYXJlU3RhdHVzKWBcdUZGMDlcdThGNkNcdTUzRDFcdTRFOEJcdTRFRjZcdTU0MERcdTMwMDIgKi9cbmV4cG9ydCBjb25zdCBXQl9DT05WRVJTQVRJT05fUFJFUEFSRV9TVEFUVVMgPSAnd2I6Y29udmVyc2F0aW9uOnByZXBhcmVTdGF0dXMnO1xuLyoqIGBDb252ZXJzYXRpb25gIE1jcFN0YXJ0dXBTdGF0dXMgXHU0RThCXHU0RUY2XHU4RjZDXHU1M0QxXHU1NDBEXHUzMDAyICovXG5leHBvcnQgY29uc3QgV0JfQ09OVkVSU0FUSU9OX01DUF9TVEFSVFVQX1NUQVRVUyA9ICd3Yjpjb252ZXJzYXRpb246bWNwU3RhcnR1cFN0YXR1cyc7XG4vKiogYENvbnZlcnNhdGlvbmAgXHU1Mzg2XHU1M0YyXHU1NkRFXHU2NTNFXHU1QjhDXHU2MjEwXHU0RThCXHU0RUY2XHVGRjA4YG9uKENvbnZlcnNhdGlvbkV2ZW50Lkhpc3RvcnlMb2FkZWQpYFx1RkYwOVx1OEY2Q1x1NTNEMVx1NEU4Qlx1NEVGNlx1NTQwRFx1MzAwMiAqL1xuZXhwb3J0IGNvbnN0IFdCX0NPTlZFUlNBVElPTl9ISVNUT1JZX0xPQURFRCA9ICd3Yjpjb252ZXJzYXRpb246aGlzdG9yeUxvYWRlZCc7XG4vKiogYENvbnZlcnNhdGlvbmAgUmVxdWVzdCBcdTVGRUJcdTcxNjdcdTUzRDhcdTY2RjRcdTRGRTFcdTUzRjdcdUZGMDhgb24oQ29udmVyc2F0aW9uRXZlbnQuUmVxdWVzdHNDaGFuZ2VkKWBcdUZGMDlcdThGNkNcdTUzRDFcdTRFOEJcdTRFRjZcdTU0MERcdUZGMUJcdThERTggSVBDIFx1NEUwRFx1NUUyNiBSZXF1ZXN0W11cdTMwMDIgKi9cbmV4cG9ydCBjb25zdCBXQl9DT05WRVJTQVRJT05fUkVRVUVTVFNfQ0hBTkdFRCA9ICd3Yjpjb252ZXJzYXRpb246cmVxdWVzdHNDaGFuZ2VkJztcbi8qKiBgQ29udmVyc2F0aW9uYCBcdTVCOUVcdTk2NDVcdTdEMkZcdThCQTEgQ3JlZGl0IFx1NTNEOFx1NTMxNlx1NEU4Qlx1NEVGNlx1MzAwMiAqL1xuZXhwb3J0IGNvbnN0IFdCX0NPTlZFUlNBVElPTl9DUkVESVRfQ0hBTkdFRCA9ICd3Yjpjb252ZXJzYXRpb246Y3JlZGl0Q2hhbmdlZCc7XG4vKiogYENvbnZlcnNhdGlvbmAgXHU0RjFBXHU4QkREXHU3RUE3XHU0RTBBXHU0RTBCXHU2NTg3XHU3NTI4XHU5MUNGXHU1RkVCXHU3MTY3XHU1M0Q4XHU1MzE2XHU0RThCXHU0RUY2XHVGRjA4XHU0RTBEXHU1NDJCIGNvc3RcdUZGMDlcdTMwMDIgKi9cbmV4cG9ydCBjb25zdCBXQl9DT05WRVJTQVRJT05fQ09OVEVYVF9VU0FHRV9DSEFOR0VEID0gJ3diOmNvbnZlcnNhdGlvbjpjb250ZXh0VXNhZ2VDaGFuZ2VkJztcbi8qKiBgQ29udmVyc2F0aW9uYCBcdTk4ODRcdThCQTFcdTYwM0IgQ3JlZGl0IFx1NTMzQVx1OTVGNFx1NTNEOFx1NTMxNlx1NEU4Qlx1NEVGNlx1MzAwMiAqL1xuZXhwb3J0IGNvbnN0IFdCX0NPTlZFUlNBVElPTl9FU1RJTUFURURfQ09TVF9DSEFOR0VEID0gJ3diOmNvbnZlcnNhdGlvbjplc3RpbWF0ZWRDb3N0Q2hhbmdlZCc7XG4vKiogYENvbnZlcnNhdGlvbmAgUHJvbXB0IFx1OTYxRlx1NTIxN1x1NTNEOFx1NTMxNlx1NEU4Qlx1NEVGNlx1MzAwMiAqL1xuZXhwb3J0IGNvbnN0IFdCX0NPTlZFUlNBVElPTl9RVUVVRV9VUERBVEUgPSAnd2I6Y29udmVyc2F0aW9uOnF1ZXVlVXBkYXRlJztcbi8qKiBgQ29udmVyc2F0aW9uYCBcdTY3MERcdTUyQTFcdTdBRUZcdTVCQjlcdTkxQ0ZcdTYzOTJcdTk2MUZcdTcyQjZcdTYwMDFcdTUzRDhcdTUzMTZcdTRFOEJcdTRFRjZcdTMwMDIgKi9cbmV4cG9ydCBjb25zdCBXQl9DT05WRVJTQVRJT05fQ0FQQUNJVFlfUVVFVUVfVVBEQVRFID0gJ3diOmNvbnZlcnNhdGlvbjpjYXBhY2l0eVF1ZXVlVXBkYXRlJztcbi8qKiBgQ29udmVyc2F0aW9uYCBcdTY1ODdcdTRFRjYvXHU0RUE3XHU3MjY5XHU1M0Q4XHU1MzE2XHU0RThCXHU0RUY2XHUzMDAyICovXG5leHBvcnQgY29uc3QgV0JfQ09OVkVSU0FUSU9OX0FSVElGQUNUX1VQREFURSA9ICd3Yjpjb252ZXJzYXRpb246YXJ0aWZhY3RVcGRhdGUnO1xuLyoqIFx1NTNFRlx1NzUyOFx1NTQ3RFx1NEVFNFx1NTNEOFx1NTMxNlx1NEU4Qlx1NEVGNlx1MzAwMiAqL1xuZXhwb3J0IGNvbnN0IFdCX0NPTlZFUlNBVElPTl9DT01NQU5EU19VUERBVEUgPSAnd2I6Y29udmVyc2F0aW9uOmNvbW1hbmRzVXBkYXRlJztcbi8qKiBcdTVGNTNcdTUyNERcdTY3NDNcdTk2NTBcdTZBMjFcdTVGMEZcdTUzRDhcdTUzMTZcdTRFOEJcdTRFRjZcdTMwMDIgKi9cbmV4cG9ydCBjb25zdCBXQl9DT05WRVJTQVRJT05fTU9ERV9DSEFOR0UgPSAnd2I6Y29udmVyc2F0aW9uOm1vZGVDaGFuZ2UnO1xuLyoqIFx1OTE0RFx1N0Y2RVx1OTAwOVx1OTg3OVx1NTNEOFx1NTMxNlx1NEU4Qlx1NEVGNlx1MzAwMiAqL1xuZXhwb3J0IGNvbnN0IFdCX0NPTlZFUlNBVElPTl9DT05GSUdfVVBEQVRFID0gJ3diOmNvbnZlcnNhdGlvbjpjb25maWdVcGRhdGUnO1xuLyoqIFx1NkEyMVx1NTc4Qlx1NTIxN1x1ODg2OFx1NjIxNlx1NUY1M1x1NTI0RFx1NkEyMVx1NTc4Qlx1NTNEOFx1NTMxNlx1NEU4Qlx1NEVGNlx1MzAwMiAqL1xuZXhwb3J0IGNvbnN0IFdCX0NPTlZFUlNBVElPTl9NT0RFTF9DSEFOR0UgPSAnd2I6Y29udmVyc2F0aW9uOm1vZGVsQ2hhbmdlJztcbi8qKiBjb21wYWN0IC8gc2Vzc2lvbiBib3VuZGFyeSBcdTdCNDlcdTk3NUUgUmVxdWVzdCBcdTY1RjZcdTk1RjRcdTdFQkZcdTRFOEJcdTRFRjZcdTMwMDIgKi9cbmV4cG9ydCBjb25zdCBXQl9DT05WRVJTQVRJT05fVElNRUxJTkVfRVZFTlQgPSAnd2I6Y29udmVyc2F0aW9uOnRpbWVsaW5lRXZlbnQnO1xuLyoqIFx1NTNFRlx1NzUyOFx1NkEyMVx1NUYwRlx1NTIxN1x1ODg2OFx1NTNEOFx1NTMxNlx1NEU4Qlx1NEVGNlx1MzAwMiAqL1xuZXhwb3J0IGNvbnN0IFdCX0NPTlZFUlNBVElPTl9NT0RFU19VUERBVEUgPSAnd2I6Y29udmVyc2F0aW9uOm1vZGVzVXBkYXRlJztcbi8qKiBcdThCQTFcdTUyMTIgVE9ETyBcdTUzRDhcdTUzMTZcdTRFOEJcdTRFRjZcdTMwMDIgKi9cbmV4cG9ydCBjb25zdCBXQl9DT05WRVJTQVRJT05fUExBTl9VUERBVEUgPSAnd2I6Y29udmVyc2F0aW9uOnBsYW5VcGRhdGUnO1xuLyoqIGNoZWNrcG9pbnQgLyBjb21tYW5kIC8gYXV0aFVybCBcdTc2ODQgQ29udmVyc2F0aW9uIFx1OEJFRFx1NEU0OVx1NjI2OVx1NUM1NVx1NEU4Qlx1NEVGNlx1OERFOCBJUEMgXHU4RjZDXHU1M0QxXHU5MDFBXHU5MDUzXHUzMDAyICovXG5leHBvcnQgY29uc3QgV0JfQ09OVkVSU0FUSU9OX0VYVEVOU0lPTl9NRVRIT0QgPSAnd2I6Y29udmVyc2F0aW9uOmV4dGVuc2lvbk1ldGhvZCc7XG4vKiogTWFpbiBcdThGREJcdTdBMEJcdTUzRUFcdTU0MTFcdTdFRDFcdTVCOUEgcmVuZGVyZXIgXHU2Mjk1XHU5MDEyXHU3Njg0XHU0RTAwXHU2QjIxXHU1QkEyXHU2MjM3XHU3QUVGXHU1REU1XHU1MTc3XHU2MjY3XHU4ODRDXHU4QkY3XHU2QzQyXHUzMDAyICovXG5leHBvcnQgY29uc3QgV0JfQ09OVkVSU0FUSU9OX0NMSUVOVF9UT09MX0lOVk9LRSA9ICd3Yjpjb252ZXJzYXRpb246Y2xpZW50VG9vbEludm9rZSc7XG4vKiogXHU1QjUwIEFnZW50L1RlYW0gXHU2Mjk1XHU1RjcxXHU1MjE3XHU4ODY4XHUzMDAxXHU4QkY3XHU2QzQyXHU1NDhDXHU3MkI2XHU2MDAxXHU1M0Q4XHU1MzE2XHUzMDAyICovXG5leHBvcnQgY29uc3QgV0JfQ09OVkVSU0FUSU9OX0NISUxEX0FHRU5UX0VWRU5UID0gJ3diOmNvbnZlcnNhdGlvbjpjaGlsZEFnZW50RXZlbnQnO1xuLyoqIENoaWxkQWdlbnQgXHU5QUQ4XHU5ODkxXHU4QkY3XHU2QzQyXHU0RThCXHU0RUY2XHU3Njg0XHU1MTg1XHU5MEU4IHRyYW5zcG9ydCBcdTYyNzlcdTZCMjFcdUZGMUJyZW5kZXJlciBcdTRGMUFcdThGRDhcdTUzOUZcdTUzOUZcdTU5Q0JcdTUxNkNcdTVGMDBcdTU2REVcdThDMDNcdTMwMDIgKi9cbmV4cG9ydCBjb25zdCBXQl9DT05WRVJTQVRJT05fQ0hJTERfQUdFTlRfRVZFTlRfQkFUQ0ggPSAnd2I6Y29udmVyc2F0aW9uOmNoaWxkQWdlbnRFdmVudEJhdGNoJztcbi8qKlxuICogXHU5NkM2XHU1NDA4XHU3RUE3XHU1MjE3XHU4ODY4XHU1M0Q4XHU2NkY0XHU0RThCXHU0RUY2XHVGRjA4XHU1MzNBXHU1MjJCXHU0RThFXHU1MTc2XHU0RjU5XHU2MzA5IGNvbnZlcnNhdGlvbklkIFx1NTIwNlx1NTNEMVx1NzY4NFx1NUI5RVx1NEY4Qlx1N0VBN1x1NEU4Qlx1NEVGNlx1RkYwOVx1MzAwMlxuICpcbiAqIFx1NzUzMSBkYWVtb24gXHU0RkE3IGBDb252ZXJzYXRpb25MaXN0UG9sbGVyYCBcdTUzNTVcdTcwQjlcdTUzRDFcdTVFMDNcdUZGMENcdTg5ODZcdTc2RDZcdThERThcdThGREJcdTdBMEIvXHU4REU4XHU3QUVGXHU3Njg0XHU1ODlFXHU1MjIwXHU2NTM5XHUyMDE0XHUyMDE0XG4gKiBcdThGRDlcdTRFOUJcdTUzRDhcdTUzMTZcdTRFMERcdTdFQ0ZcdThGQzdcdTY3MkNcdTU3MzAgU0RLIFx1NzY4NFx1NTE5OVx1NjRDRFx1NEY1Q1x1RkYwQ2BvbkNvbnZlcnNhdGlvbkNoYW5nZWRgIFx1NzcwQlx1NEUwRFx1ODlDMVx1MzAwMlxuICovXG5leHBvcnQgY29uc3QgV0JfQ09OVkVSU0FUSU9OX0xJU1RfQ0hBTkdFRCA9ICd3Yjpjb252ZXJzYXRpb25zOmxpc3RDaGFuZ2VkJztcbi8qKiBcdTk5OTZcdTYyQzkgLyBcdTRFM0JcdTUyQThcdTUyMzdcdTY1QjAgLyBzcGFjZSBcdTYxRDJcdTUyQTBcdThGN0RcdTVCOENcdTYyMTBcdTU0MEVcdTc2ODRcdTYzMDkgc3BhY2UgXHU1MjE3XHU4ODY4XHU1RkVCXHU3MTY3XHU0RThCXHU0RUY2XHUzMDAyICovXG5leHBvcnQgY29uc3QgV0JfQ09OVkVSU0FUSU9OX0xJU1RfUFJPR1JFU1MgPSAnd2I6Y29udmVyc2F0aW9uczpsaXN0UHJvZ3Jlc3MnO1xuXG4vKipcbiAqIFx1NjcyQyBTREsgXHU1MTg1IGB3Yi5jb252ZXJzYXRpb25zLmNyZWF0ZS9kZWxldGUvYXJjaGl2ZS91bmFyY2hpdmUvZm9ya2AgXHU1QjhDXHU2MjEwXHU1NDBFXHU3Njg0XHU1MzczXHU2NUY2XHU4QkVEXHU0RTQ5XHU0RThCXHU0RUY2XHUzMDAyXG4gKlxuICogXHU4QkVEXHU0RTQ5XHU3NkY0XHU2M0E1XHVGRjFBXHU0RTAwXHU0RTJBXHU1MkE4XHU0RjVDXHU0RTAwXHU0RTJBXHU0RThCXHU0RUY2XHU1NDBEXHUzMDAyXHU4REU4XHU4RkRCXHU3QTBCIFNESyBcdTZEODhcdThEMzlcdTgwMDVcdUZGMDhleHRlbnNpb24gXHU3QjQ5XHVGRjA5XHU3NkY0XHU2M0E1XHU4QkEyXHU5NjA1XHU4RkQ5XHU1MUUwXHU0RTJBXHU1MzczXHU1M0VGXHVGRjBDXG4gKiBcdTY1RTBcdTk3MDBcdTdCNDkgYFdCX0NPTlZFUlNBVElPTl9MSVNUX0NIQU5HRURgIHBvbGxlciAzMHMgdGlja1x1MzAwMlxuICogXHU4REU4XHU4RkRCXHU3QTBCL1x1OERFOFx1OEQyNlx1NTNGN1x1NTNEOFx1NTMxNlx1RkYwOFx1NkJENFx1NTk4Mlx1NUMwRlx1N0EwQlx1NUU4Rlx1N0FFRlx1NUY1Mlx1Njg2M1x1RkYwOVx1NEVDRFx1OTc2MCBwb2xsZXIgXHU1MTVDXHU1RTk1XHUzMDAyXG4gKlxuICogXHUyNkEwXHVGRTBGIGBXQl9DT05WRVJTQVRJT05fQ1JFQVRFRGAgcGF5bG9hZCBcdTVFMjYqKlx1NUI4Q1x1NjU3NCBgQ29udmVyc2F0aW9uSW5mb2AgXHU1RkVCXHU3MTY3KipcdTIwMTRcdTIwMTRcdTU2RTBcdTRFM0FcbiAqIGV4dGVuc2lvbiBcdTRGQTdcdUZGMDhcdTU5ODIgZWRnZS1zeW5jXHVGRjA5XHU2MkZGXHU1MjMwIGlkIFx1NTQwRVx1OEZEOFx1NUY5N1x1NTZERVx1Njc2NSB3Yi5jb252ZXJzYXRpb25zLmdldCBcdTYyNERcdTgwRkRcdTU0MENcdTZCNjVcdTUyMzBcdTRFOTFcdTdBRUZcdUZGMENcbiAqIFx1NEUwMFx1NkIyMSBlbWl0IFx1NzZGNFx1NjNBNVx1NjI4QSBpbmZvIFx1NUUyNlx1OEZDN1x1NTNCQlx1NzcwMVx1NEUwMFx1NkIyMSBJUEMgXHU1RjgwXHU4RkQ0XHVGRjBDXHU0RTVGXHU5MDdGXHU1MTREIGRhZW1vbiBcdTkwQTNcdThGQjkgcG9vbCBcdTVERjJcdThGQzFcdTc5RkJcdTYyMTZcbiAqIGNvbnZlcnNhdGlvbiBcdTVERjJcdTUyMjBcdTk2NjRcdTc2ODRcdTY1RjZcdTVFOEZcdTk1RUVcdTk4OThcdTMwMDJcbiAqL1xuZXhwb3J0IGNvbnN0IFdCX0NPTlZFUlNBVElPTl9DUkVBVEVEID0gJ3diOmNvbnZlcnNhdGlvbjpjcmVhdGVkJztcbmV4cG9ydCBjb25zdCBXQl9DT05WRVJTQVRJT05fREVMRVRFRCA9ICd3Yjpjb252ZXJzYXRpb246ZGVsZXRlZCc7XG5leHBvcnQgY29uc3QgV0JfQ09OVkVSU0FUSU9OX0FSQ0hJVkVEID0gJ3diOmNvbnZlcnNhdGlvbjphcmNoaXZlZCc7XG5leHBvcnQgY29uc3QgV0JfQ09OVkVSU0FUSU9OX1VOQVJDSElWRUQgPSAnd2I6Y29udmVyc2F0aW9uOnVuYXJjaGl2ZWQnO1xuZXhwb3J0IGNvbnN0IFdCX0NPTlZFUlNBVElPTl9QSU5ORUQgPSAnd2I6Y29udmVyc2F0aW9uOnBpbm5lZCc7XG5leHBvcnQgY29uc3QgV0JfQ09OVkVSU0FUSU9OX1VOUElOTkVEID0gJ3diOmNvbnZlcnNhdGlvbjp1bnBpbm5lZCc7XG5leHBvcnQgY29uc3QgV0JfQ09OVkVSU0FUSU9OX1BJTlNfUkVPUkRFUkVEID0gJ3diOmNvbnZlcnNhdGlvbjpwaW5zUmVvcmRlcmVkJztcblxuZXhwb3J0IGludGVyZmFjZSBDb252ZXJzYXRpb25DcmVhdGVkUGF5bG9hZCB7XG4gICAgY29udmVyc2F0aW9uSWQ6IHN0cmluZztcbiAgICBpbmZvOiBDb252ZXJzYXRpb25JbmZvO1xufVxuZXhwb3J0IGludGVyZmFjZSBDb252ZXJzYXRpb25EZWxldGVkUGF5bG9hZCB7XG4gICAgY29udmVyc2F0aW9uSWQ6IHN0cmluZztcbiAgICAvKiogSW50ZXJuYWwgb3duZXJzaGlwIGhpbnQ7IHJlbW90ZSBwcm9qZWN0aW9ucyBrZWVwIHRoZSBwdWJsaWMgcGF5bG9hZCB1bmNoYW5nZWQuICovXG4gICAgdHJhbnNwb3J0PzogQ29udmVyc2F0aW9uSW5mb1sndHJhbnNwb3J0J107XG59XG5leHBvcnQgaW50ZXJmYWNlIENvbnZlcnNhdGlvbkFyY2hpdmVkUGF5bG9hZCB7XG4gICAgY29udmVyc2F0aW9uSWQ6IHN0cmluZztcbiAgICAvKiogSW50ZXJuYWwgb3duZXJzaGlwIGhpbnQ7IHJlbW90ZSBwcm9qZWN0aW9ucyBrZWVwIHRoZSBwdWJsaWMgcGF5bG9hZCB1bmNoYW5nZWQuICovXG4gICAgdHJhbnNwb3J0PzogQ29udmVyc2F0aW9uSW5mb1sndHJhbnNwb3J0J107XG59XG5leHBvcnQgaW50ZXJmYWNlIENvbnZlcnNhdGlvblVuYXJjaGl2ZWRQYXlsb2FkIHtcbiAgICBjb252ZXJzYXRpb25JZDogc3RyaW5nO1xuICAgIC8qKiBJbnRlcm5hbCBvd25lcnNoaXAgaGludDsgcmVtb3RlIHByb2plY3Rpb25zIGtlZXAgdGhlIHB1YmxpYyBwYXlsb2FkIHVuY2hhbmdlZC4gKi9cbiAgICB0cmFuc3BvcnQ/OiBDb252ZXJzYXRpb25JbmZvWyd0cmFuc3BvcnQnXTtcbn1cbmV4cG9ydCBpbnRlcmZhY2UgQ29udmVyc2F0aW9uUGlubmVkUGF5bG9hZCB7IGNvbnZlcnNhdGlvbklkOiBzdHJpbmcgfVxuZXhwb3J0IGludGVyZmFjZSBDb252ZXJzYXRpb25VbnBpbm5lZFBheWxvYWQgeyBjb252ZXJzYXRpb25JZDogc3RyaW5nIH1cbmV4cG9ydCBpbnRlcmZhY2UgQ29udmVyc2F0aW9uUGluc1Jlb3JkZXJlZFBheWxvYWQge1xuICAgIGNvbnZlcnNhdGlvbklkOiBzdHJpbmc7XG4gICAgLyoqIFx1NjI4QVx1NUY1M1x1NTI0RFx1NEYxQVx1OEJERFx1NzlGQlx1NTJBOFx1NTIzMFx1OEJFNVx1NEYxQVx1OEJERFx1NTI0RFx1OTc2Mlx1RkYxQlx1NEUzQVx1N0E3QVx1ODg2OFx1NzkzQVx1NzlGQlx1NTJBOFx1NTIzMFx1N0Y2RVx1OTg3Nlx1NTIxN1x1ODg2OFx1NjcwMFx1NUU5NVx1OTBFOFx1MzAwMiAqL1xuICAgIGJlZm9yZVdoaWNoSWQ/OiBzdHJpbmc7XG59XG5cbi8qKlxuICogXHU3NTI4XHU2MjM3IHByb21wdCBcdTYyMTBcdTUyOUZcdTZEM0VcdTUzRDFcdTUyMzAgd29ya2VyIFx1NjVGNlx1ODlFNlx1NTNEMVx1RkYwOFx1NEVDNVx1NjcyQ1x1NTczMFx1NTNEMVx1OEQ3N1x1NzY4NCBwcm9tcHRcdUZGMENcdTVDMEZcdTdBMEJcdTVFOEZcdTY3NjVcdTc2ODRcdTVFMjYgX3NraXBQcm9tcHREaXNwYXRjaGVkIFx1NEUwRCBlbWl0XHVGRjA5XHUzMDAyXG4gKiBlZGdlLXN5bmMgXHU3NkQxXHU1NDJDXHU2QjY0XHU0RThCXHU0RUY2XHVGRjBDXHU1QzA2XHU2ODRDXHU5NzYyXHU3QUVGXHU2NzJDXHU1NzMwXHU1M0QxXHU3Njg0IHByb21wdCBlY2hvIFx1NjNBOFx1OTAwMVx1N0VEOVx1NUMwRlx1N0EwQlx1NUU4Rlx1MzAwMlxuICovXG5leHBvcnQgY29uc3QgV0JfQ09OVkVSU0FUSU9OX1BST01QVF9ESVNQQVRDSEVEID0gJ3diOmNvbnZlcnNhdGlvbjpwcm9tcHREaXNwYXRjaGVkJztcbmV4cG9ydCBpbnRlcmZhY2UgQ29udmVyc2F0aW9uUHJvbXB0RGlzcGF0Y2hlZFBheWxvYWQge1xuICAgIGNvbnZlcnNhdGlvbklkOiBzdHJpbmc7XG4gICAgLyoqIFx1NzUyOFx1NjIzN1x1NTNEMVx1OTAwMVx1NzY4NCBwcm9tcHQgYmxvY2tzICovXG4gICAgcHJvbXB0OiB1bmtub3duW107XG4gICAgLyoqIFx1NUY1M1x1NTI0RFx1NEYxQVx1OEJERFx1NjYyRlx1NTQyNlx1NEUzQVx1NTQwRVx1NTNGMFx1ODFFQVx1NTJBOFx1NTMxNi9cdTVCOUFcdTY1RjZcdTRFRkJcdTUyQTFcdUZGMENcdTc1MjhcdTRFOEUgdGFzay1ub3RpZnkgXHU0RTBBXHU2MkE1IHRhc2tLaW5kXHUzMDAyICovXG4gICAgaXNCYWNrZ3JvdW5kQXV0b21hdGlvbj86IGJvb2xlYW47XG59XG5cbi8qKiBgV0JfQ09OVkVSU0FUSU9OX1NUQVRFX0NIQU5HRWAgXHU3Njg0IHBheWxvYWRcdUZGMDhcdTVFMjYgY29udmVyc2F0aW9uSWQgXHU1MzNBXHU1MjA2XHU0RTBEXHU1NDBDXHU0RjFBXHU4QkREXHVGRjA5XHUzMDAyICovXG5leHBvcnQgaW50ZXJmYWNlIENvbnZlcnNhdGlvblN0YXRlQ2hhbmdlUGF5bG9hZCB7XG4gICAgY29udmVyc2F0aW9uSWQ6IHN0cmluZztcbiAgICBmcm9tOiBDb252ZXJzYXRpb25TdGF0ZTtcbiAgICB0bzogQ29udmVyc2F0aW9uU3RhdGU7XG4gICAgZmluYWxTdGF0ZT86IEZpbmFsUmVxdWVzdFN0YXRlO1xuICAgIHRlcm1pbmFsRXJyb3I/OiBDb252ZXJzYXRpb25UZXJtaW5hbEVycm9yO1xuICAgIGludGVycnVwdGlvbj86IENvbnZlcnNhdGlvblR1cm5JbnRlcnJ1cHRpb247XG4gICAgLyoqIFByb21wdFJlc3BvbnNlIFx1NURGMiByZXNvbHZlIFx1NjVGNlx1NjQzQVx1NUUyNlx1NzY4NCBzdG9wUmVhc29uIFx1NEUwRSBDTEkgdGFzayBvdXRjb21lXHUzMDAyICovXG4gICAgcHJvbXB0UmVzcG9uc2VNZXRhPzogQ29udmVyc2F0aW9uUHJvbXB0UmVzcG9uc2VNZXRhO1xufVxuXG4vKipcbiAqIGBXQl9DT05WRVJTQVRJT05fSU5GT19DSEFOR0VgIFx1NzY4NCBwYXlsb2FkXHVGRjA4XHU1RTI2IGNvbnZlcnNhdGlvbklkIFx1NTMzQVx1NTIwNlx1NEUwRFx1NTQwQ1x1NEYxQVx1OEJERFx1RkYwOVx1MzAwMlxuICpcbiAqIFx1NjQzQVx1NUUyNlx1NTNEOFx1NTMxNlx1NTQwRVx1NzY4NFx1NUI4Q1x1NjU3NCBgQ29udmVyc2F0aW9uSW5mb2AgXHU1RkVCXHU3MTY3XHVGRjBDXHU3NTI4XHU0RThFIHJlbmRlcmVyIFx1NEZBNyByZWh5ZHJhdGUgXHU3Njg0IGluZm8udGl0bGVcbiAqIGdldHRlciBcdTRFMEUgZGFlbW9uIFx1NEZERFx1NjMwMVx1NEUwMFx1ODFGNFx1RkYwOFx1NTk4MiBDTEkgdHVybiBcdTdFRDNcdTY3NUZcdTYzQThcdTkwMDFcdTY4MDdcdTk4OThcdTY2RjRcdTY1QjBcdUZGMDlcdTMwMDJcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBDb252ZXJzYXRpb25JbmZvQ2hhbmdlUGF5bG9hZCB7XG4gICAgY29udmVyc2F0aW9uSWQ6IHN0cmluZztcbiAgICBpbmZvOiBDb252ZXJzYXRpb25JbmZvO1xufVxuXG4vKiogYFdCX0NPTlZFUlNBVElPTl9SRVFVRVNUX1VQREFURWAgXHU3Njg0IHBheWxvYWRcdTMwMDIgKi9cbmV4cG9ydCBpbnRlcmZhY2UgQ29udmVyc2F0aW9uUmVxdWVzdFVwZGF0ZVBheWxvYWQge1xuICAgIGNvbnZlcnNhdGlvbklkOiBzdHJpbmc7XG4gICAgcmVxdWVzdElkOiBzdHJpbmc7XG4gICAgbWVzc2FnZUlkOiBzdHJpbmc7XG4gICAgLyoqIFx1NUI4Q1x1NjU3NCBBQ1Agbm90aWZpY2F0aW9uIFx1NTM5Rlx1NTlDQlx1OEY3RFx1ODM3N1x1RkYxQlx1NTE2Q1x1NUYwMCBSZXF1ZXN0VXBkYXRlIFx1NTZERVx1OEMwM1x1NTQwQ1x1NjgzN1x1NEVFNSB1bmtub3duIFx1NjZCNFx1OTczMlx1MzAwMiAqL1xuICAgIGNodW5rOiB1bmtub3duO1xuICAgIC8qKiBDb3JlIFx1NURGMlx1NUI4Q1x1NjIxMCBBQ1AgXHU4QkVEXHU0RTQ5XHU2MkZDXHU2M0E1XHU3Njg0XHU3QTMzXHU1QjlBXHU2RDg4XHU2MDZGXHU1ODlFXHU5MUNGXHVGRjFCcmVuZGVyZXIgXHU2RDg4XHU2MDZGXHU2Mjk1XHU1RjcxXHU1M0VBXHU2RDg4XHU4RDM5XHU2QjY0XHU1QjU3XHU2QkI1XHUzMDAyICovXG4gICAgcGF0Y2hlczogcmVhZG9ubHkgQ29udmVyc2F0aW9uUmVxdWVzdFBhdGNoW107XG59XG5cbi8qKlxuICogUmVxdWVzdFVwZGF0ZSB3aXJlIFx1NzI0OFx1NjcyQ1x1OTVFOFx1Nzk4MVx1MzAwMnR5cGVkIHBhdGNoIFx1NURGMlx1NjYyRiByZW5kZXJlciBcdTU1MkZcdTRFMDBcdTZEODhcdTYwNkZcdTU4OUVcdTkxQ0ZcdTY3NjVcdTZFOTBcdUZGMENcdTY1RTdcdThGN0RcdTgzNzdcdTRFMERcdTgwRkRcbiAqIFx1NTE4RFx1OTY0RFx1N0VBN1x1NjIxMFx1N0E3QVx1NjU3MFx1N0VDNFx1RkYwQ1x1NTQyNlx1NTIxOVx1NTM0Rlx1OEJBRVx1NEUwRFx1NTMzOVx1OTE0RFx1NEYxQVx1NEYyQVx1ODhDNVx1NjIxMFx1NkI2M1x1NUUzOFx1NEY0Nlx1NjVFMFx1NkI2M1x1NjU4N1x1NzY4NFx1NkQ0MVx1NUYwRlx1NTRDRFx1NUU5NFx1MzAwMlxuICovXG5leHBvcnQgZnVuY3Rpb24gcmVxdWlyZUNvbnZlcnNhdGlvblJlcXVlc3RQYXRjaGVzKFxuICAgIHBheWxvYWQ6IHsgcGF0Y2hlcz86IHVua25vd24gfSxcbik6IHJlYWRvbmx5IENvbnZlcnNhdGlvblJlcXVlc3RQYXRjaFtdIHtcbiAgICBpZiAoIUFycmF5LmlzQXJyYXkocGF5bG9hZC5wYXRjaGVzKSkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ0luY29tcGF0aWJsZSBDb252ZXJzYXRpb24gUmVxdWVzdFVwZGF0ZSBwYXlsb2FkOiB0eXBlZCBwYXRjaGVzIGFyZSByZXF1aXJlZCcpO1xuICAgIH1cbiAgICByZXR1cm4gcGF5bG9hZC5wYXRjaGVzIGFzIENvbnZlcnNhdGlvblJlcXVlc3RQYXRjaFtdO1xufVxuXG4vKiogXHU0RUM1XHU3NTI4XHU0RThFIGhvc3QgdHJhbnNwb3J0IFx1NzY4NFx1NTM5Rlx1NTlDQiBSZXF1ZXN0VXBkYXRlIFx1NjI3OVx1NkIyMVx1RkYxQnJlbmRlcmVyIFx1NjUzNlx1NTIzMFx1NTQwRVx1OTAxMFx1OTg3OVx1OEZEOFx1NTM5Rlx1NTE2Q1x1NUYwMFx1NTZERVx1OEMwM1x1MzAwMiAqL1xuZXhwb3J0IGludGVyZmFjZSBDb252ZXJzYXRpb25SZXF1ZXN0VXBkYXRlQmF0Y2hQYXlsb2FkIHtcbiAgICBjb252ZXJzYXRpb25JZDogc3RyaW5nO1xuICAgIHVwZGF0ZXM6IENvbnZlcnNhdGlvblJlcXVlc3RVcGRhdGVQYXlsb2FkW107XG59XG5cbi8qKiBgV0JfQ09OVkVSU0FUSU9OX1BFUk1JU1NJT05gIFx1NzY4NCBwYXlsb2FkXHUzMDAyICovXG5leHBvcnQgaW50ZXJmYWNlIENvbnZlcnNhdGlvblBlcm1pc3Npb25QYXlsb2FkIHtcbiAgICBjb252ZXJzYXRpb25JZDogc3RyaW5nO1xuICAgIHBlcm1pc3Npb246IFBlbmRpbmdSZXF1ZXN0O1xufVxuXG4vKiogYFdCX0NPTlZFUlNBVElPTl9QTFVHSU5fUkVDT01NRU5EQVRJT05fQ0hBTkdFRGAgXHU3Njg0IHBheWxvYWRcdTMwMDIgKi9cbmV4cG9ydCBpbnRlcmZhY2UgQ29udmVyc2F0aW9uUGx1Z2luUmVjb21tZW5kYXRpb25DaGFuZ2VkUGF5bG9hZCB7XG4gICAgY29udmVyc2F0aW9uSWQ6IHN0cmluZztcbiAgICByZWNvbW1lbmRhdGlvbjogQ29udmVyc2F0aW9uUGx1Z2luUmVjb21tZW5kYXRpb24gfCB1bmRlZmluZWQ7XG59XG5cbi8qKiBgV0JfQ09OVkVSU0FUSU9OX0NMT1VEX1NFUlZJQ0VfQ09ORklSTUFUSU9OX0NIQU5HRURgIFx1NzY4NCBwYXlsb2FkXHUzMDAyICovXG5leHBvcnQgaW50ZXJmYWNlIENvbnZlcnNhdGlvbkNsb3VkU2VydmljZUNvbmZpcm1hdGlvbkNoYW5nZWRQYXlsb2FkIHtcbiAgICBjb252ZXJzYXRpb25JZDogc3RyaW5nO1xuICAgIGNvbmZpcm1hdGlvbjogQ29udmVyc2F0aW9uQ2xvdWRTZXJ2aWNlQ29uZmlybWF0aW9uIHwgdW5kZWZpbmVkO1xufVxuXG4vKiogYFdCX0NPTlZFUlNBVElPTl9XQVJOSU5HYCBcdTc2ODQgcGF5bG9hZFx1MzAwMiAqL1xuZXhwb3J0IGludGVyZmFjZSBDb252ZXJzYXRpb25XYXJuaW5nUGF5bG9hZCB7XG4gICAgY29udmVyc2F0aW9uSWQ6IHN0cmluZztcbiAgICBpbmZvOiBXYXJuaW5nSW5mbztcbn1cblxuLyoqIGBXQl9DT05WRVJTQVRJT05fUFJFUEFSRV9TVEFUVVNgIFx1NzY4NCBwYXlsb2FkXHUzMDAyICovXG5leHBvcnQgaW50ZXJmYWNlIENvbnZlcnNhdGlvblByZXBhcmVTdGF0dXNQYXlsb2FkIHtcbiAgICBjb252ZXJzYXRpb25JZDogc3RyaW5nO1xuICAgIHN0YXR1czogQ29udmVyc2F0aW9uUHJlcGFyZVN0YXR1cztcbn1cblxuLyoqIGBXQl9DT05WRVJTQVRJT05fTUNQX1NUQVJUVVBfU1RBVFVTYCBcdTc2ODQgcGF5bG9hZFx1MzAwMiAqL1xuZXhwb3J0IGludGVyZmFjZSBDb252ZXJzYXRpb25NY3BTdGFydHVwU3RhdHVzUGF5bG9hZCB7XG4gICAgY29udmVyc2F0aW9uSWQ6IHN0cmluZztcbiAgICBzdGF0dXM6IENvbnZlcnNhdGlvbk1jcFN0YXJ0dXBTdGF0dXM7XG59XG5cbi8qKiBgV0JfQ09OVkVSU0FUSU9OX0hJU1RPUllfTE9BREVEYCBcdTc2ODQgcGF5bG9hZFx1RkYwOFx1NjVFMFx1NEUxQVx1NTJBMVx1NUI1N1x1NkJCNVx1RkYwQ1x1NEVDNVx1NUUyNiBjb252ZXJzYXRpb25JZCBcdTUzM0FcdTUyMDZcdUZGMDlcdTMwMDIgKi9cbmV4cG9ydCBpbnRlcmZhY2UgQ29udmVyc2F0aW9uSGlzdG9yeUxvYWRlZFBheWxvYWQge1xuICAgIGNvbnZlcnNhdGlvbklkOiBzdHJpbmc7XG59XG5cbi8qKiBgV0JfQ09OVkVSU0FUSU9OX1JFUVVFU1RTX0NIQU5HRURgIFx1NzY4NCBwYXlsb2FkXHVGRjA4XHU0RUM1XHU0RkUxXHU1M0Y3XHVGRjFCXHU2RDg4XHU4RDM5XHU2NUI5XHU2NzA5XHU3NTRDXHU2MkM5XHU1M0Q2XHU2MkZDXHU1OTdEXHU3Njg0IFJlcXVlc3RbXVx1RkYwOVx1MzAwMiAqL1xuZXhwb3J0IGludGVyZmFjZSBDb252ZXJzYXRpb25SZXF1ZXN0c0NoYW5nZWRQYXlsb2FkIHtcbiAgICBjb252ZXJzYXRpb25JZDogc3RyaW5nO1xufVxuXG4vKiogYFdCX0NPTlZFUlNBVElPTl9DUkVESVRfQ0hBTkdFRGAgXHU3Njg0XHU4REU4IElQQyBwYXlsb2FkXHUzMDAyICovXG5leHBvcnQgdHlwZSBDb252ZXJzYXRpb25DcmVkaXRDaGFuZ2VkRXZlbnRQYXlsb2FkID0gQ29udmVyc2F0aW9uQ3JlZGl0Q2hhbmdlZFBheWxvYWQgJiB7XG4gICAgY29udmVyc2F0aW9uSWQ6IHN0cmluZztcbn07XG5cbi8qKiBgV0JfQ09OVkVSU0FUSU9OX0NPTlRFWFRfVVNBR0VfQ0hBTkdFRGAgXHU3Njg0XHU4REU4IElQQyBwYXlsb2FkXHUzMDAyICovXG5leHBvcnQgdHlwZSBDb252ZXJzYXRpb25Db250ZXh0VXNhZ2VDaGFuZ2VkRXZlbnRQYXlsb2FkID0gQ29udmVyc2F0aW9uQ29udGV4dFVzYWdlQ2hhbmdlZFBheWxvYWQgJiB7XG4gICAgY29udmVyc2F0aW9uSWQ6IHN0cmluZztcbn07XG5cbi8qKiBgV0JfQ09OVkVSU0FUSU9OX0VTVElNQVRFRF9DT1NUX0NIQU5HRURgIFx1NzY4NFx1OERFOCBJUEMgcGF5bG9hZFx1MzAwMiAqL1xuZXhwb3J0IHR5cGUgQ29udmVyc2F0aW9uRXN0aW1hdGVkQ29zdENoYW5nZWRFdmVudFBheWxvYWQgPSBDb252ZXJzYXRpb25Fc3RpbWF0ZWRDb3N0Q2hhbmdlZFBheWxvYWQgJiB7XG4gICAgY29udmVyc2F0aW9uSWQ6IHN0cmluZztcbn07XG5cbi8qKiBRdWV1ZS9GaWxlIG1hbmFnZXIgXHU1M0Q4XHU2NkY0XHU0RThCXHU0RUY2XHUzMDAyYHByb2plY3Rpb25VcGRhdGVkYCBcdTUzRUFcdTc1MjhcdTRFOEUgcmVuZGVyZXIgXHU2NzJDXHU1NzMwXHU1MzczXHU2NUY2XHU2Mjk1XHU1RjcxXHUzMDAyICovXG5leHBvcnQgaW50ZXJmYWNlIENvbnZlcnNhdGlvbk1hbmFnZXJVcGRhdGVQYXlsb2FkIHtcbiAgICBjb252ZXJzYXRpb25JZDogc3RyaW5nO1xuICAgIC8qKiBcdTY3MkNcdTU3MzBcdTdGMTNcdTVCNThcdTVERjJcdTUxNDhcdTRFOEVcdTRFOEJcdTRFRjZcdTYzRDBcdTRFQTRcdUZGMUJcdThCQTJcdTk2MDVcdTgwMDVcdTUzRUZcdTdBQ0JcdTUzNzNcdThCRkJcdTUzRDZcdUZGMENcdTUxOERcdTVGMDJcdTZCNjVcdTU0MTEgZGFlbW9uIFx1NzcxRlx1NkU5MFx1NjUzNlx1NjU1Qlx1MzAwMiAqL1xuICAgIHByb2plY3Rpb25VcGRhdGVkPzogYm9vbGVhbjtcbn1cblxuZXhwb3J0IHR5cGUgQ29udmVyc2F0aW9uQ2FwYWNpdHlRdWV1ZVVwZGF0ZVBheWxvYWQgPSBDYXBhY2l0eVF1ZXVlU25hcHNob3QgJiB7XG4gICAgY29udmVyc2F0aW9uSWQ6IHN0cmluZztcbn07XG5cbi8qKlxuICogYFdCX0NPTlZFUlNBVElPTl9MSVNUX0NIQU5HRURgIFx1NzY4NCBwYXlsb2FkXHUzMDAyXG4gKlxuICogYGFkZGVkYCAvIGB1cGRhdGVkYCBcdTVFMjZcdTVCOENcdTY1NzRcdTVGRUJcdTcxNjdcdTRGOUJcdTZEODhcdThEMzlcdTgwMDVcdTUzOUZcdTU3MzBcdTYyNTNcdTg4NjVcdTRFMDFcdUZGMUJgZGVsZXRlZGAgXHU1M0VBXHU2NzA5IGlkXHUzMDAyXG4gKiBcdTUyMTdcdTg4NjhcdTYyQzlcdTUzRDZcdTk2NERcdTdFQTdcdUZGMDhgcGFydGlhbGBcdUZGMDlcdTY1RjYgYGRlbGV0ZWRgIFx1NjA1Mlx1NEUzQVx1N0E3QVx1MjAxNFx1MjAxNFx1N0YzQVx1NUUyRFx1NzY4NFx1Njc2MVx1NzZFRVx1NTNFQVx1NjYyRlx1OEZEOVx1OEY2RVx1NkNBMVx1NjdFNVx1NTIzMFx1RkYwQ1x1NEUwRFx1NEVFM1x1ODg2OFx1ODhBQlx1NTIyMFx1MzAwMlxuICovXG5leHBvcnQgaW50ZXJmYWNlIENvbnZlcnNhdGlvbkxpc3RDaGFuZ2VkUGF5bG9hZCB7XG4gICAgYWRkZWQ6IENvbnZlcnNhdGlvbkluZm9bXTtcbiAgICB1cGRhdGVkOiBDb252ZXJzYXRpb25JbmZvW107XG4gICAgZGVsZXRlZDogc3RyaW5nW107XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgQ29udmVyc2F0aW9uTGlzdFByb2dyZXNzUGF5bG9hZCB7XG4gICAgc3BhY2U6IENvbnZlcnNhdGlvbkxpc3RTY29wZTtcbiAgICBsaXN0OiBXQkxpc3RSZXN1bHQ8Q29udmVyc2F0aW9uSW5mbz47XG4gICAgdHJhY2VJZD86IHN0cmluZztcbn1cblxuZXhwb3J0IGludGVyZmFjZSBDb252ZXJzYXRpb25DaGlsZEFnZW50RXZlbnRQYXlsb2FkIHtcbiAgICBjb252ZXJzYXRpb25JZDogc3RyaW5nO1xuICAgIGV2ZW50OiBDaGlsZEFnZW50UHJvamVjdGlvbkV2ZW50O1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIENoaWxkQWdlbnRSZXF1ZXN0VXBkYXRlQmF0Y2hJdGVtIHtcbiAgICByZXF1ZXN0SWQ6IHN0cmluZztcbiAgICBtZXNzYWdlSWQ6IHN0cmluZztcbiAgICBjaHVuazogdW5rbm93bjtcbn1cblxuZXhwb3J0IGludGVyZmFjZSBDaGlsZEFnZW50UHJvamVjdGlvbkV2ZW50QmF0Y2gge1xuICAgIC8qKiBcdThCRTVcdTYyOTVcdTVGNzFcdTU3MjhcdTVGNTNcdTUyNEQgdHJhbnNwb3J0IFx1N0E5N1x1NTNFM1x1NTE4NVx1NzY4NFx1NjcwMFx1N0VDOFx1NUZFQlx1NzE2N1x1RkYwQ1x1NTNFQVx1OERFOFx1OEZEQlx1N0EwQlx1NEYyMFx1OEY5M1x1NEUwMFx1NkIyMVx1MzAwMiAqL1xuICAgIHNuYXBzaG90OiBDaGlsZEFnZW50U25hcHNob3Q7XG4gICAgLyoqIFx1NjU3MFx1NjM2RVx1NEU4Qlx1NEVGNlx1NEUwRFx1NTQwOFx1NUU3Nlx1RkYwQ1x1Nzg2RVx1NEZERFx1NjI0MFx1NjcwOVx1NTM5Rlx1NTlDQiBjaHVuayBcdTVCOENcdTY1NzRcdTRFMTRcdTY3MDlcdTVFOEZcdTMwMDIgKi9cbiAgICByZXF1ZXN0VXBkYXRlczogQ2hpbGRBZ2VudFJlcXVlc3RVcGRhdGVCYXRjaEl0ZW1bXTtcbiAgICAvKiogXHU3MkI2XHU2MDAxXHU5MDFBXHU3N0U1IGxhdGVzdC13aW5zXHVGRjFCXHU2NzAwXHU3RUM4IHNuYXBzaG90IFx1NURGMlx1NTMwNVx1NTQyQlx1OEJFNVx1N0E5N1x1NTNFM1x1NTE2OFx1OTBFOCBSZXF1ZXN0IFx1NTNEOFx1NTMxNlx1MzAwMiAqL1xuICAgIHJlcXVlc3RzQ2hhbmdlZDogYm9vbGVhbjtcbn1cblxuZXhwb3J0IGludGVyZmFjZSBDb252ZXJzYXRpb25DaGlsZEFnZW50RXZlbnRCYXRjaFBheWxvYWQge1xuICAgIGNvbnZlcnNhdGlvbklkOiBzdHJpbmc7XG4gICAgcHJvamVjdGlvbnM6IENoaWxkQWdlbnRQcm9qZWN0aW9uRXZlbnRCYXRjaFtdO1xufVxuXG4vKiogQ29udmVyc2F0aW9uIEV4dGVuc2lvbk1ldGhvZCBcdTc2ODRcdThERTggSVBDIFx1OEY3RFx1ODM3N1x1RkYxQlx1NEVDNSB0cmFuc3BvcnQgXHU1QzQyXHU5ODlEXHU1OTE2XHU2NDNBXHU1RTI2IGNvbnZlcnNhdGlvbklkXHUzMDAyICovXG5leHBvcnQgdHlwZSBDb252ZXJzYXRpb25FeHRlbnNpb25NZXRob2RFdmVudFBheWxvYWQgPSBDb252ZXJzYXRpb25FeHRlbnNpb25NZXRob2RQYXlsb2FkO1xuXG4vKiogXHU1QjlBXHU1NDExXHU2Mjk1XHU5MDEyXHU1MjMwXHU2MzAxXHU2NzA5IGV4ZWN1dGUgXHU1MUZEXHU2NTcwXHU3Njg0IHJlbmRlcmVyIFx1NzY4NFx1NUJBMlx1NjIzN1x1N0FFRlx1NURFNVx1NTE3N1x1OEMwM1x1NzUyOFx1OEJGN1x1NkM0Mlx1MzAwMiAqL1xuZXhwb3J0IGludGVyZmFjZSBDb252ZXJzYXRpb25DbGllbnRUb29sSW52b2tlUGF5bG9hZCB7XG4gICAgY29udmVyc2F0aW9uSWQ6IHN0cmluZztcbiAgICByZXF1ZXN0SWQ6IHN0cmluZztcbiAgICBwcm92aWRlcklkOiBzdHJpbmc7XG4gICAgdG9vbElkOiBzdHJpbmc7XG4gICAgdG9vbENhbGxJZDogc3RyaW5nO1xuICAgIGlucHV0OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPjtcbiAgICB0aW1lb3V0PzogbnVtYmVyO1xufVxuXG5leHBvcnQgdHlwZSBDb252ZXJzYXRpb25Db21tYW5kc1VwZGF0ZVBheWxvYWQgPSBDb21tYW5kc1VwZGF0ZVBheWxvYWQ7XG5leHBvcnQgdHlwZSBDb252ZXJzYXRpb25Nb2RlQ2hhbmdlUGF5bG9hZCA9IE1vZGVDaGFuZ2VQYXlsb2FkO1xuZXhwb3J0IHR5cGUgQ29udmVyc2F0aW9uQ29uZmlnVXBkYXRlUGF5bG9hZCA9IENvbmZpZ1VwZGF0ZVBheWxvYWQ7XG5cbi8qKlxuICogYENvbmZpZ1VwZGF0ZVBheWxvYWQub3B0aW9uc2AgXHU5MUNDXHU2MjdGXHU4RjdEIFNjZW5lIE1vZGUgXHU3Njg0IGtleVx1MzAwMlxuICpcbiAqIFx1NEUwRFx1ODBGRFx1NkNCRlx1NzUyOCBgJ21vZGUnYFx1RkYxQVx1OTBBM1x1NEUyQSBrZXkgXHU1REYyXHU4OEFCIENMSSBcdTc1MjhcdTY3NjVcdTYzQTggQUNQIFx1Njc0M1x1OTY1MFx1Njg2M1x1RkYwQ1x1NTE3MVx1NzUyOFx1NEYxQVx1OEJBOVx1Njc0M1x1OTY1MFx1NTAzQ1xuICogXHVGRjA4XHU1OTgyIGBieXBhc3NQZXJtaXNzaW9uc2BcdUZGMDlcdTg4QUJcdTUxOTlcdThGREIgYHNlc3Npb24ubW9kZWBcdUZGMENcdTg5RTZcdTUzRDEgdXNlLXdiLW1vZGUtcHJvdmlkZXJcbiAqIFx1N0VBMFx1NkI2M1x1NjIxMCBjcmFmdFx1RkYwQ1x1NjI4QSBxdWljayBcdTRGMUFcdThCRERcdTYyNTNcdTYyMTBcdTVERTVcdTRGNUNcdTZBMjFcdTVGMEZcdUZGMDgjMTAwNjE4XHVGRjA5XHUzMDAyXG4gKiBcdTRFNUZcdTRFMERcdTgwRkRcdTYzMDlcdTUwM0NcdTUzM0FcdTUyMDYgXHUyMDE0XHUyMDE0IGBwbGFuYCAvIGBhc2tgIFx1NTcyOFx1NEUyNFx1NTk1N1x1OEJFRFx1NEU0OVx1OTFDQ1x1NTQwQ1x1NTQwRFx1MzAwMlxuICpcbiAqIFx1NzUxRlx1NEVBN1x1NjVCOSBgQ29udmVyc2F0aW9uQnJpZGdlLmNvbmZpZ1NldEV4cGVydChJZClgXHVGRjBDXHU2RDg4XHU4RDM5XHU2NUI5IHJlbmRlcmVyXG4gKiBgY29udmVyc2F0aW9uLWV2ZW50LWJpbmRpbmdgXHVGRjBDXHU0RTI0XHU0RkE3XHU1NDBDXHU2RTkwXHU1RjE1XHU3NTI4XHU2NzJDXHU1RTM4XHU5MUNGXHUzMDAyXG4gKi9cbmV4cG9ydCBjb25zdCBTQ0VORV9NT0RFX0NPTkZJR19LRVkgPSAnc2NlbmVNb2RlJztcblxuZXhwb3J0IHR5cGUgQ29udmVyc2F0aW9uTW9kZWxDaGFuZ2VQYXlsb2FkID0gTW9kZWxDaGFuZ2VQYXlsb2FkO1xuZXhwb3J0IHR5cGUgQ29udmVyc2F0aW9uVGltZWxpbmVFdmVudEJ1c1BheWxvYWQgPSBDb252ZXJzYXRpb25UaW1lbGluZUV2ZW50UGF5bG9hZDtcbmV4cG9ydCB0eXBlIENvbnZlcnNhdGlvbk1vZGVzVXBkYXRlUGF5bG9hZCA9IE1vZGVzVXBkYXRlUGF5bG9hZDtcbmV4cG9ydCB0eXBlIENvbnZlcnNhdGlvblBsYW5VcGRhdGVQYXlsb2FkID0gUGxhblVwZGF0ZVBheWxvYWQ7XG4iLCAiaW1wb3J0IHtcbiAgICByZXNvbHZlQ29udmVyc2F0aW9uUmVxdWVzdElkLFxuICAgIHdpdGhDb252ZXJzYXRpb25SZXF1ZXN0SWRNZXRhLFxufSBmcm9tICcuLi8uLi9jb252ZXJzYXRpb24tcmVxdWVzdC1pZCc7XG5pbXBvcnQgdHlwZSB7XG4gICAgQXBpRXJyb3IsXG4gICAgQmxvY2ssXG4gICAgQ29udmVyc2F0aW9uLFxuICAgIENvbnZlcnNhdGlvblJlcXVlc3QsXG4gICAgQ29udmVyc2F0aW9uVHVyblJlc3VsdCxcbiAgICBSZXF1ZXN0LFxuICAgIFNlbmRPcHRpb25zLFxufSBmcm9tICcuLi8uLi90eXBlcyc7XG5pbXBvcnQge1xuICAgIENvbnZlcnNhdGlvbkF1dG9tYXRpb25FdmVudCxcbiAgICBDb252ZXJzYXRpb25FdmVudCxcbiAgICB0eXBlIENvbnZlcnNhdGlvbkV2ZW50Q2FsbGJhY2tNYXAsXG59IGZyb20gJy4uL2NvbnZlcnNhdGlvbi1ldmVudC10eXBlcyc7XG5pbXBvcnQgdHlwZSB7IENvbnZlcnNhdGlvblRlcm1pbmFsRXJyb3IgfSBmcm9tICcuLi9jb252ZXJzYXRpb24tdGVybWluYWwtZXJyb3InO1xuaW1wb3J0IHtcbiAgICBDT05WRVJTQVRJT05fU0VTU0lPTl9DT05UUk9MX0tFWSxcbn0gZnJvbSAnLi9jb252ZXJzYXRpb24tc2Vzc2lvbi1jb250cm9sJztcblxuZXhwb3J0IHtcbiAgICBDT05WRVJTQVRJT05fU0VTU0lPTl9DT05UUk9MX0tFWSxcbiAgICByZWFkQ29udmVyc2F0aW9uU2Vzc2lvbkNvbnRyb2wsXG4gICAgdHlwZSBDb252ZXJzYXRpb25TZXNzaW9uQ29udHJvbCxcbn0gZnJvbSAnLi9jb252ZXJzYXRpb24tc2Vzc2lvbi1jb250cm9sJztcblxuLy8gQ29udmVyc2F0aW9uSW1wbCBcdTc2ODRcdThGRDBcdTg4NENcdTY1RjZcdTY1QjlcdTZDRDVcdTc1MzEgYXR0YWNoQ29udmVyc2F0aW9uUHJvbXB0T3BlcmF0aW9ucyBcdTg4QzVcdTkxNERcdUZGMUJcdTU4RjBcdTY2MEVcdTU0MDhcdTVFNzZcdThCQTlcdTdDN0JcdTU5NTFcdTdFQTZcdTRFMEVcdTUxNkNcdTUxNzFcdTYzQTVcdTUzRTNcdTRFMDBcdTgxRjRcdTMwMDJcbmRlY2xhcmUgbW9kdWxlICcuL2NvbnZlcnNhdGlvbi1pbXBsJyB7XG4gICAgaW50ZXJmYWNlIENvbnZlcnNhdGlvbkltcGwge1xuICAgICAgICBydW5Qcm9tcHQocHJvbXB0OiBCbG9ja1tdLCBvcHRpb25zPzogU2VuZE9wdGlvbnMpOiBQcm9taXNlPENvbnZlcnNhdGlvblR1cm5SZXN1bHQ+O1xuICAgICAgICBnZXRSZXF1ZXN0QnlDbGllbnRSZXF1ZXN0SWQoY2xpZW50UmVxdWVzdElkOiBzdHJpbmcpOiBDb252ZXJzYXRpb25SZXF1ZXN0IHwgdW5kZWZpbmVkO1xuICAgICAgICBjbGVhcigpOiBQcm9taXNlPHZvaWQgfCBBcGlFcnJvcj47XG4gICAgICAgIGNvbXBhY3QoKTogUHJvbWlzZTx2b2lkIHwgQXBpRXJyb3I+O1xuICAgIH1cbn1cblxudHlwZSBQcm9tcHRDYXBhYmxlQ29udmVyc2F0aW9uID0gT21pdDxDb252ZXJzYXRpb24sXG4gICAgJ3J1blByb21wdCcgfCAnZ2V0UmVxdWVzdEJ5Q2xpZW50UmVxdWVzdElkJyB8ICdjbGVhcicgfCAnY29tcGFjdCc+XG4gICAgJiBQYXJ0aWFsPFBpY2s8Q29udmVyc2F0aW9uLCAncnVuUHJvbXB0JyB8ICdnZXRSZXF1ZXN0QnlDbGllbnRSZXF1ZXN0SWQnIHwgJ2NsZWFyJyB8ICdjb21wYWN0Jz4+O1xuXG5pbnRlcmZhY2UgUGVuZGluZ0NsaWVudFJlcXVlc3Qge1xuICAgIGNsaWVudFJlcXVlc3RJZDogc3RyaW5nO1xuICAgIHJlcXVlc3RJZDogc3RyaW5nO1xuICAgIGNsaWVudFRpbWVzdGFtcD86IG51bWJlcjtcbiAgICBiYXNlbGluZUlkczogUmVhZG9ubHlTZXQ8c3RyaW5nPjtcbiAgICBwcm9tcHRLZXk6IHN0cmluZztcbiAgICBtYXRjaEJ5UmVxdWVzdElkT25seTogYm9vbGVhbjtcbn1cblxudHlwZSBBdXRvbWF0aW9uVGVybWluYWxFdmVudCA9IHR5cGVvZiBDb252ZXJzYXRpb25BdXRvbWF0aW9uRXZlbnRba2V5b2YgdHlwZW9mIENvbnZlcnNhdGlvbkF1dG9tYXRpb25FdmVudF07XG50eXBlIEF1dG9tYXRpb25UZXJtaW5hbEhhbmRsZXIgPSAocmVzdWx0OiBDb252ZXJzYXRpb25UdXJuUmVzdWx0KSA9PiB2b2lkO1xuXG5pbnRlcmZhY2UgUHJvbXB0T3BlcmF0aW9uU3RhdGUge1xuICAgIHRhaWw6IFByb21pc2U8dm9pZD47XG4gICAgcmVxdWVzdEJ5Q2xpZW50UmVxdWVzdElkOiBNYXA8c3RyaW5nLCB7IHJlcXVlc3RJZDogc3RyaW5nOyBjbGllbnRUaW1lc3RhbXA/OiBudW1iZXIgfT47XG4gICAgaW5GbGlnaHRCeUNsaWVudFJlcXVlc3RJZDogTWFwPHN0cmluZywgUHJvbWlzZTxDb252ZXJzYXRpb25UdXJuUmVzdWx0Pj47XG4gICAgcGVuZGluZzogUGVuZGluZ0NsaWVudFJlcXVlc3RbXTtcbiAgICBzZXF1ZW5jZTogbnVtYmVyO1xuICAgIGF1dG9tYXRpb25IYW5kbGVyczogTWFwPEF1dG9tYXRpb25UZXJtaW5hbEV2ZW50LCBTZXQ8QXV0b21hdGlvblRlcm1pbmFsSGFuZGxlcj4+O1xuICAgIHNldHRsZWRBdXRvbWF0aW9uUmVxdWVzdHM6IFNldDxzdHJpbmc+O1xuICAgIHRpbWVvdXRCeUNsaWVudFJlcXVlc3RJZDogTWFwPHN0cmluZywgUmV0dXJuVHlwZTx0eXBlb2Ygc2V0VGltZW91dD4+O1xuICAgIHRpbWVkT3V0Q2xpZW50UmVxdWVzdElkczogU2V0PHN0cmluZz47XG4gICAgcGVuZGluZ1Rlcm1pbmFsRXJyb3I/OiBDb252ZXJzYXRpb25UZXJtaW5hbEVycm9yO1xufVxuXG5jb25zdCBBVFRBQ0hFRF9DT05WRVJTQVRJT05TID0gbmV3IFdlYWtTZXQ8b2JqZWN0PigpO1xuY29uc3QgQVVUT01BVElPTl9URVJNSU5BTF9FVkVOVFMgPSBuZXcgU2V0PENvbnZlcnNhdGlvbkV2ZW50PihPYmplY3QudmFsdWVzKENvbnZlcnNhdGlvbkF1dG9tYXRpb25FdmVudCkpO1xuY29uc3QgVEVSTUlOQUxfUkVRVUVTVF9TVEFURVMgPSBuZXcgU2V0PFJlcXVlc3RbJ3N0YXRlJ10+KFsnY29tcGxldGVkJywgJ2NhbmNlbGxlZCcsICdlcnJvciddKTtcblxuZnVuY3Rpb24gaXNBcGlFcnJvcih2YWx1ZTogdW5rbm93bik6IHZhbHVlIGlzIEFwaUVycm9yIHtcbiAgICByZXR1cm4gQm9vbGVhbih2YWx1ZSlcbiAgICAgICAgJiYgdHlwZW9mIHZhbHVlID09PSAnb2JqZWN0J1xuICAgICAgICAmJiB0eXBlb2YgKHZhbHVlIGFzIEFwaUVycm9yKS5lcnJvckNvZGUgPT09ICdzdHJpbmcnO1xufVxuXG5mdW5jdGlvbiBjb250ZW50S2V5KGNvbnRlbnQ6IHJlYWRvbmx5IEJsb2NrW10pOiBzdHJpbmcge1xuICAgIHRyeSB7XG4gICAgICAgIHJldHVybiBKU09OLnN0cmluZ2lmeShjb250ZW50KTtcbiAgICB9IGNhdGNoIHtcbiAgICAgICAgcmV0dXJuIGNvbnRlbnQubWFwKGJsb2NrID0+IGAke2Jsb2NrLnR5cGV9OiR7YmxvY2sudGV4dCA/PyAnJ31gKS5qb2luKCdcXG4nKTtcbiAgICB9XG59XG5cbmZ1bmN0aW9uIGZpbmRSZXF1ZXN0QnlJZChcbiAgICByZXF1ZXN0czogcmVhZG9ubHkgUmVxdWVzdFtdLFxuICAgIHJlcXVlc3RJZDogc3RyaW5nLFxuKTogUmVxdWVzdCB8IHVuZGVmaW5lZCB7XG4gICAgcmV0dXJuIHJlcXVlc3RzLmZpbmQocmVxdWVzdCA9PiByZXF1ZXN0LmlkID09PSByZXF1ZXN0SWQpO1xufVxuXG5mdW5jdGlvbiB0b1R1cm5SZXN1bHQoXG4gICAgcmVxdWVzdDogUmVxdWVzdCxcbiAgICBjbGllbnRSZXF1ZXN0SWQ6IHN0cmluZyxcbiAgICB0ZXJtaW5hbEVycm9yPzogQ29udmVyc2F0aW9uVGVybWluYWxFcnJvcixcbik6IENvbnZlcnNhdGlvblR1cm5SZXN1bHQge1xuICAgIHJldHVybiB7XG4gICAgICAgIGNsaWVudFJlcXVlc3RJZCxcbiAgICAgICAgcmVxdWVzdElkOiByZXF1ZXN0LmlkLFxuICAgICAgICBzdGF0ZTogcmVxdWVzdC5zdGF0ZSxcbiAgICAgICAgY29udGVudDogcmVxdWVzdC5hc3Npc3RhbnRNZXNzYWdlPy5jb250ZW50ID8/IFtdLFxuICAgICAgICAvLyBSZXF1ZXN0IFx1NTNFRlx1ODBGRFx1NjYyRlx1OERFOCBJUEMgXHU3Njg0IEpTT04gXHU1RkVCXHU3MTY3XHVGRjBDXHU0RTBEXHU0RkREXHU4QkMxXHU2NDNBXHU1RTI2XHU1QkNDXHU1QkY5XHU4QzYxXHU2NUI5XHU2Q0Q1XHUzMDAyXG4gICAgICAgIC8vIFx1NEUxNCBSZXF1ZXN0LmdldEFydGlmYWN0cyBcdTRFMERcdTY2MkZcdTRFQTdcdTcyNjlcdTc3MUZcdTZFOTBcdUZGMUJcdTc3MUZcdTZFOTBcdTY2MkYgY29udi5hcnRpZmFjdHMoKVx1MzAwMlxuICAgICAgICBhcnRpZmFjdHM6IFtdLFxuICAgICAgICByZXF1ZXN0ZWRNb2RlbDogcmVxdWVzdC5yZXF1ZXN0ZWRNb2RlbCxcbiAgICAgICAgcmVzcG9uc2VNb2RlbDogcmVxdWVzdC5yZXNwb25zZU1vZGVsLFxuICAgICAgICAuLi4ocmVxdWVzdC5zdGF0ZSA9PT0gJ2Vycm9yJyAmJiB0ZXJtaW5hbEVycm9yID8geyB0ZXJtaW5hbEVycm9yIH0gOiB7fSksXG4gICAgfTtcbn1cblxuLyoqXG4gKiBcdTdFRDkgQ29udmVyc2F0aW9uIFx1NUJDQ1x1NUJGOVx1OEM2MVx1NjMwMlx1OEY3RFx1MjAxQ1x1NjNEMFx1NEVBNFx1NUU3Nlx1N0I0OVx1NUY4NVx1ODFFQVx1NURGMVx1N0VDOFx1NjAwMVx1MjAxRFx1NzY4NFx1NEUxQVx1NTJBMVx1NjRDRFx1NEY1Q1x1MzAwMlxuICpcbiAqIFx1NUU5NVx1NUM0MiBzZW5kUHJvbXB0IFx1NEZERFx1NjMwMSBmaXJlLWFuZC1mb3JnZXQgXHU1OTUxXHU3RUE2XHVGRjFCXHU2NzJDXHU1MzRGXHU4QzAzXHU1NjY4XHU0RUM1XHU1NzI4XHU4QzAzXHU3NTI4XHU2NUI5XHU2NjBFXHU3ODZFXHU0RjdGXHU3NTI4IHJ1blByb21wdCBcdTY1RjZcdTRFMzJcdTg4NENcdTdCNDlcdTVGODVcbiAqIFJlcXVlc3RzQ2hhbmdlZFx1RkYwQ1x1NUU3Nlx1N0VGNFx1NjJBNCBjbGllbnRSZXF1ZXN0SWQgXHUyMTkyIHJlcXVlc3RJZCBcdTY2MjBcdTVDMDRcdUZGMENcdTRFMERcdTY1MzlcdTUzRDggVUkgXHU1QjlFXHU2NUY2XHU0RThCXHU0RUY2XHU2RDg4XHU4RDM5XHU2NUI5XHU1RjBGXHUzMDAyXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBhdHRhY2hDb252ZXJzYXRpb25Qcm9tcHRPcGVyYXRpb25zPFQgZXh0ZW5kcyBQcm9tcHRDYXBhYmxlQ29udmVyc2F0aW9uPihjb252ZXJzYXRpb246IFQpOiBUICYgQ29udmVyc2F0aW9uIHtcbiAgICBpZiAoQVRUQUNIRURfQ09OVkVSU0FUSU9OUy5oYXMoY29udmVyc2F0aW9uKSkge1xuICAgICAgICByZXR1cm4gY29udmVyc2F0aW9uIGFzIFQgJiBDb252ZXJzYXRpb247XG4gICAgfVxuICAgIGNvbnN0IGhhc1Byb21wdE9wZXJhdGlvbnMgPSBCb29sZWFuKFxuICAgICAgICBjb252ZXJzYXRpb24ucnVuUHJvbXB0XG4gICAgICAgICYmIGNvbnZlcnNhdGlvbi5nZXRSZXF1ZXN0QnlDbGllbnRSZXF1ZXN0SWRcbiAgICAgICAgJiYgY29udmVyc2F0aW9uLmNsZWFyXG4gICAgICAgICYmIGNvbnZlcnNhdGlvbi5jb21wYWN0LFxuICAgICk7XG4gICAgY29uc3Qgc3RhdGU6IFByb21wdE9wZXJhdGlvblN0YXRlID0ge1xuICAgICAgICB0YWlsOiBQcm9taXNlLnJlc29sdmUoKSxcbiAgICAgICAgcmVxdWVzdEJ5Q2xpZW50UmVxdWVzdElkOiBuZXcgTWFwKCksXG4gICAgICAgIGluRmxpZ2h0QnlDbGllbnRSZXF1ZXN0SWQ6IG5ldyBNYXAoKSxcbiAgICAgICAgcGVuZGluZzogW10sXG4gICAgICAgIHNlcXVlbmNlOiAwLFxuICAgICAgICBhdXRvbWF0aW9uSGFuZGxlcnM6IG5ldyBNYXAoKSxcbiAgICAgICAgc2V0dGxlZEF1dG9tYXRpb25SZXF1ZXN0czogbmV3IFNldCgpLFxuICAgICAgICB0aW1lb3V0QnlDbGllbnRSZXF1ZXN0SWQ6IG5ldyBNYXAoKSxcbiAgICAgICAgdGltZWRPdXRDbGllbnRSZXF1ZXN0SWRzOiBuZXcgU2V0KCksXG4gICAgfTtcbiAgICBjb25zdCBvcmlnaW5hbE9uID0gY29udmVyc2F0aW9uLm9uLmJpbmQoY29udmVyc2F0aW9uKTtcbiAgICBjb25zdCBvcmlnaW5hbFNlbmRQcm9tcHQgPSBjb252ZXJzYXRpb24uc2VuZFByb21wdC5iaW5kKGNvbnZlcnNhdGlvbik7XG4gICAgY29uc3Qgb3JpZ2luYWxSZXF1ZXN0cyA9IGNvbnZlcnNhdGlvbi5yZXF1ZXN0cy5iaW5kKGNvbnZlcnNhdGlvbik7XG4gICAgY29uc3Qgb3JpZ2luYWxHZXRSZXF1ZXN0ID0gY29udmVyc2F0aW9uLmdldFJlcXVlc3QuYmluZChjb252ZXJzYXRpb24pO1xuICAgIC8vIGNsaWVudFJlcXVlc3RJZCBcdTVCRjlcdThEMjZcdTUzRUFcdTk3MDBcdTg5ODFcdTVGNTNcdTUyNEQgUmVxdWVzdFN0b3JlIFx1NURGMlx1NzI2OVx1NTMxNlx1NzY4NFx1NTE2OFx1OTFDRlx1NUZFQlx1NzE2N1x1MzAwMnF1ZXJ5IFx1NUY2Mlx1NjAwMVx1NEYxQVx1OEJGQlx1NTNENlxuICAgIC8vIGFsbC1sb2FkZWQgU3RvcmVcdUZGMENcdTVFNzZcdTYyOEFcdTVDMUFcdTY3MkFcdTVDMzFcdTdFRUFcdTc2ODRcdTc2RjRcdTYzQTVcdTUzODZcdTUzRjJcdTk2NTBcdTUyMzZcdTU3MjhcdTlFRDhcdThCQTRcdTVCNTdcdTgyODJcdTk4NzVcdUZGMUJcdTY1RTcgb2Zmc2V0IFx1NUY2Mlx1NjAwMVx1NEYyMCBNQVhfU0FGRV9JTlRFR0VSXG4gICAgLy8gXHU0RjFBXHU5QTcxXHU1MkE4IEhpc3RvcnlMb2FkZXIgXHU2MzA5XHU2NzYxXHU2NTcwXHU4ODY1XHU5RjUwXHU1MTY4XHU5MEU4XHU2MzAxXHU0RTQ1XHU1MzE2XHU1Mzg2XHU1M0YyXHVGRjBDXHU2NUUyXHU2NTNFXHU1OTI3IEkvT1x1RkYwQ1x1NEU1Rlx1NTNFRlx1ODBGRFx1OEQ4QVx1OEZDNyB1c2VyIGh5ZHJhdGlvbiBcdTk4NzVcdTk4ODRcdTdCOTdcdTMwMDJcbiAgICBjb25zdCByZWFkTG9hZGVkUmVxdWVzdHMgPSAoKSA9PiBvcmlnaW5hbFJlcXVlc3RzKG51bGwpO1xuICAgIGNvbnN0IG1hcFBlbmRpbmdSZXF1ZXN0cyA9IChyZXF1ZXN0czogcmVhZG9ubHkgUmVxdWVzdFtdKTogdm9pZCA9PiB7XG4gICAgICAgIGNvbnN0IGNsYWltZWRSZXF1ZXN0SWRzID0gbmV3IFNldChcbiAgICAgICAgICAgIFsuLi5zdGF0ZS5yZXF1ZXN0QnlDbGllbnRSZXF1ZXN0SWQudmFsdWVzKCldLm1hcChpdGVtID0+IGl0ZW0ucmVxdWVzdElkKSxcbiAgICAgICAgKTtcbiAgICAgICAgZm9yIChjb25zdCBwZW5kaW5nIG9mIFsuLi5zdGF0ZS5wZW5kaW5nXSkge1xuICAgICAgICAgICAgY29uc3QgY2FuZGlkYXRlcyA9IHJlcXVlc3RzLmZpbHRlcihjYW5kaWRhdGUgPT5cbiAgICAgICAgICAgICAgICAhcGVuZGluZy5iYXNlbGluZUlkcy5oYXMoY2FuZGlkYXRlLmlkKSAmJiAhY2xhaW1lZFJlcXVlc3RJZHMuaGFzKGNhbmRpZGF0ZS5pZCkpO1xuICAgICAgICAgICAgY29uc3QgZXhhY3RSZXF1ZXN0ID0gZmluZFJlcXVlc3RCeUlkKGNhbmRpZGF0ZXMsIHBlbmRpbmcucmVxdWVzdElkKTtcbiAgICAgICAgICAgIGNvbnN0IHJlcXVlc3QgPSBleGFjdFJlcXVlc3QgPz8gKHBlbmRpbmcubWF0Y2hCeVJlcXVlc3RJZE9ubHlcbiAgICAgICAgICAgICAgICA/IHVuZGVmaW5lZFxuICAgICAgICAgICAgICAgIDogY2FuZGlkYXRlcy5maW5kKGNhbmRpZGF0ZSA9PlxuICAgICAgICAgICAgICAgICAgICBjb250ZW50S2V5KGNhbmRpZGF0ZS51c2VyTWVzc2FnZS5jb250ZW50KSA9PT0gcGVuZGluZy5wcm9tcHRLZXkpXG4gICAgICAgICAgICAgICAgPz8gKGNhbmRpZGF0ZXMubGVuZ3RoID09PSAxID8gY2FuZGlkYXRlc1swXSA6IHVuZGVmaW5lZCkpO1xuICAgICAgICAgICAgaWYgKCFyZXF1ZXN0KSB7IGNvbnRpbnVlOyB9XG4gICAgICAgICAgICBjbGFpbWVkUmVxdWVzdElkcy5hZGQocmVxdWVzdC5pZCk7XG4gICAgICAgICAgICBzdGF0ZS5yZXF1ZXN0QnlDbGllbnRSZXF1ZXN0SWQuc2V0KHBlbmRpbmcuY2xpZW50UmVxdWVzdElkLCB7XG4gICAgICAgICAgICAgICAgcmVxdWVzdElkOiByZXF1ZXN0LmlkLFxuICAgICAgICAgICAgICAgIGNsaWVudFRpbWVzdGFtcDogcGVuZGluZy5jbGllbnRUaW1lc3RhbXAsXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIHN0YXRlLnBlbmRpbmcuc3BsaWNlKHN0YXRlLnBlbmRpbmcuaW5kZXhPZihwZW5kaW5nKSwgMSk7XG4gICAgICAgIH1cbiAgICB9O1xuICAgIGNvbnN0IGVtaXRBdXRvbWF0aW9uVGVybWluYWwgPSAoXG4gICAgICAgIGV2ZW50OiBBdXRvbWF0aW9uVGVybWluYWxFdmVudCxcbiAgICAgICAgcmVzdWx0OiBDb252ZXJzYXRpb25UdXJuUmVzdWx0LFxuICAgICk6IHZvaWQgPT4ge1xuICAgICAgICBmb3IgKGNvbnN0IGhhbmRsZXIgb2Ygc3RhdGUuYXV0b21hdGlvbkhhbmRsZXJzLmdldChldmVudCkgPz8gW10pIHtcbiAgICAgICAgICAgIHRyeSB7IGhhbmRsZXIocmVzdWx0KTsgfSBjYXRjaCB7IC8qIGlzb2xhdGUgY29uc3VtZXIgKi8gfVxuICAgICAgICB9XG4gICAgfTtcbiAgICBjb25zdCBzZXR0bGVBdXRvbWF0aW9uUmVxdWVzdHMgPSAocmVxdWVzdHM6IHJlYWRvbmx5IFJlcXVlc3RbXSk6IHZvaWQgPT4ge1xuICAgICAgICBmb3IgKGNvbnN0IFtjbGllbnRSZXF1ZXN0SWQsIG1hcHBlZF0gb2Ygc3RhdGUucmVxdWVzdEJ5Q2xpZW50UmVxdWVzdElkKSB7XG4gICAgICAgICAgICBjb25zdCByZXF1ZXN0ID0gcmVxdWVzdHMuZmluZChjYW5kaWRhdGUgPT4gY2FuZGlkYXRlLmlkID09PSBtYXBwZWQucmVxdWVzdElkKTtcbiAgICAgICAgICAgIGlmICghcmVxdWVzdCB8fCAhVEVSTUlOQUxfUkVRVUVTVF9TVEFURVMuaGFzKHJlcXVlc3Quc3RhdGUpKSB7IGNvbnRpbnVlOyB9XG4gICAgICAgICAgICBpZiAoc3RhdGUuc2V0dGxlZEF1dG9tYXRpb25SZXF1ZXN0cy5oYXMocmVxdWVzdC5pZCkpIHsgY29udGludWU7IH1cbiAgICAgICAgICAgIHN0YXRlLnNldHRsZWRBdXRvbWF0aW9uUmVxdWVzdHMuYWRkKHJlcXVlc3QuaWQpO1xuICAgICAgICAgICAgY29uc3QgdGltZXIgPSBzdGF0ZS50aW1lb3V0QnlDbGllbnRSZXF1ZXN0SWQuZ2V0KGNsaWVudFJlcXVlc3RJZCk7XG4gICAgICAgICAgICBpZiAodGltZXIpIHtcbiAgICAgICAgICAgICAgICBjbGVhclRpbWVvdXQodGltZXIpO1xuICAgICAgICAgICAgICAgIHN0YXRlLnRpbWVvdXRCeUNsaWVudFJlcXVlc3RJZC5kZWxldGUoY2xpZW50UmVxdWVzdElkKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNvbnN0IHRlcm1pbmFsRXJyb3IgPSBzdGF0ZS5wZW5kaW5nVGVybWluYWxFcnJvcjtcbiAgICAgICAgICAgIHN0YXRlLnBlbmRpbmdUZXJtaW5hbEVycm9yID0gdW5kZWZpbmVkO1xuICAgICAgICAgICAgY29uc3QgcmVzdWx0ID0gdG9UdXJuUmVzdWx0KHJlcXVlc3QsIGNsaWVudFJlcXVlc3RJZCwgdGVybWluYWxFcnJvcik7XG4gICAgICAgICAgICBpZiAoc3RhdGUudGltZWRPdXRDbGllbnRSZXF1ZXN0SWRzLmRlbGV0ZShjbGllbnRSZXF1ZXN0SWQpKSB7XG4gICAgICAgICAgICAgICAgZW1pdEF1dG9tYXRpb25UZXJtaW5hbChDb252ZXJzYXRpb25BdXRvbWF0aW9uRXZlbnQuVGltZWRPdXQsIHtcbiAgICAgICAgICAgICAgICAgICAgLi4ucmVzdWx0LFxuICAgICAgICAgICAgICAgICAgICBzdGF0ZTogJ2NhbmNlbGxlZCcsXG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9IGVsc2UgaWYgKHJlcXVlc3Quc3RhdGUgPT09ICdjb21wbGV0ZWQnKSB7XG4gICAgICAgICAgICAgICAgZW1pdEF1dG9tYXRpb25UZXJtaW5hbChDb252ZXJzYXRpb25BdXRvbWF0aW9uRXZlbnQuQ29tcGxldGVkLCByZXN1bHQpO1xuICAgICAgICAgICAgfSBlbHNlIGlmIChyZXF1ZXN0LnN0YXRlID09PSAnY2FuY2VsbGVkJykge1xuICAgICAgICAgICAgICAgIGVtaXRBdXRvbWF0aW9uVGVybWluYWwoQ29udmVyc2F0aW9uQXV0b21hdGlvbkV2ZW50LkNhbmNlbGxlZCwgcmVzdWx0KTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgZW1pdEF1dG9tYXRpb25UZXJtaW5hbChDb252ZXJzYXRpb25BdXRvbWF0aW9uRXZlbnQuRmFpbGVkLCByZXN1bHQpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfTtcbiAgICBjb25zdCBoYW5kbGVSZXF1ZXN0c0NoYW5nZWQgPSAocmVxdWVzdHM6IHJlYWRvbmx5IFJlcXVlc3RbXSk6IHZvaWQgPT4ge1xuICAgICAgICBtYXBQZW5kaW5nUmVxdWVzdHMocmVxdWVzdHMpO1xuICAgICAgICBzZXR0bGVBdXRvbWF0aW9uUmVxdWVzdHMocmVxdWVzdHMpO1xuICAgICAgICAvLyBTdGF0ZUNoYW5nZSBcdTU0OEMgUmVxdWVzdHNDaGFuZ2VkIFx1NjYyRlx1NTQwQ1x1NEUwMFx1N0VDOFx1NjAwMVx1NzY4NFx1NzZGOFx1OTBCQlx1NEU4Qlx1NEVGNlx1RkYxQlx1NjcyQVx1ODhBQlx1ODFFQVx1NTJBOFx1NTMxNiBSZXF1ZXN0IFx1NkQ4OFx1OEQzOVx1NjVGNlx1NEU1Rlx1NEUwRFx1ODBGRFx1NkNDNFx1NkYwRlx1NTIzMFx1NEUwQlx1NEUwMFx1OEY2RVx1MzAwMlxuICAgICAgICBzdGF0ZS5wZW5kaW5nVGVybWluYWxFcnJvciA9IHVuZGVmaW5lZDtcbiAgICB9O1xuICAgIGNvbnZlcnNhdGlvbi5vbiA9ICgoZXZlbnQ6IENvbnZlcnNhdGlvbkV2ZW50LCBjYWxsYmFjazogQ29udmVyc2F0aW9uRXZlbnRDYWxsYmFja01hcFtDb252ZXJzYXRpb25FdmVudF0pID0+IHtcbiAgICAgICAgaWYgKEFVVE9NQVRJT05fVEVSTUlOQUxfRVZFTlRTLmhhcyhldmVudCkpIHtcbiAgICAgICAgICAgIGNvbnN0IGhhbmRsZXJzID0gc3RhdGUuYXV0b21hdGlvbkhhbmRsZXJzLmdldChldmVudCBhcyBBdXRvbWF0aW9uVGVybWluYWxFdmVudCkgPz8gbmV3IFNldCgpO1xuICAgICAgICAgICAgY29uc3QgaGFuZGxlciA9IGNhbGxiYWNrIGFzIEF1dG9tYXRpb25UZXJtaW5hbEhhbmRsZXI7XG4gICAgICAgICAgICBoYW5kbGVycy5hZGQoaGFuZGxlcik7XG4gICAgICAgICAgICBzdGF0ZS5hdXRvbWF0aW9uSGFuZGxlcnMuc2V0KGV2ZW50IGFzIEF1dG9tYXRpb25UZXJtaW5hbEV2ZW50LCBoYW5kbGVycyk7XG4gICAgICAgICAgICByZXR1cm4gKCkgPT4geyBoYW5kbGVycy5kZWxldGUoaGFuZGxlcik7IH07XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIG9yaWdpbmFsT24oZXZlbnQsIGNhbGxiYWNrKTtcbiAgICB9KSBhcyBDb252ZXJzYXRpb25bJ29uJ107XG5cbiAgICBjb25zdCBlbnJpY2hSZXF1ZXN0ID0gPFQgZXh0ZW5kcyBSZXF1ZXN0PihyZXF1ZXN0OiBUKTogVCA9PiB7XG4gICAgICAgIGNvbnN0IG1hcHBlZCA9IFsuLi5zdGF0ZS5yZXF1ZXN0QnlDbGllbnRSZXF1ZXN0SWRdLmZpbmQoKFssIHZhbHVlXSkgPT4gdmFsdWUucmVxdWVzdElkID09PSByZXF1ZXN0LmlkKTtcbiAgICAgICAgaWYgKCFtYXBwZWQpIHsgcmV0dXJuIHJlcXVlc3Q7IH1cbiAgICAgICAgY29uc3QgW2NsaWVudFJlcXVlc3RJZCwgdmFsdWVdID0gbWFwcGVkO1xuICAgICAgICByZXR1cm4gT2JqZWN0LmZyZWV6ZSh7XG4gICAgICAgICAgICAuLi5yZXF1ZXN0LFxuICAgICAgICAgICAgY2xpZW50UmVxdWVzdElkLFxuICAgICAgICAgICAgdGltZXN0YW1wOiB2YWx1ZS5jbGllbnRUaW1lc3RhbXAgPz8gcmVxdWVzdC50aW1lc3RhbXAsXG4gICAgICAgIH0pIGFzIFQ7XG4gICAgfTtcbiAgICBjb25zdCBvcGVyYXRpb25VbnN1YnMgPSBbXG4gICAgICAgIG9yaWdpbmFsT24oQ29udmVyc2F0aW9uRXZlbnQuU3RhdGVDaGFuZ2UsIChfZnJvbSwgX3RvLCBmaW5hbFN0YXRlLCB0ZXJtaW5hbEVycm9yKSA9PiB7XG4gICAgICAgICAgICBpZiAoZmluYWxTdGF0ZSAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICAgICAgc3RhdGUucGVuZGluZ1Rlcm1pbmFsRXJyb3IgPSB0ZXJtaW5hbEVycm9yO1xuICAgICAgICAgICAgfVxuICAgICAgICB9KSxcbiAgICAgICAgb3JpZ2luYWxPbihDb252ZXJzYXRpb25FdmVudC5SZXF1ZXN0c0NoYW5nZWQsIGhhbmRsZVJlcXVlc3RzQ2hhbmdlZCksXG4gICAgXTtcbiAgICBjb25zdCBkaXNwb3NhYmxlID0gY29udmVyc2F0aW9uIGFzIFQgJiB7IGRpc3Bvc2VJbnRlcm5hbD86ICgpID0+IHZvaWQgfTtcbiAgICBpZiAodHlwZW9mIGRpc3Bvc2FibGUuZGlzcG9zZUludGVybmFsID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICAgIGNvbnN0IG9yaWdpbmFsRGlzcG9zZUludGVybmFsID0gZGlzcG9zYWJsZS5kaXNwb3NlSW50ZXJuYWwuYmluZChkaXNwb3NhYmxlKTtcbiAgICAgICAgbGV0IGRpc3Bvc2VkID0gZmFsc2U7XG4gICAgICAgIGRpc3Bvc2FibGUuZGlzcG9zZUludGVybmFsID0gKCkgPT4ge1xuICAgICAgICAgICAgaWYgKGRpc3Bvc2VkKSB7IHJldHVybjsgfVxuICAgICAgICAgICAgZGlzcG9zZWQgPSB0cnVlO1xuICAgICAgICAgICAgZm9yIChjb25zdCB1bnN1YnNjcmliZSBvZiBvcGVyYXRpb25VbnN1YnMpIHsgdW5zdWJzY3JpYmUoKTsgfVxuICAgICAgICAgICAgb3JpZ2luYWxEaXNwb3NlSW50ZXJuYWwoKTtcbiAgICAgICAgfTtcbiAgICB9XG4gICAgY29udmVyc2F0aW9uLnJlcXVlc3RzID0gYXN5bmMgKC4uLmFyZ3MpID0+IHtcbiAgICAgICAgY29uc3QgcGFnZSA9IGF3YWl0IG9yaWdpbmFsUmVxdWVzdHMoLi4uYXJncyk7XG4gICAgICAgIGhhbmRsZVJlcXVlc3RzQ2hhbmdlZChwYWdlLml0ZW1zKTtcbiAgICAgICAgcmV0dXJuIHsgLi4ucGFnZSwgaXRlbXM6IHBhZ2UuaXRlbXMubWFwKGVucmljaFJlcXVlc3QpIH07XG4gICAgfTtcbiAgICBjb252ZXJzYXRpb24uZ2V0UmVxdWVzdCA9IHJlcXVlc3RJZCA9PiB7XG4gICAgICAgIGNvbnN0IHJlcXVlc3QgPSBvcmlnaW5hbEdldFJlcXVlc3QocmVxdWVzdElkKTtcbiAgICAgICAgcmV0dXJuIHJlcXVlc3QgPyBlbnJpY2hSZXF1ZXN0KHJlcXVlc3QpIDogdW5kZWZpbmVkO1xuICAgIH07XG4gICAgY29uc3Qgc2VuZFRyYWNrZWQgPSBhc3luYyAocHJvbXB0OiBCbG9ja1tdLCBvcHRpb25zOiBTZW5kT3B0aW9ucyA9IHt9KSA9PiB7XG4gICAgICAgIGNvbnN0IGNsaWVudFJlcXVlc3RJZCA9IG9wdGlvbnMuY2xpZW50UmVxdWVzdElkO1xuICAgICAgICBpZiAoIWNsaWVudFJlcXVlc3RJZCkgeyByZXR1cm4gb3JpZ2luYWxTZW5kUHJvbXB0KHByb21wdCwgb3B0aW9ucyk7IH1cbiAgICAgICAgaWYgKG9wdGlvbnMudGltZW91dE1zICE9PSB1bmRlZmluZWRcbiAgICAgICAgICAgICYmICghTnVtYmVyLmlzRmluaXRlKG9wdGlvbnMudGltZW91dE1zKSB8fCBvcHRpb25zLnRpbWVvdXRNcyA8PSAwIHx8IG9wdGlvbnMudGltZW91dE1zID4gODZfNDAwXzAwMCkpIHtcbiAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgZXJyb3JDb2RlOiAnQVVUT01BVElPTl9USU1FT1VUX0lOVkFMSUQnLFxuICAgICAgICAgICAgICAgIG1lc3NhZ2U6ICd0aW1lb3V0TXMgbXVzdCBiZSBiZXR3ZWVuIDEgYW5kIDg2NDAwMDAwIG1pbGxpc2Vjb25kcycsXG4gICAgICAgICAgICB9IHNhdGlzZmllcyBBcGlFcnJvcjtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCByZXF1ZXN0SWQgPSByZXNvbHZlQ29udmVyc2F0aW9uUmVxdWVzdElkKG9wdGlvbnMuX21ldGEpO1xuICAgICAgICBjb25zdCB0cmFja2VkT3B0aW9uczogU2VuZE9wdGlvbnMgPSB7XG4gICAgICAgICAgICAuLi5vcHRpb25zLFxuICAgICAgICAgICAgX21ldGE6IHdpdGhDb252ZXJzYXRpb25SZXF1ZXN0SWRNZXRhKG9wdGlvbnMuX21ldGEsIHJlcXVlc3RJZCksXG4gICAgICAgIH07XG4gICAgICAgIGNvbnN0IGJhc2VsaW5lID0gYXdhaXQgcmVhZExvYWRlZFJlcXVlc3RzKCk7XG4gICAgICAgIGNvbnN0IHBlbmRpbmc6IFBlbmRpbmdDbGllbnRSZXF1ZXN0ID0ge1xuICAgICAgICAgICAgY2xpZW50UmVxdWVzdElkLFxuICAgICAgICAgICAgcmVxdWVzdElkLFxuICAgICAgICAgICAgY2xpZW50VGltZXN0YW1wOiBvcHRpb25zLmNsaWVudFRpbWVzdGFtcCxcbiAgICAgICAgICAgIGJhc2VsaW5lSWRzOiBuZXcgU2V0KGJhc2VsaW5lLml0ZW1zLm1hcChyZXF1ZXN0ID0+IHJlcXVlc3QuaWQpKSxcbiAgICAgICAgICAgIHByb21wdEtleTogY29udGVudEtleShwcm9tcHQpLFxuICAgICAgICAgICAgLy8gXHU2NjNFXHU1RjBGIGNvbnZlcnNhdGlvblJlcXVlc3RJZCBcdTRGMUEgc2VlZCBcdTY3MkNcdThGNkVcdTk4ODZcdTU3REYgUmVxdWVzdFx1MzAwMlx1NkI2NFx1NjVGNlx1NTNFQVx1ODBGRFx1NjMwOVx1NjYwRVx1Nzg2RVx1OEVBQlx1NEVGRFx1NUJGOVx1OEQyNlx1RkYxQlxuICAgICAgICAgICAgLy8gXHU1MUI3XHU1Mzg2XHU1M0YyXHU2MDYyXHU1OTBEXHU2NzFGXHU5NUY0IGJhc2VsaW5lIFx1NTNFRlx1ODBGRFx1NjY4Mlx1NjVGNlx1NEUzQVx1N0E3QVx1RkYwQ1x1NjMwOSBwcm9tcHQgXHU2NTg3XHU2NzJDXHU0RjFBXHU4QkVGXHU4QkE0XHU2NUU3XHU3Njg0XHU1NDBDXHU2NTg3XHU2ODQ4IFJlcXVlc3RcdTMwMDJcbiAgICAgICAgICAgIG1hdGNoQnlSZXF1ZXN0SWRPbmx5OiBvcHRpb25zLmVtaXRVc2VyTWVzc2FnZSA9PT0gdHJ1ZSxcbiAgICAgICAgfTtcbiAgICAgICAgc3RhdGUucGVuZGluZy5wdXNoKHBlbmRpbmcpO1xuICAgICAgICBpZiAob3B0aW9ucy50aW1lb3V0TXMgIT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgY29uc3QgdGltZXIgPSBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgICAgICAgICBzdGF0ZS50aW1lb3V0QnlDbGllbnRSZXF1ZXN0SWQuZGVsZXRlKGNsaWVudFJlcXVlc3RJZCk7XG4gICAgICAgICAgICAgICAgY29uc3QgbWFwcGVkID0gc3RhdGUucmVxdWVzdEJ5Q2xpZW50UmVxdWVzdElkLmdldChjbGllbnRSZXF1ZXN0SWQpO1xuICAgICAgICAgICAgICAgIGlmIChtYXBwZWQgJiYgc3RhdGUuc2V0dGxlZEF1dG9tYXRpb25SZXF1ZXN0cy5oYXMobWFwcGVkLnJlcXVlc3RJZCkpIHsgcmV0dXJuOyB9XG4gICAgICAgICAgICAgICAgc3RhdGUudGltZWRPdXRDbGllbnRSZXF1ZXN0SWRzLmFkZChjbGllbnRSZXF1ZXN0SWQpO1xuICAgICAgICAgICAgICAgIGNvbnZlcnNhdGlvbi5jYW5jZWwoKS5jYXRjaCgoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIHN0YXRlLnRpbWVkT3V0Q2xpZW50UmVxdWVzdElkcy5kZWxldGUoY2xpZW50UmVxdWVzdElkKTtcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH0sIG9wdGlvbnMudGltZW91dE1zKTtcbiAgICAgICAgICAgIHN0YXRlLnRpbWVvdXRCeUNsaWVudFJlcXVlc3RJZC5zZXQoY2xpZW50UmVxdWVzdElkLCB0aW1lcik7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgY2xlYW51cEZhaWxlZFN1Ym1pc3Npb24gPSAoKTogdm9pZCA9PiB7XG4gICAgICAgICAgICBjb25zdCBwZW5kaW5nSW5kZXggPSBzdGF0ZS5wZW5kaW5nLmluZGV4T2YocGVuZGluZyk7XG4gICAgICAgICAgICBpZiAocGVuZGluZ0luZGV4ID49IDApIHsgc3RhdGUucGVuZGluZy5zcGxpY2UocGVuZGluZ0luZGV4LCAxKTsgfVxuICAgICAgICAgICAgY29uc3QgdGltZXIgPSBzdGF0ZS50aW1lb3V0QnlDbGllbnRSZXF1ZXN0SWQuZ2V0KGNsaWVudFJlcXVlc3RJZCk7XG4gICAgICAgICAgICBpZiAodGltZXIpIHsgY2xlYXJUaW1lb3V0KHRpbWVyKTsgfVxuICAgICAgICAgICAgc3RhdGUudGltZW91dEJ5Q2xpZW50UmVxdWVzdElkLmRlbGV0ZShjbGllbnRSZXF1ZXN0SWQpO1xuICAgICAgICAgICAgc3RhdGUudGltZWRPdXRDbGllbnRSZXF1ZXN0SWRzLmRlbGV0ZShjbGllbnRSZXF1ZXN0SWQpO1xuICAgICAgICB9O1xuICAgICAgICBsZXQgcmVzdWx0OiB2b2lkIHwgQXBpRXJyb3I7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICByZXN1bHQgPSBhd2FpdCBvcmlnaW5hbFNlbmRQcm9tcHQocHJvbXB0LCB0cmFja2VkT3B0aW9ucyk7XG4gICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgICAgICBjbGVhbnVwRmFpbGVkU3VibWlzc2lvbigpO1xuICAgICAgICAgICAgdGhyb3cgZXJyb3I7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGlzQXBpRXJyb3IocmVzdWx0KSkge1xuICAgICAgICAgICAgY2xlYW51cEZhaWxlZFN1Ym1pc3Npb24oKTtcbiAgICAgICAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgICAgIH1cbiAgICAgICAgaGFuZGxlUmVxdWVzdHNDaGFuZ2VkKChhd2FpdCByZWFkTG9hZGVkUmVxdWVzdHMoKSkuaXRlbXMpO1xuICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgIH07XG4gICAgY29udmVyc2F0aW9uLnNlbmRQcm9tcHQgPSAocHJvbXB0LCBvcHRpb25zKSA9PiB7XG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IHN0YXRlLnRhaWwudGhlbigoKSA9PiBzZW5kVHJhY2tlZChwcm9tcHQsIG9wdGlvbnMpKTtcbiAgICAgICAgc3RhdGUudGFpbCA9IHJlc3VsdC50aGVuKCgpID0+IHVuZGVmaW5lZCwgKCkgPT4gdW5kZWZpbmVkKTtcbiAgICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICB9O1xuICAgIEFUVEFDSEVEX0NPTlZFUlNBVElPTlMuYWRkKGNvbnZlcnNhdGlvbik7XG5cbiAgICBpZiAoaGFzUHJvbXB0T3BlcmF0aW9ucykge1xuICAgICAgICByZXR1cm4gY29udmVyc2F0aW9uIGFzIFQgJiBDb252ZXJzYXRpb247XG4gICAgfVxuXG4gICAgY29uc3QgcnVuT25lID0gYXN5bmMgKFxuICAgICAgICBwcm9tcHQ6IEJsb2NrW10sXG4gICAgICAgIG9wdGlvbnM6IFNlbmRPcHRpb25zID0ge30sXG4gICAgKTogUHJvbWlzZTxDb252ZXJzYXRpb25UdXJuUmVzdWx0PiA9PiB7XG4gICAgICAgIGNvbnN0IGNsaWVudFJlcXVlc3RJZCA9IG9wdGlvbnMuY2xpZW50UmVxdWVzdElkXG4gICAgICAgICAgICA/PyBgJHtjb252ZXJzYXRpb24uaW5mby5pZH06Y2xpZW50LXJlcXVlc3Q6JHtEYXRlLm5vdygpfTokeysrc3RhdGUuc2VxdWVuY2V9YDtcbiAgICAgICAgY29uc3QgcmVxdWVzdElkID0gcmVzb2x2ZUNvbnZlcnNhdGlvblJlcXVlc3RJZChvcHRpb25zLl9tZXRhKTtcblxuICAgICAgICBsZXQgcmVzb2x2ZVRlcm1pbmFsITogKHJlcXVlc3Q6IFJlcXVlc3QpID0+IHZvaWQ7XG4gICAgICAgIGNvbnN0IHRlcm1pbmFsID0gbmV3IFByb21pc2U8UmVxdWVzdD4ocmVzb2x2ZSA9PiB7IHJlc29sdmVUZXJtaW5hbCA9IHJlc29sdmU7IH0pO1xuICAgICAgICBsZXQgc2V0dGxlZCA9IGZhbHNlO1xuICAgICAgICBjb25zdCBpbnNwZWN0ID0gKHJlcXVlc3RzOiByZWFkb25seSBSZXF1ZXN0W10pOiB2b2lkID0+IHtcbiAgICAgICAgICAgIGlmIChzZXR0bGVkKSB7IHJldHVybjsgfVxuICAgICAgICAgICAgY29uc3QgcmVxdWVzdCA9IGZpbmRSZXF1ZXN0QnlJZChyZXF1ZXN0cywgcmVxdWVzdElkKTtcbiAgICAgICAgICAgIGlmICghcmVxdWVzdCB8fCAhVEVSTUlOQUxfUkVRVUVTVF9TVEFURVMuaGFzKHJlcXVlc3Quc3RhdGUpKSB7IHJldHVybjsgfVxuICAgICAgICAgICAgc2V0dGxlZCA9IHRydWU7XG4gICAgICAgICAgICByZXNvbHZlVGVybWluYWwocmVxdWVzdCk7XG4gICAgICAgIH07XG4gICAgICAgIGNvbnN0IHVuc3Vic2NyaWJlID0gY29udmVyc2F0aW9uLm9uKENvbnZlcnNhdGlvbkV2ZW50LlJlcXVlc3RzQ2hhbmdlZCwgaW5zcGVjdCk7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICAvLyBydW5Qcm9tcHQgXHU2NjJGXHU5NzAwXHU4OTgxXHU3ODZFXHU1QjlBXHU2MDI3XHU1NkRFXHU1NDEwXHU3Njg0IGhlYWRsZXNzL0lNIFx1NTE2NVx1NTNFM1x1MzAwMmNsaWVudFJlcXVlc3RJZCBcdTUzRUFcdThEMUZcdThEMjNcdTU5MTZcdTkwRThcbiAgICAgICAgICAgIC8vIFx1NUU0Mlx1N0I0OVx1RkYxQlx1OTg4Nlx1NTdERiBSZXF1ZXN0IFx1NzUyOFx1NzJFQ1x1N0FDQiBjb252ZXJzYXRpb25SZXF1ZXN0SWQgXHU1MDVBXHU3RUM4XHU2MDAxXHU1QkY5XHU4RDI2XHUzMDAyXG4gICAgICAgICAgICBjb25zdCBzZW5kUmVzdWx0ID0gYXdhaXQgc2VuZFRyYWNrZWQocHJvbXB0LCB7XG4gICAgICAgICAgICAgICAgLi4ub3B0aW9ucyxcbiAgICAgICAgICAgICAgICBjbGllbnRSZXF1ZXN0SWQsXG4gICAgICAgICAgICAgICAgZW1pdFVzZXJNZXNzYWdlOiB0cnVlLFxuICAgICAgICAgICAgICAgIF9tZXRhOiB3aXRoQ29udmVyc2F0aW9uUmVxdWVzdElkTWV0YShvcHRpb25zLl9tZXRhLCByZXF1ZXN0SWQpLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICBpZiAoaXNBcGlFcnJvcihzZW5kUmVzdWx0KSkge1xuICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgJHtzZW5kUmVzdWx0LmVycm9yQ29kZX06ICR7c2VuZFJlc3VsdC5tZXNzYWdlfWApO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaW5zcGVjdCgoYXdhaXQgcmVhZExvYWRlZFJlcXVlc3RzKCkpLml0ZW1zKTtcbiAgICAgICAgICAgIGNvbnN0IHJlcXVlc3QgPSBhd2FpdCB0ZXJtaW5hbDtcbiAgICAgICAgICAgIHN0YXRlLnJlcXVlc3RCeUNsaWVudFJlcXVlc3RJZC5zZXQoY2xpZW50UmVxdWVzdElkLCB7XG4gICAgICAgICAgICAgICAgcmVxdWVzdElkOiByZXF1ZXN0LmlkLFxuICAgICAgICAgICAgICAgIGNsaWVudFRpbWVzdGFtcDogb3B0aW9ucy5jbGllbnRUaW1lc3RhbXAsXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIHN0YXRlLnBlbmRpbmcgPSBzdGF0ZS5wZW5kaW5nLmZpbHRlcihpdGVtID0+IGl0ZW0uY2xpZW50UmVxdWVzdElkICE9PSBjbGllbnRSZXF1ZXN0SWQpO1xuICAgICAgICAgICAgcmV0dXJuIHRvVHVyblJlc3VsdChyZXF1ZXN0LCBjbGllbnRSZXF1ZXN0SWQpO1xuICAgICAgICB9IGZpbmFsbHkge1xuICAgICAgICAgICAgdW5zdWJzY3JpYmUoKTtcbiAgICAgICAgfVxuICAgIH07XG5cbiAgICBjb25zdCBlbnF1ZXVlID0gKHByb21wdDogQmxvY2tbXSwgb3B0aW9uczogU2VuZE9wdGlvbnMgPSB7fSk6IFByb21pc2U8Q29udmVyc2F0aW9uVHVyblJlc3VsdD4gPT4ge1xuICAgICAgICBjb25zdCBjbGllbnRSZXF1ZXN0SWQgPSBvcHRpb25zLmNsaWVudFJlcXVlc3RJZDtcbiAgICAgICAgaWYgKGNsaWVudFJlcXVlc3RJZCkge1xuICAgICAgICAgICAgY29uc3QgaW5GbGlnaHQgPSBzdGF0ZS5pbkZsaWdodEJ5Q2xpZW50UmVxdWVzdElkLmdldChjbGllbnRSZXF1ZXN0SWQpO1xuICAgICAgICAgICAgaWYgKGluRmxpZ2h0KSB7IHJldHVybiBpbkZsaWdodDsgfVxuICAgICAgICAgICAgY29uc3QgbWFwcGVkID0gc3RhdGUucmVxdWVzdEJ5Q2xpZW50UmVxdWVzdElkLmdldChjbGllbnRSZXF1ZXN0SWQpO1xuICAgICAgICAgICAgY29uc3QgcmVxdWVzdCA9IG1hcHBlZCA/IGNvbnZlcnNhdGlvbi5nZXRSZXF1ZXN0KG1hcHBlZC5yZXF1ZXN0SWQpIDogdW5kZWZpbmVkO1xuICAgICAgICAgICAgaWYgKHJlcXVlc3QgJiYgVEVSTUlOQUxfUkVRVUVTVF9TVEFURVMuaGFzKHJlcXVlc3Quc3RhdGUpKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIFByb21pc2UucmVzb2x2ZSh0b1R1cm5SZXN1bHQocmVxdWVzdCwgY2xpZW50UmVxdWVzdElkKSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgcmVzdWx0ID0gc3RhdGUudGFpbC50aGVuKCgpID0+IHJ1bk9uZShwcm9tcHQsIG9wdGlvbnMpKTtcbiAgICAgICAgc3RhdGUudGFpbCA9IHJlc3VsdC50aGVuKCgpID0+IHVuZGVmaW5lZCwgKCkgPT4gdW5kZWZpbmVkKTtcbiAgICAgICAgaWYgKGNsaWVudFJlcXVlc3RJZCkge1xuICAgICAgICAgICAgc3RhdGUuaW5GbGlnaHRCeUNsaWVudFJlcXVlc3RJZC5zZXQoY2xpZW50UmVxdWVzdElkLCByZXN1bHQpO1xuICAgICAgICAgICAgY29uc3QgY2xlYW51cCA9ICgpID0+IHtcbiAgICAgICAgICAgICAgICBpZiAoc3RhdGUuaW5GbGlnaHRCeUNsaWVudFJlcXVlc3RJZC5nZXQoY2xpZW50UmVxdWVzdElkKSA9PT0gcmVzdWx0KSB7XG4gICAgICAgICAgICAgICAgICAgIHN0YXRlLmluRmxpZ2h0QnlDbGllbnRSZXF1ZXN0SWQuZGVsZXRlKGNsaWVudFJlcXVlc3RJZCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIHJlc3VsdC50aGVuKGNsZWFudXAsIGNsZWFudXApO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgfTtcblxuICAgIGNvbnZlcnNhdGlvbi5ydW5Qcm9tcHQgPSBlbnF1ZXVlO1xuICAgIGNvbnZlcnNhdGlvbi5nZXRSZXF1ZXN0QnlDbGllbnRSZXF1ZXN0SWQgPSBjbGllbnRSZXF1ZXN0SWQgPT4ge1xuICAgICAgICBjb25zdCBtYXBwZWQgPSBzdGF0ZS5yZXF1ZXN0QnlDbGllbnRSZXF1ZXN0SWQuZ2V0KGNsaWVudFJlcXVlc3RJZCk7XG4gICAgICAgIHJldHVybiBtYXBwZWQgPyBjb252ZXJzYXRpb24uZ2V0UmVxdWVzdChtYXBwZWQucmVxdWVzdElkKSA6IHVuZGVmaW5lZDtcbiAgICB9O1xuICAgIGNvbnN0IGVucXVldWVDb250cm9sID0gKGNvbnRyb2w6ICdjbGVhcicgfCAnY29tcGFjdCcpOiBQcm9taXNlPHZvaWQgfCBBcGlFcnJvcj4gPT4ge1xuICAgICAgICBjb25zdCByZXN1bHQgPSBzdGF0ZS50YWlsLnRoZW4oKCkgPT4gb3JpZ2luYWxTZW5kUHJvbXB0KFt7XG4gICAgICAgICAgICB0eXBlOiAndGV4dCcsXG4gICAgICAgICAgICB0ZXh0OiAnJyxcbiAgICAgICAgICAgIFtDT05WRVJTQVRJT05fU0VTU0lPTl9DT05UUk9MX0tFWV06IGNvbnRyb2wsXG4gICAgICAgIH1dKSk7XG4gICAgICAgIHN0YXRlLnRhaWwgPSByZXN1bHQudGhlbigoKSA9PiB1bmRlZmluZWQsICgpID0+IHVuZGVmaW5lZCk7XG4gICAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgfTtcbiAgICBjb252ZXJzYXRpb24uY2xlYXIgPSAoKSA9PiBlbnF1ZXVlQ29udHJvbCgnY2xlYXInKTtcbiAgICAvLyBcdTRFNTBcdTg5QzIgVGltZWxpbmUgXHU1RkM1XHU5ODdCXHU3NTMxXHU3NzFGXHU2QjYzXHU2M0E1XHU2NTM2XHU2M0E3XHU1MjM2XHU4QkY3XHU2QzQyXHU3Njg0IENvbnZlcnNhdGlvbkltcGwgXHU1MjFCXHU1RUZBXHUzMDAyUmVuZGVyZXIgXHU3Njg0XG4gICAgLy8gcmVoeWRyYXRlIFx1NUJDQ1x1NUJGOVx1OEM2MVx1N0VDRiBJUEMgXHU1M0VBXHU2NzA5IHNlbmRQcm9tcHRcdUZGMENcdTgyRTVcdTU3MjhcdThGRDlcdTRFMkFcdTVCQTJcdTYyMzdcdTdBRUZcdTUzMDVcdTg4QzVcdTVDNDJcdTUzNjBcdTRGNERcdUZGMENkYWVtb24gXHU3NzBCXHU0RTBEXHU1MjMwXG4gICAgLy8gXHU1NDBDXHU0RTAwXHU0RTJBXHU3NTFGXHU1NDdEXHU1NDY4XHU2NzFGXHVGRjBDcnVudGltZSBcdTVFMjdcdTRGMUFcdTkwMDBcdTUzMTZcdTYyMTBcdTRFMEJcdTRFMDBcdThGNkVcdTc2ODRcdTY1QjBcdTRFOEJcdTRFRjZcdTMwMDJcbiAgICBjb252ZXJzYXRpb24uY29tcGFjdCA9ICgpID0+IGVucXVldWVDb250cm9sKCdjb21wYWN0Jyk7XG5cbiAgICByZXR1cm4gY29udmVyc2F0aW9uIGFzIFQgJiBDb252ZXJzYXRpb247XG59XG4iLCAiLyoqXG4gKiBDb252ZXJzYXRpb25XaXJlRGVzY3JpcHRvciBcdTIwMTRcdTIwMTQgd2IuY29udmVyc2F0aW9ucyBcdThGREVcdTYzQTVcdTYwMDFcdTMwMENcdTY1QjlcdTZDRDUgLyBcdTRFOEJcdTRFRjZcdTMwMERcdTc2ODRcdTUzNTVcdTRFMDBcdTc3MUZcdTc2RjhcdTZFOTBcdUZGMDhTU09UXHVGRjA5XHUzMDAyXG4gKlxuICogXHU4MENDXHU2NjZGXHVGRjFBXHU2NUIwXHU1ODlFL1x1OTFDRFx1NTQ3RFx1NTQwRFx1NEUwMFx1NEUyQVx1OEZERVx1NjNBNVx1NjAwMSB3aXJlIFx1ODBGRFx1NTI5Qlx1RkYwQ1x1NTM5Rlx1NjcyQ1x1ODk4MVx1NTQwQ1x1NkI2NVx1NjUzOSA1IFx1NTkwNFx1NjI0Qlx1NTE5OVx1NTNFMFx1NUM0Mlx1RkYxQVxuICogICBgdHlwZXMudHNgXHVGRjA4XHU2NUI5XHU2Q0Q1XHU5NTJFXHU3NjdEXHU1NDBEXHU1MzU1XHVGRjA5XHUyMTkyIGBicmlkZ2UudHNgXHVGRjA4XHU1QjlFXHU3M0IwXHVGRjA5XHUyMTkyIGBzZXJ2aWNlLnRzYFx1RkYwOGZvcndhcmRcdUZGMDlcbiAqICAgXHUyMTkyIGByZWh5ZHJhdGUudHNgXHVGRjA4XHU2NUI5XHU2Q0Q1XHU1OEYzICsgXHU0RThCXHU0RUY2XHU1OEYzXHVGRjA5XHUyMTkyIGBpbmRleC50c2BcdUZGMDhcdTk2QzZcdTU0MDhcdTdFQTdcdTRFOEJcdTRFRjYgc3dpdGNoXHVGRjA5XHUzMDAyXG4gKlxuICogXHU2NzJDXHU2NTg3XHU0RUY2XHU2MjhBXHUzMDBDXHU2NjZFXHU5MDFBXHU2NUI5XHU2Q0Q1XHUzMDBEXHU0RTBFXHUzMDBDXHU2NjZFXHU5MDFBXHU0RThCXHU0RUY2XHUzMDBEXHU2MkJEXHU2MjEwXHU4ODY4XHVGRjBDXHU4QkE5XHU0RTBBXHU4RkYwXHU1NDA0XHU1OTA0XHU0RUNFXHU4ODY4XHU2RDNFXHU3NTFGL1x1NjgyMVx1OUE4Q1x1RkYxQVxuICogLSBgTUVUSE9EX0JJTkRTYFx1RkYxQVx1OEZERVx1NjNBNVx1NjAwMVx1NjVCOVx1NkNENVx1NjAzQlx1ODg2OFx1RkYwQ2B0eXBlcy50c2AgXHU3Njg0IGBDb252ZXJzYXRpb25SZW1vdGVNZXRob2RLZXlgIFx1NEVDRVx1NUI4M1x1NkQzRVx1NzUxRlx1RkYwQ1xuICogICBgcmVoeWRyYXRlYCBcdTY1QjlcdTZDRDVcdTU4RjNcdTMwMDFgc2VydmljZWAgZm9yd2FyZCBcdTc1MzFcdTVCODNcdTc1MUZcdTYyMTBcdUZGMENgYnJpZGdlYCBcdTc1MjhcdTVCODNcdTUwNUFcdTVCOENcdTU5MDdcdTYwMjdcdTY4MjFcdTlBOENcdTMwMDJcbiAqIC0gYElOU1RBTkNFX0VWRU5UX0JJTkRTYCAvIGBDT0xMRUNUSU9OX0VWRU5UX0JJTkRTYFx1RkYxQVx1NUI5RVx1NEY4Qlx1N0VBNyAvIFx1OTZDNlx1NTQwOFx1N0VBN1x1NjY2RVx1OTAxQVx1NEU4Qlx1NEVGNlx1ODg2OFx1RkYwQ1xuICogICBcdTUxNzFcdTRFQUJcdTU0MENcdTRFMDBcdTYyNzkgYFdCX0NPTlZFUlNBVElPTl8qYCBidXMgXHU1RTM4XHU5MUNGXHVGRjFCXHU0RTI0XHU1OTA0IGBvbigpYCBzd2l0Y2ggXHU3Njg0XHU2NjZFXHU5MDFBXHU2NTJGXHU0RUNFXHU4ODY4XHU2RDNFXHU3NTFGXHVGRjBDXG4gKiAgIFx1NzI3OVx1NEY4Qlx1RkYwOFx1NTNDQyBidXMgLyBob3N0IFx1NTI2Rlx1NEY1Q1x1NzUyOCAvIFx1NUM0MFx1OTBFOFx1NzJCNlx1NjAwMVx1NEY5RFx1OEQ1Nlx1RkYwOVx1NEZERFx1NzU1OVx1NjI0Qlx1NTE5OVx1MzAwMlxuICogLSBcdTVCOENcdTU5MDdcdTYwMjdcdTY1QURcdThBMDBcdUZGMDhcdTdDN0JcdTU3OEJcdTVDNDIgKyBcdThGRDBcdTg4NENcdTY3MUZcdUZGMDlcdTc4NkVcdTRGRERcdTY3OUFcdTRFM0UvXHU3NjdEXHU1NDBEXHU1MzU1XHU0RTBEXHU0RTBFXHU4ODY4XHU2RjAyXHU3OUZCXHUzMDAyXG4gKlxuICogXHU2RDRGXHU4OUM4XHU1NjY4XHU1Qjg5XHU1MTY4XHVGRjFBXHU3RUFGXHU3QzdCXHU1NzhCICsgXHU1RTM4XHU5MUNGXHVGRjBDXHU1M0VBIHR5cGUtaW1wb3J0IFx1NTk1MVx1N0VBNlx1RkYwQ1x1NEUwRCB2YWx1ZS1pbXBvcnQgXHU0RUZCXHU0RjU1IE5vZGUvRWxlY3Ryb25cdTMwMDJcbiAqL1xuXG5pbXBvcnQge1xuICAgIHR5cGUgQ29udmVyc2F0aW9uQ2FwYWNpdHlRdWV1ZVVwZGF0ZVBheWxvYWQsXG4gICAgdHlwZSBDb252ZXJzYXRpb25DaGlsZEFnZW50RXZlbnRQYXlsb2FkLFxuICAgIHR5cGUgQ29udmVyc2F0aW9uQ2xvdWRTZXJ2aWNlQ29uZmlybWF0aW9uQ2hhbmdlZFBheWxvYWQsXG4gICAgdHlwZSBDb252ZXJzYXRpb25Db21tYW5kc1VwZGF0ZVBheWxvYWQsXG4gICAgdHlwZSBDb252ZXJzYXRpb25Db25maWdVcGRhdGVQYXlsb2FkLFxuICAgIHR5cGUgQ29udmVyc2F0aW9uQ29udGV4dFVzYWdlQ2hhbmdlZEV2ZW50UGF5bG9hZCxcbiAgICB0eXBlIENvbnZlcnNhdGlvbkNyZWRpdENoYW5nZWRFdmVudFBheWxvYWQsXG4gICAgdHlwZSBDb252ZXJzYXRpb25Fc3RpbWF0ZWRDb3N0Q2hhbmdlZEV2ZW50UGF5bG9hZCxcbiAgICB0eXBlIENvbnZlcnNhdGlvbkhpc3RvcnlMb2FkZWRQYXlsb2FkLFxuICAgIHR5cGUgQ29udmVyc2F0aW9uSW5mb0NoYW5nZVBheWxvYWQsXG4gICAgdHlwZSBDb252ZXJzYXRpb25NYW5hZ2VyVXBkYXRlUGF5bG9hZCxcbiAgICB0eXBlIENvbnZlcnNhdGlvbk1jcFN0YXJ0dXBTdGF0dXNQYXlsb2FkLFxuICAgIHR5cGUgQ29udmVyc2F0aW9uTW9kZUNoYW5nZVBheWxvYWQsXG4gICAgdHlwZSBDb252ZXJzYXRpb25Nb2RlbENoYW5nZVBheWxvYWQsXG4gICAgdHlwZSBDb252ZXJzYXRpb25Nb2Rlc1VwZGF0ZVBheWxvYWQsXG4gICAgdHlwZSBDb252ZXJzYXRpb25QZXJtaXNzaW9uUGF5bG9hZCxcbiAgICB0eXBlIENvbnZlcnNhdGlvblBsYW5VcGRhdGVQYXlsb2FkLFxuICAgIHR5cGUgQ29udmVyc2F0aW9uUGx1Z2luUmVjb21tZW5kYXRpb25DaGFuZ2VkUGF5bG9hZCxcbiAgICB0eXBlIENvbnZlcnNhdGlvblByZXBhcmVTdGF0dXNQYXlsb2FkLFxuICAgIHR5cGUgQ29udmVyc2F0aW9uU3RhdGVDaGFuZ2VQYXlsb2FkLFxuICAgIHR5cGUgQ29udmVyc2F0aW9uVGltZWxpbmVFdmVudEJ1c1BheWxvYWQsXG4gICAgdHlwZSBDb252ZXJzYXRpb25XYXJuaW5nUGF5bG9hZCxcbiAgICBXQl9DT05WRVJTQVRJT05fQVJUSUZBQ1RfVVBEQVRFLFxuICAgIFdCX0NPTlZFUlNBVElPTl9DQVBBQ0lUWV9RVUVVRV9VUERBVEUsXG4gICAgV0JfQ09OVkVSU0FUSU9OX0NISUxEX0FHRU5UX0VWRU5ULFxuICAgIFdCX0NPTlZFUlNBVElPTl9DTE9VRF9TRVJWSUNFX0NPTkZJUk1BVElPTl9DSEFOR0VELFxuICAgIFdCX0NPTlZFUlNBVElPTl9DT01NQU5EU19VUERBVEUsXG4gICAgV0JfQ09OVkVSU0FUSU9OX0NPTkZJR19VUERBVEUsXG4gICAgV0JfQ09OVkVSU0FUSU9OX0NPTlRFWFRfVVNBR0VfQ0hBTkdFRCxcbiAgICBXQl9DT05WRVJTQVRJT05fQ1JFRElUX0NIQU5HRUQsXG4gICAgV0JfQ09OVkVSU0FUSU9OX0VTVElNQVRFRF9DT1NUX0NIQU5HRUQsXG4gICAgV0JfQ09OVkVSU0FUSU9OX0hJU1RPUllfTE9BREVELFxuICAgIFdCX0NPTlZFUlNBVElPTl9JTkZPX0NIQU5HRSxcbiAgICBXQl9DT05WRVJTQVRJT05fTUNQX1NUQVJUVVBfU1RBVFVTLFxuICAgIFdCX0NPTlZFUlNBVElPTl9NT0RFX0NIQU5HRSxcbiAgICBXQl9DT05WRVJTQVRJT05fTU9ERUxfQ0hBTkdFLFxuICAgIFdCX0NPTlZFUlNBVElPTl9NT0RFU19VUERBVEUsXG4gICAgV0JfQ09OVkVSU0FUSU9OX1BFUk1JU1NJT04sXG4gICAgV0JfQ09OVkVSU0FUSU9OX1BMQU5fVVBEQVRFLFxuICAgIFdCX0NPTlZFUlNBVElPTl9QTFVHSU5fUkVDT01NRU5EQVRJT05fQ0hBTkdFRCxcbiAgICBXQl9DT05WRVJTQVRJT05fUFJFUEFSRV9TVEFUVVMsXG4gICAgV0JfQ09OVkVSU0FUSU9OX1FVRVVFX1VQREFURSxcbiAgICBXQl9DT05WRVJTQVRJT05fU1RBVEVfQ0hBTkdFLFxuICAgIFdCX0NPTlZFUlNBVElPTl9USU1FTElORV9FVkVOVCxcbiAgICBXQl9DT05WRVJTQVRJT05fV0FSTklORyxcbn0gZnJvbSAnLi4vY29tbW9uL2V2ZW50LW5hbWVzJztcbmltcG9ydCB7XG4gICAgdHlwZSBDb252ZXJzYXRpb24sXG4gICAgQ29udmVyc2F0aW9uRXZlbnQsXG4gICAgdHlwZSBDb252ZXJzYXRpb25FdmVudENhbGxiYWNrTWFwLFxuICAgIENvbnZlcnNhdGlvbnNFdmVudCxcbiAgICB0eXBlIENvbnZlcnNhdGlvbnNFdmVudENhbGxiYWNrTWFwLFxufSBmcm9tICcuLi9jb21tb24vdHlwZXMnO1xuXG4vLyBcdTI1MDBcdTI1MDBcdTI1MDAgXHU2NUI5XHU2Q0Q1XHU2M0NGXHU4RkYwXHU3QjI2IFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXG4vKipcbiAqIFx1NjVCOVx1NkNENVx1NThGM1x1NzY4NFx1NEUwOVx1NzlDRFx1NjI2N1x1ODg0Q1x1OEJFRFx1NEU0OVx1RkYwOFx1NUJGOVx1NUU5NCByZWh5ZHJhdGUgXHU2NUI5XHU2Q0Q1XHU1OEYzXHU3Njg0XHU0RTA5XHU3QzdCXHU1MTk5XHU2Q0Q1XHVGRjA5XHVGRjFBXG4gKiAtIGBhc3luY2BcdUZGMUFgKC4uLikgPT4gY29udmVyc2F0aW9uLmtleShpZCwgLi4uKWAgXHU3NkY0XHU2M0E1IHJldHVybiBQcm9taXNlXHVGRjA4c2VuZFByb21wdC9jYW5jZWwvXHUyMDI2XHVGRjA5XG4gKiAtIGBmaXJlQW5kRm9yZ2V0YFx1RkYxQWAoLi4uKSA9PiB7IGNvbnZlcnNhdGlvbi5rZXkoaWQsIC4uLikuY2F0Y2goLi4uKSB9YCBcdThGRDRcdTU2REUgdm9pZFx1RkYwOHByZWxvYWQvbG9nXHVGRjA5XG4gKiAtIGBzeW5jVm9pZGBcdUZGMUFcdTU0MEMgZmlyZUFuZEZvcmdldFx1RkYwQ1x1NEY0Nlx1NTE2Q1x1NUYwMFx1N0I3RVx1NTQwRFx1NjcyQ1x1NUMzMVx1NjYyRlx1NTQwQ1x1NkI2NSB2b2lkXHVGRjA4cmVzb2x2ZVBlbmRpbmcvcmVqZWN0UGVuZGluZ1x1RkYwOVxuICovXG5leHBvcnQgdHlwZSBNZXRob2RNb2RlID0gJ2FzeW5jJyB8ICdmaXJlQW5kRm9yZ2V0JyB8ICdzeW5jVm9pZCc7XG5cbi8qKlxuICogXHU1MzU1XHU0RTJBXHU4RkRFXHU2M0E1XHU2MDAxXHU2NUI5XHU2Q0Q1XHU1NzI4IHdpcmUgXHU1MTY4XHU5NEZFXHU4REVGXHU3Njg0XHU2M0NGXHU4RkYwXHUzMDAyXG4gKiBga2V5YCBcdTdFQTZcdTY3NUZcdTRFM0EgYGtleW9mIENvbnZlcnNhdGlvbmBcdUZGMUFcdTRGRERcdThCQzFcdTdCN0VcdTU0MERcdTRFQ0UgYENvbnZlcnNhdGlvbltLXWAgXHU2RDNFXHU3NTFGXHVGRjBDXHU0RTBEXHU5MDAwXHU1MzE2IGFueVx1MzAwMlxuICovXG5leHBvcnQgaW50ZXJmYWNlIE1ldGhvZEJpbmQ8SyBleHRlbmRzIGtleW9mIENvbnZlcnNhdGlvbiA9IGtleW9mIENvbnZlcnNhdGlvbj4ge1xuICAgIC8qKiBcdTVCRjlcdTVFOTQgYENvbnZlcnNhdGlvbmAgXHU0RTBBXHU3Njg0XHU2NUI5XHU2Q0Q1XHU1NDBEXHVGRjA4PSByZWh5ZHJhdGUgXHU2NUI5XHU2Q0Q1XHU1OEYzXHU5NTJFID0gYnJpZGdlIGBjb252Lnh4eGAgXHU5NTJFXHVGRjA5XHUzMDAyICovXG4gICAgcmVhZG9ubHkga2V5OiBLO1xuICAgIC8qKiBcdTY1QjlcdTZDRDVcdTU4RjNcdTYyNjdcdTg4NENcdThCRURcdTRFNDlcdTMwMDIgKi9cbiAgICByZWFkb25seSBtb2RlOiBNZXRob2RNb2RlO1xuICAgIC8qKiBmaXJlQW5kRm9yZ2V0IC8gc3luY1ZvaWQgXHU3Njg0IGNhdGNoIFx1NTkwNFx1NzQwNlx1RkYxQWBzaWxlbnRgXHVGRjA4XHU1NDFFXHU2Mzg5XHVGRjA5fCBgd2FybmBcdUZGMDhjb25zb2xlLndhcm4gXHU1RTI2IFRBR1x1RkYwOVx1MzAwMiAqL1xuICAgIHJlYWRvbmx5IG9uUmVqZWN0PzogJ3NpbGVudCcgfCAnd2Fybic7XG4gICAgLyoqIGJyaWRnZSBcdTRGQTdcdTY2MkZcdTU0MjZcdThENzBcdTdFQUYgYHdpdGhDb252ZXJzYXRpb25gIFx1NzUxRlx1NjIxMFx1RkYwOHRydWVcdUZGMDlcdUZGMUJmYWxzZSBcdTg4NjhcdTc5M0EgYnJpZGdlIFx1NEZERFx1NzU1OVx1NjI0Qlx1NTE5OVx1NzI3OVx1NEY4Qlx1MzAwMiAqL1xuICAgIHJlYWRvbmx5IGJyaWRnZUF1dG86IGJvb2xlYW47XG59XG5cbi8qKlxuICogXHU4RkRFXHU2M0E1XHU2MDAxXHU2NUI5XHU2Q0Q1XHU2MDNCXHU4ODY4XHVGRjA4U1NPVFx1RkYwOVx1MzAwMlxuICpcbiAqIGBhcyBjb25zdCBzYXRpc2ZpZXMgcmVhZG9ubHkgTWV0aG9kQmluZFtdYFx1RkYxQVx1N0YxNlx1OEJEMVx1NjcxRlx1OTUwMVx1NkI3Qlx1NkJDRlx1NEUyQSBga2V5IFx1MjIwOCBrZXlvZiBDb252ZXJzYXRpb25gXG4gKiBcdUZGMDhcdTYyRkNcdTk1MTlcdTdBQ0JcdTUzNzNcdTYyQTVcdTk1MTlcdUZGMDlcdUZGMENcdTU0MENcdTY1RjZcdTRGRERcdTc1NTlcdTVCNTdcdTk3NjJcdTkxQ0ZcdTUxNDNcdTdFQzRcdTRGOUJcdThGRDBcdTg4NENcdTY3MUZcdThGRURcdTRFRTMgLyBcdTVCOENcdTU5MDdcdTYwMjdcdTY1QURcdThBMDBcdTMwMDJcbiAqXG4gKiBcdTZDRThcdTYxMEYgcmVoeWRyYXRlIFx1NEZBN1x1NUJGOVx1NEVFNVx1NEUwQlx1OTUyRSoqXHU0RTBEXHU3NTI4KiogYGJpbmRSZW1vdGVNZXRob2RzYCBcdTc1MUZcdTYyMTBcdUZGMDhcdTg5QzEgUkVIWURSQVRFX01BTlVBTF9LRVlTXHVGRjA5XHVGRjFBXG4gKiAtIGByZXF1ZXN0c2AgLyBgcmVxdWVzdEVudHJpZXNgXHVGRjFBXHU5NzAwXHU5NjQ0XHU1RTI2IGBjYWNoZVJlcXVlc3RzYCBcdTUyNkZcdTRGNUNcdTc1MjhcbiAqIC0gYHJlc2VuZGBcdUZGMUFcdTk3MDBcdTY4MzlcdTYzNkUgbXV0YXRpb24gcmVzdWx0IFx1NTQwQ1x1NkI2NSByZW5kZXJlciBSZXF1ZXN0IGNhY2hlXG4gKiAtIGBnZXRQZW5kaW5nSW5mb2BcdUZGMUFcdThCRkJcdTY3MkNcdTU3MzBcdTdGMTNcdTVCNThcdUZGMENcdTRFMERcdTU5RDRcdTYyNTggY29udmVyc2F0aW9uXG4gKiAtIGBwcmVsb2FkYFx1RkYxQXJlaHlkcmF0ZSBcdTRGQTcgZmlyZS1hbmQtZm9yZ2V0XHVGRjA4XHU4ODY4XHU1M0VGXHU3NTFGXHU2MjEwXHVGRjBDXHU0RjQ2XHU0RTBFIGJyaWRnZSBcdTcyNzlcdTRGOEJcdTUzM0FcdTUyMDZcdUZGMENcdTdFREZcdTRFMDBcdTUyMTdcdTUxNjVcdTYyNEJcdTUxOTlcdTZFMDVcdTUzNTVcdUZGMDlcbiAqL1xuZXhwb3J0IGNvbnN0IE1FVEhPRF9CSU5EUyA9IFtcbiAgICB7IGtleTogJ3NlbmRQcm9tcHQnLCBtb2RlOiAnYXN5bmMnLCBicmlkZ2VBdXRvOiB0cnVlIH0sXG4gICAgeyBrZXk6ICdydW5Qcm9tcHQnLCBtb2RlOiAnYXN5bmMnLCBicmlkZ2VBdXRvOiB0cnVlIH0sXG4gICAgeyBrZXk6ICdjbGVhcicsIG1vZGU6ICdhc3luYycsIGJyaWRnZUF1dG86IHRydWUgfSxcbiAgICB7IGtleTogJ2NvbXBhY3QnLCBtb2RlOiAnYXN5bmMnLCBicmlkZ2VBdXRvOiB0cnVlIH0sXG4gICAgeyBrZXk6ICdyZXF1ZXN0cycsIG1vZGU6ICdhc3luYycsIGJyaWRnZUF1dG86IHRydWUgfSxcbiAgICB7IGtleTogJ3JlcXVlc3RFbnRyaWVzJywgbW9kZTogJ2FzeW5jJywgYnJpZGdlQXV0bzogdHJ1ZSB9LFxuICAgIHsga2V5OiAnZ2V0QmFja2dyb3VuZFRlcm1pbmFscycsIG1vZGU6ICdhc3luYycsIGJyaWRnZUF1dG86IHRydWUgfSxcbiAgICB7IGtleTogJ3VzZXJQcm9tcHRzJywgbW9kZTogJ2FzeW5jJywgYnJpZGdlQXV0bzogdHJ1ZSB9LFxuICAgIHsga2V5OiAnaW5wdXRIaXN0b3J5JywgbW9kZTogJ2FzeW5jJywgYnJpZGdlQXV0bzogdHJ1ZSB9LFxuICAgIHsga2V5OiAndXBkYXRlRXN0aW1hdGVkQ29zdCcsIG1vZGU6ICdhc3luYycsIGJyaWRnZUF1dG86IHRydWUgfSxcbiAgICB7IGtleTogJ2xvYWRUb29sRGV0YWlsJywgbW9kZTogJ2FzeW5jJywgYnJpZGdlQXV0bzogdHJ1ZSB9LFxuICAgIHsga2V5OiAnYXJ0aWZhY3RzJywgbW9kZTogJ2FzeW5jJywgYnJpZGdlQXV0bzogZmFsc2UgfSxcbiAgICB7IGtleTogJ2ZpbGVzJywgbW9kZTogJ2FzeW5jJywgYnJpZGdlQXV0bzogZmFsc2UgfSxcbiAgICB7IGtleTogJ3NlYXJjaEZpbGVzJywgbW9kZTogJ2FzeW5jJywgYnJpZGdlQXV0bzogdHJ1ZSB9LFxuICAgIHsga2V5OiAnY2hhbmdlcycsIG1vZGU6ICdhc3luYycsIGJyaWRnZUF1dG86IGZhbHNlIH0sXG4gICAgeyBrZXk6ICdjaGFuZ2VNYW5pZmVzdHMnLCBtb2RlOiAnYXN5bmMnLCBicmlkZ2VBdXRvOiBmYWxzZSB9LFxuICAgIHsga2V5OiAnY2hhbmdlRGV0YWlsJywgbW9kZTogJ2FzeW5jJywgYnJpZGdlQXV0bzogZmFsc2UgfSxcbiAgICB7IGtleTogJ2NhbmNlbCcsIG1vZGU6ICdhc3luYycsIGJyaWRnZUF1dG86IHRydWUgfSxcbiAgICB7IGtleTogJ2NhbmNlbEJhY2tncm91bmRUYXNrJywgbW9kZTogJ2FzeW5jJywgYnJpZGdlQXV0bzogdHJ1ZSB9LFxuICAgIHsga2V5OiAnZ2V0Q2FwYWNpdHlRdWV1ZVN0YXRlJywgbW9kZTogJ2FzeW5jJywgYnJpZGdlQXV0bzogdHJ1ZSB9LFxuICAgIHsga2V5OiAnY2FuY2VsQ2FwYWNpdHlRdWV1ZScsIG1vZGU6ICdhc3luYycsIGJyaWRnZUF1dG86IHRydWUgfSxcbiAgICB7IGtleTogJ3Jlc2VuZCcsIG1vZGU6ICdhc3luYycsIGJyaWRnZUF1dG86IHRydWUgfSxcbiAgICB7IGtleTogJ3Jld2luZCcsIG1vZGU6ICdhc3luYycsIGJyaWRnZUF1dG86IHRydWUgfSxcbiAgICB7IGtleTogJ2NoZWNrcG9pbnRSZWFkJywgbW9kZTogJ2FzeW5jJywgYnJpZGdlQXV0bzogdHJ1ZSB9LFxuICAgIHsga2V5OiAnZ2V0UGVuZGluZ0luZm8nLCBtb2RlOiAnYXN5bmMnLCBicmlkZ2VBdXRvOiB0cnVlIH0sXG4gICAgeyBrZXk6ICdnZXRDbG91ZFNlcnZpY2VDb25maXJtYXRpb24nLCBtb2RlOiAnYXN5bmMnLCBicmlkZ2VBdXRvOiB0cnVlIH0sXG4gICAgeyBrZXk6ICdnZXRQbHVnaW5SZWNvbW1lbmRhdGlvbicsIG1vZGU6ICdhc3luYycsIGJyaWRnZUF1dG86IHRydWUgfSxcbiAgICB7IGtleTogJ3JlbmFtZScsIG1vZGU6ICdhc3luYycsIGJyaWRnZUF1dG86IHRydWUgfSxcbiAgICB7IGtleTogJ3ByZWxvYWQnLCBtb2RlOiAnZmlyZUFuZEZvcmdldCcsIG9uUmVqZWN0OiAnc2lsZW50JywgYnJpZGdlQXV0bzogZmFsc2UgfSxcbiAgICB7IGtleTogJ2Vuc3VyZVJ1bnRpbWUnLCBtb2RlOiAnZmlyZUFuZEZvcmdldCcsIG9uUmVqZWN0OiAnc2lsZW50JywgYnJpZGdlQXV0bzogZmFsc2UgfSxcbiAgICB7IGtleTogJ3JlbGVhc2VSdW50aW1lSG9sZCcsIG1vZGU6ICdmaXJlQW5kRm9yZ2V0Jywgb25SZWplY3Q6ICdzaWxlbnQnLCBicmlkZ2VBdXRvOiBmYWxzZSB9LFxuICAgIC8vIGFzeW5jXHVGRjA4XHU5NzVFIGZpcmVBbmRGb3JnZXRcdUZGMDlcdUZGMUFVSSBcdTcwQjlcdTUxRkJcdTc1MjhcdTkxQ0ZcdTU3MDZcdTczQUZcdTU0MEVcdTg5ODFcdTc1MjhcdThGRDRcdTU2REVcdTc2ODQgUHJvbWlzZSBcdTY1MzYgbG9hZGluZyBcdTYwMDFcdTMwMDJcbiAgICB7IGtleTogJ3JlZnJlc2hDb250ZXh0VXNhZ2UnLCBtb2RlOiAnYXN5bmMnLCBicmlkZ2VBdXRvOiB0cnVlIH0sXG4gICAgeyBrZXk6ICdyZXNvbHZlUGVuZGluZycsIG1vZGU6ICdzeW5jVm9pZCcsIG9uUmVqZWN0OiAnd2FybicsIGJyaWRnZUF1dG86IHRydWUgfSxcbiAgICB7IGtleTogJ3JlamVjdFBlbmRpbmcnLCBtb2RlOiAnc3luY1ZvaWQnLCBvblJlamVjdDogJ3dhcm4nLCBicmlkZ2VBdXRvOiB0cnVlIH0sXG4gICAgeyBrZXk6ICdsb2cnLCBtb2RlOiAnZmlyZUFuZEZvcmdldCcsIG9uUmVqZWN0OiAnc2lsZW50JywgYnJpZGdlQXV0bzogdHJ1ZSB9LFxuICAgIHsga2V5OiAnbWFya0V4Y2x1ZGVMYXVuY2hTcGVjU2VydmVycycsIG1vZGU6ICdhc3luYycsIGJyaWRnZUF1dG86IHRydWUgfSxcbl0gYXMgY29uc3Qgc2F0aXNmaWVzIHJlYWRvbmx5IE1ldGhvZEJpbmRbXTtcblxuLyoqIFx1OEZERVx1NjNBNVx1NjAwMVx1NjVCOVx1NkNENVx1OTUyRVx1ODA1NFx1NTQwOFx1RkYwOGB0eXBlcy50c2AgXHU3Njg0IGBDb252ZXJzYXRpb25SZW1vdGVNZXRob2RLZXlgIFx1NEVDRVx1NkI2NFx1NkQzRVx1NzUxRlx1RkYwOVx1MzAwMiAqL1xuZXhwb3J0IHR5cGUgV2lyZU1ldGhvZEtleSA9IHR5cGVvZiBNRVRIT0RfQklORFNbbnVtYmVyXVsna2V5J107XG5cbi8qKlxuICogcmVoeWRyYXRlIFx1N0YxNlx1NjM5Mlx1NUM0MioqXHU2MjRCXHU1MTk5XHU4OTg2XHU3NkQ2KipcdTMwMDFcdTRFMERcdTdFQ0YgYGJpbmRSZW1vdGVNZXRob2RzYCBcdTc1MUZcdTYyMTBcdTc2ODRcdTY1QjlcdTZDRDVcdTk1MkVcdUZGMUFcbiAqIC0gYHJlcXVlc3RzYCAvIGByZXF1ZXN0RW50cmllc2BcdUZGMUFcdTk2NDRcdTVFMjYgYGNhY2hlUmVxdWVzdHNgIFx1NTI2Rlx1NEY1Q1x1NzUyOFxuICogLSBgcmVzZW5kYFx1RkYxQVx1NjgzOVx1NjM2RSBtdXRhdGlvbiByZXN1bHQgXHU1NDBDXHU2QjY1IHJlbmRlcmVyIFJlcXVlc3QgY2FjaGVcbiAqIC0gYHJld2luZGBcdUZGMUFcdTU0MEMgcmVzZW5kXHVGRjBDXHU1NkRFXHU5MDAwXHU1NDBFXHU5NzAwXHU2ODM5XHU2MzZFIG11dGF0aW9uIHJlc3VsdCBcdTU0MENcdTZCNjUgcmVuZGVyZXIgUmVxdWVzdCBjYWNoZVxuICogLSBgZ2V0UGVuZGluZ0luZm9gXHVGRjFBXHU4QkZCXHU2NzJDXHU1NzMwXHU3RjEzXHU1QjU4XHVGRjBDXHU0RTBEXHU1OUQ0XHU2MjU4IGNvbnZlcnNhdGlvblxuICogLSBgcHJlbG9hZGBcdUZGMUFmaXJlLWFuZC1mb3JnZXQgXHU0RjQ2XHU0RTBFXHU1MTg1XHU5MEU4IHByZWxvYWQgXHU4OUU2XHU1M0QxXHU3RjE2XHU2MzkyXHU4MDI2XHU1NDA4XG4gKi9cbmV4cG9ydCBjb25zdCBSRUhZRFJBVEVfTUFOVUFMX0tFWVMgPSBbJ3JlcXVlc3RzJywgJ3JlcXVlc3RFbnRyaWVzJywgJ3Jlc2VuZCcsICdyZXdpbmQnLCAnZ2V0UGVuZGluZ0luZm8nLCAncHJlbG9hZCddIGFzIGNvbnN0O1xuXG4vKipcbiAqIGBDb252ZXJzYXRpb25SZW1vdGVBcGlgIFx1NEUwQVx1NEUwRFx1NkQzRVx1NzUxRlx1ODFFQSBgQ29udmVyc2F0aW9uYCBcdTc2ODQgd2lyZS1vbmx5IFx1NjVCOVx1NkNENVx1OTUyRVx1MzAwMlxuICogXHU0RUM1XHU3NTI4XHU0RThFXHU1QjhDXHU1OTA3XHU2MDI3XHU2NUFEXHU4QTAwXHU3Njg0IGV4Y2x1ZGUgXHU5NkM2XHVGRjBDXHU0RTBEXHU1M0MyXHU0RTBFIGBDb252ZXJzYXRpb25bS11gIFx1NjYyMFx1NUMwNFx1MzAwMlxuICovXG5leHBvcnQgY29uc3QgV0lSRV9PTkxZX01FVEhPRF9LRVlTID0gW1xuICAgICdkaXNwb3NlJyxcbiAgICAncXVldWVJdGVtcycsICdxdWV1ZVBhdXNlJywgJ3F1ZXVlUmVzdW1lJywgJ3F1ZXVlRGVsZXRlJywgJ3F1ZXVlTW92ZScsICdxdWV1ZVNlbmROb3cnLFxuICAgICdyZWdpc3RlckNsaWVudFRvb2xzJywgJ3VucmVnaXN0ZXJDbGllbnRUb29scycsXG4gICAgJ2ZpbGVBcnRpZmFjdHMnLCAnZmlsZUZpbGVzJywgJ2ZpbGVDaGFuZ2VzJyxcbiAgICAnY2hpbGRBZ2VudFNuYXBzaG90cycsICdjaGlsZEFnZW50UmVxdWVzdHMnLCAnY2hpbGRBZ2VudExvYWRUb29sRGV0YWlsJyxcbiAgICAnY29uZmlnU2V0TW9kZScsICdjb25maWdTZXRNb2RlbCcsICdjb25maWdTZXRDb25uZWN0b3JzJyxcbiAgICAnY29uZmlnU2V0UGVybWlzc2lvbk1vZGUnLCAnY29uZmlnU2V0U2FuZGJveE1vZGUnLCAnY29uZmlnU2V0VGhvdWdodExldmVsJywgJ2NvbmZpZ1NldFByZU1lc3NhZ2VDb21wYWN0UGN0JywgJ2NvbmZpZ1NldENvbnRleHRXaW5kb3cnLCAnY29uZmlnU2V0RXhwZXJ0JywgJ2NvbmZpZ1NldEV4cGVydElkJyxcbl0gYXMgY29uc3Q7XG5cbi8vIFx1MjUwMFx1MjUwMFx1MjUwMCBcdTRFOEJcdTRFRjZcdTYzQ0ZcdThGRjBcdTdCMjZcdUZGMDhcdTVCOUVcdTRGOEJcdTdFQTcgLyBcdTk2QzZcdTU0MDhcdTdFQTdcdTUxNzFcdTRFQUJcdTVFOTVcdTVFQTdcdUZGMDkgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cbi8qKlxuICogXHU0RTAwXHU0RTJBIGJ1cyBcdTRFOEJcdTRFRjZcdTU3MjhcdTRFMjRcdTU5NTcgc3dpdGNoIFx1OTFDQ1x1NTE3MVx1NEVBQlx1NzY4NFx1NUU5NVx1NUVBN1x1NjNDRlx1OEZGMFx1MzAwMlxuICogYFBgIFx1NjYyRiBldmVudEJ1cyBcdTRFMEFcdTc2ODQgcGF5bG9hZCBcdTdDN0JcdTU3OEJcdUZGMDhcdTRFMDBcdTVCOUFcdTU0MkIgY29udmVyc2F0aW9uSWRcdUZGMDlcdTMwMDJcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBFdmVudEJpbmQ8UCBleHRlbmRzIHsgY29udmVyc2F0aW9uSWQ6IHN0cmluZyB9ID0geyBjb252ZXJzYXRpb25JZDogc3RyaW5nIH0+IHtcbiAgICAvKiogZXZlbnRCdXMgXHU1RTM4XHU5MUNGXHVGRjA4YFdCX0NPTlZFUlNBVElPTl8qYFx1RkYwOVx1MzAwMiAqL1xuICAgIHJlYWRvbmx5IGJ1c0V2ZW50OiBzdHJpbmc7XG4gICAgLyoqIHBoYW50b20gXHU3QzdCXHU1NzhCXHU2ODA3XHU4QkIwIHBheWxvYWQgXHU1RjYyXHU3MkI2XHVGRjBDXHU0RUM1XHU3NTI4XHU0RThFXHU3QzdCXHU1NzhCXHU2M0E4XHU1QkZDXHVGRjBDXHU4RkQwXHU4ODRDXHU2NzFGXHU0RTBEXHU1QjU4XHU1NzI4XHUzMDAyICovXG4gICAgcmVhZG9ubHkgX3BheWxvYWQ/OiBQO1xufVxuXG4vKiogXHU1OEYwXHU2NjBFXHU0RTAwXHU0RTJBIGBFdmVudEJpbmRgIFx1NUU3Nlx1OTUwMVx1NUI5QSBwYXlsb2FkIFx1N0M3Qlx1NTc4Qlx1RkYwOFx1NURFNVx1NTM4Mlx1RkYwQ1x1NEZERFx1NzU1OVx1N0M3Qlx1NTc4Qlx1ODA1NFx1NTJBOFx1RkYwOVx1MzAwMiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGV2ZW50QmluZDxQIGV4dGVuZHMgeyBjb252ZXJzYXRpb25JZDogc3RyaW5nIH0+KGJ1c0V2ZW50OiBzdHJpbmcpOiBFdmVudEJpbmQ8UD4ge1xuICAgIHJldHVybiB7IGJ1c0V2ZW50IH07XG59XG5cbi8qKlxuICogXHU1QjlFXHU0RjhCXHU3RUE3XHU2NjZFXHU5MDFBXHU0RThCXHU0RUY2XHU2NzYxXHU3NkVFXHVGRjFBYGJ1c0V2ZW50YCArIHBheWxvYWQgXHUyMTkyIFx1NTE2Q1x1NUYwMFx1NTZERVx1OEMwM1x1NUI5RVx1NTNDMlx1NTE0M1x1N0VDNFx1RkYwOCoqXHU1MjY1XHU3OUJCIGNvbnZlcnNhdGlvbklkKipcdUZGMDlcdTMwMDJcbiAqIFx1OEJBMlx1OTYwNVx1NjVGNlx1NzUzMSBgb25Db252RXZlbnRgIFx1NTE0OFx1NjMwOSBjb252ZXJzYXRpb25JZCBcdThGQzdcdTZFRTRcdUZGMENcdTUxOEQgYG1hcGAgXHU1MUZBXHU0RTFBXHU1MkExXHU1QjU3XHU2QkI1XHUzMDAyXG4gKiBgUGAgXHU2NjJGIGJ1cyBwYXlsb2FkIFx1N0M3Qlx1NTc4Qlx1RkYwQ2BFYCBcdTY2MkZcdTVCRjlcdTVFOTRcdTc2ODRcdTVCOUVcdTRGOEJcdTdFQTdcdTRFOEJcdTRFRjZcdTMwMDJcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBJbnN0YW5jZUV2ZW50RW50cnk8XG4gICAgUCBleHRlbmRzIHsgY29udmVyc2F0aW9uSWQ6IHN0cmluZyB9LFxuICAgIEUgZXh0ZW5kcyBDb252ZXJzYXRpb25FdmVudCxcbj4ge1xuICAgIHJlYWRvbmx5IGJpbmQ6IEV2ZW50QmluZDxQPjtcbiAgICByZWFkb25seSBtYXA6IChwYXlsb2FkOiBQKSA9PiBSZWFkb25seTxQYXJhbWV0ZXJzPENvbnZlcnNhdGlvbkV2ZW50Q2FsbGJhY2tNYXBbRV0+Pjtcbn1cblxuLyoqXG4gKiBcdTVCOUVcdTRGOEJcdTdFQTdcdTY2NkVcdTkwMUFcdTRFOEJcdTRFRjZcdTg4NjhcdUZGMDhyZWh5ZHJhdGUgYG9uKClgIFx1NzY4NFx1NjY2RVx1OTAxQVx1NjUyRlx1RkYwOVx1MzAwMlxuICogXHU1M0VBXHU4OTg2XHU3NkQ2XHUzMDBDXHU1MzU1XHU2NTJGIGBvbkNvbnZFdmVudChidXMsIGlkLCBtYXApYFx1MzAwRFx1NzY4NFx1NEU4Qlx1NEVGNlx1RkYxQjQgXHU0RTJBXHU3Mjc5XHU0RjhCXG4gKiBcdUZGMDhSZXF1ZXN0VXBkYXRlIC8gUXVldWVVcGRhdGUgLyBSZXF1ZXN0c0NoYW5nZWQgLyBFeHRlbnNpb25NZXRob2RcdUZGMDlcdThENzBcdTYyNEJcdTUxOTlcdUZGMENcdTg5QzEgSU5TVEFOQ0VfU1BFQ0lBTF9FVkVOVFNcdTMwMDJcbiAqL1xuZXhwb3J0IGNvbnN0IElOU1RBTkNFX0VWRU5UX0JJTkRTID0ge1xuICAgIFtDb252ZXJzYXRpb25FdmVudC5TdGF0ZUNoYW5nZV06IHtcbiAgICAgICAgYmluZDogZXZlbnRCaW5kPENvbnZlcnNhdGlvblN0YXRlQ2hhbmdlUGF5bG9hZD4oV0JfQ09OVkVSU0FUSU9OX1NUQVRFX0NIQU5HRSksXG4gICAgICAgIG1hcDogKHA6IENvbnZlcnNhdGlvblN0YXRlQ2hhbmdlUGF5bG9hZCkgPT4gcC5wcm9tcHRSZXNwb25zZU1ldGFcbiAgICAgICAgICAgID8gW1xuICAgICAgICAgICAgICAgIHAuZnJvbSxcbiAgICAgICAgICAgICAgICBwLnRvLFxuICAgICAgICAgICAgICAgIHAuZmluYWxTdGF0ZSxcbiAgICAgICAgICAgICAgICBwLnRlcm1pbmFsRXJyb3IsXG4gICAgICAgICAgICAgICAgcC5pbnRlcnJ1cHRpb24sXG4gICAgICAgICAgICAgICAgcC5wcm9tcHRSZXNwb25zZU1ldGEsXG4gICAgICAgICAgICBdIGFzIGNvbnN0XG4gICAgICAgICAgICA6IHAuaW50ZXJydXB0aW9uXG4gICAgICAgICAgICAgICAgPyBbcC5mcm9tLCBwLnRvLCBwLmZpbmFsU3RhdGUsIHAudGVybWluYWxFcnJvciwgcC5pbnRlcnJ1cHRpb25dIGFzIGNvbnN0XG4gICAgICAgICAgICAgICAgOiBbcC5mcm9tLCBwLnRvLCBwLmZpbmFsU3RhdGUsIHAudGVybWluYWxFcnJvcl0gYXMgY29uc3QsXG4gICAgfSxcbiAgICBbQ29udmVyc2F0aW9uRXZlbnQuSW5mb0NoYW5nZV06IHtcbiAgICAgICAgYmluZDogZXZlbnRCaW5kPENvbnZlcnNhdGlvbkluZm9DaGFuZ2VQYXlsb2FkPihXQl9DT05WRVJTQVRJT05fSU5GT19DSEFOR0UpLFxuICAgICAgICBtYXA6IChwOiBDb252ZXJzYXRpb25JbmZvQ2hhbmdlUGF5bG9hZCkgPT4gW3AuaW5mb10gYXMgY29uc3QsXG4gICAgfSxcbiAgICBbQ29udmVyc2F0aW9uRXZlbnQuQ2FwYWNpdHlRdWV1ZVVwZGF0ZV06IHtcbiAgICAgICAgYmluZDogZXZlbnRCaW5kPENvbnZlcnNhdGlvbkNhcGFjaXR5UXVldWVVcGRhdGVQYXlsb2FkPihXQl9DT05WRVJTQVRJT05fQ0FQQUNJVFlfUVVFVUVfVVBEQVRFKSxcbiAgICAgICAgbWFwOiAocDogQ29udmVyc2F0aW9uQ2FwYWNpdHlRdWV1ZVVwZGF0ZVBheWxvYWQpID0+IFtwXSBhcyBjb25zdCxcbiAgICB9LFxuICAgIFtDb252ZXJzYXRpb25FdmVudC5BcnRpZmFjdFVwZGF0ZV06IHtcbiAgICAgICAgYmluZDogZXZlbnRCaW5kPENvbnZlcnNhdGlvbk1hbmFnZXJVcGRhdGVQYXlsb2FkPihXQl9DT05WRVJTQVRJT05fQVJUSUZBQ1RfVVBEQVRFKSxcbiAgICAgICAgbWFwOiAoX3A6IENvbnZlcnNhdGlvbk1hbmFnZXJVcGRhdGVQYXlsb2FkKSA9PiBbXSBhcyBjb25zdCxcbiAgICB9LFxuICAgIFtDb252ZXJzYXRpb25FdmVudC5XYXJuaW5nXToge1xuICAgICAgICBiaW5kOiBldmVudEJpbmQ8Q29udmVyc2F0aW9uV2FybmluZ1BheWxvYWQ+KFdCX0NPTlZFUlNBVElPTl9XQVJOSU5HKSxcbiAgICAgICAgbWFwOiAocDogQ29udmVyc2F0aW9uV2FybmluZ1BheWxvYWQpID0+IFtwLmluZm9dIGFzIGNvbnN0LFxuICAgIH0sXG4gICAgW0NvbnZlcnNhdGlvbkV2ZW50LlByZXBhcmVTdGF0dXNdOiB7XG4gICAgICAgIGJpbmQ6IGV2ZW50QmluZDxDb252ZXJzYXRpb25QcmVwYXJlU3RhdHVzUGF5bG9hZD4oV0JfQ09OVkVSU0FUSU9OX1BSRVBBUkVfU1RBVFVTKSxcbiAgICAgICAgbWFwOiAocDogQ29udmVyc2F0aW9uUHJlcGFyZVN0YXR1c1BheWxvYWQpID0+IFtwLnN0YXR1c10gYXMgY29uc3QsXG4gICAgfSxcbiAgICBbQ29udmVyc2F0aW9uRXZlbnQuTWNwU3RhcnR1cFN0YXR1c106IHtcbiAgICAgICAgYmluZDogZXZlbnRCaW5kPENvbnZlcnNhdGlvbk1jcFN0YXJ0dXBTdGF0dXNQYXlsb2FkPihXQl9DT05WRVJTQVRJT05fTUNQX1NUQVJUVVBfU1RBVFVTKSxcbiAgICAgICAgbWFwOiAocDogQ29udmVyc2F0aW9uTWNwU3RhcnR1cFN0YXR1c1BheWxvYWQpID0+IFtwLnN0YXR1c10gYXMgY29uc3QsXG4gICAgfSxcbiAgICBbQ29udmVyc2F0aW9uRXZlbnQuUGVuZGluZ1JlcXVlc3RdOiB7XG4gICAgICAgIGJpbmQ6IGV2ZW50QmluZDxDb252ZXJzYXRpb25QZXJtaXNzaW9uUGF5bG9hZD4oV0JfQ09OVkVSU0FUSU9OX1BFUk1JU1NJT04pLFxuICAgICAgICBtYXA6IChwOiBDb252ZXJzYXRpb25QZXJtaXNzaW9uUGF5bG9hZCkgPT4gW3AucGVybWlzc2lvbl0gYXMgY29uc3QsXG4gICAgfSxcbiAgICBbQ29udmVyc2F0aW9uRXZlbnQuUGx1Z2luUmVjb21tZW5kYXRpb25DaGFuZ2VkXToge1xuICAgICAgICBiaW5kOiBldmVudEJpbmQ8Q29udmVyc2F0aW9uUGx1Z2luUmVjb21tZW5kYXRpb25DaGFuZ2VkUGF5bG9hZD4oXG4gICAgICAgICAgICBXQl9DT05WRVJTQVRJT05fUExVR0lOX1JFQ09NTUVOREFUSU9OX0NIQU5HRUQsXG4gICAgICAgICksXG4gICAgICAgIG1hcDogKHA6IENvbnZlcnNhdGlvblBsdWdpblJlY29tbWVuZGF0aW9uQ2hhbmdlZFBheWxvYWQpID0+IFtwLnJlY29tbWVuZGF0aW9uXSBhcyBjb25zdCxcbiAgICB9LFxuICAgIFtDb252ZXJzYXRpb25FdmVudC5DbG91ZFNlcnZpY2VDb25maXJtYXRpb25DaGFuZ2VkXToge1xuICAgICAgICBiaW5kOiBldmVudEJpbmQ8Q29udmVyc2F0aW9uQ2xvdWRTZXJ2aWNlQ29uZmlybWF0aW9uQ2hhbmdlZFBheWxvYWQ+KFxuICAgICAgICAgICAgV0JfQ09OVkVSU0FUSU9OX0NMT1VEX1NFUlZJQ0VfQ09ORklSTUFUSU9OX0NIQU5HRUQsXG4gICAgICAgICksXG4gICAgICAgIG1hcDogKHA6IENvbnZlcnNhdGlvbkNsb3VkU2VydmljZUNvbmZpcm1hdGlvbkNoYW5nZWRQYXlsb2FkKSA9PiBbcC5jb25maXJtYXRpb25dIGFzIGNvbnN0LFxuICAgIH0sXG4gICAgW0NvbnZlcnNhdGlvbkV2ZW50Lkhpc3RvcnlMb2FkZWRdOiB7XG4gICAgICAgIGJpbmQ6IGV2ZW50QmluZDxDb252ZXJzYXRpb25IaXN0b3J5TG9hZGVkUGF5bG9hZD4oV0JfQ09OVkVSU0FUSU9OX0hJU1RPUllfTE9BREVEKSxcbiAgICAgICAgbWFwOiAoX3A6IENvbnZlcnNhdGlvbkhpc3RvcnlMb2FkZWRQYXlsb2FkKSA9PiBbXSBhcyBjb25zdCxcbiAgICB9LFxuICAgIFtDb252ZXJzYXRpb25FdmVudC5DcmVkaXRDaGFuZ2VkXToge1xuICAgICAgICBiaW5kOiBldmVudEJpbmQ8Q29udmVyc2F0aW9uQ3JlZGl0Q2hhbmdlZEV2ZW50UGF5bG9hZD4oV0JfQ09OVkVSU0FUSU9OX0NSRURJVF9DSEFOR0VEKSxcbiAgICAgICAgbWFwOiAocDogQ29udmVyc2F0aW9uQ3JlZGl0Q2hhbmdlZEV2ZW50UGF5bG9hZCkgPT4gW3sgcmVxdWVzdElkOiBwLnJlcXVlc3RJZCwgY29zdDogcC5jb3N0IH1dIGFzIGNvbnN0LFxuICAgIH0sXG4gICAgW0NvbnZlcnNhdGlvbkV2ZW50LkNvbnRleHRVc2FnZUNoYW5nZWRdOiB7XG4gICAgICAgIGJpbmQ6IGV2ZW50QmluZDxDb252ZXJzYXRpb25Db250ZXh0VXNhZ2VDaGFuZ2VkRXZlbnRQYXlsb2FkPihXQl9DT05WRVJTQVRJT05fQ09OVEVYVF9VU0FHRV9DSEFOR0VEKSxcbiAgICAgICAgbWFwOiAocDogQ29udmVyc2F0aW9uQ29udGV4dFVzYWdlQ2hhbmdlZEV2ZW50UGF5bG9hZCkgPT4gW3tcbiAgICAgICAgICAgIHRvdGFsVG9rZW5zOiBwLnRvdGFsVG9rZW5zLFxuICAgICAgICAgICAgY29udGV4dFdpbmRvdzogcC5jb250ZXh0V2luZG93LFxuICAgICAgICAgICAgLi4uKHAuYnlDYXRlZ29yeSA/IHsgYnlDYXRlZ29yeTogcC5ieUNhdGVnb3J5IH0gOiB7fSksXG4gICAgICAgIH1dIGFzIGNvbnN0LFxuICAgIH0sXG4gICAgW0NvbnZlcnNhdGlvbkV2ZW50LkVzdGltYXRlZENvc3RDaGFuZ2VkXToge1xuICAgICAgICBiaW5kOiBldmVudEJpbmQ8Q29udmVyc2F0aW9uRXN0aW1hdGVkQ29zdENoYW5nZWRFdmVudFBheWxvYWQ+KFdCX0NPTlZFUlNBVElPTl9FU1RJTUFURURfQ09TVF9DSEFOR0VEKSxcbiAgICAgICAgbWFwOiAocDogQ29udmVyc2F0aW9uRXN0aW1hdGVkQ29zdENoYW5nZWRFdmVudFBheWxvYWQpID0+XG4gICAgICAgICAgICBbeyByZXF1ZXN0SWQ6IHAucmVxdWVzdElkLCBlc3RpbWF0ZWRDb3N0OiBwLmVzdGltYXRlZENvc3QgfV0gYXMgY29uc3QsXG4gICAgfSxcbiAgICBbQ29udmVyc2F0aW9uRXZlbnQuQ29tbWFuZHNVcGRhdGVdOiB7XG4gICAgICAgIGJpbmQ6IGV2ZW50QmluZDxDb252ZXJzYXRpb25Db21tYW5kc1VwZGF0ZVBheWxvYWQ+KFdCX0NPTlZFUlNBVElPTl9DT01NQU5EU19VUERBVEUpLFxuICAgICAgICBtYXA6IChwOiBDb252ZXJzYXRpb25Db21tYW5kc1VwZGF0ZVBheWxvYWQpID0+IFtwXSBhcyBjb25zdCxcbiAgICB9LFxuICAgIFtDb252ZXJzYXRpb25FdmVudC5Nb2RlQ2hhbmdlXToge1xuICAgICAgICBiaW5kOiBldmVudEJpbmQ8Q29udmVyc2F0aW9uTW9kZUNoYW5nZVBheWxvYWQ+KFdCX0NPTlZFUlNBVElPTl9NT0RFX0NIQU5HRSksXG4gICAgICAgIG1hcDogKHA6IENvbnZlcnNhdGlvbk1vZGVDaGFuZ2VQYXlsb2FkKSA9PiBbcF0gYXMgY29uc3QsXG4gICAgfSxcbiAgICBbQ29udmVyc2F0aW9uRXZlbnQuQ29uZmlnVXBkYXRlXToge1xuICAgICAgICBiaW5kOiBldmVudEJpbmQ8Q29udmVyc2F0aW9uQ29uZmlnVXBkYXRlUGF5bG9hZD4oV0JfQ09OVkVSU0FUSU9OX0NPTkZJR19VUERBVEUpLFxuICAgICAgICBtYXA6IChwOiBDb252ZXJzYXRpb25Db25maWdVcGRhdGVQYXlsb2FkKSA9PiBbcF0gYXMgY29uc3QsXG4gICAgfSxcbiAgICBbQ29udmVyc2F0aW9uRXZlbnQuTW9kZWxDaGFuZ2VdOiB7XG4gICAgICAgIGJpbmQ6IGV2ZW50QmluZDxDb252ZXJzYXRpb25Nb2RlbENoYW5nZVBheWxvYWQ+KFdCX0NPTlZFUlNBVElPTl9NT0RFTF9DSEFOR0UpLFxuICAgICAgICBtYXA6IChwOiBDb252ZXJzYXRpb25Nb2RlbENoYW5nZVBheWxvYWQpID0+IFtwXSBhcyBjb25zdCxcbiAgICB9LFxuICAgIFtDb252ZXJzYXRpb25FdmVudC5UaW1lbGluZUV2ZW50XToge1xuICAgICAgICBiaW5kOiBldmVudEJpbmQ8Q29udmVyc2F0aW9uVGltZWxpbmVFdmVudEJ1c1BheWxvYWQ+KFdCX0NPTlZFUlNBVElPTl9USU1FTElORV9FVkVOVCksXG4gICAgICAgIG1hcDogKHA6IENvbnZlcnNhdGlvblRpbWVsaW5lRXZlbnRCdXNQYXlsb2FkKSA9PiBbcF0gYXMgY29uc3QsXG4gICAgfSxcbiAgICBbQ29udmVyc2F0aW9uRXZlbnQuTW9kZXNVcGRhdGVdOiB7XG4gICAgICAgIGJpbmQ6IGV2ZW50QmluZDxDb252ZXJzYXRpb25Nb2Rlc1VwZGF0ZVBheWxvYWQ+KFdCX0NPTlZFUlNBVElPTl9NT0RFU19VUERBVEUpLFxuICAgICAgICBtYXA6IChwOiBDb252ZXJzYXRpb25Nb2Rlc1VwZGF0ZVBheWxvYWQpID0+IFtwXSBhcyBjb25zdCxcbiAgICB9LFxuICAgIFtDb252ZXJzYXRpb25FdmVudC5QbGFuVXBkYXRlXToge1xuICAgICAgICBiaW5kOiBldmVudEJpbmQ8Q29udmVyc2F0aW9uUGxhblVwZGF0ZVBheWxvYWQ+KFdCX0NPTlZFUlNBVElPTl9QTEFOX1VQREFURSksXG4gICAgICAgIG1hcDogKHA6IENvbnZlcnNhdGlvblBsYW5VcGRhdGVQYXlsb2FkKSA9PiBbcF0gYXMgY29uc3QsXG4gICAgfSxcbn0gYXMgY29uc3Q7XG5cbi8qKiBcdTVCOUVcdTRGOEJcdTdFQTdcdTRFOEJcdTRFRjZcdTcyNzlcdTRGOEJcdUZGMDhcdTRGRERcdTc1NTlcdTYyNEJcdTUxOTlcdUZGMENcdTRFMERcdThGREJcdTY2NkVcdTkwMUFcdTg4NjhcdUZGMDlcdTMwMDIgKi9cbmV4cG9ydCBjb25zdCBJTlNUQU5DRV9TUEVDSUFMX0VWRU5UUyA9IFtcbiAgICBDb252ZXJzYXRpb25FdmVudC5SZXF1ZXN0VXBkYXRlLFxuICAgIENvbnZlcnNhdGlvbkV2ZW50LlF1ZXVlVXBkYXRlLFxuICAgIENvbnZlcnNhdGlvbkV2ZW50LlJlcXVlc3RzQ2hhbmdlZCxcbiAgICBDb252ZXJzYXRpb25FdmVudC5FeHRlbnNpb25NZXRob2QsXG4gICAgLy8gXHU3NTMxIGF0dGFjaENvbnZlcnNhdGlvblByb21wdE9wZXJhdGlvbnMgXHU1N0ZBXHU0RThFIFJlcXVlc3RzQ2hhbmdlZCBcdTU3MjhcdTU0MDRcdThGREJcdTdBMEJcdTY3MkNcdTU3MzBcdTZEM0VcdTc1MUZcdUZGMENcbiAgICAvLyBcdTRFMERcdTU4OUVcdTUyQTBcdTkxQ0RcdTU5MERcdTc2ODQgd2lyZSBidXNcdTMwMDJcbiAgICBDb252ZXJzYXRpb25FdmVudC5BdXRvbWF0aW9uQ29tcGxldGVkLFxuICAgIENvbnZlcnNhdGlvbkV2ZW50LkF1dG9tYXRpb25GYWlsZWQsXG4gICAgQ29udmVyc2F0aW9uRXZlbnQuQXV0b21hdGlvbkNhbmNlbGxlZCxcbiAgICBDb252ZXJzYXRpb25FdmVudC5BdXRvbWF0aW9uVGltZWRPdXQsXG5dIGFzIGNvbnN0O1xuXG4vKipcbiAqIFx1OTZDNlx1NTQwOFx1N0VBN1x1NjY2RVx1OTAxQVx1NEU4Qlx1NEVGNlx1Njc2MVx1NzZFRVx1RkYxQXBheWxvYWQgXHUyMTkyIFx1NTE2Q1x1NUYwMFx1NTZERVx1OEMwM1x1NUI5RVx1NTNDMlx1NTE0M1x1N0VDNFx1RkYwOCoqXHU0RkREXHU3NTU5IGNvbnZlcnNhdGlvbklkIFx1NEY1Q1x1OTk5Nlx1NTNDMioqXHVGRjA5XHUzMDAyXG4gKiBcdTc1MzEgYGV2ZW50QnVzLm9uKGJ1c0V2ZW50LCAuLi4pYCBcdTc2RjRcdTYzQTVcdThCQTJcdTk2MDVcdUZGMDhcdTRFMERcdTYzMDkgaWQgXHU4RkM3XHU2RUU0XHVGRjA5XHUzMDAyXG4gKiBgUGAgXHU2NjJGIGJ1cyBwYXlsb2FkIFx1N0M3Qlx1NTc4Qlx1RkYwQ2BFYCBcdTY2MkZcdTVCRjlcdTVFOTRcdTc2ODRcdTk2QzZcdTU0MDhcdTdFQTdcdTRFOEJcdTRFRjZcdTMwMDJcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBDb2xsZWN0aW9uRXZlbnRFbnRyeTxcbiAgICBQIGV4dGVuZHMgeyBjb252ZXJzYXRpb25JZDogc3RyaW5nIH0sXG4gICAgRSBleHRlbmRzIENvbnZlcnNhdGlvbnNFdmVudCxcbj4ge1xuICAgIHJlYWRvbmx5IGJpbmQ6IEV2ZW50QmluZDxQPjtcbiAgICByZWFkb25seSBtYXA6IChwYXlsb2FkOiBQKSA9PiBSZWFkb25seTxQYXJhbWV0ZXJzPENvbnZlcnNhdGlvbnNFdmVudENhbGxiYWNrTWFwW0VdPj47XG59XG5cbi8qKlxuICogXHU5NkM2XHU1NDA4XHU3RUE3XHU2NjZFXHU5MDFBXHU0RThCXHU0RUY2XHU4ODY4XHVGRjA4YGluZGV4LnRzYCBcdTc2ODQgYHN1YnNjcmliZUNvbGxlY3Rpb25FdmVudGAgXHU2NjZFXHU5MDFBXHU2NTJGXHVGRjA5XHUzMDAyXG4gKiAyIFx1NEUyQVx1NzI3OVx1NEY4Qlx1RkYwOExpc3RDaGFuZ2UgLyBSZXF1ZXN0VXBkYXRlZFx1RkYwOVx1OEQ3MFx1NjI0Qlx1NTE5OVx1RkYwQ1x1ODlDMSBDT0xMRUNUSU9OX1NQRUNJQUxfRVZFTlRTXHUzMDAyXG4gKlxuICogXHU0RTBFXHU1QjlFXHU0RjhCXHU3RUE3XHU1MTcxXHU0RUFCXHU1NDBDXHU0RTAwXHU2Mjc5IGBXQl9DT05WRVJTQVRJT05fKmAgYnVzIFx1NUUzOFx1OTFDRlx1RkYwQ1x1NURFRVx1NUYwMlx1NTNFQVx1NTcyOCBtYXAgXHU0RkREXHU3NTU5IGNvbnZlcnNhdGlvbklkXHUzMDAyXG4gKi9cbmV4cG9ydCBjb25zdCBDT0xMRUNUSU9OX0VWRU5UX0JJTkRTID0ge1xuICAgIFtDb252ZXJzYXRpb25zRXZlbnQuQWdlbnRUZWFtQ2hhbmdlZF06IHtcbiAgICAgICAgYmluZDogZXZlbnRCaW5kPENvbnZlcnNhdGlvbkNoaWxkQWdlbnRFdmVudFBheWxvYWQ+KFdCX0NPTlZFUlNBVElPTl9DSElMRF9BR0VOVF9FVkVOVCksXG4gICAgICAgIG1hcDogKHA6IENvbnZlcnNhdGlvbkNoaWxkQWdlbnRFdmVudFBheWxvYWQpID0+IFtwLmNvbnZlcnNhdGlvbklkLCBwLmV2ZW50XSBhcyBjb25zdCxcbiAgICB9LFxuICAgIFtDb252ZXJzYXRpb25zRXZlbnQuU3RhdGVDaGFuZ2VkXToge1xuICAgICAgICBiaW5kOiBldmVudEJpbmQ8Q29udmVyc2F0aW9uU3RhdGVDaGFuZ2VQYXlsb2FkPihXQl9DT05WRVJTQVRJT05fU1RBVEVfQ0hBTkdFKSxcbiAgICAgICAgbWFwOiAocDogQ29udmVyc2F0aW9uU3RhdGVDaGFuZ2VQYXlsb2FkKSA9PiBbcC5jb252ZXJzYXRpb25JZCwgcC5mcm9tLCBwLnRvXSBhcyBjb25zdCxcbiAgICB9LFxuICAgIFtDb252ZXJzYXRpb25zRXZlbnQuSW5mb0NoYW5nZWRdOiB7XG4gICAgICAgIGJpbmQ6IGV2ZW50QmluZDxDb252ZXJzYXRpb25JbmZvQ2hhbmdlUGF5bG9hZD4oV0JfQ09OVkVSU0FUSU9OX0lORk9fQ0hBTkdFKSxcbiAgICAgICAgbWFwOiAocDogQ29udmVyc2F0aW9uSW5mb0NoYW5nZVBheWxvYWQpID0+IFtwLmNvbnZlcnNhdGlvbklkLCBwLmluZm9dIGFzIGNvbnN0LFxuICAgIH0sXG4gICAgW0NvbnZlcnNhdGlvbnNFdmVudC5RdWV1ZVVwZGF0ZWRdOiB7XG4gICAgICAgIGJpbmQ6IGV2ZW50QmluZDxDb252ZXJzYXRpb25NYW5hZ2VyVXBkYXRlUGF5bG9hZD4oV0JfQ09OVkVSU0FUSU9OX1FVRVVFX1VQREFURSksXG4gICAgICAgIG1hcDogKHA6IENvbnZlcnNhdGlvbk1hbmFnZXJVcGRhdGVQYXlsb2FkKSA9PiBbcC5jb252ZXJzYXRpb25JZF0gYXMgY29uc3QsXG4gICAgfSxcbiAgICBbQ29udmVyc2F0aW9uc0V2ZW50LkFydGlmYWN0VXBkYXRlZF06IHtcbiAgICAgICAgYmluZDogZXZlbnRCaW5kPENvbnZlcnNhdGlvbk1hbmFnZXJVcGRhdGVQYXlsb2FkPihXQl9DT05WRVJTQVRJT05fQVJUSUZBQ1RfVVBEQVRFKSxcbiAgICAgICAgbWFwOiAocDogQ29udmVyc2F0aW9uTWFuYWdlclVwZGF0ZVBheWxvYWQpID0+IFtwLmNvbnZlcnNhdGlvbklkXSBhcyBjb25zdCxcbiAgICB9LFxuICAgIFtDb252ZXJzYXRpb25zRXZlbnQuV2FybmluZ106IHtcbiAgICAgICAgYmluZDogZXZlbnRCaW5kPENvbnZlcnNhdGlvbldhcm5pbmdQYXlsb2FkPihXQl9DT05WRVJTQVRJT05fV0FSTklORyksXG4gICAgICAgIG1hcDogKHA6IENvbnZlcnNhdGlvbldhcm5pbmdQYXlsb2FkKSA9PiBbcC5jb252ZXJzYXRpb25JZCwgcC5pbmZvXSBhcyBjb25zdCxcbiAgICB9LFxufSBhcyBjb25zdDtcblxuLyoqIFx1OTZDNlx1NTQwOFx1N0VBN1x1NEU4Qlx1NEVGNlx1NzI3OVx1NEY4Qlx1RkYwOFx1NEZERFx1NzU1OVx1NjI0Qlx1NTE5OVx1RkYwOVx1MzAwMiAqL1xuZXhwb3J0IGNvbnN0IENPTExFQ1RJT05fU1BFQ0lBTF9FVkVOVFMgPSBbXG4gICAgQ29udmVyc2F0aW9uc0V2ZW50Lkxpc3RDaGFuZ2UsXG4gICAgQ29udmVyc2F0aW9uc0V2ZW50LlJlcXVlc3RVcGRhdGVkLFxuXSBhcyBjb25zdDtcblxuLy8gXHUyNTAwXHUyNTAwXHUyNTAwIFx1NUI4Q1x1NTkwN1x1NjAyN1x1NjVBRFx1OEEwMFx1RkYwOFx1N0YxNlx1OEJEMVx1NjcxRlx1RkYwOSBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblxuLyoqXG4gKiBcdTdGMTZcdThCRDFcdTY3MUZcdTVCOENcdTU5MDdcdTYwMjdcdTY1QURcdThBMDBcdUZGMDhcdTdFQUZcdTdDN0JcdTU3OEJcdUZGMENcdTY1RTBcdThGRDBcdTg4NENcdTY3MUZcdTVGMDBcdTk1MDBcdUZGMDlcdUZGMUFcbiAqIC0gXHU2NUI5XHU2Q0Q1XHU4ODY4XHU2QkNGXHU0RTJBIGtleSBcdTVGQzVcdTk4N0IgXHUyMjA4IGtleW9mIENvbnZlcnNhdGlvblx1RkYwOGBzYXRpc2ZpZXNgIFx1NURGMlx1NEZERFx1OEJDMVx1RkYwQ1x1NkI2NFx1NTkwNFx1NjYzRVx1NUYwRlx1NTE5N1x1NEY1OVx1OTUwMVx1NkI3Qlx1RkYwOVx1MzAwMlxuICogLSBcdTVCOUVcdTRGOEJcdTdFQTcgLyBcdTk2QzZcdTU0MDhcdTdFQTdcdTMwMENcdTY2NkVcdTkwMUFcdTg4NjggXHUyMjJBIFx1NzI3OVx1NEY4Qlx1OTZDNlx1MzAwRFx1NUZDNVx1OTg3Qlx1ODk4Nlx1NzZENlx1NUJGOVx1NUU5NFx1NEU4Qlx1NEVGNlx1NTE2OFx1Njc5QVx1NEUzRVx1RkYxQlx1N0YzQVx1NEUwMFx1NTIxOSBgRXhjbHVkZWAgXHU5NzVFIGBuZXZlcmBcdUZGMENcbiAqICAgYEFzc2VydE5ldmVyYCBcdTdFQTZcdTY3NUZcdTg5RTZcdTUzRDFcdTdGMTZcdThCRDFcdTdFQTJcdTMwMDJcdThGRDBcdTg4NENcdTY3MUZcdTVCOENcdTU5MDdcdTYwMjdcdTc1MzEgYHdpcmUtZGVzY3JpcHRvci5zcGVjLnRzYCBcdTUzQ0NcdTRGRERcdTk2NjlcdTMwMDJcbiAqL1xudHlwZSBBc3NlcnRUcnVlPFQgZXh0ZW5kcyB0cnVlPiA9IFQ7XG50eXBlIEFzc2VydE5ldmVyPFQgZXh0ZW5kcyBuZXZlcj4gPSBUO1xuXG50eXBlIEluc3RhbmNlSGFuZGxlZEV2ZW50ID0ga2V5b2YgdHlwZW9mIElOU1RBTkNFX0VWRU5UX0JJTkRTIHwgdHlwZW9mIElOU1RBTkNFX1NQRUNJQUxfRVZFTlRTW251bWJlcl07XG50eXBlIENvbGxlY3Rpb25IYW5kbGVkRXZlbnQgPSBrZXlvZiB0eXBlb2YgQ09MTEVDVElPTl9FVkVOVF9CSU5EUyB8IHR5cGVvZiBDT0xMRUNUSU9OX1NQRUNJQUxfRVZFTlRTW251bWJlcl07XG5cbi8qKlxuICogXHU3RjE2XHU4QkQxXHU2NzFGXHU1QjhDXHU1OTA3XHU2MDI3XHU2NUFEXHU4QTAwXHU2QzQ3XHU2MDNCXHVGRjA4XHU1QkZDXHU1MUZBXHU0RUU1XHU5MDdGXHU1MTREIGBub1VudXNlZExvY2Fsc2BcdUZGMUJcdTdFQUZcdTdDN0JcdTU3OEJcdUZGMENcdTY1RTBcdThGRDBcdTg4NENcdTY3MUZcdTRFQTdcdTcyNjlcdUZGMDlcdTMwMDJcbiAqIFx1NEVGQlx1NEUwMFx1NTE0M1x1N0QyMFx1N0VBNlx1Njc1Rlx1NEUwRFx1NkVFMVx1OERCM1x1NTM3M1x1N0YxNlx1OEJEMVx1N0VBMlx1MzAwMlxuICovXG5leHBvcnQgdHlwZSBXaXJlQ29tcGxldGVuZXNzQXNzZXJ0aW9ucyA9IFtcbiAgICBBc3NlcnRUcnVlPFdpcmVNZXRob2RLZXkgZXh0ZW5kcyBrZXlvZiBDb252ZXJzYXRpb24gPyB0cnVlIDogZmFsc2U+LFxuICAgIEFzc2VydE5ldmVyPEV4Y2x1ZGU8Q29udmVyc2F0aW9uRXZlbnQsIEluc3RhbmNlSGFuZGxlZEV2ZW50Pj4sXG4gICAgQXNzZXJ0TmV2ZXI8RXhjbHVkZTxDb252ZXJzYXRpb25zRXZlbnQsIENvbGxlY3Rpb25IYW5kbGVkRXZlbnQ+Pixcbl07XG4iLCAiaW1wb3J0IHtcbiAgICB0eXBlIEFwaUVycm9yLFxuICAgIHR5cGUgQ29udmVyc2F0aW9uLFxuICAgIHR5cGUgQ29udmVyc2F0aW9uSW5mbyxcbiAgICB0eXBlIENvbnZlcnNhdGlvblRyYW5zcG9ydCxcbn0gZnJvbSAnLi4vY29tbW9uL3R5cGVzJztcbmltcG9ydCB0eXBlIHsgQ29udmVyc2F0aW9uQnJpZGdlIH0gZnJvbSAnLi9icmlkZ2UnO1xuaW1wb3J0IHR5cGUgeyBDb252ZXJzYXRpb25zQXBpIH0gZnJvbSAnLi9pbmRleCc7XG5pbXBvcnQgdHlwZSB7XG4gICAgUmVtb3RlQ29udmVyc2F0aW9uQ29ubmVjdG9yU25hcHNob3QsXG4gICAgUmVtb3RlQ29udmVyc2F0aW9uU25hcHNob3QsXG59IGZyb20gJy4vcmVoeWRyYXRlJztcbmltcG9ydCB7IHRvUmVtb3RlSnNvblZhbHVlIH0gZnJvbSAnLi9yZW1vdGUtanNvbic7XG5pbXBvcnQgdHlwZSB7IENvbnZlcnNhdGlvblJlbW90ZUFwaSB9IGZyb20gJy4vdHlwZXMnO1xuaW1wb3J0IHsgTUVUSE9EX0JJTkRTLCBXSVJFX09OTFlfTUVUSE9EX0tFWVMsIHR5cGUgV2lyZU1ldGhvZEtleSB9IGZyb20gJy4vd2lyZS1kZXNjcmlwdG9yJztcblxuZnVuY3Rpb24gaXNBcGlFcnJvcih2YWx1ZTogQ29udmVyc2F0aW9uIHwgQXBpRXJyb3IpOiB2YWx1ZSBpcyBBcGlFcnJvciB7XG4gICAgcmV0dXJuIHR5cGVvZiB2YWx1ZSA9PT0gJ29iamVjdCcgJiYgdmFsdWUgIT09IG51bGwgJiYgJ2Vycm9yQ29kZScgaW4gdmFsdWUgJiYgJ21lc3NhZ2UnIGluIHZhbHVlO1xufVxuXG4vKipcbiAqIENtZCtRIFx1NzUyOFx1RkYxQVx1NjI4QSBwb29sIFx1NkQzQlx1NUI5RVx1NEY4Qlx1NjI5NVx1NjIxMCBDb252ZXJzYXRpb25JbmZvXHUzMDAyXG4gKiBcdTRFM0IgaWRsZSArIFx1NUI1MC9cdTU0MEVcdTUzRjAgYnVzeSBcdTY1RjZcdTYyQUNcdTYyMTAgd29ya2luZ1x1RkYwQ1x1NEUwRSBMb2NhbENvbnZlcnNhdGlvbnNJbXBsLnRvQ29udmVyc2F0aW9uSW5mbyBcdTUzRTNcdTVGODRcdTVCRjlcdTlGNTBcdTMwMDJcbiAqL1xuZnVuY3Rpb24gdG9RdWl0TGl2ZUNvbnZlcnNhdGlvbkluZm8oY29udmVyc2F0aW9uOiBDb252ZXJzYXRpb24pOiBDb252ZXJzYXRpb25JbmZvIHtcbiAgICBjb25zdCBpbmZvID0gY29udmVyc2F0aW9uLmluZm87XG4gICAgY29uc3QgaGFzQWN0aXZlQ2hpbGRBZ2VudHMgPSBpbmZvLmhhc0FjdGl2ZUNoaWxkQWdlbnRzID09PSB0cnVlO1xuICAgIGNvbnN0IGhhc1J1bm5pbmdCYWNrZ3JvdW5kVGFza3MgPSBpbmZvLmhhc1J1bm5pbmdCYWNrZ3JvdW5kVGFza3MgPT09IHRydWU7XG4gICAgY29uc3Qgc3RhdGUgPSBpbmZvLnN0YXRlID09PSAnaWRsZScgJiYgKGhhc0FjdGl2ZUNoaWxkQWdlbnRzIHx8IGhhc1J1bm5pbmdCYWNrZ3JvdW5kVGFza3MpXG4gICAgICAgID8gJ3dvcmtpbmcnXG4gICAgICAgIDogaW5mby5zdGF0ZTtcbiAgICByZXR1cm4ge1xuICAgICAgICAuLi5pbmZvLFxuICAgICAgICBzdGF0ZSxcbiAgICAgICAgaGFzQWN0aXZlQ2hpbGRBZ2VudHMsXG4gICAgICAgIGhhc1J1bm5pbmdCYWNrZ3JvdW5kVGFza3MsXG4gICAgfTtcbn1cblxuZnVuY3Rpb24gdG9SZW1vdGVDb25uZWN0b3JTbmFwc2hvdChjb25uZWN0b3I6IENvbnZlcnNhdGlvblsnY29uZmlnTWFuYWdlciddWydjb25uZWN0b3JzJ11bbnVtYmVyXSk6IFJlbW90ZUNvbnZlcnNhdGlvbkNvbm5lY3RvclNuYXBzaG90IHtcbiAgICBjb25zdCByZXN1bHQgPSB0b1JlbW90ZUpzb25WYWx1ZShjb25uZWN0b3IsIG5ldyBXZWFrU2V0KCkpO1xuICAgIGNvbnN0IGRhdGEgPSByZXN1bHQgJiYgIUFycmF5LmlzQXJyYXkocmVzdWx0KSAmJiB0eXBlb2YgcmVzdWx0ID09PSAnb2JqZWN0JyA/IHJlc3VsdCA6IHt9O1xuICAgIHJldHVybiB7XG4gICAgICAgIC4uLmRhdGEsXG4gICAgICAgIC4uLihjb25uZWN0b3IuaWQgPyB7IGlkOiBjb25uZWN0b3IuaWQgfSA6IHt9KSxcbiAgICAgICAgbmFtZTogY29ubmVjdG9yLm5hbWUsXG4gICAgfTtcbn1cblxuLyoqXG4gKiBcdThERTggYnJpZGdlIFx1NTNFQVx1NEYyMFx1OEY5MyByZW5kZXJlciBcdTkxQ0RcdTVFRkEgQ29udmVyc2F0aW9uIFx1NjI0MFx1OTcwMFx1NzY4NFx1N0VBRlx1NjU3MFx1NjM2RVx1NUZFQlx1NzE2N1x1MzAwMlxuICogZGFlbW9uIFx1NTE4NVx1NzY4NCBDb25uZWN0aW9uXHUzMDAxbWFuYWdlclx1MzAwMXdvcmtlci9hZ2VudC90cmFuc3BvcnQgXHU3QjQ5XHU4RkQwXHU4ODRDXHU2NUY2XHU1QkY5XHU4QzYxXHU0RTAwXHU1RjhCXHU0RTBEXHU4RkRCXHU1MTY1IElQQ1x1MzAwMlxuICovXG5mdW5jdGlvbiB0b1JlbW90ZUNvbnZlcnNhdGlvblNuYXBzaG90KGNvbnZlcnNhdGlvbjogQ29udmVyc2F0aW9uKTogUmVtb3RlQ29udmVyc2F0aW9uU25hcHNob3Qge1xuICAgIGNvbnN0IHsgY29uZmlnTWFuYWdlciB9ID0gY29udmVyc2F0aW9uO1xuICAgIHJldHVybiB7XG4gICAgICAgIGluZm86IGNvbnZlcnNhdGlvbi5pbmZvLFxuICAgICAgICBjb25maWdNYW5hZ2VyOiB7XG4gICAgICAgICAgICBtb2RlOiBjb25maWdNYW5hZ2VyLm1vZGUsXG4gICAgICAgICAgICBtb2RlbDogY29uZmlnTWFuYWdlci5tb2RlbCxcbiAgICAgICAgICAgIGNvbm5lY3RvcnM6IGNvbmZpZ01hbmFnZXIuY29ubmVjdG9ycy5tYXAodG9SZW1vdGVDb25uZWN0b3JTbmFwc2hvdCksXG4gICAgICAgICAgICBleHBlcnRJZDogY29uZmlnTWFuYWdlci5leHBlcnRJZCxcbiAgICAgICAgICAgIGV4cGVydDogY29uZmlnTWFuYWdlci5leHBlcnQgPyB7IC4uLmNvbmZpZ01hbmFnZXIuZXhwZXJ0IH0gOiB1bmRlZmluZWQsXG4gICAgICAgICAgICBwZXJtaXNzaW9uTW9kZTogY29uZmlnTWFuYWdlci5wZXJtaXNzaW9uTW9kZSxcbiAgICAgICAgICAgIHVzZVNhbmRib3hDTEk6IGNvbmZpZ01hbmFnZXIudXNlU2FuZGJveENMSSxcbiAgICAgICAgICAgIHRob3VnaHRMZXZlbDogY29uZmlnTWFuYWdlci50aG91Z2h0TGV2ZWwsXG4gICAgICAgICAgICBjb250ZXh0V2luZG93OiBjb25maWdNYW5hZ2VyLmNvbnRleHRXaW5kb3csXG4gICAgICAgIH0sXG4gICAgfTtcbn1cblxuLyoqXG4gKiBEYWVtb24tZmFjaW5nIGB3Yi5jb252ZXJzYXRpb25zYCBzZXJ2aWNlLlxuICpcbiAqIFRoZSBjb2xsZWN0aW9uIEFQSSBhbmQgcGVyLWNvbnZlcnNhdGlvbiBicmlkZ2Ugc2hhcmUgb25lIG5hbWVzcGFjZSBzbyBJUENcbiAqIGNvbnN1bWVycyBuZWVkIG9ubHkgYHdiOmNvbnZlcnNhdGlvbnM6KmAgY2hhbm5lbHMuIFRoaXMgaXMgYW4gaW50ZXJuYWxcbiAqIGNvbXBvc2l0aW9uIGhlbHBlcjsgaXQgaXMgbm90IGFuIGFkZGl0aW9uYWwgU0RLIG5hbWVzcGFjZS5cbiAqL1xuZXhwb3J0IHR5cGUgQ29udmVyc2F0aW9uc0JyaWRnZVNlcnZpY2UgPSBPbWl0PENvbnZlcnNhdGlvbnNBcGksICdnZXQnIHwgJ2NyZWF0ZScgfCAnZm9yaycgfCAnbGlzdEJ5SWRzJyB8ICdnZXRBcmNoaXZlZElkcyc+ICYgQ29udmVyc2F0aW9uUmVtb3RlQXBpICYge1xuICAgIGdldChpZDogc3RyaW5nKTogUHJvbWlzZTxSZW1vdGVDb252ZXJzYXRpb25TbmFwc2hvdCB8IHVuZGVmaW5lZD47XG4gICAgY3JlYXRlKHBhcmFtczogUGFyYW1ldGVyczxDb252ZXJzYXRpb25zQXBpWydjcmVhdGUnXT5bMF0pOiBQcm9taXNlPFJlbW90ZUNvbnZlcnNhdGlvblNuYXBzaG90IHwgQXBpRXJyb3I+O1xuICAgIGZvcmsoaWQ6IHN0cmluZyk6IFByb21pc2U8UmVtb3RlQ29udmVyc2F0aW9uU25hcHNob3QgfCBBcGlFcnJvcj47XG4gICAgLyoqXG4gICAgICogXHU1NzI4IGJyaWRnZSBcdTUxRkFcdTUzRTNcdTRFMEFcdTY1MzZcdTdBODRcdTRFM0FcdTVGQzVcdTkwMDlcdUZGMUFcdTVFOTVcdTVDNDJcdTVCOUVcdTczQjBcdTdGM0FcdTU5MzFcdTY1RjZcdTc1MzFcdTY3MkMgc2VydmljZSBcdTUxNUNcdTVFOTVcdTYyMTBcdTdBN0FcdTY1NzBcdTdFQzRcdUZGMENcbiAgICAgKiBcdThGRDlcdTY4MzcgZGFlbW9uIFx1NEZBN1x1RkYwOFx1OEY2RVx1OEJFMlx1N0I0OVx1RkYwOVx1NEUwRFx1OTcwMFx1ODk4MVx1NTcyOFx1NkJDRlx1NEUyQVx1OEMwM1x1NzUyOFx1NzBCOVx1OTFDRFx1NTkwRFx1NTIyNFx1N0E3QVx1MzAwMlxuICAgICAqL1xuICAgIGxpc3RCeUlkcyhpZHM6IHJlYWRvbmx5IHN0cmluZ1tdLCBvcHRpb25zPzogeyBzaWduYWw/OiBBYm9ydFNpZ25hbCB9KTogUHJvbWlzZTxyZWFkb25seSBDb252ZXJzYXRpb25JbmZvW10+O1xuICAgIC8qKlxuICAgICAqIFx1NjUzNlx1N0E4NFx1NEUzQVx1NUZDNVx1OTAwOVx1RkYwOFx1NTQwQyBsaXN0QnlJZHNcdUZGMDlcdUZGMUFcdTYzMDkgaWQgXHU1NkRFXHU2N0U1XHU2NzJDXHU3QUVGXHU1REYyXHU1RjUyXHU2ODYzIGlkLFx1NEY5QiBwb2xsZXIgXHU3NTA0XHU1MjJCXHUzMDBDXHU1RjUyXHU2ODYzXHUyMjYwXHU1MjIwXHU5NjY0XHUzMDBEKCMxMDU3MTIpXHUzMDAyXG4gICAgICogXHU1RTk1XHU1QzQyXHU2NzJBXHU1QjlFXHU3M0IwXHU2NUY2XHU2NzJDIHNlcnZpY2UgXHU1MTVDXHU1RTk1XHU3QTdBXHU5NkM2XHUzMDAyZGFlbW9uIFx1NTE4NVx1OTBFOFx1NTQwQ1x1NkI2NVx1OEJGQlx1NjcyQ1x1NTczMFx1N0YxM1x1NUI1OCxcdTY1RTBcdTdGNTFcdTdFRENcdTMwMDJcbiAgICAgKi9cbiAgICBnZXRBcmNoaXZlZElkcyhpZHM6IHJlYWRvbmx5IHN0cmluZ1tdKTogU2V0PHN0cmluZz47XG4gICAgLyoqIGRhZW1vbiBcdTUxODVcdTkwRThcdTZEODhcdThEMzlcdTZEM0JcdTVCOUVcdTRGOEJcdUZGMUJcdTRFMEJcdTUyMTJcdTdFQkZcdTUyNERcdTdGMDBcdTc4NkVcdTRGRERcdTRFMERcdTRGMUFcdTVDNTVcdTVFNzNcdTYyMTAgSVBDIGNoYW5uZWxcdTMwMDIgKi9cbiAgICBfZ2V0TGl2ZUNvbnZlcnNhdGlvbihpZDogc3RyaW5nKTogUHJvbWlzZTxDb252ZXJzYXRpb24gfCB1bmRlZmluZWQ+O1xuICAgIC8qKlxuICAgICAqIENtZCtRXHVGRjFBXHU2QzYwXHU1MTg1XHU2RDNCXHU0RjFBXHU4QkREXHU2Mjk1XHU1RjcxXHVGRjA4XHU1NDJCXHU1QjUwXHU1RkQ5IFx1MjE5MiB3b3JraW5nXHVGRjA5XHUzMDAyXHU0RTBEXHU4RDcwIGxpc3QgXHU3RkZCXHU5ODc1XHVGRjBDXHU5MDdGXHU1MTREIGlkbGUgXHU3QTk3XHU2MjJBXHU2NUFEXHU2RjBGXHU2MjkzXHUzMDAyXG4gICAgICogXHU0RTBCXHU1MjEyXHU3RUJGXHU0RTBEXHU4RkRCIElQQ1x1MzAwMlxuICAgICAqIFx1NkNFOFx1NjEwRlx1RkYxQVx1N0VDRiBodWIgYHdyYXBGYWNhZGVgIFx1NTQwRVx1OEMwM1x1NzUyOFx1NjVCOVx1NjJGRlx1NTIzMFx1NzY4NFx1NjYyRiBQcm9taXNlXHVGRjBDcXVpdCBcdTY3RTVcdThCRTJcdTVGQzVcdTk4N0IgYXdhaXRcdTMwMDJcbiAgICAgKi9cbiAgICBfbGlzdExpdmVDb252ZXJzYXRpb25JbmZvcygpOiByZWFkb25seSBDb252ZXJzYXRpb25JbmZvW107XG4gICAgLyoqIGRhZW1vbiBcdTUxODVcdTkwRThcdUZGMUFcdTgxRUFcdTUyQThcdTUzMTZcdTk4ODRcdTUyMDZcdTkxNEQgaWQgXHU2M0QwXHU1MjREXHU1MTk5XHU1MTY1IGxvY2FsIGxvY2F0b3JcdUZGMUJcdTRFMEJcdTUyMTJcdTdFQkZcdTUyNERcdTdGMDBcdTRFMERcdThGREIgSVBDXHUzMDAyICovXG4gICAgX2RlY2xhcmVMb2NhbChjb252ZXJzYXRpb25JZDogc3RyaW5nKTogdm9pZDtcbiAgICAvKiogZGFlbW9uIFx1NTE4NVx1OTBFOFx1RkYxQVx1NTQwQ1x1NkI2NVx1NjI0MFx1NjcwOSByZW5kZXJlciBcdTVGNTNcdTUyNERcdTUzRUZcdTg5QzFcdTRGMUFcdThCRERcdTc2ODRcdTVFNzZcdTk2QzZcdUZGMENcdTRGRERcdTYyQTRcdTZDNjBcdTUxODVcdTUzRUZcdTg5QzFcdTVCOUVcdTRGOEJcdTMwMDIgKi9cbiAgICBfc2V0Q3VycmVudENvbnZlcnNhdGlvbklkcyhjb252ZXJzYXRpb25JZHM6IHJlYWRvbmx5IHN0cmluZ1tdKTogUHJvbWlzZTx2b2lkPjtcbiAgICBfcmVzZXRBbGwocmVhc29uPzogc3RyaW5nKTogUHJvbWlzZTx2b2lkPjtcbiAgICBfZGlzcG9zZUFsbCgpOiBQcm9taXNlPHZvaWQ+O1xufTtcblxuLyoqXG4gKiBcdThGREVcdTYzQTVcdTYwMDFcdTY1QjlcdTZDRDVcdTU3MjhcdTY3MkMgc2VydmljZSBcdTVDNDJcdTU0MTEgYnJpZGdlIFx1NzY4NCoqXHU3RUFGXHU5MDBGXHU0RjIwKiogZm9yd2FyZCBcdTk1MkVcdTk2QzZcdUZGMDhTU09UIFx1NkQzRVx1NzUxRlx1RkYwOVx1RkYxQVxuICogPSBgTUVUSE9EX0JJTkRTYCBcdTc2ODRcdTY1QjlcdTZDRDVcdTk1MkVcdUZGMDhcdTk2NjQgYHJlbmFtZWAgXHUyMDE0XHUyMDE0IFx1NUI4M1x1OEY2Q1x1NTNEMVx1NTIzMCBgY29udmVyc2F0aW9uc2AgXHU5NkM2XHU1NDA4XHU3Q0JFXHU3ODZFXHU4REVGXHU3NTMxXHVGRjA5XG4gKiAgIFx1MjIyQSBgV0lSRV9PTkxZX01FVEhPRF9LRVlTYFx1RkYwOHF1ZXVlKiAvIGZpbGUqIC8gY2hpbGRBZ2VudCogLyBjb25maWdTZXQqIC8gcmVnaXN0ZXIqIC8gZGlzcG9zZVx1RkYwOVx1MzAwMlxuICogXHU2MjQwXHU2NzA5XHU5NTJFXHU1NzI4XHU2NzJDXHU1QzQyXHU1NzQ3XHU0RTNBIGAoLi4uYXJncykgPT4gYnJpZGdlW2tleV0oLi4uYXJncylgXHVGRjBDXHU2NTQ1XHU3NTMxXHU4ODY4XHU3RURGXHU0RTAwXHU3NTFGXHU2MjEwXHVGRjBDXHU5MDdGXHU1MTREXHU5MDEwXHU2NzYxXHU2MjRCXHU2Mjg0XHUzMDAyXG4gKi9cbmNvbnN0IEJSSURHRV9GT1JXQVJEX0tFWVM6IHJlYWRvbmx5IChrZXlvZiBDb252ZXJzYXRpb25SZW1vdGVBcGkpW10gPSBbXG4gICAgLi4uTUVUSE9EX0JJTkRTLm1hcChiaW5kID0+IGJpbmQua2V5KS5maWx0ZXIoKGtleSk6IGtleSBpcyBFeGNsdWRlPFdpcmVNZXRob2RLZXksICdyZW5hbWUnPiA9PiBrZXkgIT09ICdyZW5hbWUnKSxcbiAgICAuLi5XSVJFX09OTFlfTUVUSE9EX0tFWVMsXG5dO1xuXG4vKiogXHU0RjlEXHU2MzZFIGBCUklER0VfRk9SV0FSRF9LRVlTYCBcdTc1MUZcdTYyMTBcdTMwMENzZXJ2aWNlIFx1MjE5MiBicmlkZ2VcdTMwMERcdTdFQUZcdTkwMEZcdTRGMjAgZm9yd2FyZCBcdTcyNDdcdTZCQjVcdTMwMDIgKi9cbmZ1bmN0aW9uIGJ1aWxkQnJpZGdlRm9yd2FyZHMoYnJpZGdlOiBDb252ZXJzYXRpb25CcmlkZ2UpOiBQaWNrPENvbnZlcnNhdGlvblJlbW90ZUFwaSwgdHlwZW9mIEJSSURHRV9GT1JXQVJEX0tFWVNbbnVtYmVyXT4ge1xuICAgIGNvbnN0IHJlbW90ZSA9IGJyaWRnZSBhcyB1bmtub3duIGFzIFJlY29yZDxzdHJpbmcsICguLi5hcmdzOiB1bmtub3duW10pID0+IFByb21pc2U8dW5rbm93bj4+O1xuICAgIGNvbnN0IG91dDogUmVjb3JkPHN0cmluZywgdW5rbm93bj4gPSB7fTtcbiAgICBmb3IgKGNvbnN0IGtleSBvZiBCUklER0VfRk9SV0FSRF9LRVlTKSB7XG4gICAgICAgIG91dFtrZXldID0gKC4uLmFyZ3M6IHVua25vd25bXSk6IFByb21pc2U8dW5rbm93bj4gPT4gcmVtb3RlW2tleV0oLi4uYXJncyk7XG4gICAgfVxuICAgIHJldHVybiBvdXQgYXMgUGljazxDb252ZXJzYXRpb25SZW1vdGVBcGksIHR5cGVvZiBCUklER0VfRk9SV0FSRF9LRVlTW251bWJlcl0+O1xufVxuXG5leHBvcnQgZnVuY3Rpb24gY3JlYXRlQ29udmVyc2F0aW9uc0JyaWRnZVNlcnZpY2UoXG4gICAgY29udmVyc2F0aW9uczogQ29udmVyc2F0aW9uc0FwaSxcbiAgICBicmlkZ2U6IENvbnZlcnNhdGlvbkJyaWRnZSxcbik6IENvbnZlcnNhdGlvbnNCcmlkZ2VTZXJ2aWNlIHtcbiAgICBjb25zdCB2aWV3ID0gKG5hbWU6ICdsb2NhbCcgfCAnY2xvdWQnIHwgJ2NsYXcnIHwgJ2dlbmllJyB8ICdtaW5pYXBwJyB8ICdhcHAnKSA9PiAoe1xuICAgICAgICBsaXN0OiAoZmlsdGVyPzogUGFyYW1ldGVyczxDb252ZXJzYXRpb25zQXBpWydsaXN0J10+WzBdLCBvcHRpb25zPzogUGFyYW1ldGVyczxDb252ZXJzYXRpb25zQXBpWydsaXN0J10+WzFdKSA9PiBjb252ZXJzYXRpb25zW25hbWVdLmxpc3QoZmlsdGVyLCBvcHRpb25zKSxcbiAgICB9KTtcbiAgICBjb25zdCBnZXRTbmFwc2hvdCA9IGFzeW5jIChpZDogc3RyaW5nKTogUHJvbWlzZTxSZW1vdGVDb252ZXJzYXRpb25TbmFwc2hvdCB8IHVuZGVmaW5lZD4gPT4ge1xuICAgICAgICBjb25zdCBjb252ZXJzYXRpb24gPSBhd2FpdCBicmlkZ2UuZ2V0KGlkKTtcbiAgICAgICAgcmV0dXJuIGNvbnZlcnNhdGlvbiA/IHRvUmVtb3RlQ29udmVyc2F0aW9uU25hcHNob3QoY29udmVyc2F0aW9uKSA6IHVuZGVmaW5lZDtcbiAgICB9O1xuXG4gICAgcmV0dXJuIHtcbiAgICAgICAgLy8gXHU4RkRFXHU2M0E1XHU2MDAxXHU3RUFGXHU5MDBGXHU0RjIwXHU2NUI5XHU2Q0Q1XHVGRjA4c2VuZFByb21wdC9yZXF1ZXN0cy9xdWV1ZSovZmlsZSovY29uZmlnU2V0Ki8uLi4gXHUyMTkyIGJyaWRnZVx1RkYwOVx1RkYwQ1x1ODg2OFx1OUE3MVx1NTJBOFx1NzUxRlx1NjIxMFx1MzAwMlxuICAgICAgICAuLi5idWlsZEJyaWRnZUZvcndhcmRzKGJyaWRnZSksXG4gICAgICAgIGxpc3Q6IChmaWx0ZXIsIG9wdGlvbnMpID0+IGNvbnZlcnNhdGlvbnMubGlzdChmaWx0ZXIsIG9wdGlvbnMpLFxuICAgICAgICBlbnN1cmVMaXN0OiAoc3BhY2UsIGZpbHRlcikgPT4gY29udmVyc2F0aW9ucy5lbnN1cmVMaXN0KHNwYWNlLCBmaWx0ZXIpLFxuICAgICAgICBsaXN0U2NvcGU6IChzcGFjZSwgZmlsdGVyKSA9PiBjb252ZXJzYXRpb25zLmxpc3RTY29wZShzcGFjZSwgZmlsdGVyKSxcbiAgICAgICAgbGlzdEJ5SWRzOiAoaWRzLCBvcHRpb25zKSA9PiBjb252ZXJzYXRpb25zLmxpc3RCeUlkcz8uKGlkcywgb3B0aW9ucykgPz8gUHJvbWlzZS5yZXNvbHZlKFtdKSxcbiAgICAgICAgZ2V0QXJjaGl2ZWRJZHM6IGlkcyA9PiBjb252ZXJzYXRpb25zLmdldEFyY2hpdmVkSWRzPy4oaWRzKSA/PyBuZXcgU2V0PHN0cmluZz4oKSxcbiAgICAgICAgbG9jYWw6IHZpZXcoJ2xvY2FsJyksXG4gICAgICAgIGNsb3VkOiB2aWV3KCdjbG91ZCcpLFxuICAgICAgICBjbGF3OiB2aWV3KCdjbGF3JyksXG4gICAgICAgIGdlbmllOiB2aWV3KCdnZW5pZScpLFxuICAgICAgICBtaW5pYXBwOiB2aWV3KCdtaW5pYXBwJyksXG4gICAgICAgIGFwcDogdmlldygnYXBwJyksXG4gICAgICAgIGdldDogZ2V0U25hcHNob3QsXG4gICAgICAgIGNyZWF0ZTogYXN5bmMgcGFyYW1zID0+IHtcbiAgICAgICAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IGNvbnZlcnNhdGlvbnMuY3JlYXRlKHBhcmFtcyk7XG4gICAgICAgICAgICBpZiAoaXNBcGlFcnJvcihyZXN1bHQpKSB7IHJldHVybiByZXN1bHQ7IH1cbiAgICAgICAgICAgIGJyaWRnZS5hZG9wdChyZXN1bHQuaW5mby5pZCwgcmVzdWx0KTtcbiAgICAgICAgICAgIHJldHVybiB0b1JlbW90ZUNvbnZlcnNhdGlvblNuYXBzaG90KHJlc3VsdCk7XG4gICAgICAgIH0sXG4gICAgICAgIGZvcms6IGFzeW5jIGlkID0+IHtcbiAgICAgICAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IGNvbnZlcnNhdGlvbnMuZm9yayhpZCk7XG4gICAgICAgICAgICBpZiAoaXNBcGlFcnJvcihyZXN1bHQpKSB7IHJldHVybiByZXN1bHQ7IH1cbiAgICAgICAgICAgIGJyaWRnZS5hZG9wdChyZXN1bHQuaW5mby5pZCwgcmVzdWx0KTtcbiAgICAgICAgICAgIHJldHVybiB0b1JlbW90ZUNvbnZlcnNhdGlvblNuYXBzaG90KHJlc3VsdCk7XG4gICAgICAgIH0sXG4gICAgICAgIG9uQ29udmVyc2F0aW9uQ2hhbmdlZDogKHR5cGUsIGhhbmRsZXIpID0+IGNvbnZlcnNhdGlvbnMub25Db252ZXJzYXRpb25DaGFuZ2VkKHR5cGUsIGhhbmRsZXIpLFxuICAgICAgICBvbjogKGV2ZW50LCBjYWxsYmFjaykgPT4gY29udmVyc2F0aW9ucy5vbihldmVudCwgY2FsbGJhY2spLFxuICAgICAgICByZW9yZGVyUGlubmVkOiBvcmRlcmVkSWRzID0+IGNvbnZlcnNhdGlvbnMucmVvcmRlclBpbm5lZChvcmRlcmVkSWRzKSxcbiAgICAgICAgbGlzdFBpbm5lZDogKCkgPT4gY29udmVyc2F0aW9ucy5saXN0UGlubmVkKCksXG4gICAgICAgIG1hcmtSZWFkOiBpZCA9PiBjb252ZXJzYXRpb25zLm1hcmtSZWFkKGlkKSxcbiAgICAgICAgLy8gXHU2NUUwIHRyYW5zcG9ydCBcdTc2ODRcdTUzNTVcdTRGMUFcdThCREQgcmVuYW1lIFx1OEQ3MFx1NkQzQlx1NUI5RVx1NEY4Qlx1RkYwQ1x1ODlFNlx1NTNEMSBJbmZvQ2hhbmdlXHVGRjFCXHU2NjNFXHU1RjBGIHRyYW5zcG9ydCBcdTRGRERcdTc1NTlcdTk2QzZcdTU0MDhcdTdDQkVcdTc4NkVcdThERUZcdTc1MzFcdTMwMDJcbiAgICAgICAgcmVuYW1lOiAoaWQsIHRpdGxlLCB0cmFuc3BvcnQ/OiBDb252ZXJzYXRpb25UcmFuc3BvcnQpID0+IHtcbiAgICAgICAgICAgIGlmICghdHJhbnNwb3J0KSB7IHJldHVybiBicmlkZ2UucmVuYW1lKGlkLCB0aXRsZSk7IH1cbiAgICAgICAgICAgIHJldHVybiBjb252ZXJzYXRpb25zLnJlbmFtZShpZCwgdGl0bGUsIHRyYW5zcG9ydCk7XG4gICAgICAgIH0sXG4gICAgICAgIG1vdmU6IChpZCwgY3dkLCB0cmFuc3BvcnQpID0+IGNvbnZlcnNhdGlvbnMubW92ZShpZCwgY3dkLCB0cmFuc3BvcnQpLFxuICAgICAgICBkZWxldGU6IGFzeW5jIChpZCwgdHJhbnNwb3J0KSA9PiB7XG4gICAgICAgICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBjb252ZXJzYXRpb25zLmRlbGV0ZShpZCwgdHJhbnNwb3J0KTtcbiAgICAgICAgICAgIC8vIFx1NTIyMFx1OTY2NFx1NTkzMVx1OEQyNS9cdTUzRDZcdTZEODhcdTY1RjZcdTRGMUFcdThCRERcdTRFQ0RcdTVCNThcdTU3MjhcdUZGMENcdTRGRERcdTc1NTlcdTZEM0JcdTVCOUVcdTRGOEJcdTUzQ0FcdTUxNzZcdTRFQTdcdTcyNjlcdTVGRUJcdTcxNjdcdUZGMUJcdTRFQzVcdTYyMTBcdTUyOUZcdTU0MEVcdTkxQ0FcdTY1M0VcdTMwMDJcbiAgICAgICAgICAgIGlmICghcmVzdWx0KSB7IGF3YWl0IGJyaWRnZS5kaXNwb3NlKGlkKTsgfVxuICAgICAgICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICAgICAgfSxcbiAgICAgICAgYXJjaGl2ZTogKGlkLCB0cmFuc3BvcnQpID0+IGNvbnZlcnNhdGlvbnMuYXJjaGl2ZShpZCwgdHJhbnNwb3J0KSxcbiAgICAgICAgdW5hcmNoaXZlOiAoaWQsIHRyYW5zcG9ydCkgPT4gY29udmVyc2F0aW9ucy51bmFyY2hpdmUoaWQsIHRyYW5zcG9ydCksXG4gICAgICAgIHBpbjogaWQgPT4gY29udmVyc2F0aW9ucy5waW4oaWQpLFxuICAgICAgICB1bnBpbjogaWQgPT4gY29udmVyc2F0aW9ucy51bnBpbihpZCksXG4gICAgICAgIF9nZXRMaXZlQ29udmVyc2F0aW9uOiBpZCA9PiBicmlkZ2UuZ2V0KGlkKSxcbiAgICAgICAgX2xpc3RMaXZlQ29udmVyc2F0aW9uSW5mb3M6ICgpID0+IGJyaWRnZS5fbGlzdFBvb2xlZENvbnZlcnNhdGlvbnMoKS5tYXAodG9RdWl0TGl2ZUNvbnZlcnNhdGlvbkluZm8pLFxuICAgICAgICBfZGVjbGFyZUxvY2FsOiBjb252ZXJzYXRpb25JZCA9PiB7XG4gICAgICAgICAgICAoY29udmVyc2F0aW9ucyBhcyB7IGRlY2xhcmVPd25lcj86IChpZDogc3RyaW5nLCBraW5kOiAnbG9jYWwnIHwgJ2Nsb3VkJykgPT4gdm9pZCB9KVxuICAgICAgICAgICAgICAgIC5kZWNsYXJlT3duZXI/Lihjb252ZXJzYXRpb25JZCwgJ2xvY2FsJyk7XG4gICAgICAgIH0sXG4gICAgICAgIF9zZXRDdXJyZW50Q29udmVyc2F0aW9uSWRzOiBhc3luYyBjb252ZXJzYXRpb25JZHMgPT4ge1xuICAgICAgICAgICAgYnJpZGdlLl9zZXRDdXJyZW50Q29udmVyc2F0aW9uSWRzKGNvbnZlcnNhdGlvbklkcyk7XG4gICAgICAgIH0sXG4gICAgICAgIF9yZXNldEFsbDogcmVhc29uID0+IGJyaWRnZS5fcmVzZXRBbGwocmVhc29uKSxcbiAgICAgICAgX2Rpc3Bvc2VBbGw6ICgpID0+IGJyaWRnZS5fZGlzcG9zZUFsbCgpLFxuICAgIH07XG59XG4iLCAiLyoqXG4gKiBXQiBCcmlkZ2UgXHU4REU4IGNvbnRleHQgXHU3RUJGXHU1MzRGXHU4QkFFXHU0RTBFXHU4RjdEXHU0RjUzXHU2NUUwXHU1MTczXHU3QUVGXHU3MEI5XHUzMDAyXG4gKi9cblxuaW1wb3J0IHR5cGUgeyBJbnZva2VDb250ZXh0IH0gZnJvbSAnLi4vcGVybWlzc2lvbi9hdXRob3JpemF0aW9uJztcblxuLyoqIFx1NUY1M1x1NTI0RFx1N0EzM1x1NUI5QVx1NzY4NFx1OERFOCBjb250ZXh0IEJyaWRnZSBcdTdFQkZcdTUzNEZcdThCQUVcdTcyNDhcdTY3MkNcdTMwMDIgKi9cbmV4cG9ydCBjb25zdCBXQl9CUklER0VfUFJPVE9DT0xfVkVSU0lPTiA9ICcxLjAnO1xuXG5leHBvcnQgaW50ZXJmYWNlIEhhbmRzaGFrZVJlcXVlc3Qge1xuICAgIHR5cGU6ICd3YjpoYW5kc2hha2U6cmVxdWVzdCc7XG4gICAgcmVxdWVzdElkOiBzdHJpbmc7XG4gICAgcHJvdG9jb2xWZXJzaW9uOiBzdHJpbmc7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgSGFuZHNoYWtlUmVzcG9uc2Uge1xuICAgIHR5cGU6ICd3YjpoYW5kc2hha2U6cmVzcG9uc2UnO1xuICAgIHJlcXVlc3RJZDogc3RyaW5nO1xuICAgIHByb3RvY29sVmVyc2lvbjogc3RyaW5nO1xuICAgIGVycm9yPzogeyBtZXNzYWdlOiBzdHJpbmc7IGNvZGU/OiBzdHJpbmcgfCBudW1iZXIgfTtcbn1cblxuZXhwb3J0IGludGVyZmFjZSBJbnZva2VSZXF1ZXN0IHtcbiAgICB0eXBlOiAnd2I6aW52b2tlOnJlcXVlc3QnO1xuICAgIHJlcXVlc3RJZDogc3RyaW5nO1xuICAgIGNoYW5uZWw6IHN0cmluZztcbiAgICBjb250ZXh0OiBJbnZva2VDb250ZXh0IHwgdW5kZWZpbmVkO1xuICAgIGFyZ3M6IHVua25vd25bXTtcbn1cblxuZXhwb3J0IGludGVyZmFjZSBJbnZva2VSZXNwb25zZSB7XG4gICAgdHlwZTogJ3diOmludm9rZTpyZXNwb25zZSc7XG4gICAgcmVxdWVzdElkOiBzdHJpbmc7XG4gICAgcmVzdWx0PzogdW5rbm93bjtcbiAgICBlcnJvcj86IHtcbiAgICAgICAgbWVzc2FnZTogc3RyaW5nO1xuICAgICAgICBjb2RlPzogc3RyaW5nIHwgbnVtYmVyO1xuICAgICAgICBzb3VyY2U/OiBzdHJpbmc7XG4gICAgICAgIGh0dHBTdGF0dXM/OiBudW1iZXI7XG4gICAgICAgIGRhdGE/OiB1bmtub3duO1xuICAgIH07XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgRXZlbnRNZXNzYWdlIHtcbiAgICB0eXBlOiAnd2I6ZXZlbnQnO1xuICAgIGV2ZW50OiBzdHJpbmc7XG4gICAgcGF5bG9hZDogdW5rbm93bjtcbn1cblxuLyoqIEd1ZXN0IFx1NEU4Qlx1NEVGNlx1OEJBMlx1OTYwNVx1NjNBN1x1NTIzNiBjaGFubmVsXHVGRjFCXHU1M0VBXHU3NTMxXHU1QkI5XHU1NjY4IEhvc3QgXHU1OTA0XHU3NDA2XHVGRjBDXHU0RTBEXHU4RjZDXHU1M0QxXHU1MjMwXHU0RTFBXHU1MkExIHdiXHUzMDAyICovXG5leHBvcnQgY29uc3QgV0JfQlJJREdFX1NVQlNDUklCRV9FVkVOVF9DSEFOTkVMID0gJ3diOiRicmlkZ2U6c3Vic2NyaWJlRXZlbnQnO1xuZXhwb3J0IGNvbnN0IFdCX0JSSURHRV9VTlNVQlNDUklCRV9FVkVOVF9DSEFOTkVMID0gJ3diOiRicmlkZ2U6dW5zdWJzY3JpYmVFdmVudCc7XG5cbmV4cG9ydCBmdW5jdGlvbiBpc0ludm9rZVJlcXVlc3QodmFsdWU6IHVua25vd24pOiB2YWx1ZSBpcyBJbnZva2VSZXF1ZXN0IHtcbiAgICByZXR1cm4gQm9vbGVhbih2YWx1ZSkgJiYgKHZhbHVlIGFzIHsgdHlwZT86IHVua25vd24gfSkudHlwZSA9PT0gJ3diOmludm9rZTpyZXF1ZXN0Jztcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGlzSGFuZHNoYWtlUmVxdWVzdCh2YWx1ZTogdW5rbm93bik6IHZhbHVlIGlzIEhhbmRzaGFrZVJlcXVlc3Qge1xuICAgIHJldHVybiBCb29sZWFuKHZhbHVlKSAmJiAodmFsdWUgYXMgeyB0eXBlPzogdW5rbm93biB9KS50eXBlID09PSAnd2I6aGFuZHNoYWtlOnJlcXVlc3QnO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gaXNIYW5kc2hha2VSZXNwb25zZSh2YWx1ZTogdW5rbm93bik6IHZhbHVlIGlzIEhhbmRzaGFrZVJlc3BvbnNlIHtcbiAgICByZXR1cm4gQm9vbGVhbih2YWx1ZSkgJiYgKHZhbHVlIGFzIHsgdHlwZT86IHVua25vd24gfSkudHlwZSA9PT0gJ3diOmhhbmRzaGFrZTpyZXNwb25zZSc7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBpc0ludm9rZVJlc3BvbnNlKHZhbHVlOiB1bmtub3duKTogdmFsdWUgaXMgSW52b2tlUmVzcG9uc2Uge1xuICAgIHJldHVybiBCb29sZWFuKHZhbHVlKSAmJiAodmFsdWUgYXMgeyB0eXBlPzogdW5rbm93biB9KS50eXBlID09PSAnd2I6aW52b2tlOnJlc3BvbnNlJztcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGlzRXZlbnRNZXNzYWdlKHZhbHVlOiB1bmtub3duKTogdmFsdWUgaXMgRXZlbnRNZXNzYWdlIHtcbiAgICByZXR1cm4gQm9vbGVhbih2YWx1ZSkgJiYgKHZhbHVlIGFzIHsgdHlwZT86IHVua25vd24gfSkudHlwZSA9PT0gJ3diOmV2ZW50Jztcbn1cblxuZXhwb3J0IHR5cGUgVW5zdWJzY3JpYmUgPSAoKSA9PiB2b2lkO1xuXG4vKiogXHU1MTY1XHU3QUQ5XHU2RDg4XHU2MDZGXHU0RTBBXHU0RTBCXHU2NTg3XHVGRjBDXHU3NTMxXHU1MTc3XHU0RjUzXHU4RjdEXHU0RjUzXHU2M0QwXHU0RjlCXHU2NzY1XHU2RTkwXHUzMDAxb3JpZ2luIFx1NTQ4Q1x1NUI5QVx1NTQxMVx1NTZERVx1NTkwRFx1MzAwMiAqL1xuZXhwb3J0IGludGVyZmFjZSBJbmJvdW5kQ29udGV4dCB7XG4gICAgcmVwbHkobWVzc2FnZTogdW5rbm93bik6IHZvaWQ7XG4gICAgc291cmNlPzogdW5rbm93bjtcbiAgICBvcmlnaW4/OiBzdHJpbmc7XG4gICAgcmF3PzogdW5rbm93bjtcbn1cblxuLyoqIFx1OEY3RFx1NEY1M1x1NjVFMFx1NTE3M1x1NzY4NFx1NTNDQ1x1NTQxMVx1NkQ4OFx1NjA2Rlx1N0FFRlx1NzBCOVx1MzAwMiAqL1xuZXhwb3J0IGludGVyZmFjZSBNZXNzYWdlRW5kcG9pbnQge1xuICAgIHBvc3QobWVzc2FnZTogdW5rbm93bik6IHZvaWQ7XG4gICAgbGlzdGVuKGhhbmRsZXI6IChtZXNzYWdlOiB1bmtub3duLCBjb250ZXh0OiBJbmJvdW5kQ29udGV4dCkgPT4gdm9pZCk6IFVuc3Vic2NyaWJlO1xufVxuIiwgIi8qKlxuICogQnJpZGdlIENsaWVudCBcdTIwMTRcdTIwMTQgcmVuZGVyZXIgXHU0RkE3XHU3Njg0XHU4RkRDXHU3QTBCXHU4QzAzXHU3NTI4XHU0RUUzXHU3NDA2XHUzMDAyXG4gKlxuICogXHU5MDEyXHU1RjUyIFByb3h5XHVGRjFBXHU1QzVFXHU2MDI3XHU4QkJGXHU5NUVFXHU2MkZDXHU4REVGXHU1Rjg0XHVGRjBDXHU1MUZEXHU2NTcwXHU4QzAzXHU3NTI4XHU4RDcwIGludm9rZVx1MzAwMlxuICogXHU0RTBFXHU0RTNCXHU4RkRCXHU3QTBCIGJyaWRnZS5iaW5kIFx1NkNFOFx1NTE4Q1x1NzY4NCBjaGFubmVsIFx1NEUwMFx1NEUwMFx1NUJGOVx1NUU5NFx1MzAwMlxuICpcbiAqIFx1OTUxOVx1OEJFRlx1NjA2Mlx1NTkwRFx1RkYxQVx1NEUzQlx1OEZEQlx1N0EwQlx1NUMwNiBXQkVycm9yIFx1NUU4Rlx1NTIxN1x1NTMxNlx1NEUzQSBgU2VyaWFsaXplZEJyaWRnZUVycm9yYFx1RkYwOGBfX3diRXJyb3I6IHRydWVgXHVGRjA5XHU4RkQ0XHU1NkRFXHVGRjBDXG4gKiBjbGllbnQgXHU1QzQyXHU5MDFBXHU4RkM3IGBkZXNlcmlhbGl6ZVJlc3VsdGAgXHU2OEMwXHU2RDRCXHU1RTc2XHU4RkQ4XHU1MzlGXHU0RTNBXHU1RTI2IG5hbWUvY29kZSBcdTc2ODQgRXJyb3JcdUZGMENcbiAqIFx1NEUxQVx1NTJBMVx1NUM0MiBjYXRjaCBcdTUzRUZcdTc1MjggYGVyci5uYW1lID09PSAnV0JFcnJvcidgIFx1NjIxNiBgZXJyLmNvZGVgIFx1OEJDNlx1NTIyQlx1OERFOFx1OEZCOVx1NzU0Q1x1NEUxQVx1NTJBMVx1OTUxOVx1OEJFRlx1MzAwMlxuICpcbiAqIGNhbGxlcklkIFx1N0VEMVx1NUI5QVx1RkYxQVx1Njc4NFx1OTAyMFx1NjVGNlx1NTNFRlx1NEYyMFx1NTE2NSBtb2R1bGVJZFx1RkYwQ1x1NTQwRVx1N0VFRFx1NkJDRlx1NkIyMSBpbnZva2UgXHU4MUVBXHU1MkE4XHU0RUU1IGBJbnZva2VDb250ZXh0YCBcdTRGMjBcdTkwMTJcdTdFRDkgYnJpZGdlXHVGRjBDXG4gKiBcdTRGN0ZcdTVGOTdcdTYzODhcdTY3NDNcdTVDNDJcdTgwRkRcdThCQzZcdTUyMkJcdThDMDNcdTc1MjhcdTY3NjVcdTZFOTBcdTMwMDJcdTRFMERcdTRGMjAgY2FsbGVySWQgXHU2NUY2XHU3QjQ5XHU0RUY3XHU0RThFXHU1QkJGXHU0RTNCXHU4QzAzXHU3NTI4XHVGRjA4XHU1NDExXHU1NDBFXHU1MTdDXHU1QkI5XHVGRjA5XHUzMDAyXG4gKlxuICogQGV4YW1wbGVcbiAqIGBgYHRzXG4gKiAvLyBcdTVCQkZcdTRFM0JcdThDMDNcdTc1MjhcdUZGMDhcdTY1RTBcdTY3NDNcdTk2NTBcdTk2NTBcdTUyMzZcdUZGMDlcbiAqIGNvbnN0IHNraWxscyA9IGNyZWF0ZUd1ZXN0UHJveHkoJ3NraWxscycsIHdiSW52b2tlKTtcbiAqIGF3YWl0IHNraWxscy5pbnN0YWxsZWQoKTsgICAgIC8vIFx1MjE5MiBpbnZva2UoJ3diOnNraWxsczppbnN0YWxsZWQnKVxuICpcbiAqIC8vIFx1NkEyMVx1NTc1N1x1OEMwM1x1NzUyOFx1RkYwOFx1OTY0NFx1NUUyNiBtb2R1bGVJZCBcdThENzBcdTY3NDNcdTk2NTBcdTY4QzBcdTY3RTVcdUZGMDlcbiAqIGNvbnN0IHNraWxscyA9IGNyZWF0ZUd1ZXN0UHJveHkoJ3NraWxscycsIHdiSW52b2tlLCB7IGNhbGxlcklkOiAnbXktbW9kdWxlJyB9KTtcbiAqIGF3YWl0IHNraWxscy5tYXJrZXRwbGFjZS5idWlsdGluLmxpc3QoKTtcbiAqXG4gKiAvLyBcdTI1MDBcdTI1MDBcdTI1MDAgXHU2MjE2XHU4MDA1XHVGRjFBXHU0RTBEXHU5ODg0XHU1MTQ4XHU2MzA3XHU1QjlBIG5hbWVzcGFjZVx1RkYwQ1x1NzUyOCBjcmVhdGVHdWVzdFdiIFx1NjJGRlx1NEUyQVwiXHU1MTY4XHU4MEZEIHdiXCIgXHUyNTAwXHUyNTAwXHUyNTAwXG4gKiBjb25zdCB3YiA9IGNyZWF0ZUd1ZXN0V2Iod2JJbnZva2UpO1xuICogYXdhaXQgd2Iuc2tpbGxzLmluc3RhbGxlZCgpO1xuICogYXdhaXQgd2Iuc3RvcmFnZS51c2VyLnNldCgnbnMnLCAnaycsICd2Jyk7XG4gKiBgYGBcbiAqL1xuXG5pbXBvcnQgeyBnZXRCdXMsIHR5cGUgV0JCdXNIYW5kbGVyIH0gZnJvbSAnLi4vLi4vaW5mcmEvYnVzL2J1cyc7XG5pbXBvcnQgeyBkZXNlcmlhbGl6ZVJlc3VsdCB9IGZyb20gJy4uL2JvdW5kYXJ5L2Vycm9yLWVudmVsb3BlJztcbmltcG9ydCB0eXBlIHsgQnJpZGdlU3ViamVjdCB9IGZyb20gJy4uL2JvdW5kYXJ5L3Blcm1pc3Npb24vYXV0aG9yaXphdGlvbic7XG5pbXBvcnQgeyBXQl9CUklER0VfU1VCU0NSSUJFX0VWRU5UX0NIQU5ORUwsIFdCX0JSSURHRV9VTlNVQlNDUklCRV9FVkVOVF9DSEFOTkVMIH0gZnJvbSAnLi4vYm91bmRhcnkvdHJhbnNwb3J0L3Byb3RvY29sJztcbmltcG9ydCB0eXBlIHsgRXZlbnRIYW5kbGVyLCBJbnZva2VDb250ZXh0LCBJbnZva2VGbiB9IGZyb20gJy4uL2JvdW5kYXJ5L3RyYW5zcG9ydC90eXBlcyc7XG5cbi8vIFx1MjUwMFx1MjUwMFx1MjUwMCBgLmxpc3RgIGNoYW5uZWwgXHU4MjgyXHU2RDQxIC8gXHU3RjEzXHU1QjU4IGhpdFx1RkYwOHJlbmRlcmVyIE9PTSAvIElQQyBcdTZEMkFcdTZDMzRcdTdGMTNcdTg5RTNcdUZGMDkgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG4vL1xuLy8gXHUzMDEwXHU4MENDXHU2NjZGXHUzMDExcmVuZGVyZXIgXHU5MUNDXHU1OTFBXHU0RTJBXHU3RUM0XHU0RUY2XHVGRjA4XHU0RkE3XHU2ODBGXHU1MjE3XHU4ODY4XHUzMDAxXHU1NDdEXHU0RUU0XHU5NzYyXHU2NzdGXHUzMDAxUHJvdmlkZXIgXHU4OEM1XHU5MTREXHUzMDAxaG9va3MgXHU3QjQ5XHVGRjA5XG4vLyBcdTRGMUFcdTU0MDRcdTgxRUFcdThDMDNcdTc1MjggYHdiLjxucz4uPC4uLj4ubGlzdCguLi4pYFx1RkYwQ1x1NTQwQ1x1NEUwMFx1NjVGNlx1NTIzQlx1NTNFRlx1ODBGRFx1NTM0MVx1NTFFMFx1NTkwNFx1NTQwQ1x1NTNDMlx1NjU3MFx1NUU3Nlx1NTNEMVx1RkYxQlx1NTM3M1x1NEY3Rlx1NEUwRFx1NUU3Nlx1NTNEMVx1RkYwQ1xuLy8gXHU3N0VEXHU2NUY2XHU5NUY0XHU1MTg1XHU1M0NEXHU1OTBEXHU4QzAzXHU3NTI4XHU0RTVGXHU0RjFBXHU2MjUzXHU1MUZBXHU2MjEwIE4gXHU2QjIxXHU1NDBDXHU1M0MyXHU2NTcwIElQQ1x1MzAwMlx1NTIxN1x1ODg2OFx1N0M3Qlx1NjNBNVx1NTNFM1x1N0VEM1x1Njc5Q1x1OTAxQVx1NUUzOFx1NTcyOFx1NTFFMFx1NzY3RSBtcyBcdTUxODVcdTRFMERcdTUzRDhcdUZGMENcbi8vIFx1NTcyOCBndWVzdCBwcm94eSBcdTVDNDJcdTUwNUFcdTRFMDBcdTZCMjFcdTMwMENcdThGREJcdTg4NENcdTRFMkRcdTU0MDhcdTVFNzYgKyBcdTc3RUQgVFRMIFx1N0VEM1x1Njc5Q1x1NTkwRFx1NzUyOFx1MzAwRFx1ODBGRFx1NjYwRVx1NjYzRVx1NTI0QSBJUENcdTMwMDJcbi8vXG4vLyBcdTMwMTBcdTUzRUFcdTVCRjkgYC5saXN0YCBcdTdFRDNcdTVDM0VcdTc2ODQgY2hhbm5lbCBcdTc1MUZcdTY1NDhcdTMwMTFcdTIwMTRcdTIwMTQgbWV0aG9kIG5hbWUgXHU2NjJGIGBsaXN0YCBcdTYyNERcdThENzBcdTdGMTNcdTVCNThcdUZGMUJcdTUxNzZcdTVCODNcdTY1QjlcdTZDRDVcbi8vIFx1RkYwOGNyZWF0ZSAvIGdldCAvIHVwZGF0ZSAvIHNlbmQgXHU3QjQ5XHVGRjA5XHU0RkREXHU2MzAxXHU1MzlGXHU4QkVEXHU0RTQ5XHUzMDAyXHU1MjI0XHU1QjlBXHU1N0ZBXHU0RThFIHBhdGggXHU1QzNFXHU2QkI1XHU1QjU3XHU3QjI2XHU0RTMyXHVGRjBDXHU2NUUwXHU5NzAwXHU0RTFBXHU1MkExXHU2NUI5XG4vLyBcdTY2M0VcdTVGMEZcdTU4RjBcdTY2MEVcdTMwMDJcbi8vXG4vLyBcdTMwMTBcdTUzRUFcdTdGMTNcdTVCNTggZnVsZmlsbGVkIFByb21pc2VcdTMwMTFcdTIwMTRcdTIwMTQgcmVqZWN0ZWQgXHU3QUNCXHU1MjNCXHU0RUNFIGNhY2hlIFx1NzlGQlx1OTY2NFx1RkYwQ1x1OTA3Rlx1NTE0RFx1OTUxOVx1OEJFRlx1N0VEM1x1Njc5Q1x1NjMwMVx1NEU0NVx1NTMxNlx1MzAwMlxuLy8gcGVuZGluZyBcdTY3MUZcdTk1RjRcdTRFNUZcdTUxNzFcdTRFQUJcdTU0MENcdTRFMDBcdTRFMkEgUHJvbWlzZVx1RkYwOGluLWZsaWdodCBkZWR1cFx1RkYwOVx1RkYwQ1x1NUU3Nlx1NTNEMVx1NTkxQVx1NzBCOVx1NTQwQ1x1NTNDMlx1NjU3MFx1NjI1M1x1OEZEQlx1Njc2NVx1NTNFQVx1NTNEMVx1NEUwMFx1NkIyMSBJUENcdTMwMDJcbi8vXG4vLyBcdTMwMTBcdTUxNzNcdTk1RURcdTVGMDBcdTUxNzNcdTMwMTFcdTczQUZcdTU4ODNcdTUzRDhcdTkxQ0YgYFdCX0dVRVNUX0xJU1RfVEhST1RUTEVfTVNgXHVGRjFBXG4vLyAgIC0gXHU2NzJBXHU4QkJFXHU3RjZFIC8gXHU5NzVFXHU2Q0Q1XHU1MDNDIFx1MjE5MiBcdTlFRDhcdThCQTQgMzAwbXNcbi8vICAgLSBcdTY2M0VcdTVGMEYgMCBcdTIxOTIgXHU1MTczXHU5NUVEXHU3RjEzXHU1QjU4XHVGRjA4XHU1NkRFXHU5MDAwXHU1MjMwXHU3NkY0XHU5MDFBXHVGRjA5XHVGRjFCXHU2QkNGXHU2QjIxXHU4QzAzXHU3NTI4XHU3MTY3XHU1RTM4XHU1M0QxIElQQ1xuLy8gICAtIFx1NkI2M1x1NjU3NFx1NjU3MCBcdTIxOTIgXHU0RjdGXHU3NTI4XHU4QkU1XHU1MDNDXHU0RjVDXHU0RTNBIGZ1bGZpbGxlZCBcdTdFRDNcdTY3OUNcdTc2ODQgVFRMXG4vL1xuLy8gXHUzMDEwXHU0RTNBXHU0RUMwXHU0RTQ4XHU0RTBEXHU1MDVBXHU2REYxXHU2MkY3XHU4RDFEXHUzMDExY2FjaGUgXHU1NDdEXHU0RTJEXHU3NkY0XHU2M0E1XHU4RkQ0XHU1NkRFXHU1NDBDXHU0RTAwXHU0RTJBIFByb21pc2VcdUZGMDhhd2FpdCBcdTUxRkFcdTY3NjVcdTY2MkZcdTU0MENcdTRFMDBcdTRFRkQgcmVzdWx0IFx1NUYxNVx1NzUyOFx1RkYwOVx1MzAwMlxuLy8gXHU0RTFBXHU1MkExXHU2NUI5XHU0RTBEXHU1MTQxXHU4QkI4IG11dGF0ZSBsaXN0IFx1OEZENFx1NTZERVx1NTAzQ1x1MjAxNFx1MjAxNFdCIFx1NEZBNyBsaXN0IFx1N0VEM1x1Njc5Q1x1NjMwOSBBUEkgXHU1OTUxXHU3RUE2XHU2NjJGXHU1M0VBXHU4QkZCXHU1RkVCXHU3MTY3XHUzMDAyXHU1OTgyXHU2NzlDXHU2NzJBXHU2NzY1XG4vLyBcdTUxRkFcdTczQjAgbXV0YXRlIFx1ODg0Q1x1NEUzQVx1NTE4RFx1ODAwM1x1ODY1MVx1NTFCQlx1N0VEMyAvIFx1N0VEM1x1Njc4NFx1NTMxNlx1NTE0Qlx1OTY4Nlx1MzAwMlxuY29uc3QgREVGQVVMVF9MSVNUX1RIUk9UVExFX01TID0gMzAwO1xuXG5mdW5jdGlvbiByZWFkTGlzdFRocm90dGxlTXMoKTogbnVtYmVyIHtcbiAgICBpZiAodHlwZW9mIHByb2Nlc3MgPT09ICd1bmRlZmluZWQnKSB7IHJldHVybiBERUZBVUxUX0xJU1RfVEhST1RUTEVfTVM7IH1cbiAgICBjb25zdCByYXcgPSBwcm9jZXNzLmVudj8uV0JfR1VFU1RfTElTVF9USFJPVFRMRV9NUztcbiAgICBpZiAocmF3ID09PSB1bmRlZmluZWQpIHsgcmV0dXJuIERFRkFVTFRfTElTVF9USFJPVFRMRV9NUzsgfVxuICAgIGNvbnN0IHBhcnNlZCA9IE51bWJlcihyYXcpO1xuICAgIGlmICghTnVtYmVyLmlzRmluaXRlKHBhcnNlZCkgfHwgcGFyc2VkIDwgMCkgeyByZXR1cm4gREVGQVVMVF9MSVNUX1RIUk9UVExFX01TOyB9XG4gICAgcmV0dXJuIE1hdGguZmxvb3IocGFyc2VkKTtcbn1cblxuY29uc3QgTElTVF9USFJPVFRMRV9NUyA9IHJlYWRMaXN0VGhyb3R0bGVNcygpO1xuXG4vKiogXHU1MzU1XHU0RTJBIGAubGlzdGAgY2hhbm5lbCBcdTc2ODQgY2FjaGUgXHU2NzYxXHU3NkVFXHUzMDAyZnVsZmlsbGVkQXQgXHU1QjU4XHU1NzI4XHU1MzczXHU0RTNBXHUzMDBDXHU1REYyIHNldHRsZVx1RkYwQ1x1NTkwNFx1NEU4RSBUVEwgXHU0RkREXHU3NTU5XHU2NzFGXHUzMDBEXHUzMDAyICovXG5pbnRlcmZhY2UgTGlzdENhY2hlRW50cnkge1xuICAgIHByb21pc2U6IFByb21pc2U8dW5rbm93bj47XG4gICAgZnVsZmlsbGVkQXQ/OiBudW1iZXI7XG59XG5cbi8qKiBcdTUzQzJcdTY1NzBcdTVFOEZcdTUyMTdcdTUzMTYgXHUyMDE0XHUyMDE0IFx1NzUyOCBKU09OLnN0cmluZ2lmeSBcdTc1MUZcdTYyMTAgY2FjaGUga2V5XHUzMDAyICovXG5mdW5jdGlvbiBzZXJpYWxpemVMaXN0QXJncyhhcmdzOiByZWFkb25seSB1bmtub3duW10pOiBzdHJpbmcgfCB1bmRlZmluZWQge1xuICAgIHRyeSB7XG4gICAgICAgIHJldHVybiBKU09OLnN0cmluZ2lmeShhcmdzKTtcbiAgICB9IGNhdGNoIHtcbiAgICAgICAgLy8gXHU1M0MyXHU2NTcwXHU1NDJCXHU1RkFBXHU3M0FGXHU1RjE1XHU3NTI4IC8gU3ltYm9sIC8gRnVuY3Rpb24gXHU3QjQ5XHU2NUUwXHU2Q0Q1XHU1RThGXHU1MjE3XHU1MzE2XHU3Njg0XHU0RTFDXHU4OTdGIFx1MjE5MiBcdTY1M0VcdTVGMDNcdTdGMTNcdTVCNThcdUZGMENcdThENzBcdTUzOUZcdThERUZcdTVGODRcdTMwMDJcbiAgICAgICAgLy8gXHU0RTBEXHU3RjEzXHU1QjU4XHU2QkQ0XHU0RTcxXHU3RjEzXHU1QjU4XHU1Qjg5XHU1MTY4XHVGRjA4XHU1QjgxXHU1M0VGXHU1OTFBXHU1M0QxIElQQyBcdTRFNUZcdTRFMERcdTgwRkRcdThGRDRcdTU2REVcdTk1MTlcdTc2ODRcdTdFRDNcdTY3OUNcdTdFRDlcdTUyMkJcdTc2ODQgY2FsbGVyXHVGRjA5XHUzMDAyXG4gICAgICAgIHJldHVybiB1bmRlZmluZWQ7XG4gICAgfVxufVxuXG4vKiogY3JlYXRlR3Vlc3RQcm94eSBcdTkxNERcdTdGNkVcdTkwMDlcdTk4NzkgKi9cbmV4cG9ydCBpbnRlcmZhY2UgQ3JlYXRlR3Vlc3RQcm94eU9wdGlvbnMge1xuICAgIC8qKiBcdThDMDNcdTc1MjhcdTY1QjlcdTVCOENcdTY1NzRcdTRFM0JcdTRGNTNcdUZGMUJcdTUzRUZcdTRGRTEgSG9zdCBcdTg4QzVcdTkxNERcdTVFOTRcdTRGMThcdTUxNDhcdTRGMjBcdTZCNjRcdTk4NzlcdTMwMDIgKi9cbiAgICBzdWJqZWN0PzogQnJpZGdlU3ViamVjdDtcbiAgICAvKiogXHU4QzAzXHU3NTI4XHU2NUI5IG1vZHVsZUlkXHUzMDAyXHU0RTBEXHU0RjIwIHN1YmplY3QgXHU2NUY2XHU4RjZDXHU2MzYyXHU0RTNBIHR5cGU9bW9kdWxlXHUzMDAxc2NvcGVzPVtdIFx1NzY4NCBTdWJqZWN0XHUzMDAyICovXG4gICAgY2FsbGVySWQ/OiBzdHJpbmc7XG4gICAgLyoqXG4gICAgICogQ2FjaGUvZGVkdXBsaWNhdGUgYC5saXN0YCBjYWxscyBpbiB0aGlzIHByb3h5IHRyZWUgKGRlZmF1bHQgdHJ1ZSkuXG4gICAgICogU2V0IGZhbHNlIHdoZW4gYSBsaWZlY3ljbGUtYXdhcmUgc3RvcmUgYWxyZWFkeSBvd25zIGZyZXNobmVzcyBhbmQgaW4tZmxpZ2h0XG4gICAgICogY29vcmRpbmF0aW9uOyBpdHMgcmVmcmVzaCBtdXN0IGJlIGFibGUgdG8gcmVhZCBhIG5ldyBzbmFwc2hvdCBpbW1lZGlhdGVseS5cbiAgICAgKi9cbiAgICBjYWNoZUxpc3RSZXN1bHRzPzogYm9vbGVhbjtcbn1cblxuZnVuY3Rpb24gcmVzb2x2ZUludm9rZUNvbnRleHQob3B0aW9ucz86IENyZWF0ZUd1ZXN0UHJveHlPcHRpb25zKTogSW52b2tlQ29udGV4dCB8IHVuZGVmaW5lZCB7XG4gICAgY29uc3Qgc3ViamVjdCA9IG9wdGlvbnM/LnN1YmplY3QgPz8gKG9wdGlvbnM/LmNhbGxlcklkXG4gICAgICAgID8geyBtb2R1bGVJZDogb3B0aW9ucy5jYWxsZXJJZCwgdHlwZTogJ21vZHVsZScgYXMgY29uc3QsIHNjb3BlczogW10gfVxuICAgICAgICA6IHVuZGVmaW5lZCk7XG4gICAgaWYgKCFzdWJqZWN0KSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgICByZXR1cm4geyBjYWxsZXJJZDogc3ViamVjdC5tb2R1bGVJZCwgc3ViamVjdCB9O1xufVxuXG4vKiogY3JlYXRlR3Vlc3RXYiBcdTkxNERcdTdGNkVcdTkwMDlcdTk4NzlcdUZGMDhcdTU3MjggR3Vlc3RQcm94eSBcdTU3RkFcdTc4NDBcdTRFMEFcdTUyQTBcdTRFOEJcdTRFRjZcdThCQTJcdTk2MDVcdTY1MkZcdTYzMDFcdUZGMDkgKi9cbmV4cG9ydCBpbnRlcmZhY2UgQ3JlYXRlR3Vlc3RXYk9wdGlvbnMgZXh0ZW5kcyBDcmVhdGVHdWVzdFByb3h5T3B0aW9ucyB7XG4gICAgLyoqIFJlbGVhc2VzIG9ubHkgc3Vic2NyaXB0aW9ucyBvd25lZCBieSB0aGlzIFNESyBpbnN0YW5jZSB3aGVuIGFib3J0ZWQuICovXG4gICAgc2lnbmFsPzogQWJvcnRTaWduYWw7XG4gICAgLyoqXG4gICAgICogXHU0RThCXHU0RUY2XHU4QkEyXHU5NjA1XHU1MTY1XHU1M0UzXHVGRjA4XHU1M0VGXHU5MDA5XHVGRjA5XHUyMDE0XHUyMDE0IFx1NEYyMFx1NTE2NVx1NTQwRSBgd2Iub24gLyB3Yi5vZmYgLyB3Yi5vbkFueWAgXHU2MjREXHU0RjFBXHU2NTM2XHU1MjMwXHU4RkRDXHU3QUVGXHU0RThCXHU0RUY2XHUzMDAyXG4gICAgICpcbiAgICAgKiBcdTdCN0VcdTU0MERcdThEREYgY29yZSBgRXZlbnRIYW5kbGVyYFx1RkYwOGAoZXZlbnQsIHBheWxvYWQpID0+IHZvaWRgXHVGRjA5XHU0RTAwXHU4MUY0IFx1MjAxNFx1MjAxNCBcdTRGMjBcdTc2ODRcdTY2MkYgdHJhbnNwb3J0XG4gICAgICogXHU1QzQyXHU3Njg0IGV2ZW50IGxpc3RlbmVyIHNsb3RcdUZGMDhcdTU5ODIgYGNyZWF0ZU1lc3NhZ2VQb3J0SW52b2tlKCkub25gIC9cbiAgICAgKiBgY3JlYXRlUHJvY2Vzc0NsaWVudFRyYW5zcG9ydCgpLm9uYFx1RkYwOVx1MzAwMlx1OTk5Nlx1NkIyMVx1OEMwMyBgd2Iub24gLyB3Yi5vbkFueWAgXHU2NUY2IGxhenkgYXR0YWNoXHVGRjBDXG4gICAgICogXHU2MkZGXHU1MjMwXHU3Njg0XHU4RkRDXHU3QUVGXHU0RThCXHU0RUY2XHU5MDFBXHU4RkM3IGBnZXRCdXMoKS5lbWl0KGV2ZW50LCBwYXlsb2FkKWAgXHU4RjZDXHU1M0QxXHU1MjMwXHU2NzJDXHU4RkRCXHU3QTBCIGJ1c1x1MzAwMlxuICAgICAqIGB3Yi5vbi9vZmZgIFx1NTQwQ1x1NjVGNlx1NzY3Qlx1OEJCMC9cdTUzRDZcdTZEODhcdTVCQkZcdTRFM0JcdTc2ODRcdTUxNzdcdTU0MERcdTRFOEJcdTRFRjZcdThCQTJcdTk2MDVcdUZGMUJgb25BbnlgIFx1NzZEMVx1NTQyQ1x1NURGMlx1OTAwMVx1OEZCRVx1NjcyQ1x1NTczMFx1NzY4NFx1NEU4Qlx1NEVGNlx1MzAwMlxuICAgICAqXG4gICAgICogXHUzMDEwXHU0RTNBXHU0RUMwXHU0RTQ4XHU1RkM1XHU5ODdCXHU4RkQ5XHU1QzQyXHU1QzAxXHU4OEM1XHUzMDExXG4gICAgICogICBndWVzdCBwcm94eSBcdTUzRUFcdTYyOEFcdTY1QjlcdTZDRDVcdThDMDNcdTc1MjhcdTdGRkJcdThCRDFcdTYyMTAgUlBDXHVGRjBDXHU2NUUwXHU2Q0Q1XHU2MjdGXHU4RjdEXHU4QkEyXHU5NjA1XHU4QkVEXHU0RTQ5XHVGRjA4aGFuZGxlciBmdW5jdGlvbiBcdTY1RTBcdTZDRDVcbiAgICAgKiAgIFx1OERFOCBJUEMgXHU1RThGXHU1MjE3XHU1MzE2XHVGRjBDXHU0RTE0IGRhZW1vbiBcdTRGQTdcdTZDQTFcdTY3MDkgYHdiOm9uYCBoYW5kbGVyXHVGRjA5XHUzMDAyXG4gICAgICpcbiAgICAgKiBcdTMwMTBcdTRFM0FcdTRFQzBcdTRFNDhcdTc2RjRcdTYzQTVcdTc1MjggZ2V0QnVzKCkgXHU4MDBDXHU0RTBEXHU4MUVBXHU1REYxXHU5MDIwIGRpc3BhdGNoZXJcdTMwMTFcbiAgICAgKiAgIGBnZXRCdXMoKWAgXHU2NjJGKipcdThGREJcdTdBMEJcdTdFQTdcdTUzNTVcdTRGOEIqKiBcdTIwMTRcdTIwMTQgZXh0ZW5zaW9uIFx1NUI1MFx1OEZEQlx1N0EwQiAvIGlmcmFtZSAvIHdlYnZpZXcgXHU1NDA0XHU4MUVBXHU3Njg0XG4gICAgICogICBgZ2V0QnVzKClgIFx1NTkyOVx1NzEzNlx1OTY5NFx1NzlCQlx1RkYwOFx1NEUwRFx1NTQwQyBKUyByZWFsbVx1RkYwOVx1RkYwQ1x1OERERiBkYWVtb24gXHU0RTNCXHU4RkRCXHU3QTBCXHU3Njg0IGJ1cyBcdTY2MkZcdTRFMERcdTU0MENcdTVCOUVcdTRGOEJcdUZGMENcdTRFMERcdTRGMUFcdTRFMzJcdTMwMDJcbiAgICAgKiAgIGd1ZXN0IFx1OEZEQlx1N0EwQlx1NTE4NVx1NTE3Nlx1NEVENiBjb2RlIFx1NEU1Rlx1ODBGRFx1NzUyOFx1NTQwQ1x1NEUwMFx1NEVGRCBidXMgXHU2NTM2XHU1M0QxXHU0RThCXHU0RUY2XHVGRjA4XHU2QkQ0XHU1OTgyIGV4dGVuc2lvbiBzZXJ2ZXIgXHU1MTg1XHU5MEU4XHU2QTIxXHU1NzU3XG4gICAgICogICBcdTRFOTJcdTc2RjhcdTkwMUFcdTRGRTFcdUZGMDlcdUZGMENcdTRFMDBcdTRFRkRcdTVCOUVcdTczQjBcdTg5ODZcdTc2RDZcdTYyNDBcdTY3MDlcdTU3M0FcdTY2NkZcdTMwMDJcbiAgICAgKlxuICAgICAqIFx1MzAxMFx1NEUwRFx1NEYyMFx1NjVGNlx1MzAxMWB3Yi5vbiAvIHdiLm9uQW55YCBcdTRFQ0RcdThGRDRcdTU2REVcdTUzRUZcdTc1MjhcdTc2ODQgYnVzLm9uIC8gb25BbnlcdUZGMENcdTRGNDZcdTY1MzZcdTRFMERcdTUyMzBcdThGRENcdTdBRUZcdTRFOEJcdTRFRjZcbiAgICAgKiAgIFx1RkYwOFx1NTNFQVx1ODBGRFx1NjUzNlx1NjcyQ1x1OEZEQlx1N0EwQlx1NTE4NSBgZ2V0QnVzKCkuZW1pdGAgXHU3Njg0XHU0RThCXHU0RUY2XHVGRjA5XHUyMDE0XHUyMDE0IFx1NTM1NVx1OEZEQlx1N0EwQlx1NTczQVx1NjY2RiAvIFx1NTM1NVx1NkQ0Qlx1NTczQVx1NjY2Rlx1NTNFRlx1NzUyOFx1MzAwMlxuICAgICAqL1xuICAgIHN1YnNjcmliZT86IChsaXN0ZW5lcjogRXZlbnRIYW5kbGVyKSA9PiB2b2lkO1xuICAgIC8qKlxuICAgICAqIFx1NTIwNlx1NUM0MiBTREsgXHU1M0VGXHU2Q0U4XHU1MTY1XHU3Njg0XHU2NzJDXHU1NzMwIG5hbWVzcGFjZSBcdTVCOUVcdTczQjBcdTMwMDJcdTY3MkFcdTU0N0RcdTRFMkRcdTY1RjZcdTRFQ0RcdTU2REVcdTkwMDBcdTUyQThcdTYwMDEgR3Vlc3RQcm94eVx1MzAwMlxuICAgICAqIFx1NzUyOFx1NEU4RSBjYWxsYmFjay9cdTRFOEJcdTRFRjZcdTdDN0IgQVBJXHVGRjBDXHU5MDdGXHU1MTREXHU2MjhBXHU1MUZEXHU2NTcwXHU1M0MyXHU2NTcwXHU5MDAxXHU4RkRCIElQQ1x1MzAwMlxuICAgICAqL1xuICAgIG5hbWVzcGFjZXM/OiBSZWFkb25seTxSZWNvcmQ8c3RyaW5nLCB1bmtub3duPj47XG59XG5cbi8qKlxuICogXHU1MjFCXHU1RUZBXHU4RkRDXHU3QTBCIG5hbWVzcGFjZSBcdTRFRTNcdTc0MDZcdTMwMDJcbiAqXG4gKiBAcGFyYW0gbmFtZXNwYWNlIFx1OTg3Nlx1NUM0Mlx1NTQ3RFx1NTQwRFx1N0E3QVx1OTVGNFx1RkYwOFx1NTk4MiBgJ3NraWxscydgXHVGRjA5XG4gKiBAcGFyYW0gaW52b2tlIFx1OTAxQVx1OTA1M1x1NTFGRFx1NjU3MFx1RkYwOGBicmlkZ2UuaW52b2tlYCAvIGBjcmVhdGVJcGNJbnZva2UoaXBjUmVuZGVyZXIpYCAvIGBjcmVhdGVNZXNzYWdlUG9ydEludm9rZSh7IHBvcnQgfSlgXHVGRjA5XG4gKiBAcGFyYW0gb3B0aW9ucyBcdTUzRUZcdTkwMDlcdTkxNERcdTdGNkVcdUZGMDhgY2FsbGVySWRgIFx1N0I0OVx1RkYwOVxuICovXG5leHBvcnQgZnVuY3Rpb24gY3JlYXRlR3Vlc3RQcm94eShuYW1lc3BhY2U6IHN0cmluZywgaW52b2tlOiBJbnZva2VGbiwgb3B0aW9ucz86IENyZWF0ZUd1ZXN0UHJveHlPcHRpb25zKTogYW55IHtcbiAgICByZXR1cm4gX3Byb3h5KG5hbWVzcGFjZSwgaW52b2tlLCByZXNvbHZlSW52b2tlQ29udGV4dChvcHRpb25zKSwgb3B0aW9ucz8uY2FjaGVMaXN0UmVzdWx0cyAhPT0gZmFsc2UpO1xufVxuXG4vKipcbiAqIFx1NTIxQlx1NUVGQVwiXHU1MTY4XHU4MEZEIHdiIFx1NEVFM1x1NzQwNlwiXHUyMDE0XHUyMDE0IFx1OTg3Nlx1NUM0MiBQcm94eSBcdTUyQThcdTYwMDFcdTZEM0VcdTUzRDFcdTUyMzAgbmFtZXNwYWNlXHVGRjBDXHU4RERGXHU1QkJGXHU0RTNCIGB3Yi4qYCBcdTdFRDNcdTY3ODRcdTU0MENcdTY3ODRcdTMwMDJcbiAqXG4gKiBcdTRFMERcdTk3MDBcdTg5ODFcdTYzRDBcdTUyNERcdTUyMTdcdTRFM0UgbmFtZXNwYWNlXHVGRjBDXHU0RUZCXHU0RjU1IGB3Yi54eHhgIFx1OEJCRlx1OTVFRVx1NEYxQVx1ODFFQVx1NTJBOFx1NzUxRlx1NjIxMFx1NEUwMFx1NEUyQSBgY3JlYXRlR3Vlc3RQcm94eSgneHh4JywgaW52b2tlKWBcdTMwMDJcbiAqIFx1OTAwMlx1NTQwOCBpZnJhbWUgLyB3ZWJ2aWV3IC8gZXh0ZW5zaW9uIFx1NUI1MFx1OEZEQlx1N0EwQiBndWVzdCBcdTRGQTdcdTRFMDBcdTg4NENcdTYzQTVcdTUxNjUgd2JcdTMwMDJcbiAqXG4gKiBcdTI2QTBcdUZFMEYgXHU3QzdCXHU1NzhCXHVGRjFBXHU4RkQ0XHU1NkRFXHU1MDNDXHU2NTQ1XHU2MTBGXHU3NTI4IGBhbnlgIFx1MjAxNFx1MjAxNCBcdTUxNjhcdTUyQThcdTYwMDFcdTZEM0VcdTUzRDFcdTc2ODRcdTVCRjlcdThDNjFcdTY1RTBcdTZDRDVcdTU3MjhcdTdDN0JcdTU3OEJcdTVDNDJcdTY1MzZcdTdBODRcdTMwMDJcdTRFMUFcdTUyQTFcdTk3MDBcdTg5ODFcdTVGM0FcdTdDN0JcdTU3OEJcdTY1RjZcdTUzRUZcdTRFRTVcbiAqIGBjb25zdCB3YiA9IGNyZWF0ZUd1ZXN0V2IoLi4uKSBhcyB1bmtub3duIGFzIFdvcmtidWRkeVNES2BcdUZGMDhcdThEREYgd2luZG93LndiIFx1NzY4NFx1NTA1QVx1NkNENVx1NEUwMFx1ODFGNFx1RkYwOVx1MzAwMlxuICpcbiAqIEBleGFtcGxlXG4gKiBgYGB0c1xuICogY29uc3Qgd2IgPSBjcmVhdGVHdWVzdFdiKGludm9rZSwge1xuICogICAgIGNhbGxlcklkOiAnbXktZXh0ZW5zaW9uJyxcbiAqICAgICBzdWJzY3JpYmU6IHRyYW5zcG9ydC5vbiwgIC8vIFx1NEYyMFx1NTE2NVx1NjI0RFx1ODBGRCB3Yi5vbiBcdTY1MzZcdTUyMzBcdThGRENcdTdBRUZcdTRFOEJcdTRFRjZcbiAqIH0pO1xuICogYXdhaXQgd2Iuc2tpbGxzLmluc3RhbGxlZCgpO1xuICogYXdhaXQgd2Iuc3RvcmFnZS51c2VyLnNldCgnZHJhZnRzJywgJ3gnLCAnaGVsbG8nKTtcbiAqIHdiLm9uKCdzb21lLmV2ZW50JywgcGF5bG9hZCA9PiBjb25zb2xlLmxvZyhwYXlsb2FkKSk7XG4gKiBhd2FpdCB3Yi5pbnZva2UoJ2NsYXc6Z2V0V2VjaGF0bXBFbmFibGVkJyk7ICAvLyBcdTkwMDNcdTc1MUZcdTgyMzFcdUZGMUFcdTRFRkJcdTYxMEYgZGFlbW9uIGNoYW5uZWxcbiAqIGBgYFxuICovXG5leHBvcnQgZnVuY3Rpb24gY3JlYXRlR3Vlc3RXYihpbnZva2U6IEludm9rZUZuLCBvcHRpb25zPzogQ3JlYXRlR3Vlc3RXYk9wdGlvbnMpOiBhbnkge1xuICAgIC8vIFx1NEU4Qlx1NEVGNlx1OTc2Mlx1RkYxQVx1NzZGNFx1NjNBNVx1NTkwRFx1NzUyOFx1OEZEQlx1N0EwQlx1N0VBNyBXQkJ1cyBcdTUzNTVcdTRGOEJcdTMwMDJcbiAgICAvLyBnZXRCdXMoKSBcdTU3MjggZXh0ZW5zaW9uIFx1NUI1MFx1OEZEQlx1N0EwQiAvIGlmcmFtZSAvIHdlYnZpZXcgXHU5MUNDXHU2NjJGXHU1NDA0XHU4MUVBIHJlYWxtIFx1NzJFQ1x1N0FDQlx1NUI5RVx1NEY4Qlx1RkYwQ1x1OERERiBkYWVtb25cbiAgICAvLyBcdTRFM0JcdThGREJcdTdBMEJcdTc2ODQgYnVzIFx1NTkyOVx1NzEzNlx1OTY5NFx1NzlCQlx1MzAwMnN1YnNjcmliZVx1RkYwOHRyYW5zcG9ydC5vblx1RkYwOVx1NjUzNlx1NTIzMFx1OEZEQ1x1N0FFRlx1NEU4Qlx1NEVGNlx1OEY2Q1x1NTNEMVx1NTIzMFx1NjcyQ1x1OEZEQlx1N0EwQiBidXNcdUZGMENcbiAgICAvLyB3Yi5vbi9vZmYvb25BbnkgXHU1OUQ0XHU2RDNFIGJ1c1x1RkYxQnNpZ25hbCBcdTUzRUFcdTkxQ0FcdTY1M0VcdTVGNTNcdTUyNEQgR3Vlc3QgU0RLIFx1NjMwMVx1NjcwOVx1NzY4NFx1OEJBMlx1OTYwNVx1MzAwMlxuICAgIGNvbnN0IGJ1cyA9IGdldEJ1cygpO1xuICAgIGxldCBzdWJzY3JpYmVBdHRhY2hlZCA9IGZhbHNlO1xuICAgIGNvbnN0IHNpZ25hbCA9IG9wdGlvbnM/LnNpZ25hbDtcbiAgICBjb25zdCBsb2NhbFJlbGVhc2VzID0gbmV3IFNldDwoKSA9PiB2b2lkPigpO1xuICAgIGZ1bmN0aW9uIGVuc3VyZVN1YnNjcmliZWQoKTogdm9pZCB7XG4gICAgICAgIGlmIChzaWduYWw/LmFib3J0ZWQgfHwgc3Vic2NyaWJlQXR0YWNoZWQgfHwgIW9wdGlvbnM/LnN1YnNjcmliZSkgeyByZXR1cm47IH1cbiAgICAgICAgc3Vic2NyaWJlQXR0YWNoZWQgPSB0cnVlO1xuICAgICAgICBvcHRpb25zLnN1YnNjcmliZSgoZXZlbnQsIHBheWxvYWQpID0+IHsgaWYgKCFzaWduYWw/LmFib3J0ZWQpIHsgYnVzLmVtaXQoZXZlbnQsIHBheWxvYWQpOyB9IH0pO1xuICAgIH1cblxuICAgIC8vIGNvbnRleHRcdUZGMDhzdWJqZWN0IC8gXHU1MTdDXHU1QkI5IGNhbGxlcklkXHVGRjA5XHU1OTBEXHU3NTI4IEd1ZXN0UHJveHkgXHU3Njg0XHU4OUM0XHU1MjE5XHVGRjFCaW52b2tlIFx1OTAwM1x1NzUxRlx1ODIzMVx1NEU1Rlx1NTkwRFx1NzUyOFx1NTQwQ1x1NEUwMCBjb250ZXh0XHUzMDAyXG4gICAgY29uc3QgaW52b2tlQ29udGV4dCA9IHJlc29sdmVJbnZva2VDb250ZXh0KG9wdGlvbnMpO1xuXG4gICAgLy8gXHU4RkRDXHU3QUVGXHU2MzA5XHU0RThCXHU0RUY2XHU1NDBEXHU2Mjk1XHU5MDEyXHVGRjFCXHU2NzJDXHU1NzMwXHU2NzAwXHU1NDBFXHU0RTAwXHU0RTJBXHU3NkQxXHU1NDJDXHU3OUZCXHU5NjY0XHU2NUY2XHU2MjREXHU1M0Q2XHU2RDg4XHU1QkJGXHU0RTNCXHU4QkEyXHU5NjA1XHUzMDAyXG4gICAgY29uc3QgZXZlbnRIYW5kbGVycyA9IG5ldyBNYXA8c3RyaW5nLCBTZXQ8V0JCdXNIYW5kbGVyPj4oKTtcbiAgICBjb25zdCBvZmYgPSAoZXZlbnQ6IHN0cmluZywgaGFuZGxlcjogV0JCdXNIYW5kbGVyKTogdm9pZCA9PiB7XG4gICAgICAgIGJ1cy5vZmYoZXZlbnQsIGhhbmRsZXIpO1xuICAgICAgICBjb25zdCBoYW5kbGVycyA9IGV2ZW50SGFuZGxlcnMuZ2V0KGV2ZW50KTtcbiAgICAgICAgaWYgKCFoYW5kbGVycz8uZGVsZXRlKGhhbmRsZXIpIHx8IGhhbmRsZXJzLnNpemUgPiAwKSB7IHJldHVybjsgfVxuICAgICAgICBldmVudEhhbmRsZXJzLmRlbGV0ZShldmVudCk7XG4gICAgICAgIGludm9rZShXQl9CUklER0VfVU5TVUJTQ1JJQkVfRVZFTlRfQ0hBTk5FTCwgaW52b2tlQ29udGV4dCwgZXZlbnQpLmNhdGNoKCgpID0+IHVuZGVmaW5lZCk7XG4gICAgfTtcbiAgICBjb25zdCBvbiA9IChldmVudDogc3RyaW5nLCBoYW5kbGVyOiBXQkJ1c0hhbmRsZXIpOiAoKCkgPT4gdm9pZCkgPT4ge1xuICAgICAgICBlbnN1cmVTdWJzY3JpYmVkKCk7XG4gICAgICAgIGlmIChzaWduYWw/LmFib3J0ZWQpIHsgcmV0dXJuICgpID0+IHVuZGVmaW5lZDsgfVxuICAgICAgICBpZiAoIW9wdGlvbnM/LnN1YnNjcmliZSkgeyByZXR1cm4gdHJhY2tSZWxlYXNlKGJ1cy5vbihldmVudCwgaGFuZGxlcikpOyB9XG4gICAgICAgIGJ1cy5vbihldmVudCwgaGFuZGxlcik7XG4gICAgICAgIGxldCBoYW5kbGVycyA9IGV2ZW50SGFuZGxlcnMuZ2V0KGV2ZW50KTtcbiAgICAgICAgaWYgKCFoYW5kbGVycykge1xuICAgICAgICAgICAgaGFuZGxlcnMgPSBuZXcgU2V0KCk7XG4gICAgICAgICAgICBldmVudEhhbmRsZXJzLnNldChldmVudCwgaGFuZGxlcnMpO1xuICAgICAgICAgICAgaW52b2tlKFdCX0JSSURHRV9TVUJTQ1JJQkVfRVZFTlRfQ0hBTk5FTCwgaW52b2tlQ29udGV4dCwgZXZlbnQpLmNhdGNoKCgpID0+IHVuZGVmaW5lZCk7XG4gICAgICAgIH1cbiAgICAgICAgaGFuZGxlcnMuYWRkKGhhbmRsZXIpO1xuICAgICAgICByZXR1cm4gKCkgPT4gb2ZmKGV2ZW50LCBoYW5kbGVyKTtcbiAgICB9O1xuXG4gICAgZnVuY3Rpb24gdHJhY2tSZWxlYXNlKHJlbGVhc2U6ICgpID0+IHZvaWQpOiAoKSA9PiB2b2lkIHtcbiAgICAgICAgY29uc3QgdHJhY2tlZCA9ICgpID0+IHtcbiAgICAgICAgICAgIGlmICghbG9jYWxSZWxlYXNlcy5kZWxldGUodHJhY2tlZCkpIHsgcmV0dXJuOyB9XG4gICAgICAgICAgICByZWxlYXNlKCk7XG4gICAgICAgIH07XG4gICAgICAgIGxvY2FsUmVsZWFzZXMuYWRkKHRyYWNrZWQpO1xuICAgICAgICByZXR1cm4gdHJhY2tlZDtcbiAgICB9XG4gICAgc2lnbmFsPy5hZGRFdmVudExpc3RlbmVyKCdhYm9ydCcsICgpID0+IHtcbiAgICAgICAgZm9yIChjb25zdCBbZXZlbnQsIGhhbmRsZXJzXSBvZiBldmVudEhhbmRsZXJzKSB7XG4gICAgICAgICAgICBmb3IgKGNvbnN0IGhhbmRsZXIgb2YgaGFuZGxlcnMpIHsgb2ZmKGV2ZW50LCBoYW5kbGVyKTsgfVxuICAgICAgICB9XG4gICAgICAgIGZvciAoY29uc3QgcmVsZWFzZSBvZiBsb2NhbFJlbGVhc2VzKSB7IHJlbGVhc2UoKTsgfVxuICAgIH0sIHsgb25jZTogdHJ1ZSB9KTtcblxuICAgIC8vIFx1NkJDRlx1NkIyMVx1OEJCRlx1OTVFRSAubmFtZXNwYWNlIFx1OTBGRFx1OEZENFx1NTZERVx1NEUwMFx1NEUyQVx1NzJFQ1x1N0FDQlx1NzY4NCBjcmVhdGVHdWVzdFByb3h5KG5hbWVzcGFjZSlcdTMwMDJcbiAgICAvLyBcdTc1MjggUHJveHkgXHU4MDBDXHU5NzVFXHU2NjZFXHU5MDFBXHU1QkY5XHU4QzYxXHVGRjFBXHU2NUUwXHU5NzAwXHU5ODg0XHU1MTQ4XHU1MjE3XHU0RTNFXHU2MjQwXHU2NzA5IG5hbWVzcGFjZVx1RkYwQ3diIFx1NEUwQVx1NEVFNVx1NTQwRVx1NTJBMFx1NEU4Nlx1NjVCMCBuYW1lc3BhY2UgZ3Vlc3QgXHU0RkE3XG4gICAgLy8gXHU4MUVBXHU1MkE4XHU1M0VGXHU3NTI4XHVGRjFCXHU0RTE0XHU2MEYwXHU2MDI3XHU1MjFCXHU1RUZBIFx1MjAxNFx1MjAxNCBcdTUzRUFcdTc1MjhcdTUyMzBcdTc2ODQgbmFtZXNwYWNlIFx1NjI0RFx1NEVBN1x1NzUxRlx1NUI1MCBQcm94eVx1MzAwMlxuICAgIC8vXG4gICAgLy8gXHUyNkEwXHVGRTBGICoqXHU3Mjc5XHU1MjI0IGtleSoqIFx1MjAxNFx1MjAxNCBHdWVzdFByb3h5IFx1NEYxQVx1NjI4QVx1OEZEOVx1NEU5QiBrZXkgXHU1RjUzIG5hbWVzcGFjZSBcdTYyRkNcdThERUZcdTVGODRcdUZGMENcdThCRURcdTRFNDlcdTk1MTlcdTRFNzFcdUZGMUFcbiAgICAvLyAgIFx1MDBCNyBgb24vb2ZmL29uQW55YCBcdTY2MkZcdThCQTJcdTk2MDVcdUZGMDhoYW5kbGVyIGZ1bmN0aW9uIFx1NjVFMFx1NkNENVx1OERFOCBJUENcdUZGMDlcdUZGMENcdTc2RjRcdTYzQTVcdTU5RDRcdTZEM0VcdTY3MkNcdThGREJcdTdBMEIgYnVzXG4gICAgLy8gICBcdTAwQjcgYGludm9rZWAgXHU2NjJGXHU5MDFBXHU3NTI4IGNoYW5uZWwgXHU5MDAzXHU3NTFGXHU4MjMxXHVGRjA4Y2hhbm5lbCBcdTc1MzFcdTdCMkNcdTRFMDBcdTRFMkEgYXJnIFx1NEYyMFx1RkYwQ1x1NEUwRFx1NjYyRiBuYW1lc3BhY2UgXHU2MkZDXHVGRjA5XHVGRjBDXG4gICAgLy8gICAgIEd1ZXN0IHByb3h5IFx1NEYxQVx1NjJGQ1x1NTFGQVx1NzU3OFx1NUY2MiBgd2I6Omludm9rZWBcdUZGMDhhcHBseSB0cmFwIFx1OTFDQyBsYXN0RG90PS0xXHVGRjA5XHUyMDE0XHUyMDE0IFx1OEQ3MFx1NEUwRFx1OTAxQVxuICAgIHJldHVybiBuZXcgUHJveHkoe30gYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj4sIHtcbiAgICAgICAgZ2V0KF90YXJnZXQsIHByb3ApIHtcbiAgICAgICAgICAgIGlmICh0eXBlb2YgcHJvcCAhPT0gJ3N0cmluZycpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICAgICAgICAgICAgLy8gUHJvbWlzZS1saWtlIFx1NjNBMlx1NkQ0Qlx1RkYwOGF3YWl0IFx1NEUwMFx1NEUyQVx1OTc1RSBQcm9taXNlIFx1NUJGOVx1OEM2MVx1NjVGNiBKUyBcdTRGMUEgZ2V0KCd0aGVuJylcdUZGMDlcbiAgICAgICAgICAgIGlmIChwcm9wID09PSAndGhlbicgfHwgcHJvcCA9PT0gJ3RvSlNPTicpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuXG4gICAgICAgICAgICAvLyBcdTI1MDBcdTI1MDAgXHU0RThCXHU0RUY2XHU5NzYyXHVGRjFBXHU1OUQ0XHU2RDNFXHU2NzJDXHU4RkRCXHU3QTBCIGJ1c1x1RkYwQ1x1OERERiBob3N0IFx1NEZBNyBgd2Iub24gPSBidXMub24uYmluZChidXMpYCBcdTVCOENcdTUxNjhcdTRFMDBcdTgxRjQgXHUyNTAwXHUyNTAwXG4gICAgICAgICAgICBpZiAocHJvcCA9PT0gJ29uJykge1xuICAgICAgICAgICAgICAgIHJldHVybiBvbjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChwcm9wID09PSAnb2ZmJykge1xuICAgICAgICAgICAgICAgIHJldHVybiBvZmY7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAocHJvcCA9PT0gJ29uQW55Jykge1xuICAgICAgICAgICAgICAgIGVuc3VyZVN1YnNjcmliZWQoKTtcbiAgICAgICAgICAgICAgICByZXR1cm4gKGhhbmRsZXI6IEV2ZW50SGFuZGxlcikgPT4gc2lnbmFsPy5hYm9ydGVkXG4gICAgICAgICAgICAgICAgICAgID8gKCkgPT4gdW5kZWZpbmVkXG4gICAgICAgICAgICAgICAgICAgIDogdHJhY2tSZWxlYXNlKGJ1cy5vbkFueShoYW5kbGVyKSk7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIC8vIFx1MjUwMFx1MjUwMCBcdTkwMDNcdTc1MUZcdTgyMzFcdUZGMUF3Yi5pbnZva2UoY2hhbm5lbCwgLi4uYXJncykgXHU5MDFBXHU3NTI4IGNoYW5uZWwgXHU4QzAzXHU3NTI4IFx1MjUwMFx1MjUwMFxuICAgICAgICAgICAgLy8gICBob3N0IFx1NEZBNyBgd2IuaW52b2tlYCA9IGBleHRlcm5hbEludm9rZShjaGFubmVsLCB1bmRlZmluZWQsIC4uLmFyZ3MpYFx1RkYwQ1xuICAgICAgICAgICAgLy8gICBndWVzdCBcdTRGQTdcdTU0MENcdTZCM0VcdThCRURcdTRFNDlcdUZGMUFjaGFubmVsIFx1NzUzMVx1NzUyOFx1NjIzN1x1NEYyMFx1RkYwQ1x1OEQ3MCB3aXJlIFx1NTIzMCBkYWVtb24gUlBDIFx1OTAxQVx1NzUyOFx1OERFRlx1NzUzMVxuICAgICAgICAgICAgLy8gICBcdUZGMDhicmlkZ2UtaG9zdCBcdTRGQTdcdTVCRjlcdTk3NUUgYHdiOmAgXHU1MjREXHU3RjAwIGNoYW5uZWwgXHU4RDcwIGRhZW1vbiBSUEMgXHU3NkY0XHU4QzAzXHVGRjA5XHUzMDAyXG4gICAgICAgICAgICBpZiAocHJvcCA9PT0gJ2ludm9rZScpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gPFQgPSB1bmtub3duPihjaGFubmVsOiBzdHJpbmcsIC4uLmFyZ3M6IHVua25vd25bXSk6IFByb21pc2U8VD4gPT4gaW52b2tlKGNoYW5uZWwsIGludm9rZUNvbnRleHQsIC4uLmFyZ3MpIGFzIFByb21pc2U8VD47XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIGlmIChcbiAgICAgICAgICAgICAgICBvcHRpb25zPy5uYW1lc3BhY2VzXG4gICAgICAgICAgICAgICAgJiYgT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKG9wdGlvbnMubmFtZXNwYWNlcywgcHJvcClcbiAgICAgICAgICAgICkge1xuICAgICAgICAgICAgICAgIHJldHVybiBvcHRpb25zLm5hbWVzcGFjZXNbcHJvcF07XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gY3JlYXRlR3Vlc3RQcm94eShwcm9wLCBpbnZva2UsIG9wdGlvbnMpO1xuICAgICAgICB9LFxuICAgIH0pO1xufVxuXG5mdW5jdGlvbiBfcHJveHkocGF0aDogc3RyaW5nLCBpbnZva2U6IEludm9rZUZuLCBjb250ZXh0OiBJbnZva2VDb250ZXh0IHwgdW5kZWZpbmVkLCBjYWNoZUxpc3RSZXN1bHRzOiBib29sZWFuKTogYW55IHtcbiAgICAvLyBcdTVCNTBcdThERUZcdTVGODQgUHJveHkgXHU3RjEzXHU1QjU4IFx1MjAxNFx1MjAxNCBcdTVGMTVcdTc1MjhcdTdBMzNcdTVCOUFcdTYwMjdcdTRGRERcdThCQzFcdTMwMDJcbiAgICAvL1xuICAgIC8vIFx1NEY5QiBSZWFjdCB1c2VFZmZlY3QgLyB1c2VNZW1vIFx1NEY5RFx1OEQ1Nlx1NkJENFx1OEY4Mzpgd2Iuc2tpbGxzLmluc3RhbGxlZGAgXHU2QkNGXHU2QjIxIGdldFxuICAgIC8vIFx1OTBGRFx1NjVCMFx1NUVGQSBQcm94eSBcdTRGMUFcdTVCRkNcdTgxRjRcdTRGOURcdThENTZcdTYyOTZcdTUyQThcdTMwMDJcdTdGMTNcdTVCNThcdTU0MEUgYHdiLnNraWxscyA9PT0gd2Iuc2tpbGxzYFx1MzAwMlxuICAgIC8vXG4gICAgLy8gXHU3RjEzXHU1QjU4XHU3QzkyXHU1RUE2Olx1OERERlx1Nzc0MFx1NzIzNiBQcm94eSBcdTc1MUZcdTU0N0RcdTU0NjhcdTY3MUZcdUZGMDhcdTZCQ0ZcdTRFMkEgX3Byb3h5IFx1OEMwM1x1NzUyOFx1NEUwMFx1NEVGRFx1RkYwOVx1RkYwQ1x1NUI5RVx1NEY4Qlx1OTVGNFx1NEUwRFx1NTE3MVx1NEVBQiBcdTIwMTRcdTIwMTRcbiAgICAvLyBcdTRFMjRcdTRFMkFcdTRFMERcdTU0MEMgY3JlYXRlR3Vlc3RQcm94eSBcdTVCOUVcdTRGOEJcdUZGMDhjYWxsZXJJZCBcdTRFMERcdTU0MENcdUZGMDlcdTVCNTBcdThERUZcdTVGODRcdTcyRUNcdTdBQ0JcdUZGMENcdTY3NUNcdTdFRERcdTY3NDNcdTk2NTBcdTRFMzJcdTYyNzBcdTMwMDJcbiAgICBjb25zdCBjaGlsZHJlbiA9IG5ldyBNYXA8c3RyaW5nLCBhbnk+KCk7XG4gICAgLy8gYC5saXN0YCBcdTdFRDNcdTY3OUNcdTdGMTNcdTVCNTggXHUyMDE0XHUyMDE0IFx1NkJDRlx1NEUyQSBfcHJveHkgXHU1QjlFXHU0RjhCXHVGRjA4XHU1MzczXHU2QkNGXHU0RTJBIGNoYW5uZWwgcGF0aFx1RkYwOVx1NEUwMFx1NEVGRCBNYXBcdTMwMDJcbiAgICAvLyBrZXkgPSBcdTUzQzJcdTY1NzAgSlNPTlx1RkYxQnZhbHVlID0geyBwcm9taXNlLCBmdWxmaWxsZWRBdD8gfVx1MzAwMlxuICAgIC8vIFx1NTNFQVx1NTcyOFx1NUY1M1x1NTI0RCBfcHJveHkgXHU2NjJGXCJcdTRFRTUgLmxpc3QgXHU3RUQzXHU1QzNFXHU3Njg0XHU1M0VGXHU4QzAzXHU3NTI4XHU4MjgyXHU3MEI5XCJcdTY1RjZcdTYyNERcdTRGMUFcdTg4QUJcdTUxOTlcdTUxNjVcdUZGMUJcdTUxNzZcdTVCODMgbWV0aG9kIFx1NUI4Q1x1NTE2OFx1N0VENVx1NUYwMFx1MzAwMlxuICAgIC8vIGNhbGxlcklkIFx1OTY5NFx1NzlCQlx1NTkyOVx1NzEzNlx1NkVFMVx1OERCMzpcdTRFMjRcdTRFMkFcdTRFMERcdTU0MEMgY3JlYXRlR3Vlc3RQcm94eSBcdTY3MDlcdTU0MDRcdTgxRUFcdTc2ODQgX3Byb3h5IFx1NjgxMVx1RkYwQ2NhY2hlIFx1NTkyOVx1NzEzNlx1NTIwNlx1NzlCQlx1MzAwMlxuICAgIGNvbnN0IGxpc3RDYWNoZSA9IG5ldyBNYXA8c3RyaW5nLCBMaXN0Q2FjaGVFbnRyeT4oKTtcbiAgICBjb25zdCBwcm94eTogYW55ID0gbmV3IFByb3h5KCgpID0+IHt9LCB7XG4gICAgICAgIGdldChfdGFyZ2V0LCBwcm9wKSB7XG4gICAgICAgICAgICBpZiAocHJvcCA9PT0gJ3RoZW4nKSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgICAgICAgICAgIGlmIChwcm9wID09PSAndG9KU09OJykgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gICAgICAgICAgICAvLyBTeW1ib2wgXHU0RkREXHU2MkE0XHVGRjFBUHJveHkgXHU3Njg0IHByb3AgXHU1M0MyXHU2NTcwXHU4RkQwXHU4ODRDXHU2NUY2XHU1M0VGXHU4MEZEXHU2NjJGIFN5bWJvbFx1RkYwOGF3YWl0IFx1NjNBMlx1NkQ0Qlx1NzY4NFxuICAgICAgICAgICAgLy8gYFN5bWJvbC50b1ByaW1pdGl2ZWBcdTMwMDFSZWFjdCBcdTUxODVcdTkwRTggYFN5bWJvbC5pdGVyYXRvcmAgXHU3QjQ5XHVGRjA5XHUzMDAyXHU2MkZDXG4gICAgICAgICAgICAvLyBgJHtwYXRofS4ke3Byb3B9YCBcdTRGMUFcdTYyOUIgYFR5cGVFcnJvcjogQ2Fubm90IGNvbnZlcnQgYSBTeW1ib2wgdG8gc3RyaW5nYFx1MzAwMlxuICAgICAgICAgICAgLy8gXHU2NjNFXHU1RjBGXHU4RkQ0XHU1NkRFIHVuZGVmaW5lZCBcdThCQTlcdThCRURcdTRFNDlcdTY2RjRcdTdBMzNcdTMwMDJcbiAgICAgICAgICAgIGlmICh0eXBlb2YgcHJvcCAhPT0gJ3N0cmluZycpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICAgICAgICAgICAgLy8gXHUyNTAwXHUyNTAwXHUyNTAwIEZ1bmN0aW9uLnByb3RvdHlwZSBcdTY3MkNcdTU3MzBcdThCRURcdTRFNDlcdTYyRTZcdTYyMkFcdUZGMDhmaXggIzkxNjUwXHVGRjA5XHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG4gICAgICAgICAgICAvLyBiaW5kL2NhbGwvYXBwbHkgXHU2NjJGIEZ1bmN0aW9uIFx1NjcyQ1x1NTczMFx1NjVCOVx1NkNENVx1RkYwQ1x1N0VERFx1NUJGOVx1NEUwRFx1ODBGRFx1NUVGQVx1NjIxMFx1OEZEQ1x1N0EwQlx1NUI1MFx1OERFRlx1NUY4NFx1MzAwMlxuICAgICAgICAgICAgLy8gXHU1NDI2XHU1MjE5IGBjb252LnJlc2VydmVSdW50aW1lLmJpbmQoY29udilgIFx1NEYxQSBpbnZva2VcbiAgICAgICAgICAgIC8vIGB3Yjpjb252LnJlc2VydmVSdW50aW1lOmJpbmRgXHVGRjBDXHU1RTc2XHU2MjhBIFByb3h5IFx1OTAwMVx1OEZEQiBpcGNSZW5kZXJlciBcdTIxOTJcbiAgICAgICAgICAgIC8vIERhdGFDbG9uZUVycm9yXHUzMDAyXG4gICAgICAgICAgICAvL1xuICAgICAgICAgICAgLy8gXHU0RTVGXHU0RTBEXHU4MEZEXHU4RkQ0XHU1NkRFIGBGdW5jdGlvbi5wcm90b3R5cGUuYmluZC5hcHBseShfdGFyZ2V0KWBcdUZGMUFcdTdFRDFcdTVCOUFcdTU0MEVcdTc2ODRcbiAgICAgICAgICAgIC8vIFx1NTFGRFx1NjU3MFx1N0VENVx1OEZDN1x1NjcyQyBQcm94eSBcdTc2ODQgYXBwbHkgdHJhcFx1RkYwQ1x1OEMwM1x1NzUyOFx1NjVGNlx1NkNBMVx1NjcwOSBpbnZva2UgXHU4RjZDXHU1M0QxXHUzMDAyXG4gICAgICAgICAgICAvL1xuICAgICAgICAgICAgLy8gXHU4RkQ5XHU5MUNDXHU2MjRCXHU1MTk5XHU2NkZGXHU4RUFCXHVGRjFBXG4gICAgICAgICAgICAvLyAgIGJpbmQodGhpc0FyZywgLi4uYm91bmRBcmdzKSBcdTIxOTIgXHU2NUIwXHU1MUZEXHU2NTcwXHVGRjBDXHU4QzAzXHU3NTI4XHU2NUY2IFJlZmxlY3QuYXBwbHkgXHU1MjMwXHU2NzJDIHByb3h5XG4gICAgICAgICAgICAvLyAgIGNhbGwodGhpc0FyZywgLi4uYXJncykgICAgICBcdTIxOTIgXHU3NkY0XHU2M0E1IFJlZmxlY3QuYXBwbHkgXHU1MjMwXHU2NzJDIHByb3h5XG4gICAgICAgICAgICAvLyAgIGFwcGx5KHRoaXNBcmcsIGFyZ3M/KSAgICAgICBcdTIxOTIgXHU3NkY0XHU2M0E1IFJlZmxlY3QuYXBwbHkgXHU1MjMwXHU2NzJDIHByb3h5XG4gICAgICAgICAgICAvLyB0aGlzQXJnIFx1NEUwMFx1NUY4Qlx1NUZGRFx1NzU2NVx1RkYxQVx1OEZEQ1x1N0EwQiBoYW5kbGVyIFx1NkNBMVx1NjcwOSB0aGlzIFx1OEJFRFx1NEU0OVx1MzAwMlxuICAgICAgICAgICAgaWYgKHByb3AgPT09ICdiaW5kJykge1xuICAgICAgICAgICAgICAgIHJldHVybiAoX3RoaXNBcmc/OiB1bmtub3duLCAuLi5ib3VuZEFyZ3M6IHVua25vd25bXSkgPT5cbiAgICAgICAgICAgICAgICAgICAgKC4uLmNhbGxBcmdzOiB1bmtub3duW10pID0+IFJlZmxlY3QuYXBwbHkocHJveHksIHVuZGVmaW5lZCwgWy4uLmJvdW5kQXJncywgLi4uY2FsbEFyZ3NdKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChwcm9wID09PSAnY2FsbCcpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gKF90aGlzQXJnPzogdW5rbm93biwgLi4uYXJnczogdW5rbm93bltdKSA9PiBSZWZsZWN0LmFwcGx5KHByb3h5LCB1bmRlZmluZWQsIGFyZ3MpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKHByb3AgPT09ICdhcHBseScpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gKF90aGlzQXJnPzogdW5rbm93biwgYXJncz86IHVua25vd25bXSkgPT4gUmVmbGVjdC5hcHBseShwcm94eSwgdW5kZWZpbmVkLCBhcmdzID8/IFtdKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNvbnN0IGNhY2hlZCA9IGNoaWxkcmVuLmdldChwcm9wKTtcbiAgICAgICAgICAgIGlmIChjYWNoZWQgIT09IHVuZGVmaW5lZCkgeyByZXR1cm4gY2FjaGVkOyB9XG4gICAgICAgICAgICBjb25zdCBjaGlsZCA9IF9wcm94eShgJHtwYXRofS4ke3Byb3B9YCwgaW52b2tlLCBjb250ZXh0LCBjYWNoZUxpc3RSZXN1bHRzKTtcbiAgICAgICAgICAgIGNoaWxkcmVuLnNldChwcm9wLCBjaGlsZCk7XG4gICAgICAgICAgICByZXR1cm4gY2hpbGQ7XG4gICAgICAgIH0sXG4gICAgICAgIGFwcGx5KF90YXJnZXQsIF90aGlzQXJnLCBhcmdzKSB7XG4gICAgICAgICAgICAvLyBwYXRoID0gJ3NraWxscy5tYXJrZXRwbGFjZS5idWlsdGluLmxpc3QnXG4gICAgICAgICAgICAvLyBcdTIxOTIgY2hhbm5lbCA9ICd3Yjpza2lsbHMubWFya2V0cGxhY2UuYnVpbHRpbjpsaXN0J1xuICAgICAgICAgICAgY29uc3QgbGFzdERvdCA9IHBhdGgubGFzdEluZGV4T2YoJy4nKTtcbiAgICAgICAgICAgIGNvbnN0IGNoYW5uZWwgPSBgd2I6JHtwYXRoLnNsaWNlKDAsIGxhc3REb3QpfToke3BhdGguc2xpY2UobGFzdERvdCArIDEpfWA7XG4gICAgICAgICAgICAvLyBkZXNlcmlhbGl6ZVJlc3VsdCBcdTY4QzBcdTZENEJcdTUyMzAgU2VyaWFsaXplZEJyaWRnZUVycm9yIFx1NEYxQVx1NjI5Qlx1OEZEOFx1NTM5Rlx1NTQwRVx1NzY4NCBFcnJvclx1RkYwQ1xuICAgICAgICAgICAgLy8gXHU1NDI2XHU1MjE5XHU1MzlGXHU2ODM3XHU4RkQ0XHU1NkRFXHUzMDAyXHU4REU4XHU4RkI5XHU3NTRDXHU5NTE5XHU4QkVGXHU4RkQ4XHU1MzlGXHU5MDNCXHU4RjkxXHU0RTBFXHU2MjQwXHU2NzA5IFRyYW5zcG9ydCBcdTU5MERcdTc1MjhcdTU0MENcdTRFMDBcdTU5NTdcdUZGMDhlcnJvci1lbnZlbG9wZVx1RkYwOVx1MzAwMlxuXG4gICAgICAgICAgICAvLyBcdTI1MDBcdTI1MDBcdTI1MDAgYC5saXN0YCBcdTdFRDNcdTVDM0VcdTc2ODQgY2hhbm5lbCBcdThENzBcdTdGMTNcdTVCNTggaGl0ICsgaW4tZmxpZ2h0IGRlZHVwIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuICAgICAgICAgICAgLy9cbiAgICAgICAgICAgIC8vIFx1ODlFNlx1NTNEMVx1Njc2MVx1NEVGNlx1NTE2OFx1OTBFOFx1NkVFMVx1OERCM1x1NjI0RFx1OEZEQlx1N0YxM1x1NUI1ODpcbiAgICAgICAgICAgIC8vICAgMSkgXHU3M0FGXHU1ODgzXHU1M0Q4XHU5MUNGXHU2NzJBXHU2MjhBIFRUTCBcdTY2M0VcdTVGMEZcdThCQkVcdTRFM0EgMFx1RkYwOExJU1RfVEhST1RUTEVfTVMgPiAwXHVGRjA5XG4gICAgICAgICAgICAvLyAgIDIpIHBhdGggXHU1QzNFXHU2QkI1XHU2NjJGXHU1QjU3XHU5NzYyXHU5MUNGIGBsaXN0YFx1RkYwOFx1NTIyNFx1NjVBRCBtZXRob2QgbmFtZVx1RkYwQ1x1NEUwRFx1NjYyRiBjaGFubmVsIFx1NjU3NFx1NEY1M1x1RkYwOVxuICAgICAgICAgICAgLy8gICAzKSBcdTUzQzJcdTY1NzBcdTUzRUYgSlNPTiBcdTVFOEZcdTUyMTdcdTUzMTZcdUZGMDhGdW5jdGlvbi9TeW1ib2wvXHU1RkFBXHU3M0FGXHU1RjE1XHU3NTI4XHU3NkY0XHU2M0E1XHU4RDcwXHU3NkY0XHU5MDFBXHVGRjA5XG4gICAgICAgICAgICAvL1xuICAgICAgICAgICAgLy8gXHU3RjEzXHU1QjU4XHU3QjU2XHU3NTY1OlxuICAgICAgICAgICAgLy8gICBcdTAwQjcgXHU1REYyIGZ1bGZpbGxlZCBcdTRFMTRcdTY3MkFcdThGQzcgVFRMIFx1MjE5MiBcdTc2RjRcdTYzQTVcdThGRDQgY2FjaGVkIHByb21pc2VcdUZGMDhcdTU0MENcdTRFMDBcdTRFRkQgcmVzdWx0IFx1NUYxNVx1NzUyOFx1RkYwOVxuICAgICAgICAgICAgLy8gICBcdTAwQjcgcGVuZGluZyBcdTIxOTIgXHU4RkQ0IGNhY2hlZCBwcm9taXNlXHVGRjA4XHU1OTFBIGNhbGxlciBcdTVFNzZcdTUzRDFcdTU0MDhcdTVFNzZcdTYyMTBcdTRFMDBcdTZCMjEgSVBDXHVGRjA5XG4gICAgICAgICAgICAvLyAgIFx1MDBCNyByZWplY3RlZCBcdTIxOTIgXHU3QUNCXHU1MjNCXHU0RUNFIGNhY2hlIFx1NTIyMFx1NjM4OVx1NTE4RFx1OTFDRFx1NTNEMVx1RkYwOFx1NEUwRFx1NjMwMVx1NEU0NVx1NTMxNlx1OTUxOVx1OEJFRlx1RkYwOVxuICAgICAgICAgICAgY29uc3QgaXNMaXN0Q2FsbCA9IGNhY2hlTGlzdFJlc3VsdHMgJiYgTElTVF9USFJPVFRMRV9NUyA+IDBcbiAgICAgICAgICAgICAgICAmJiAocGF0aCA9PT0gJ2xpc3QnIHx8IHBhdGguZW5kc1dpdGgoJy5saXN0JykpO1xuICAgICAgICAgICAgaWYgKGlzTGlzdENhbGwpIHtcbiAgICAgICAgICAgICAgICBjb25zdCBrZXkgPSBzZXJpYWxpemVMaXN0QXJncyhhcmdzKTtcbiAgICAgICAgICAgICAgICBpZiAoa2V5ICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgY2FjaGVkID0gbGlzdENhY2hlLmdldChrZXkpO1xuICAgICAgICAgICAgICAgICAgICBpZiAoY2FjaGVkKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBub3cgPSBEYXRlLm5vdygpO1xuICAgICAgICAgICAgICAgICAgICAgICAgLy8gZnVsZmlsbGVkQXQgPT09IHVuZGVmaW5lZCBcdTg4NjhcdTc5M0FcdThGRDhcdTU3MjggcGVuZGluZ1x1RkYwQ1x1NzZGNFx1NjNBNVx1NTkwRFx1NzUyOFxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gXHVGRjA4XHU0RTBEXHU2OEMwXHU2N0U1IFRUTFx1RkYxQXBlbmRpbmcgXHU2NzFGXHU2NUUwXHU2MjQwXHU4QzEzIFRUTFx1RkYwQ1x1N0I0OSBzZXR0bGUgXHU2MjREXHU1RjAwXHU1OUNCXHU4QkExXHU2NUY2XHVGRjA5XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoY2FjaGVkLmZ1bGZpbGxlZEF0ID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBcdTg5QzJcdTZENEJcdTY1RTVcdTVGRDc6cGVuZGluZyBcdTY3MUZcdTU0MDhcdTVFNzZcdUZGMDhpbi1mbGlnaHQgZGVkdXBcdUZGMDlcdUZGMENcdTUxNzNcdTk1MkVcdTY1MzZcdTc2Q0FcdTcwQjlcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGBbd2ItbGlzdC1jYWNoZV0gSElULUlORkxJR0hUIGNoYW5uZWw9JHtjaGFubmVsfSBrZXlMZW49JHtrZXkubGVuZ3RofWApO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBjYWNoZWQucHJvbWlzZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChub3cgLSBjYWNoZWQuZnVsZmlsbGVkQXQgPCBMSVNUX1RIUk9UVExFX01TKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gXHU4OUMyXHU2RDRCXHU2NUU1XHU1RkQ3OmZ1bGZpbGxlZCBUVEwgXHU1MTg1XHU3NkY0XHU2M0E1XHU4RkQ0XHU1NkRFXHU0RTBBXHU2QjIxXHU3RUQzXHU2NzlDXHVGRjBDXHU3NzAxXHU0RTAwXHU2QjIxIElQQ1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coYFt3Yi1saXN0LWNhY2hlXSBISVQtRlJFU0ggY2hhbm5lbD0ke2NoYW5uZWx9IGFnZU1zPSR7bm93IC0gY2FjaGVkLmZ1bGZpbGxlZEF0fSBrZXlMZW49JHtrZXkubGVuZ3RofWApO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBjYWNoZWQucHJvbWlzZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIFRUTCBcdTUyMzBcdTY3MUYgXHUyMTkyIFx1NTIyMFx1OTY2NFx1NUU3Nlx1OTFDRFx1NTNEMVxuICAgICAgICAgICAgICAgICAgICAgICAgbGlzdENhY2hlLmRlbGV0ZShrZXkpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIC8vIFx1ODlDMlx1NkQ0Qlx1NjVFNVx1NUZENzpjYWNoZSBtaXNzXHVGRjBDXHU1QjlFXHU5NjQ1XHU2MjUzIElQQ1xuXG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGBbd2ItbGlzdC1jYWNoZV0gTUlTUyBjaGFubmVsPSR7Y2hhbm5lbH0ga2V5TGVuPSR7a2V5Lmxlbmd0aH1gKTtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgcHJvbWlzZSA9IGludm9rZShjaGFubmVsLCBjb250ZXh0LCAuLi5hcmdzKS50aGVuKGRlc2VyaWFsaXplUmVzdWx0KTtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgZW50cnk6IExpc3RDYWNoZUVudHJ5ID0geyBwcm9taXNlIH07XG4gICAgICAgICAgICAgICAgICAgIGxpc3RDYWNoZS5zZXQoa2V5LCBlbnRyeSk7XG4gICAgICAgICAgICAgICAgICAgIHByb21pc2UudGhlbihcbiAgICAgICAgICAgICAgICAgICAgICAgICgpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBcdTUzRUFcdTY3MDlcdTVGNTNcdTUyNEQgZW50cnkgXHU0RUNEXHU1NzI4IG1hcCBcdTRFMkRcdTYyNERcdTY4MDdcdThCQjAgZnVsZmlsbGVkQXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBcdUZGMDhcdTkwN0ZcdTUxNERcdTRFMEJcdTk3NjJcdThGRDlcdTc5Q0RcdTdBREVcdTYwMDE6XHU2NzFGXHU5NUY0XHU4OEFCXHU0RTNCXHU1MkE4IGRlbGV0ZSBcdTU0MEVcdTUzQzhcdTU4NkJcdTRFODZcdTY1QjAgZW50cnlcdUZGMENcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyAgXHU4RkQ5XHU5MUNDXHU2MjhBXHU2NUIwIGVudHJ5IFx1NzY4NCBmdWxmaWxsZWRBdCBcdTg5ODZcdTUxOTlcdTYyMTBcdTY1RTdcdThDMDNcdTc1MjhcdTc2ODRcdTY1RjZcdTk1RjRcdTYyMzNcdUZGMDlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAobGlzdENhY2hlLmdldChrZXkpID09PSBlbnRyeSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbnRyeS5mdWxmaWxsZWRBdCA9IERhdGUubm93KCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIFx1NTIzMFx1NjcxRlx1ODFFQVx1NTJBOFx1NkUwNVx1NzQwNlx1RkYwQ1x1OTYzMlx1NkI2Mlx1OTU3Rlx1NjVGNlx1OTVGNFx1NEUwRFx1NTE4RFx1OEMwM1x1NzUyOFx1NjVGNiBtYXAgXHU5MUNDXHU2QjhCXHU3NTU5XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHRpbWVyID0gc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAobGlzdENhY2hlLmdldChrZXkpID09PSBlbnRyeSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxpc3RDYWNoZS5kZWxldGUoa2V5KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSwgTElTVF9USFJPVFRMRV9NUyk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIE5vZGUgXHU3M0FGXHU1ODgzOnRpbWVyIFx1NTIyQlx1NjMyMSBldmVudCBsb29wIFx1OTAwMFx1NTFGQVx1RkYwOHJlbmRlcmVyIFx1NjVFMCB1bnJlZiBcdTRFNUZcdTY1RTBcdTVCQjNcdUZGMDlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKHRpbWVyIGFzIHVua25vd24gYXMgeyB1bnJlZj86ICgpID0+IHZvaWQgfSk/LnVucmVmPy4oKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgKCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIHJlamVjdGVkIFx1N0FDQlx1NTIzQlx1NTkzMVx1NjU0OFx1RkYwQ1x1OTYzMlx1NkI2Mlx1OTUxOVx1OEJFRlx1NjMwMVx1NEU0NVx1NTMxNlx1NUY3MVx1NTRDRFx1NEUwQlx1NEUwMFx1NkIyMVx1OTFDRFx1OEJENVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChsaXN0Q2FjaGUuZ2V0KGtleSkgPT09IGVudHJ5KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxpc3RDYWNoZS5kZWxldGUoa2V5KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gXHU4OUMyXHU2RDRCXHU2NUU1XHU1RkQ3Olx1NTkzMVx1OEQyNVx1N0FDQlx1NTM3M1x1NEVDRSBjYWNoZSBcdTZFMDVcdTYzODlcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGBbd2ItbGlzdC1jYWNoZV0gUkVKRUNUIGNoYW5uZWw9JHtjaGFubmVsfSBrZXlMZW49JHtrZXkubGVuZ3RofWApO1xuICAgICAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHByb21pc2U7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIC8vIGtleSBcdTc1MUZcdTYyMTBcdTU5MzFcdThEMjUgXHUyMTkyIFx1ODlDMlx1NkQ0Qlx1NjVFNVx1NUZENyArIGZhbGwgdGhyb3VnaCBcdTUyMzBcdTc2RjRcdTkwMUFcblxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGBbd2ItbGlzdC1jYWNoZV0gU0tJUC1VTkNBQ0hFQUJMRSBjaGFubmVsPSR7Y2hhbm5lbH0gKGFyZ3Mgbm90IEpTT04tc2VyaWFsaXphYmxlKWApO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICByZXR1cm4gaW52b2tlKGNoYW5uZWwsIGNvbnRleHQsIC4uLmFyZ3MpLnRoZW4oZGVzZXJpYWxpemVSZXN1bHQpO1xuICAgICAgICB9LFxuICAgIH0pO1xuICAgIHJldHVybiBwcm94eTtcbn1cbiIsICIvKipcbiAqIFNESyBOYW1lc3BhY2UgTWFuaWZlc3QgXHUyMDE0XHUyMDE0IFx1ODlDNFx1ODMwM1x1NTIzNlx1NUI5QVx1ODAwNVx1NzY4NFx1NjgzOFx1NUZDM1x1RkYxQVx1NUI5QVx1NEU0OVwiXHU1QjU4XHU1NzI4XHU1NEVBXHU0RTlCIG5hbWVzcGFjZVwiKyBcIlx1NEVDMFx1NEU0OFx1NUU3M1x1NTNGMFx1NUZDNVx1OTg3Qlx1NjMwMlx1NTRFQVx1NEU5QlwiXHUzMDAyXG4gKlxuICogXHU4RkQ5XHU2NjJGIFNESyBcdTRGNUNcdTRFM0FcdTg5QzRcdTgzMDNcdTUyMzZcdTVCOUFcdTgwMDVcdTc2ODRcdTUzNTVcdTcwQjlcdTU4RjBcdTY2MEVcdUZGMDhTU09UXHVGRjA5XHUzMDAyXHU0RUZCXHU0RjU1XHU2MEYzXHU2MzAyIG5hbWVzcGFjZSBcdTc2ODRcdTVCQkZcdTRFM0JcdUZGMDhXZWIgLyBEZXNrdG9wIC8gQ0xJIC8gTUNQXHVGRjA5XG4gKiBcdTkwRkRcdTVGQzVcdTk4N0JcdTkwNzVcdTVCODhcdTY3MkNcdTZFMDVcdTUzNTVcdUZGMENcdTdGMTZcdThCRDFcdTY3MUZcdTVGM0FcdTUyMzZcdTY4QzBcdTY3RTVcdTVCOENcdTY1NzRcdTYwMjdcdTIwMTRcdTIwMTRcdTZGMEZcdTRFMDBcdTRFMkFcdTdBQ0JcdTUzNzMgVFMgXHU3RjE2XHU4QkQxXHU2MkE1XHU5NTE5XHVGRjBDXHU2NzVDXHU3RUREXCJXZWIgXHU1NDhDIERlc2t0b3AgXHU0RTBEXHU1QkY5XHU3QjQ5XCJcdTk1RUVcdTk4OThcdTMwMDJcbiAqXG4gKiBcdTMwMTBcdTY1QjBcdTU4OUUgY29yZSBuYW1lc3BhY2UgXHU3Njg0XHU2RDQxXHU3QTBCXHUzMDExXG4gKiAgIDEuIGBzZGsvdHlwZXMudHNgIFx1OTFDQ1x1NzY4NCBgV29ya2J1ZGR5U0RLYCBpbnRlcmZhY2UgXHU1MkEwXHU1QjU3XHU2QkI1XG4gKiAgIDIuIGBzZGsvdHlwZXMudHNgIFx1OTFDQ1x1NzY4NCBgUHJvdmlkYWJsZU5hbWVzcGFjZXNgIFx1NTJBMFx1NUI1N1x1NkJCNVxuICogICAzLiBcdTY3MkNcdTY1ODdcdTRFRjZcdTc2ODQgYEFMTF9OQU1FU1BBQ0VTYCBcdTUyQTBcdTU0MERcdTc5RjBcbiAqICAgNC4gXHU2NzJDXHU2NTg3XHU0RUY2XHU3Njg0IGBQTEFURk9STV9NQU5JRkVTVC53ZWJgIC8gYC5kZXNrdG9wYCBcdTYzMDlcdTVGNTJcdTVDNUVcdTUyQTBcdTUxNjVcbiAqICAgNS4gV2ViIC8gRGVza3RvcCBcdTc2ODQgc2V0dXAgXHU4OEM1XHU5MTREXHU0RUUzXHU3ODAxXHU4ODY1IGBuYW1lc3BhY2VzLnh4eDogY3JlYXRlV0JYeHhGcm9tRmFjYWRlKC4uLilgXG4gKlxuICogXHU2RjBGIDMgLyA0IC8gNSBcdTRFRkJcdTYxMEZcdTRFMDBcdTZCNjUgXHUyMDE0XHUyMDE0IFx1N0YxNlx1OEJEMVx1N0FDQlx1NTM3M1x1NTkzMVx1OEQyNVx1MzAwMlx1OEZEOVx1NUMzMVx1NjYyRlwiU0RLIFx1NUYzQVx1NTIzNlx1ODlDNFx1ODMwM1wiXHU3Njg0XHU2NzJDXHU4RDI4XHUzMDAyXG4gKlxuICogXHUzMDEwXHU3MkVDXHU3QUNCXHU3NTFGXHU2MDAxXHU1MzA1IC8gcmVuZGVyZXIgXHU0RkE3IG5hbWVzcGFjZVx1MzAxMVxuICogICBcdTRFMERcdTU3MjhcdTY3MkNcdTZFMDVcdTUzNTVcdTkxQ0NcdTIwMTRcdTIwMTRcdTkwMUFcdThGQzcgYGRlY2xhcmUgbW9kdWxlICdAZ2VuaWUvd29ya2J1ZGR5LWNvcmUvd2IvY29yZS90eXBlcydgIGF1Z21lbnRcbiAqICAgYFByb3ZpZGFibGVOYW1lc3BhY2VzYFx1RkYwQ1x1ODhDNVx1OTE0RFx1NUM0Mlx1ODFFQVx1NURGMVx1OEMwMyBgJHByb3ZpZGVgXHUzMDAyY29yZSBcdTRFMERcdTYxMUZcdTc3RTVcdTUxNzdcdTRGNTNcdTU0MERcdTVCNTdcdTMwMDJcbiAqICAgXHU1MTc4XHU1NzhCXHU0RjhCXHU1QjUwXHVGRjFBYWdlbnQtdWkgXHU3Njg0IGB1aWAgLyBgbmF2aWdhdGlvbmAgLyBgdXRpbHNgXHVGRjFCYEBnZW5pZS93b3JrYnVkZHktZXh0ZW5zaW9uc2BcbiAqICAgXHU3Njg0IGBleHRlbnNpb25zYFx1MzAwMlxuICpcbiAqIFx1MzAxMFx1NEUyNFx1N0M3QiBuYW1lc3BhY2VcdTMwMTFcbiAqICAgLSAqKlx1Njc4NFx1OTAyMFx1NjcxRlx1NUZDNVx1NjMwMioqXHVGRjA4XHU1NzI4IGBQTEFURk9STV9NQU5JRkVTVGAgXHU5MUNDXHVGRjA5XHVGRjFBXHU4OEM1XHU5MTREXHU5NjM2XHU2QkI1XHU1QzMxXHU1RkM1XHU5ODdCXHU3RUQ5XHU1QjlFXHU3M0IwXHVGRjA4XHU0RTFBXHU1MkExXHU4MEZEXHU1MjlCXHVGRjA5XG4gKiAgIC0gKipTREsgXHU4MUVBXHU1RUZBKipcdUZGMDhcdTU3MjggYEJVSUxUX0lOX05BTUVTUEFDRVNgIFx1OTFDQ1x1RkYwOVx1RkYxQVNESyBcdTUxODVcdTkwRThcdTgxRUFcdTVERjFcdTUyMUJcdTVFRkFcdUZGMENcdTVCQkZcdTRFM0JcdTY1RTBcdTk3MDBcdTZDRThcdTUxNjVcbiAqICAgICBcdUZGMDh0ZWxlbWV0cnkgLyBodHRwIC8gZmVlZGJhY2tcdUZGMDlcdUZGMENcdTUyMTdcdTU3MjhcdThGRDlcdTkxQ0NcdTY1QjlcdTRGQkZcdTY3RTVcdTk2MDVcbiAqL1xuXG5pbXBvcnQgdHlwZSB7IFByb3ZpZGFibGVOYW1lc3BhY2VzIH0gZnJvbSAnLi90eXBlcyc7XG5cbi8qIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMCBcdTUyMDZcdTdDN0JcdTZFMDVcdTUzNTUgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwICovXG5cbi8qKlxuICogU0RLIFx1ODFFQVx1NUVGQVx1MzAwMVx1NUJCRlx1NEUzQlx1NjVFMFx1OTcwMFx1NkNFOFx1NTE2NVx1NzY4NCBuYW1lc3BhY2VcdTMwMDJcbiAqXG4gKiBcdThGRDlcdTUxRTBcdTRFMkFcdTU3MjggYGNyZWF0ZVdvcmtidWRkeVNES2AgXHU1MTg1XHU5MEU4XHU1QzMxXHU1REYyXHU3RUNGXHU4OEM1XHU1OTdEXHVGRjFBXG4gKiAtIGB0ZWxlbWV0cnlgXHVGRjFBXHU5RUQ4XHU4QkE0IG5vb3Agc2lua1x1RkYwQ1x1NTNFRlx1OTAxQVx1OEZDNyBgJHByb3ZpZGUoJ3RlbGVtZXRyeScsIGltcGwpYCBcdTg5ODZcdTc2RDZcbiAqIC0gYGh0dHBgXHVGRjFBXHU2Nzg0XHU5MDIwXHU2NUY2XHU3Njg0IGh0dHAgXHU1M0MyXHU2NTcwXHU3NkY0XHU2M0E1XHU1MzA1XHU4OEM1XG4gKiAtIGBmZWVkYmFja2BcdUZGMUFEZXNrdG9wIFx1OEQ3MCBkYWVtb24gYGZlZWRiYWNrOnN1Ym1pdGAgXHU2MjUzXHU1MzA1XHU2NUU1XHU1RkQ3XHVGRjFCV2ViIFx1OEQ3MCBIVFRQXG4gKi9cbmV4cG9ydCBjb25zdCBCVUlMVF9JTl9OQU1FU1BBQ0VTID0gWyd0ZWxlbWV0cnknLCAnaHR0cCcsICdmZWVkYmFjayddIGFzIGNvbnN0O1xuZXhwb3J0IHR5cGUgQnVpbHRJbk5hbWVzcGFjZSA9ICh0eXBlb2YgQlVJTFRfSU5fTkFNRVNQQUNFUylbbnVtYmVyXTtcblxuLyoqXG4gKiBXZWIgLyBEZXNrdG9wIFx1OTBGRFx1NUZDNVx1OTg3Qlx1NjMwMlx1OEY3RFx1NzY4NFx1NEUxQVx1NTJBMSBuYW1lc3BhY2VcdUZGMDhcdThERThcdTVFNzNcdTUzRjBcdTY4MzhcdTVGQzNcdTgwRkRcdTUyOUJcdUZGMDlcdTMwMDJcbiAqXG4gKiBcdTk4N0FcdTVFOEZcdTYzMDlcdTRFMUFcdTUyQTFcdTkxQ0RcdTg5ODFcdTYwMjdcdTYzOTJcdUZGMDhhY2NvdW50IFx1NTE0OFx1MzAwMW5ldGRyaXZlIFx1NTQwRVx1RkYwOVx1RkYwQ1x1NjUzOVx1NTJBOFx1NkI2NFx1NkUwNVx1NTM1NVx1NjVGNlx1NTQwQ1x1NkI2NVx1NjZGNFx1NjVCMFxuICogV2ViIC8gRGVza3RvcCBcdTc2ODQgc2V0dXAgXHU1MUZEXHU2NTcwXHU0RUU1XHU1M0NBXHU1NDA0IGRvbWFpbiBcdTc2ODQgd2IvaW5kZXgudHNcdTMwMDJcbiAqL1xuZXhwb3J0IGNvbnN0IENPUkVfTkFNRVNQQUNFUyA9IFtcbiAgICAnc3RvcmFnZScsXG4gICAgJ2NvbmZpZycsXG4gICAgJ2FjY291bnQnLFxuICAgICdvcGVuQXV0aCcsXG4gICAgJ3NraWxscycsXG4gICAgJ2V4cGVydHMnLFxuICAgICdhdXRvbWF0aW9ucycsXG4gICAgJ3dvcmtzcGFjZXMnLFxuICAgICdtb2RlbHMnLFxuICAgICdub3RpZmljYXRpb25zJyxcbiAgICAnb3BzJyxcbiAgICAnY29ubmVjdG9ycycsXG4gICAgJ2NvbnZlcnNhdGlvbnMnLFxuICAgICdhcnRpZmFjdHMnLFxuICAgICdzZWFyY2gnLFxuICAgICdjaGFuZ2VzJyxcbiAgICAnaW50ZW50UmVjb2duaXRpb24nLFxuICAgICdpbUNoYW5uZWxzJyxcbiAgICAnbWV0cmljcycsXG4gICAgJ25ldGRyaXZlJyxcbiAgICAnaW5zcGlyYXRpb25Db2RlJyxcbiAgICAnY2xvdWQnLFxuXSBhcyBjb25zdCBzYXRpc2ZpZXMgcmVhZG9ubHkgKGtleW9mIFByb3ZpZGFibGVOYW1lc3BhY2VzKVtdO1xuZXhwb3J0IHR5cGUgQ29yZU5hbWVzcGFjZSA9ICh0eXBlb2YgQ09SRV9OQU1FU1BBQ0VTKVtudW1iZXJdO1xuXG4vKipcbiAqIERlc2t0b3AgXHU3MkVDXHU2NzA5XHU3Njg0IG5hbWVzcGFjZVx1RkYwOFdlYiBcdTczQUZcdTU4ODNcdTZDQTFcdTY3MDlcdTVCRjlcdTVFOTRcdTVCOUVcdTczQjBcdUZGMDlcdTMwMDJcbiAqXG4gKiAtIGBwYXRoc2BcdUZGMUFcdTc4QzFcdTc2RDhcdThERUZcdTVGODRcdTY3RTVcdThCRTJcdUZGMDhob21lIC8gdXNlckRhdGEgLyBhcHBSb290IC8gcmVzb2x2ZUFzc2V0XHVGRjA5XHUyMDE0XHUyMDE0IFx1NkQ0Rlx1ODlDOFx1NTY2OFx1NjVFMFx1NUJGOVx1NUU5NFxuICogLSBgc2hlbGxgXHVGRjFBXHU3Q0ZCXHU3RURGIHNoZWxsIFx1NEUwRVx1OUVEOFx1OEJBNFx1NjI1M1x1NUYwMFx1NUU5NFx1NzUyOFx1NEVBNFx1NEU5Mlx1MjAxNFx1MjAxNFx1NkQ0Rlx1ODlDOFx1NTY2OFx1NkM5OVx1N0JCMVx1NTFGQVx1NEUwRFx1NTNCQlxuICpcbiAqIGB3aW5kb3dzYCBcdTRFMEUgYGV4dGVuc2lvbnNgIFx1NEUwRFx1NTcyOFx1OEZEOVx1OTFDQ1x1RkYxQVx1NUI4M1x1NEVFQ1x1NTIwNlx1NTIyQlx1NzUzMVxuICogYEBnZW5pZS93b3JrYnVkZHktZGVza3RvcC1zZGtgIFx1NTQ4QyBgQGdlbmllL3dvcmtidWRkeS1leHRlbnNpb25zYCBcdTkwMUFcdThGQzcgbW9kdWxlXG4gKiBhdWdtZW50YXRpb24gXHU0RTBFIGAkcHJvdmlkZWAgXHU1NDBFXHU3RjZFXHU2Q0U4XHU1MTY1XHVGRjBDY29yZSBcdTRFMERcdTUzQ0RcdTU0MTFcdTRGOURcdThENTZcdThGRDlcdTRFOUJcdTcyRUNcdTdBQ0Igb3duZXIgXHU1MzA1XHUzMDAyXG4gKi9cbmV4cG9ydCBjb25zdCBERVNLVE9QX09OTFlfTkFNRVNQQUNFUyA9IFtcbiAgICAncGF0aHMnLFxuICAgICdzaGVsbCcsXG4gICAgJ21jcCcsXG4gICAgJ2J1ZGR5QXBwcycsXG5dIGFzIGNvbnN0IHNhdGlzZmllcyByZWFkb25seSAoa2V5b2YgUHJvdmlkYWJsZU5hbWVzcGFjZXMpW107XG5leHBvcnQgdHlwZSBEZXNrdG9wT25seU5hbWVzcGFjZSA9ICh0eXBlb2YgREVTS1RPUF9PTkxZX05BTUVTUEFDRVMpW251bWJlcl07XG5cbi8qIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMCBcdTVFNzNcdTUzRjBcdTZFMDVcdTUzNTUgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwICovXG5cbi8qKlxuICogXHU1RTczXHU1M0YwXHU1RjUyXHU1QzVFXHU2RTA1XHU1MzU1IFx1MjAxNFx1MjAxNCBcdTZCQ0ZcdTRFMkFcdTVFNzNcdTUzRjBcdTU3MjhcdTg4QzVcdTkxNERcdTY3MUZcdTVGQzVcdTk4N0JcdTYzMDJcdThGN0RcdTc2ODQgbmFtZXNwYWNlIFx1OTZDNlx1NTQwOFx1MzAwMlxuICpcbiAqIFx1OEZEOVx1NjYyRiBTREsgXHU3Njg0XHU2ODM4XHU1RkMzXHU1OTUxXHU3RUE2XHVGRjFBXHU3QzdCXHU1NzhCXHU3Q0ZCXHU3RURGXHU5MDFBXHU4RkM3IGBXZWJSZXF1aXJlZE5hbWVzcGFjZXNgIC8gYERlc2t0b3BSZXF1aXJlZE5hbWVzcGFjZXNgXG4gKiBcdTVGM0FcdTUyMzZcdTg4QzVcdTkxNERcdTRFRTNcdTc4MDFcdTYzRDBcdTRGOUJcdTVCOENcdTY1NzRcdTc2ODRcdTVCOUVcdTczQjBcdTk2QzZcdTU0MDhcdUZGMENcdTZGMEZcdTRFMDBcdTRFMkFcdTUzNzNcdTdGMTZcdThCRDFcdTU5MzFcdThEMjVcdTMwMDJcbiAqL1xuZXhwb3J0IGNvbnN0IFBMQVRGT1JNX01BTklGRVNUID0ge1xuICAgIC8qKiBXZWIgXHU3QUVGXHU1RkM1XHU2MzAyXHU4RjdEXHU3Njg0IG5hbWVzcGFjZVx1RkYwOFx1OERFOFx1NUU3M1x1NTNGMFx1NjgzOFx1NUZDM1x1RkYwOSAqL1xuICAgIHdlYjogQ09SRV9OQU1FU1BBQ0VTLFxuICAgIC8qKiBEZXNrdG9wIFx1N0FFRlx1NUZDNVx1NjMwMlx1OEY3RFx1NzY4NCBuYW1lc3BhY2VcdUZGMDhcdThERThcdTVFNzNcdTUzRjBcdTY4MzhcdTVGQzMgKyBEZXNrdG9wIFx1NzJFQ1x1NjcwOVx1RkYwOSAqL1xuICAgIGRlc2t0b3A6IFsuLi5DT1JFX05BTUVTUEFDRVMsIC4uLkRFU0tUT1BfT05MWV9OQU1FU1BBQ0VTXSBhcyBjb25zdCxcbn0gYXMgY29uc3Q7XG5cbi8qIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMCBcdTdDN0JcdTU3OEJcdTU5NTFcdTdFQTYgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwICovXG5cbi8qKlxuICogV2ViIFx1N0FFRlx1ODhDNVx1OTE0RFx1NTk1MVx1N0VBNlx1RkYxQWBuYW1lc3BhY2VzYCBcdTVGQzVcdTk4N0JcdTUzMDVcdTU0MkIgYENPUkVfTkFNRVNQQUNFU2AgXHU3Njg0XHU2MjQwXHU2NzA5XHU5NTJFXHVGRjBDXG4gKiBcdTZCQ0ZcdTRFMkFcdTk1MkVcdTVCRjlcdTVFOTQgYFByb3ZpZGFibGVOYW1lc3BhY2VzYCBcdTkxQ0NcdTc2ODRcdTdDN0JcdTU3OEJcdTMwMDJcbiAqXG4gKiBcdTg4QzVcdTkxNERcdTRFRTNcdTc4MDFcdTkxQ0NcdTVDMTFcdTdFRDlcdTRFMDBcdTRFMkEgbmFtZXNwYWNlIFx1MjE5MiBUUyBcdTdGMTZcdThCRDFcdTYyQTVcdTk1MTlcdTMwMDJcbiAqL1xuZXhwb3J0IHR5cGUgV2ViUmVxdWlyZWROYW1lc3BhY2VzID0gUmVxdWlyZWQ8UGljazxQcm92aWRhYmxlTmFtZXNwYWNlcywgQ29yZU5hbWVzcGFjZT4+O1xuXG4vKipcbiAqIERlc2t0b3AgXHU3QUVGXHU4OEM1XHU5MTREXHU1OTUxXHU3RUE2XHVGRjFBV2ViIFx1N0FFRlx1NTE2OFx1OTBFOCArIERlc2t0b3AgXHU3MkVDXHU2NzA5XHU3Njg0XHVGRjA4d2luZG93c1x1RkYwOVx1MzAwMlxuICovXG5leHBvcnQgdHlwZSBEZXNrdG9wUmVxdWlyZWROYW1lc3BhY2VzID0gUmVxdWlyZWQ8UGljazxQcm92aWRhYmxlTmFtZXNwYWNlcywgQ29yZU5hbWVzcGFjZSB8IERlc2t0b3BPbmx5TmFtZXNwYWNlPj47XG5cbi8qIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMCBcdTUxNjhcdTkwRThcdTZFMDVcdTUzNTVcdUZGMDhcdThCQ0FcdTY1QURcdTc1MjhcdUZGMDkgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwICovXG5cbi8qKlxuICogXHU2MjQwXHU2NzA5XHU1REYyXHU1QjlBXHU0RTQ5XHU3Njg0IG5hbWVzcGFjZSBcdTU0MERcdTc5RjBcdUZGMDhjb3JlIENPUkUgKyBEZXNrdG9wLW9ubHkgKyBcdTUxODVcdTVFRkFcdUZGMDlcdTMwMDJcbiAqXG4gKiBcdTc1MjhcdTkwMTRcdUZGMUFcdThCQ0FcdTY1QURcdTgxMUFcdTY3MkNcdTMwMDFcdThDMDNcdThCRDVcdTk3NjJcdTY3N0ZcdTMwMDFnZW4gXHU4MTFBXHU2NzJDXHU1M0MyXHU4MDAzXHUzMDAyXHU4OEM1XHU5MTREXHU1OTUxXHU3RUE2XHU0RTBEXHU3NzBCXHU4RkQ5XHU0RTJBXHVGRjBDXHU3NzBCIGBQTEFURk9STV9NQU5JRkVTVGBcdTMwMDJcbiAqIFx1NzJFQ1x1N0FDQlx1NzUxRlx1NjAwMVx1NTMwNSAvIHJlbmRlcmVyIFx1NEZBNyBhdWdtZW50IFx1NjMwMlx1OEY3RFx1NzY4NCBuYW1lc3BhY2VcdUZGMDhcdTU5ODIgdWkgLyBuYXZpZ2F0aW9uIC8gdXRpbHMgL1xuICogZXh0ZW5zaW9uc1x1RkYwOVx1NEUwRFx1NTIxN1x1NTcyOFx1OEZEOVx1OTFDQyBcdTIwMTRcdTIwMTQgY29yZSBcdTRFMERcdTYxMUZcdTc3RTVcdTUxNzdcdTRGNTNcdTU0MERcdTVCNTdcdTMwMDJcbiAqL1xuZXhwb3J0IGNvbnN0IEFMTF9OQU1FU1BBQ0VTID0gWy4uLkNPUkVfTkFNRVNQQUNFUywgLi4uREVTS1RPUF9PTkxZX05BTUVTUEFDRVMsIC4uLkJVSUxUX0lOX05BTUVTUEFDRVNdIGFzIGNvbnN0O1xuZXhwb3J0IHR5cGUgTmFtZXNwYWNlTmFtZSA9ICh0eXBlb2YgQUxMX05BTUVTUEFDRVMpW251bWJlcl07XG4iLCAiaW1wb3J0IHNlbXZlciBmcm9tICdzZW12ZXInO1xuXG5pbXBvcnQgdHlwZSB7IFNraWxsSW5mbywgU3luY1N0YXRlIH0gZnJvbSAnLi90eXBlcyc7XG5cbmZ1bmN0aW9uIG5vcm1hbGl6ZVN0YW5kYXJkVmVyc2lvbih2ZXJzaW9uOiBzdHJpbmcgfCBudWxsIHwgdW5kZWZpbmVkKTogc3RyaW5nIHwgdW5kZWZpbmVkIHtcbiAgICBpZiAodHlwZW9mIHZlcnNpb24gIT09ICdzdHJpbmcnKSB7cmV0dXJuIHVuZGVmaW5lZDt9XG4gICAgY29uc3QgdHJpbW1lZCA9IHZlcnNpb24udHJpbSgpO1xuICAgIGlmICghdHJpbW1lZCkge3JldHVybiB1bmRlZmluZWQ7fVxuICAgIGNvbnN0IGNsZWFuZWQgPSBzZW12ZXIuY2xlYW4odHJpbW1lZCk7XG4gICAgcmV0dXJuIGNsZWFuZWQgJiYgc2VtdmVyLnZhbGlkKGNsZWFuZWQpID8gY2xlYW5lZCA6IHVuZGVmaW5lZDtcbn1cblxuLyoqXG4gKiBDb21wYXJlIHN0YW5kYXJkIFNlbVZlciBzdHJpbmdzIG9ubHkuXG4gKiBOb24tc3RhbmRhcmQgdmVyc2lvbnMgc3VjaCBhcyBcImxhdGVzdFwiIGFyZSBsZWdhY3kgcGxhY2Vob2xkZXJzIGFuZCBhcmUgbm90IGNvbXBhcmFibGUuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBjb21wYXJlVmVyc2lvbihhOiBzdHJpbmcgfCBudWxsIHwgdW5kZWZpbmVkLCBiOiBzdHJpbmcgfCBudWxsIHwgdW5kZWZpbmVkKTogLTEgfCAwIHwgMSB8IHVuZGVmaW5lZCB7XG4gICAgY29uc3QgbGVmdCA9IG5vcm1hbGl6ZVN0YW5kYXJkVmVyc2lvbihhKTtcbiAgICBjb25zdCByaWdodCA9IG5vcm1hbGl6ZVN0YW5kYXJkVmVyc2lvbihiKTtcbiAgICBpZiAoIWxlZnQgfHwgIXJpZ2h0KSB7cmV0dXJuIHVuZGVmaW5lZDt9XG5cbiAgICBjb25zdCBjb21wYXJlZCA9IHNlbXZlci5jb21wYXJlKGxlZnQsIHJpZ2h0KTtcbiAgICBpZiAoY29tcGFyZWQgPiAwKSB7cmV0dXJuIDE7fVxuICAgIGlmIChjb21wYXJlZCA8IDApIHtyZXR1cm4gLTE7fVxuICAgIHJldHVybiAwO1xufVxuXG5mdW5jdGlvbiBpc0FmdGVyKGN1cnJlbnQ6IHN0cmluZyB8IG51bGwgfCB1bmRlZmluZWQsIGJhc2VsaW5lOiBzdHJpbmcgfCBudWxsIHwgdW5kZWZpbmVkKTogYm9vbGVhbiB7XG4gICAgaWYgKCFjdXJyZW50IHx8ICFiYXNlbGluZSkge3JldHVybiBmYWxzZTt9XG4gICAgY29uc3QgY3VycmVudFRpbWUgPSBEYXRlLnBhcnNlKGN1cnJlbnQpO1xuICAgIGNvbnN0IGJhc2VsaW5lVGltZSA9IERhdGUucGFyc2UoYmFzZWxpbmUpO1xuICAgIGlmIChOdW1iZXIuaXNOYU4oY3VycmVudFRpbWUpIHx8IE51bWJlci5pc05hTihiYXNlbGluZVRpbWUpKSB7cmV0dXJuIGZhbHNlO31cbiAgICByZXR1cm4gY3VycmVudFRpbWUgPiBiYXNlbGluZVRpbWU7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgRGVyaXZlU3luY1N0YXRlUGFyYW1zIHtcbiAgICBoYXNMb2NhbDogYm9vbGVhbjtcbiAgICBoYXNDbG91ZDogYm9vbGVhbjtcbiAgICBsb2NhbFZlcnNpb24/OiBzdHJpbmcgfCBudWxsO1xuICAgIC8qKiBAZGVwcmVjYXRlZCBVc2UgbG9jYWxWZXJzaW9uIGluc3RlYWQuIEtlcHQgZm9yIG9sZCBjYWxsZXJzIGR1cmluZyBtaWdyYXRpb24uICovXG4gICAgbWV0YVZlcnNpb24/OiBzdHJpbmcgfCBudWxsO1xuICAgIGNsb3VkVmVyc2lvbj86IHN0cmluZyB8IG51bGw7XG4gICAgdXNlck1vZGlmaWVkPzogYm9vbGVhbjtcbiAgICBjbG91ZFVwZGF0ZWRBdD86IHN0cmluZztcbiAgICBsYXN0Q2xvdWRVcGRhdGVkQXQ/OiBzdHJpbmc7XG4gICAgLyoqXG4gICAgICogUDJcdUZGMDhcdTY1QjlcdTY4NDggQlx1RkYwOVx1RkYxQVx1NUY1M1x1NTI0RFx1NjU3NFx1NTMwNVx1NTE4NVx1NUJCOSBoYXNoXHUzMDAyXHU1M0VBXHU2NzA5XHU4QzAzXHU3NTI4XHU2NUI5XHU2NjNFXHU1RjBGXHU2M0QwXHU0RjlCXHU2NUY2XHU2MjREXHU1M0MyXHU0RTBFXHU1MjI0XHU1QjlBXHVGRjBDXG4gICAgICogXHU2NzJBXHU2M0QwXHU0RjlCXHVGRjA4XHU1QkJGXHU0RTNCXHU2NzJBXHU2M0E1XHU1MTY1IGhhc2ggXHU4QkExXHU3Qjk3XHVGRjBDXHU2MjE2XHU4QkU1XHU2MjgwXHU4MEZEXHU0RTBEXHU2NjJGXHU1MDE5XHU5MDA5XHU4MUVBXHU1QjlBXHU0RTQ5XHU2MjgwXHU4MEZEXHVGRjA5XHU2NUY2XHU1QjhDXHU1MTY4XHU0RTBEXHU1RjcxXHU1NENEXG4gICAgICogXHU0RTBCXHU5NzYyXHU3MjQ4XHU2NzJDXHU1M0Y3L1x1NjVGNlx1OTVGNFx1NjIzM1x1NTIyNFx1NUI5QVx1RkYwQ1x1NTQxMVx1NTQwRVx1NTE3Q1x1NUJCOVx1MzAwMlxuICAgICAqL1xuICAgIHBhY2thZ2VDb250ZW50SGFzaD86IHN0cmluZztcbiAgICAvKiogXHU4RDI2XHU2NzJDXHU4QkIwXHU1RjU1XHU3Njg0XHUzMDBDXHU0RTBBXHU2QjIxXHU2MjEwXHU1MjlGXHU1NDBDXHU2QjY1XHUzMDBEXHU2NTc0XHU1MzA1XHU1MTg1XHU1QkI5IGhhc2hcdUZGMUJcdTY1RTBcdTUzODZcdTUzRjJcdThEMjZcdTY3MkNcdThCQjBcdTVGNTVcdTY1RjZcdTRFM0EgdW5kZWZpbmVkXHUzMDAyICovXG4gICAgc3luY2VkQ29udGVudEhhc2g/OiBzdHJpbmc7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBkZXJpdmVTeW5jU3RhdGUocGFyYW1zOiBEZXJpdmVTeW5jU3RhdGVQYXJhbXMpOiBTeW5jU3RhdGUge1xuICAgIGNvbnN0IHtcbiAgICAgICAgaGFzTG9jYWwsXG4gICAgICAgIGhhc0Nsb3VkLFxuICAgICAgICBsb2NhbFZlcnNpb24sXG4gICAgICAgIG1ldGFWZXJzaW9uLFxuICAgICAgICBjbG91ZFZlcnNpb24sXG4gICAgICAgIHVzZXJNb2RpZmllZCA9IGZhbHNlLFxuICAgICAgICBjbG91ZFVwZGF0ZWRBdCxcbiAgICAgICAgbGFzdENsb3VkVXBkYXRlZEF0LFxuICAgICAgICBwYWNrYWdlQ29udGVudEhhc2gsXG4gICAgICAgIHN5bmNlZENvbnRlbnRIYXNoLFxuICAgIH0gPSBwYXJhbXM7XG5cbiAgICBpZiAoaGFzTG9jYWwgJiYgIWhhc0Nsb3VkKSB7cmV0dXJuICdsb2NhbF9vbmx5Jzt9XG4gICAgaWYgKCFoYXNMb2NhbCAmJiBoYXNDbG91ZCkge3JldHVybiAnY2xvdWRfb25seSc7fVxuICAgIGlmICghaGFzTG9jYWwgJiYgIWhhc0Nsb3VkKSB7cmV0dXJuICdzeW5jZWQnO31cblxuICAgIGlmICh1c2VyTW9kaWZpZWQpIHtyZXR1cm4gJ2xvY2FsX2FoZWFkJzt9XG5cbiAgICAvLyBQMlx1RkYwOFx1NjVCOVx1Njg0OCBCXHVGRjA5XHVGRjFBXHU4RDI2XHU2NzJDIGhhc2ggXHU0RjE4XHU1MTQ4XHU0RThFXHU3MjQ4XHU2NzJDXHU1M0Y3XHUyMDE0XHUyMDE0aGFzaCBcdTc2RjRcdTYzQTVcdTUzQ0RcdTY2MjBcdTUxODVcdTVCQjlcdTc3MUZcdTc2RjhcdUZGMENcdTgwRkRcdTYxMUZcdTc3RTVcbiAgICAvLyBcdTMwMENcdTY1MzlcdTUxODVcdTVCQjlcdTVGRDhcdThCQjAgYnVtcCBcdTcyNDhcdTY3MkNcdTUzRjdcdTMwMERcdTc2ODRcdTU3M0FcdTY2NkZcdUZGMUJcdTcyNDhcdTY3MkNcdTUzRjdcdTUzRUFcdTU3MjggaGFzaCBcdTUyMjRcdTMwMENcdTZDQTFcdTUzRDhcdTMwMERcdTY1RjZcdTc1MjhcdTRFOEVcdTUxNUNcdTVFOTVcbiAgICAvLyBcdTUzM0FcdTUyMDZcdUZGMDhcdTU5ODJcdTU0MEVcdTUzRjBcdTYyOEFcdTRFOTFcdTdBRUZcdTcyNDhcdTY3MkNcdTUzRjdcdTYzQThcdThGREJcdTRFODZcdTRGNDZcdTUxODVcdTVCQjlcdTUxNzZcdTVCOUVcdTZDQTFcdTUzRDhcdUZGMDlcdTMwMDJcdTcxNjdcdTYyODRcdTRFMTNcdTVCQjZcdTZBMjFcdTU3NTcgZGVyaXZlUHJlc2VuY2UgXHU3Njg0XHU0RjE4XHU1MTQ4XHU3RUE3XHUzMDAyXG4gICAgLy9cbiAgICAvLyBcdTZDRThcdTYxMEZcdUZGMUFcdTUzRUFcdTY3MDkgcGFja2FnZUNvbnRlbnRIYXNoIFx1NTQ4QyBzeW5jZWRDb250ZW50SGFzaCAqKlx1OTBGRFx1NUI1OFx1NTcyOCoqXHU2NUY2XHU2MjREXHU1M0MyXHU0RTBFIGhhc2ggXHU1MjI0XHU1QjlBXHUzMDAyXG4gICAgLy8gXHU4RDI2XHU2NzJDXHU2NjJGXHU2NzJDXHU2QjIxXHU2NUIwXHU1ODlFXHU3Njg0XHU3MkVDXHU3QUNCXHU2NTg3XHU0RUY2XHVGRjBDXHU1MjFBXHU0RTBBXHU3RUJGXHU2NUY2XHU1QkY5XHU2MjQwXHU2NzA5XHU1Mzg2XHU1M0YyXHU1REYyXHU1NDBDXHU2QjY1XHU4MUVBXHU1QjlBXHU0RTQ5XHU2MjgwXHU4MEZEXHU5MEZEXHU2Q0ExXHU2NzA5XHU4QkIwXHU1RjU1XHUyMDE0XHUyMDE0XG4gICAgLy8gXHU1OTgyXHU2NzlDXHU2MjhBXCJcdTY1RTBcdThEMjZcdTY3MkNcdThCQjBcdTVGNTVcIlx1NEU1Rlx1NUY1M1x1NjIxMFwiXHU2NzJDXHU1NzMwXHU5ODg2XHU1MTQ4XCJcdUZGMENcdTRGMUFcdTVCRkNcdTgxRjRcdTU5MjdcdTkxQ0ZcdTY1RTlcdTVDMzFcdTU0MENcdTZCNjVcdThGQzdcdTc2ODRcdTVCNThcdTkxQ0ZcdTYyODBcdTgwRkRcdTRFMDBcdTZCMjFcdTYwMjdcbiAgICAvLyBcdTg4QUJcdThCRUZcdTUyMjRcdTRFM0FcIlx1NjcyQ1x1NTczMFx1NjcwOVx1NjZGNFx1NjVCMFwiXHVGRjA4XHU1MUI3XHU1NDJGXHU1MkE4XHU1NjZBXHU1OEYwXHVGRjBDXHU0RTBEXHU2NjJGXHU3NzFGXHU1QjlFXHU3RjE2XHU4RjkxXHVGRjA5XHUzMDAyXHU1NkUwXHU2QjY0XHU4RDI2XHU2NzJDXHU3RjNBXHU4QkIwXHU1RjU1XHU2NUY2XHU1QjhDXHU1MTY4XHU4REYzXHU4RkM3XG4gICAgLy8gaGFzaCBcdTUyMjRcdTVCOUFcdTMwMDFcdTkwMDBcdTU2REVcdTY1RTdcdTc2ODRcdTcyNDhcdTY3MkNcdTUzRjcvXHU2NUY2XHU5NUY0XHU2MjMzXHU5MDNCXHU4RjkxXHVGRjFCXHU1M0VBXHU2NzA5XHU3NTI4XHU2MjM3XHU1QjlFXHU5NjQ1XHU4OUU2XHU1M0QxXHU4RkM3XHU0RTAwXHU2QjIxXHU0RTBBXHU0RjIwL1x1NEUwQlx1OEY3RFx1MzAwMVxuICAgIC8vIFx1OEQyNlx1NjcyQ1x1NEVBN1x1NzUxRlx1OEJCMFx1NUY1NVx1NTQwRVx1RkYwQ2hhc2ggXHU1MjI0XHU1QjlBXHU2MjREXHU1RjAwXHU1OUNCXHU3NTFGXHU2NTQ4XHUzMDAyXG4gICAgaWYgKHBhY2thZ2VDb250ZW50SGFzaCAhPT0gdW5kZWZpbmVkICYmIHN5bmNlZENvbnRlbnRIYXNoICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgaWYgKHBhY2thZ2VDb250ZW50SGFzaCAhPT0gc3luY2VkQ29udGVudEhhc2gpIHtcbiAgICAgICAgICAgIHJldHVybiAnbG9jYWxfYWhlYWQnO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgY29uc3QgY29tcGFyZWQgPSBjb21wYXJlVmVyc2lvbihsb2NhbFZlcnNpb24gPz8gbWV0YVZlcnNpb24sIGNsb3VkVmVyc2lvbik7XG4gICAgaWYgKGNvbXBhcmVkICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgaWYgKGNvbXBhcmVkID4gMCkge3JldHVybiAnbG9jYWxfYWhlYWQnO31cbiAgICAgICAgaWYgKGNvbXBhcmVkIDwgMCkge3JldHVybiAnY2xvdWRfYWhlYWQnO31cbiAgICB9XG5cbiAgICBpZiAoaXNBZnRlcihjbG91ZFVwZGF0ZWRBdCwgbGFzdENsb3VkVXBkYXRlZEF0KSkge3JldHVybiAnY2xvdWRfYWhlYWQnO31cblxuICAgIHJldHVybiAnc3luY2VkJztcbn1cblxuZnVuY3Rpb24gaXNNYXJrZXRTa2lsbChza2lsbDogU2tpbGxJbmZvKTogYm9vbGVhbiB7XG4gICAgLy8gXHU1MjA2XHU3QzdCXHU1MjI0XHU1QjlBXHU2NTM5XHU3NTI4IGlzTWFya2V0Q29udGVudEVkaXRlZFx1RkYwOFx1NjU3NFx1NTMwNSBoYXNoIFx1NUJGOVx1NkJENFx1NUY5N1x1NTFGQVx1RkYwOVx1RkYwQ1x1NEUwRFx1NTE4RFx1OEJGQiB1c2VyTW9kaWZpZWRcdTIwMTRcdTIwMTRcbiAgICAvLyBcdTU0MEVcdTgwMDVcdTY2MkZcdTcyRUNcdTdBQ0JcdTc2ODRcdTRFMDBcdTY3NjFcdTdFQkZcdUZGMENcdTUzRUFcdTY3MERcdTUyQTFcdTMwMENcdTVFMDJcdTU3M0FcdTYyODBcdTgwRkRcdTY1QjBcdTcyNDhcdTY3MkNcdTY2MkZcdTU0MjZcdTk3NTlcdTlFRDhcdTgxRUFcdTUyQThcdTY2RjRcdTY1QjBcdTMwMERcdTMwMDJcbiAgICAvLyBcdThCRTZcdTg5QzEgZG9jcy93b3JrYnVkZHkvc2tpbGwtbWFya2V0LWVkaXQtZGV0ZWN0aW9uLWFuZC1jbGFzc2lmaWNhdGlvbi1yZWRlc2lnbi5tZFx1MzAwMlxuICAgIHJldHVybiBCb29sZWFuKHNraWxsLm1hcmtldHBsYWNlU291cmNlICYmICFza2lsbC5pc01hcmtldENvbnRlbnRFZGl0ZWQpO1xufVxuXG5mdW5jdGlvbiBzZWxlY3RMYXRlc3RDbG91ZFNraWxsKGN1cnJlbnQ6IFNraWxsSW5mbywgbmV4dDogU2tpbGxJbmZvKTogU2tpbGxJbmZvIHtcbiAgICBjb25zdCBjdXJyZW50VGltZSA9IGN1cnJlbnQuY2xvdWRVcGRhdGVkQXQgPyBEYXRlLnBhcnNlKGN1cnJlbnQuY2xvdWRVcGRhdGVkQXQpIDogTmFOO1xuICAgIGNvbnN0IG5leHRUaW1lID0gbmV4dC5jbG91ZFVwZGF0ZWRBdCA/IERhdGUucGFyc2UobmV4dC5jbG91ZFVwZGF0ZWRBdCkgOiBOYU47XG5cbiAgICBpZiAoTnVtYmVyLmlzTmFOKGN1cnJlbnRUaW1lKSAmJiBOdW1iZXIuaXNOYU4obmV4dFRpbWUpKSB7cmV0dXJuIGN1cnJlbnQ7fVxuICAgIGlmIChOdW1iZXIuaXNOYU4oY3VycmVudFRpbWUpKSB7cmV0dXJuIG5leHQ7fVxuICAgIGlmIChOdW1iZXIuaXNOYU4obmV4dFRpbWUpKSB7cmV0dXJuIGN1cnJlbnQ7fVxuICAgIHJldHVybiBuZXh0VGltZSA+IGN1cnJlbnRUaW1lID8gbmV4dCA6IGN1cnJlbnQ7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBtZXJnZVNraWxsQ2xvdWRTeW5jU3RhdGUoXG4gICAgbG9jYWxTa2lsbHM6IFNraWxsSW5mb1tdLFxuICAgIGNsb3VkU2tpbGxzOiBTa2lsbEluZm9bXSxcbiAgICAvKiogUDJcdUZGMDhcdTY1QjlcdTY4NDggQlx1RkYwOVx1RkYxQVx1NjI4MFx1ODBGRFx1NTQwRCBcdTIxOTIgXHU4RDI2XHU2NzJDXHU4QkIwXHU1RjU1XHU3Njg0XHU2NjIwXHU1QzA0XHVGRjFCXHU2NzJBXHU2M0QwXHU0RjlCXHU2NUY2IGRlcml2ZVN5bmNTdGF0ZSBcdTVCOENcdTUxNjhcdTkwMDBcdTU2REVcdTY1RTdcdTkwM0JcdThGOTFcdTMwMDIgKi9cbiAgICBzeW5jTGVkZ2VyQnlOYW1lPzogUmVjb3JkPHN0cmluZywgeyBzeW5jZWRDb250ZW50SGFzaD86IHN0cmluZyB9Pixcbik6IFNraWxsSW5mb1tdIHtcbiAgICBjb25zdCBsb2NhbEJ5TmFtZSA9IG5ldyBNYXA8c3RyaW5nLCBTa2lsbEluZm8+KCk7XG4gICAgY29uc3QgY2xvdWRCeU5hbWUgPSBuZXcgTWFwPHN0cmluZywgU2tpbGxJbmZvPigpO1xuICAgIGNvbnN0IG5hbWVzOiBzdHJpbmdbXSA9IFtdO1xuXG4gICAgZm9yIChjb25zdCBza2lsbCBvZiBsb2NhbFNraWxscykge1xuICAgICAgICBpZiAoIWxvY2FsQnlOYW1lLmhhcyhza2lsbC5uYW1lKSkge1xuICAgICAgICAgICAgbG9jYWxCeU5hbWUuc2V0KHNraWxsLm5hbWUsIHNraWxsKTtcbiAgICAgICAgICAgIG5hbWVzLnB1c2goc2tpbGwubmFtZSk7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBmb3IgKGNvbnN0IHNraWxsIG9mIGNsb3VkU2tpbGxzKSB7XG4gICAgICAgIGNvbnN0IGV4aXN0aW5nID0gY2xvdWRCeU5hbWUuZ2V0KHNraWxsLm5hbWUpO1xuICAgICAgICBjbG91ZEJ5TmFtZS5zZXQoc2tpbGwubmFtZSwgZXhpc3RpbmcgPyBzZWxlY3RMYXRlc3RDbG91ZFNraWxsKGV4aXN0aW5nLCBza2lsbCkgOiBza2lsbCk7XG4gICAgICAgIGlmICghbG9jYWxCeU5hbWUuaGFzKHNraWxsLm5hbWUpICYmICFuYW1lcy5pbmNsdWRlcyhza2lsbC5uYW1lKSkge1xuICAgICAgICAgICAgbmFtZXMucHVzaChza2lsbC5uYW1lKTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIHJldHVybiBuYW1lc1xuICAgICAgICAubWFwKG5hbWUgPT4ge1xuICAgICAgICAgICAgY29uc3QgbG9jYWxTa2lsbCA9IGxvY2FsQnlOYW1lLmdldChuYW1lKTtcbiAgICAgICAgICAgIGNvbnN0IGNsb3VkU2tpbGwgPSBjbG91ZEJ5TmFtZS5nZXQobmFtZSk7XG4gICAgICAgICAgICBjb25zdCBiYXNlU2tpbGwgPSBsb2NhbFNraWxsID8/IGNsb3VkU2tpbGw7XG4gICAgICAgICAgICBpZiAoIWJhc2VTa2lsbCkge1xuICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgU2tpbGwgJHtuYW1lfSBpcyBtaXNzaW5nIGZyb20gYm90aCBsb2NhbCBhbmQgY2xvdWQgbWFwc2ApO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBjb25zdCBjbG91ZFZlcnNpb24gPSBjbG91ZFNraWxsPy5jbG91ZFZlcnNpb24gPz8gY2xvdWRTa2lsbD8udmVyc2lvbiA/PyBsb2NhbFNraWxsPy5jbG91ZFZlcnNpb247XG4gICAgICAgICAgICBjb25zdCBjbG91ZFVwZGF0ZWRBdCA9IGNsb3VkU2tpbGw/LmNsb3VkVXBkYXRlZEF0ID8/IGxvY2FsU2tpbGw/LmNsb3VkVXBkYXRlZEF0O1xuICAgICAgICAgICAgY29uc3Qgc3luY1N0YXRlID0gZGVyaXZlU3luY1N0YXRlKHtcbiAgICAgICAgICAgICAgICBoYXNMb2NhbDogQm9vbGVhbihsb2NhbFNraWxsKSxcbiAgICAgICAgICAgICAgICBoYXNDbG91ZDogQm9vbGVhbihjbG91ZFNraWxsKSxcbiAgICAgICAgICAgICAgICBsb2NhbFZlcnNpb246IGxvY2FsU2tpbGw/LnZlcnNpb24sXG4gICAgICAgICAgICAgICAgY2xvdWRWZXJzaW9uLFxuICAgICAgICAgICAgICAgIHVzZXJNb2RpZmllZDogbG9jYWxTa2lsbD8udXNlck1vZGlmaWVkID8/IGZhbHNlLFxuICAgICAgICAgICAgICAgIGNsb3VkVXBkYXRlZEF0LFxuICAgICAgICAgICAgICAgIGxhc3RDbG91ZFVwZGF0ZWRBdDogbG9jYWxTa2lsbD8uY2xvdWRVcGRhdGVkQXQsXG4gICAgICAgICAgICAgICAgcGFja2FnZUNvbnRlbnRIYXNoOiBsb2NhbFNraWxsPy5wYWNrYWdlQ29udGVudEhhc2gsXG4gICAgICAgICAgICAgICAgc3luY2VkQ29udGVudEhhc2g6IHN5bmNMZWRnZXJCeU5hbWU/LltuYW1lXT8uc3luY2VkQ29udGVudEhhc2gsXG4gICAgICAgICAgICB9KTtcblxuICAgICAgICAgICAgY29uc3QgbWVyZ2VkOiBTa2lsbEluZm8gPSB7XG4gICAgICAgICAgICAgICAgLi4uKGNsb3VkU2tpbGwgPz8ge30pLFxuICAgICAgICAgICAgICAgIC4uLihsb2NhbFNraWxsID8/IHt9KSxcbiAgICAgICAgICAgICAgICBuYW1lLFxuICAgICAgICAgICAgICAgIGZpbGVQYXRoOiBsb2NhbFNraWxsPy5maWxlUGF0aCA/PyBjbG91ZFNraWxsPy5maWxlUGF0aCA/PyAnJyxcbiAgICAgICAgICAgICAgICBkZXNjcmlwdGlvbjogbG9jYWxTa2lsbD8uZGVzY3JpcHRpb24gPz8gY2xvdWRTa2lsbD8uZGVzY3JpcHRpb24gPz8gJycsXG4gICAgICAgICAgICAgICAgc291cmNlOiBiYXNlU2tpbGwuc291cmNlLFxuICAgICAgICAgICAgICAgIHR5cGU6IGJhc2VTa2lsbC50eXBlLFxuICAgICAgICAgICAgICAgIHZlcnNpb246IGxvY2FsU2tpbGw/LnZlcnNpb24gPz8gY2xvdWRTa2lsbD8udmVyc2lvbixcbiAgICAgICAgICAgICAgICBjbG91ZFVpZDogY2xvdWRTa2lsbD8uY2xvdWRVaWQgPz8gbG9jYWxTa2lsbD8uY2xvdWRVaWQsXG4gICAgICAgICAgICAgICAgY2xvdWRWZXJzaW9uLFxuICAgICAgICAgICAgICAgIGNsb3VkVXBkYXRlZEF0OiBjbG91ZFVwZGF0ZWRBdCA/PyBsb2NhbFNraWxsPy5jbG91ZFVwZGF0ZWRBdCxcbiAgICAgICAgICAgICAgICBsb2NhbFVwZGF0ZWRBdDogbG9jYWxTa2lsbD8ubG9jYWxVcGRhdGVkQXQsXG4gICAgICAgICAgICAgICAgbXRpbWVNczogbG9jYWxTa2lsbD8ubXRpbWVNcyxcbiAgICAgICAgICAgICAgICAvLyBcdTRFOTFcdTdBRUZcdTYyODBcdTgwRkRcdUZGMDhjbG91ZF9vbmx5XHVGRjA5XHU0RTVGXHU5NzAwXHU0RkREXHU3NTU5IG1hcmtldHBsYWNlU291cmNlXHVGRjA4XHU1OTgyICdza2lsbGh1YidcdUZGMDlcdUZGMENcbiAgICAgICAgICAgICAgICAvLyBcdTRGOUJcdTY3MkNcdTU3MzBcdTgzRENcdTUzNTVcdTc2ODRcIlx1NEUwQlx1OEY3RFx1NTQwRVx1NEY3Rlx1NzUyOFwiXHU2MzA5XHU1RTAyXHU1NzNBXHU1Qjg5XHU4OEM1XHU5MDFBXHU5MDUzXHU1MjA2XHU2RDQxXHU0RTBCXHU4RjdEXHUzMDAyXG4gICAgICAgICAgICAgICAgbWFya2V0cGxhY2VTb3VyY2U6IGxvY2FsU2tpbGw/Lm1hcmtldHBsYWNlU291cmNlID8/IGNsb3VkU2tpbGw/Lm1hcmtldHBsYWNlU291cmNlLFxuICAgICAgICAgICAgICAgIHVzZXJNb2RpZmllZDogbG9jYWxTa2lsbD8udXNlck1vZGlmaWVkLFxuICAgICAgICAgICAgICAgIGlzTWFya2V0Q29udGVudEVkaXRlZDogbG9jYWxTa2lsbD8uaXNNYXJrZXRDb250ZW50RWRpdGVkLFxuICAgICAgICAgICAgICAgIHN5bmNTdGF0ZSxcbiAgICAgICAgICAgIH07XG4gICAgICAgICAgICByZXR1cm4gbWVyZ2VkO1xuICAgICAgICB9KVxuICAgICAgICAuc29ydCgoYSwgYikgPT4ge1xuICAgICAgICAgICAgY29uc3QgYUlzTWFya2V0ID0gaXNNYXJrZXRTa2lsbChhKTtcbiAgICAgICAgICAgIGNvbnN0IGJJc01hcmtldCA9IGlzTWFya2V0U2tpbGwoYik7XG4gICAgICAgICAgICBpZiAoYUlzTWFya2V0ICE9PSBiSXNNYXJrZXQpIHtyZXR1cm4gYUlzTWFya2V0ID8gMSA6IC0xO31cbiAgICAgICAgICAgIHJldHVybiBhLm5hbWUubG9jYWxlQ29tcGFyZShiLm5hbWUpO1xuICAgICAgICB9KTtcbn1cbiIsICIvKipcbiAqIGNoaWxkX3Byb2Nlc3MgSVBDIFRyYW5zcG9ydCBcdTVCOUVcdTczQjBcdUZGMDgqKlx1NTNDQ1x1NTQxMSoqXHVGRjA5XHUzMDAyXG4gKlxuICogXHU1QjlFXHU3M0IwIGNvcmUgXHU2NUIwIEJyaWRnZSBUcmFuc3BvcnQgXHU1MzRGXHU4QkFFXHVGRjA4YGhhbmRsZSAvIGJyb2FkY2FzdCAvIGludm9rZSAvIG9uIC8gZGlzcG9zZWBcdUZGMDlcdUZGMENcbiAqIFx1NEUxNCoqXHU3MjM2XHU1QjUwXHU4RkRCXHU3QTBCXHU0RTI0XHU0RkE3XHU5MEZEXHU1QjhDXHU2NTc0XHU1QjlFXHU3M0IwXHU1NkRCXHU0RUY2XHU1OTU3KipcdUZGMENcdTVGNjJcdTYyMTBcdTUzQ0NcdTU0MTEgUlBDICsgXHU0RThCXHU0RUY2XHU2M0E4XHU5MDAxXHU5MDFBXHU5MDUzXHVGRjFBXG4gKlxuICogYGBgXG4gKiAgICAgICAgICAgICAgXHU3MjM2XHU4RkRCXHU3QTBCIChIb3N0KSAgICAgICAgICAgICAgXHU1QjUwXHU4RkRCXHU3QTBCIChDbGllbnQpXG4gKiAgICAgICAgICAgICAgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwICAgICAgICAgICAgICBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcbiAqICAgXHU1QjUwXHU4QzAzXHU3MjM2IFx1MjE5MiAgIGhhbmRsZShmbikgICAgICAgICAgPFx1MjUwMFx1MjUwMFx1MjUwMCAgIGludm9rZSguLi4pXG4gKiAgIFx1NzIzNlx1OEMwM1x1NUI1MCBcdTIxOTIgICBpbnZva2UoLi4uKSAgICAgICAgIFx1MjUwMFx1MjUwMFx1MjUwMD4gICBoYW5kbGUoZm4pICAgICBcdTIxOTAgZXh0ZW5zaW9uIFx1NkNFOFx1NTE4Q1x1ODFFQVx1NURGMVx1NzY4NCBtZXRob2RzXG4gKiAgIFx1NzIzNlx1NjNBOFx1NEU4Qlx1NEVGNiBcdTIxOTIgYnJvYWRjYXN0KGV2dCwgcCkgICBcdTI1MDBcdTI1MDBcdTI1MDA+ICAgb24oZm4pXG4gKiBgYGBcbiAqXG4gKiBXaXJlIFx1NTM0Rlx1OEJBRVx1RkYxQWBJcGNXaXJlTWVzc2FnZWBcdUZGMDhjaGlsZF9wcm9jZXNzIFx1NzlDMVx1NjcwOVx1NjgzQ1x1NUYwRlx1RkYwOVxuICogXHU5NTE5XHU4QkVGXHU0RkUxXHU1QzAxXHVGRjFBXHU1OTBEXHU3NTI4IGNvcmUgXHU3Njg0IGBzZXJpYWxpemVCcmlkZ2VFcnJvcmAgLyBgZGVzZXJpYWxpemVSZXN1bHRgXHVGRjBDXHU0RTBFIEVsZWN0cm9uIElQQyBcdTRFMDBcdTgxRjRcdTMwMDJcbiAqL1xuaW1wb3J0IHR5cGUgeyBDaGlsZFByb2Nlc3MgfSBmcm9tICdub2RlOmNoaWxkX3Byb2Nlc3MnO1xuXG5pbXBvcnQge1xuICAgIHR5cGUgQ2hhbm5lbEhhbmRsZXIsXG4gICAgZGVzZXJpYWxpemVSZXN1bHQsXG4gICAgdHlwZSBFdmVudEhhbmRsZXIsXG4gICAgdHlwZSBJbnZva2VDb250ZXh0LFxuICAgIGlzU2VyaWFsaXplZEJyaWRnZUVycm9yLFxuICAgIHR5cGUgUmVxdWVzdEhhbmRsZXIsXG4gICAgc2VyaWFsaXplQnJpZGdlRXJyb3IsXG4gICAgdHlwZSBUcmFuc3BvcnQsXG59IGZyb20gJ0BnZW5pZS93b3JrYnVkZHktY29yZS93Yic7XG5cbmltcG9ydCB0eXBlIHsgSXBjV2lyZU1lc3NhZ2UgfSBmcm9tICcuL3R5cGVzJztcblxuZXhwb3J0IGludGVyZmFjZSBQcm9jZXNzVHJhbnNwb3J0IGV4dGVuZHMgVHJhbnNwb3J0IHtcbiAgICAvKiogRHJhaW4gZXhpc3Rpbmcgd29yazsgcmVmdXNlIG5ldyBpbmJvdW5kIGJ1c2luZXNzIGNhbGxzIHdoaWxlIGNsZWFudXAgbWF5IGNhbGwgSG9zdC4gKi9cbiAgICBzdG9wQWNjZXB0aW5nUmVxdWVzdHMoKTogdm9pZDtcbn1cblxuLy8gXHUyNTAwXHUyNTAwXHUyNTAwIFx1OTAxQVx1NzUyOCBSUEMgXHU3MkI2XHU2MDAxXHU2NzNBXHVGRjA4XHU3MjM2XHU1QjUwXHU0RTI0XHU0RkE3XHU1MTcxXHU0RUFCXHU5MDNCXHU4RjkxXHVGRjA5IFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXG5pbnRlcmZhY2UgUnBjU2lkZU9wdGlvbnMge1xuICAgIGlzQ29ubmVjdGVkKCk6IGJvb2xlYW47XG4gICAgLyoqIFx1NTNEMVx1NkQ4OFx1NjA2Rlx1NTIzMFx1NUJGOVx1N0FFRiAqL1xuICAgIHNlbmQ6IChtc2c6IElwY1dpcmVNZXNzYWdlLCBjYWxsYmFjazogKGVycm9yOiBFcnJvciB8IG51bGwpID0+IHZvaWQpID0+IHZvaWQ7XG4gICAgZGlzY29ubmVjdCgpOiB2b2lkO1xuICAgIG9uQ2xvc2U6IChsaXN0ZW5lcjogKGVycm9yPzogRXJyb3IpID0+IHZvaWQpID0+ICgpID0+IHZvaWQ7XG4gICAgLyoqIFx1NjMwMlx1NkQ4OFx1NjA2Rlx1NzZEMVx1NTQyQ1x1RkYwOFx1OEZENFx1NTZERVx1NTM3OFx1OEY3RFx1NTFGRFx1NjU3MFx1RkYwOSAqL1xuICAgIG9uTWVzc2FnZTogKGxpc3RlbmVyOiAocmF3OiB1bmtub3duKSA9PiB2b2lkKSA9PiAoKSA9PiB2b2lkO1xuICAgIC8qKiBzaWRlIFx1NjgwN1x1N0I3RVx1RkYwQ1x1NzUyOFx1NEU4RVx1OTUxOVx1OEJFRlx1NjNEMFx1NzkzQSAqL1xuICAgIGxhYmVsOiBzdHJpbmc7XG59XG5cbnR5cGUgUmVxdWVzdERlbGl2ZXJ5ID0gJ25vdC1zZW50JyB8ICd1bmtub3duJztcblxuZnVuY3Rpb24gdHJhbnNwb3J0Q2xvc2VkKGVycm9yOiBFcnJvciwgZGVsaXZlcnk6IFJlcXVlc3REZWxpdmVyeSk6IEVycm9yIHtcbiAgICByZXR1cm4gT2JqZWN0LmFzc2lnbihuZXcgRXJyb3IoZXJyb3IubWVzc2FnZSwgeyBjYXVzZTogZXJyb3IgfSksIHtcbiAgICAgICAgY29kZTogJ0VYVEVOU0lPTl9UUkFOU1BPUlRfQ0xPU0VEJyxcbiAgICAgICAgZGF0YTogeyBkZWxpdmVyeSB9LFxuICAgIH0pO1xufVxuXG4vKipcbiAqIFx1Njc4NFx1NUVGQVx1NEUwMFx1NEUyQVx1NkVFMVx1OERCMyBjb3JlIGBUcmFuc3BvcnRgIFx1NjNBNVx1NTNFM1x1NzY4NFx1NUJGOVx1OEM2MVx1MzAwMlx1NEUyNFx1NEZBN1x1NTE3MVx1NzUyOFx1NkI2NFx1NUI5RVx1NzNCMFx1RkYwQ1xuICogXHU1REVFXHU1RjAyXHU0RUM1XHU1NzI4IHNlbmQgLyBvbk1lc3NhZ2UgXHU3Njg0XHU3MjY5XHU3NDA2XHU2MjdGXHU4RjdEXHVGRjA4Y2hpbGQuc2VuZCB2cyBwcm9jZXNzLnNlbmRcdUZGMDlcdTMwMDJcbiAqL1xuZnVuY3Rpb24gY3JlYXRlUnBjU2lkZShvcHRzOiBScGNTaWRlT3B0aW9ucyk6IFByb2Nlc3NUcmFuc3BvcnQge1xuICAgIGNvbnN0IHsgb25NZXNzYWdlLCBsYWJlbCB9ID0gb3B0cztcblxuICAgIC8vIGh1Yi1vcmNoZXN0cmF0aW9uIFx1OTAwMlx1OTE0RFx1RkYxQXBlci1jaGFubmVsIGhhbmRsZXIgbWFwXHVGRjBDXHU3QjdFXHU1NDBEXHU3RURGXHU0RTAwXHU0RTNBIGBDaGFubmVsSGFuZGxlcmBcdTMwMDJcbiAgICBjb25zdCByZXF1ZXN0SGFuZGxlcnMgPSBuZXcgTWFwPHN0cmluZywgQ2hhbm5lbEhhbmRsZXI+KCk7XG4gICAgLyoqXG4gICAgICogXHU5MDFBXHU5MTREIGhhbmRsZXJcdUZGMDhjYXRjaC1hbGxcdUZGMDlcdTIwMTRcdTIwMTQgcGVyLWNoYW5uZWwgaGFuZGxlciBtYXAgXHU5MUNDXHU2N0U1XHU0RTBEXHU1MjMwXHU2NUY2XHU3Njg0XHU1MTVDXHU1RTk1XHUzMDAyXG4gICAgICpcbiAgICAgKiBcdTc1MjhcdTRFOEUgd2IuaW52b2tlKGNoYW5uZWwsIC4uLikgXHU5MDAzXHU3NTFGXHU4MjMxXHVGRjFBZXh0ZW5zaW9uIFx1NEZBN1x1ODk4MVx1ODBGRFx1OEMwMyoqXHU0RUZCXHU2MTBGIGRhZW1vbiBSUEMgY2hhbm5lbCoqXG4gICAgICogXHVGRjA4XHU2QkQ0XHU1OTgyIGBjbGF3OmdldFdlY2hhdG1wRW5hYmxlZGBcdUZGMDlcdUZGMENcdTRFMERcdTgwRkRcdTRFOEJcdTUxNDggcGVyLWNoYW5uZWwgXHU2MzAyIGhhbmRsZXJcdUZGMDhjaGFubmVsIFx1OTZDNlx1NTQwOFxuICAgICAqIFx1NjYyRlx1OEZEMFx1ODg0Q1x1NjVGNlx1NUYwMFx1NjUzRVx1NzY4NFx1RkYwOVx1MzAwMlx1ODhDNVx1OTE0RFx1NUM0Mlx1NjMwMlx1NEUwMFx1NEUyQSBjYXRjaC1hbGwgXHU1MDVBXHU1MjREXHU3RjAwXHU4REVGXHU3NTMxXHVGRjA4d2I6KiBcdThENzAgbWV0aG9kQ2hhbm5lbFx1RkYxQlxuICAgICAqIFx1NTE3Nlx1NEVENlx1OEQ3MCBkYWVtb24gUlBDXHVGRjA5XHUzMDAyXG4gICAgICpcbiAgICAgKiBcdTI2QTBcdUZFMEYgXHU3QjdFXHU1NDBEXHU4RDcwIGNvcmUgYFJlcXVlc3RIYW5kbGVyYFx1RkYwOGAoY2hhbm5lbCwgY3R4LCAuLi5hcmdzKWBcdUZGMDlcdTIwMTRcdTIwMTRwZXItY2hhbm5lbCBoYW5kbGVyXG4gICAgICogXHU3NTI4IGBDaGFubmVsSGFuZGxlcmBcdUZGMDhjaGFubmVsIFx1NURGMlx1N0VDRlx1NTcyOCBtYXAga2V5IFx1OTFDQ1x1RkYwQ1x1NEUwRFx1OTcwMFx1ODk4MSBoYW5kbGVyIFx1NTNDMlx1NjU3MFx1NUUyNlx1NEUwMFx1OTA0RFx1RkYwOVx1RkYwQ1xuICAgICAqIGNhdGNoLWFsbCBcdTk3MDBcdTg5ODEgaGFuZGxlciBcdTYxMUZcdTc3RTUgY2hhbm5lbCBcdTYyNERcdTgwRkRcdThERUZcdTc1MzFcdUZGMENcdTYyNDBcdTRFRTVcdThENzAgUmVxdWVzdEhhbmRsZXIgXHU1MTY4XHU3QjdFXHU1NDBEXHUzMDAyXG4gICAgICovXG4gICAgbGV0IGFueUhhbmRsZXI6IFJlcXVlc3RIYW5kbGVyIHwgdW5kZWZpbmVkO1xuICAgIGxldCBldmVudEhhbmRsZXI6IEV2ZW50SGFuZGxlciB8IHVuZGVmaW5lZDtcbiAgICBsZXQgcmVxdWVzdENvdW50ZXIgPSAwO1xuICAgIGNvbnN0IHBlbmRpbmcgPSBuZXcgTWFwPHN0cmluZywge1xuICAgICAgICByZXNvbHZlOiAodjogdW5rbm93bikgPT4gdm9pZDtcbiAgICAgICAgcmVqZWN0OiAoZTogRXJyb3IpID0+IHZvaWQ7XG4gICAgICAgIGRlbGl2ZXJ5OiBSZXF1ZXN0RGVsaXZlcnk7XG4gICAgfT4oKTtcblxuICAgIGxldCBjbG9zZWQ6IEVycm9yIHwgdW5kZWZpbmVkO1xuICAgIGxldCBhY2NlcHRpbmdSZXF1ZXN0cyA9IHRydWU7XG4gICAgbGV0IGRldGFjaCA9ICgpOiB2b2lkID0+IHVuZGVmaW5lZDtcbiAgICBsZXQgZGV0YWNoQ2xvc2UgPSAoKTogdm9pZCA9PiB1bmRlZmluZWQ7XG5cbiAgICBmdW5jdGlvbiBjbG9zZShlcnJvciA9IG5ldyBFcnJvcihgWyR7bGFiZWx9XSBkaXNwb3NlZGApKTogdm9pZCB7XG4gICAgICAgIGlmIChjbG9zZWQpIHsgcmV0dXJuOyB9XG4gICAgICAgIGNsb3NlZCA9IGVycm9yO1xuICAgICAgICBkZXRhY2goKTtcbiAgICAgICAgZGV0YWNoQ2xvc2UoKTtcbiAgICAgICAgZm9yIChjb25zdCByZXF1ZXN0IG9mIHBlbmRpbmcudmFsdWVzKCkpIHsgcmVxdWVzdC5yZWplY3QodHJhbnNwb3J0Q2xvc2VkKGVycm9yLCByZXF1ZXN0LmRlbGl2ZXJ5KSk7IH1cbiAgICAgICAgcGVuZGluZy5jbGVhcigpO1xuICAgICAgICByZXF1ZXN0SGFuZGxlcnMuY2xlYXIoKTtcbiAgICAgICAgYW55SGFuZGxlciA9IHVuZGVmaW5lZDtcbiAgICAgICAgZXZlbnRIYW5kbGVyID0gdW5kZWZpbmVkO1xuICAgIH1cblxuICAgIGZ1bmN0aW9uIHNlbmQobWVzc2FnZTogSXBjV2lyZU1lc3NhZ2UpOiB2b2lkIHtcbiAgICAgICAgaWYgKGNsb3NlZCkgeyByZXR1cm47IH1cbiAgICAgICAgaWYgKCFvcHRzLmlzQ29ubmVjdGVkKCkpIHtcbiAgICAgICAgICAgIGZhaWxDb25uZWN0aW9uKG5ldyBFcnJvcihgWyR7bGFiZWx9XSBkaXNjb25uZWN0ZWRgKSk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIC8vIE5vZGUncyBzZW5kIGNhbGxiYWNrIGlzIG5vdCBhbiBleGVjdXRpb24gYWNrbm93bGVkZ2VtZW50LiBPbmNlXG4gICAgICAgICAgICAvLyBhdHRlbXB0ZWQsIGEgbWlzc2luZyByZXBseSBjYW5ub3QgcHJvdmUgdGhlIG9wZXJhdGlvbiBkaWQgbm90IHJ1bi5cbiAgICAgICAgICAgIGNvbnN0IHJlcXVlc3QgPSBtZXNzYWdlLnR5cGUgPT09ICdpbnZva2U6cmVxdWVzdCcgJiYgbWVzc2FnZS5yZXF1ZXN0SWRcbiAgICAgICAgICAgICAgICA/IHBlbmRpbmcuZ2V0KG1lc3NhZ2UucmVxdWVzdElkKSA6IHVuZGVmaW5lZDtcbiAgICAgICAgICAgIGlmIChyZXF1ZXN0KSB7IHJlcXVlc3QuZGVsaXZlcnkgPSAndW5rbm93bic7IH1cbiAgICAgICAgICAgIC8vIHNlbmQoKSByZXR1cm5pbmcgZmFsc2UgbWVhbnMgYmFja3ByZXNzdXJlIHRvbywgbm90IG5lY2Vzc2FyaWx5IGZhaWx1cmUuXG4gICAgICAgICAgICAvLyBPbmx5IHRoZSBOb2RlIGNhbGxiYWNrIG9yIGEgdHJhbnNwb3J0IGNsb3NlIGV2ZW50IGRlY2lkZXMgZmFpbHVyZS5cbiAgICAgICAgICAgIG9wdHMuc2VuZChtZXNzYWdlLCBlcnJvciA9PiB7IGlmIChlcnJvcikgeyBmYWlsQ29ubmVjdGlvbihlcnJvcik7IH0gfSk7XG4gICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgICAgICAvLyBOb2RlJ3MgZGVmYXVsdCBKU09OIElQQyBzZXJpYWxpemVzIHN5bmNocm9ub3VzbHkuIEEgYmFkIHBheWxvYWQgaXNcbiAgICAgICAgICAgIC8vIGxvY2FsIHRvIHRoaXMgUlBDOiBsZXQgdGhlIHJlcXVlc3QgaGFuZGxlciBzZW5kIGl0cyBlcnJvciByZXNwb25zZS5cbiAgICAgICAgICAgIC8vIE9ubHkgaW5zcGVjdCBKU09OIGFmdGVyIHNlbmQgdGhyb3dzOyBkbyBub3Qgc2VyaWFsaXplIGV2ZXJ5IG1lc3NhZ2UgdHdpY2UuXG4gICAgICAgICAgICB0cnkgeyBKU09OLnN0cmluZ2lmeShtZXNzYWdlKTsgfSBjYXRjaCB7XG4gICAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBbJHtsYWJlbH1dIElQQyBtZXNzYWdlIGlzIG5vdCBKU09OIHNlcmlhbGl6YWJsZWApO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZmFpbENvbm5lY3Rpb24oZXJyb3IgaW5zdGFuY2VvZiBFcnJvciA/IGVycm9yIDogbmV3IEVycm9yKFN0cmluZyhlcnJvcikpKTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIGZ1bmN0aW9uIGZhaWxDb25uZWN0aW9uKGVycm9yOiBFcnJvcik6IHZvaWQge1xuICAgICAgICBjbG9zZShlcnJvcik7XG4gICAgICAgIC8vIExvZ2ljYWwgY2xvc3VyZSBhbG9uZSBsZWF2ZXMgdGhlIHBlZXIgd2FpdGluZyBmb3JldmVyLiBUaGUgcGh5c2ljYWxcbiAgICAgICAgLy8gZGlzY29ubmVjdCBhbHNvIHJlYWNoZXMgdGhlIFNlcnZpY2UgbGlmZWN5Y2xlIGFuZCBSZWdpc3RyeSBzdXBlcnZpc2lvbi5cbiAgICAgICAgdHJ5IHsgb3B0cy5kaXNjb25uZWN0KCk7IH0gY2F0Y2ggeyAvKiB0aGUgY2hhbm5lbCBtYXkgYWxyZWFkeSBiZSBjbG9zZWQgKi8gfVxuICAgIH1cblxuICAgIGNvbnN0IGxpc3RlbmVyID0gYXN5bmMgKHJhdzogdW5rbm93bik6IFByb21pc2U8dm9pZD4gPT4ge1xuICAgICAgICBpZiAoY2xvc2VkKSB7IHJldHVybjsgfVxuICAgICAgICBpZiAoIWlzV2lyZU1lc3NhZ2UocmF3KSkge3JldHVybjt9XG4gICAgICAgIGNvbnN0IG1zZyA9IHJhdztcblxuICAgICAgICAvLyBcdTI1MDBcdTI1MDBcdTI1MDAgXHU2NTM2XHU1MjMwXHU1QkY5XHU3QUVGXHU1M0QxXHU2NzY1XHU3Njg0IFJQQyBcdThCRjdcdTZDNDIgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG4gICAgICAgIGlmIChtc2cudHlwZSA9PT0gJ2ludm9rZTpyZXF1ZXN0JyAmJiBtc2cuY2hhbm5lbCAmJiBtc2cucmVxdWVzdElkKSB7XG4gICAgICAgICAgICBpZiAoIWFjY2VwdGluZ1JlcXVlc3RzKSB7XG4gICAgICAgICAgICAgICAgc2VuZCh7XG4gICAgICAgICAgICAgICAgICAgIHR5cGU6ICdpbnZva2U6cmVzcG9uc2UnLCByZXF1ZXN0SWQ6IG1zZy5yZXF1ZXN0SWQsXG4gICAgICAgICAgICAgICAgICAgIGVycm9yOiBzZXJpYWxpemVCcmlkZ2VFcnJvcihuZXcgRXJyb3IoYFske2xhYmVsfV0gc2h1dHRpbmcgZG93bmApKSxcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICAvLyBwZXItY2hhbm5lbCBcdTdDQkVcdTc4NkVcdTUzMzlcdTkxNERcdTRGMThcdTUxNDhcdUZGMENtaXNzIFx1OEQ3MFx1OTAxQVx1OTE0RCBoYW5kbGVyXHVGRjA4Y2F0Y2gtYWxsXHVGRjBDXHU0RjlCIHdiLmludm9rZSBcdTkwMDNcdTc1MUZcdTgyMzFcdUZGMDlcbiAgICAgICAgICAgIGNvbnN0IHBlckNoYW5uZWxIYW5kbGVyID0gcmVxdWVzdEhhbmRsZXJzLmdldChtc2cuY2hhbm5lbCk7XG4gICAgICAgICAgICBpZiAoIXBlckNoYW5uZWxIYW5kbGVyICYmICFhbnlIYW5kbGVyKSB7XG4gICAgICAgICAgICAgICAgc2VuZCh7XG4gICAgICAgICAgICAgICAgICAgIHR5cGU6ICdpbnZva2U6cmVzcG9uc2UnLFxuICAgICAgICAgICAgICAgICAgICByZXF1ZXN0SWQ6IG1zZy5yZXF1ZXN0SWQsXG4gICAgICAgICAgICAgICAgICAgIGVycm9yOiBzZXJpYWxpemVCcmlkZ2VFcnJvcihuZXcgRXJyb3IoXG4gICAgICAgICAgICAgICAgICAgICAgICBgWyR7bGFiZWx9XSBubyBoYW5kbGVyIGZvciBjaGFubmVsOiAke21zZy5jaGFubmVsfWAsXG4gICAgICAgICAgICAgICAgICAgICkpLFxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgLy8gV2lyZSBcdTUzNEZcdThCQUVcdUZGMUFgYXJnczogW2NvbnRleHQsIC4uLnVzZXJBcmdzXWBcdUZGMDhcdTg5QzFcdTRFMEJcdTY1QjkgaW52b2tlIGZuIFx1NzY4NCBzZW5kIFx1N0VEM1x1Njc4NFx1RkYwOVx1MzAwMlxuICAgICAgICAgICAgICAgIC8vIHBlci1jaGFubmVsOiBDaGFubmVsSGFuZGxlciA9IChjb250ZXh0LCAuLi5hcmdzKVxuICAgICAgICAgICAgICAgIC8vIGNhdGNoLWFsbDogUmVxdWVzdEhhbmRsZXIgPSAoY2hhbm5lbCwgY29udGV4dCwgLi4uYXJncykgXHUyMDE0XHUyMDE0IFx1NjExRlx1NzdFNSBjaGFubmVsIFx1NjI0RFx1ODBGRFx1NTA1QVx1NTI0RFx1N0YwMFx1OERFRlx1NzUzMVxuICAgICAgICAgICAgICAgIGNvbnN0IHJhd0FyZ3MgPSBtc2cuYXJncyA/PyBbXTtcbiAgICAgICAgICAgICAgICBjb25zdCBbY29udGV4dCwgLi4udXNlckFyZ3NdID0gcmF3QXJncztcbiAgICAgICAgICAgICAgICBjb25zdCByZXN1bHQgPSBwZXJDaGFubmVsSGFuZGxlclxuICAgICAgICAgICAgICAgICAgICA/IGF3YWl0IHBlckNoYW5uZWxIYW5kbGVyKGNvbnRleHQgYXMgSW52b2tlQ29udGV4dCB8IHVuZGVmaW5lZCwgLi4udXNlckFyZ3MpXG4gICAgICAgICAgICAgICAgICAgIDogYXdhaXQgYW55SGFuZGxlciEobXNnLmNoYW5uZWwsIGNvbnRleHQgYXMgSW52b2tlQ29udGV4dCB8IHVuZGVmaW5lZCwgLi4udXNlckFyZ3MpO1xuICAgICAgICAgICAgICAgIHNlbmQoeyB0eXBlOiAnaW52b2tlOnJlc3BvbnNlJywgcmVxdWVzdElkOiBtc2cucmVxdWVzdElkLCByZXN1bHQgfSk7XG4gICAgICAgICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgICAgICAgICBzZW5kKHtcbiAgICAgICAgICAgICAgICAgICAgdHlwZTogJ2ludm9rZTpyZXNwb25zZScsXG4gICAgICAgICAgICAgICAgICAgIHJlcXVlc3RJZDogbXNnLnJlcXVlc3RJZCxcbiAgICAgICAgICAgICAgICAgICAgZXJyb3I6IHNlcmlhbGl6ZUJyaWRnZUVycm9yKGVyciksXG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cblxuICAgICAgICAvLyBcdTI1MDBcdTI1MDBcdTI1MDAgXHU2NTM2XHU1MjMwXHU1QkY5XHU3QUVGXHU4RkQ0XHU1NkRFXHU3Njg0IFJQQyBcdTdFRDNcdTY3OUMgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG4gICAgICAgIGlmIChtc2cudHlwZSA9PT0gJ2ludm9rZTpyZXNwb25zZScgJiYgbXNnLnJlcXVlc3RJZCkge1xuICAgICAgICAgICAgY29uc3QgcCA9IHBlbmRpbmcuZ2V0KG1zZy5yZXF1ZXN0SWQpO1xuICAgICAgICAgICAgaWYgKCFwKSB7cmV0dXJuO31cbiAgICAgICAgICAgIHBlbmRpbmcuZGVsZXRlKG1zZy5yZXF1ZXN0SWQpO1xuICAgICAgICAgICAgaWYgKG1zZy5lcnJvciAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGlzU2VyaWFsaXplZEJyaWRnZUVycm9yKG1zZy5lcnJvcikpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGRlc2VyaWFsaXplUmVzdWx0KG1zZy5lcnJvcik7IC8vIFx1NkMzOFx1OEZEQ1x1NjI5QlxuICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKFN0cmluZyhtc2cuZXJyb3IpKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICAgICAgICAgICAgICBwLnJlamVjdChlcnIgYXMgRXJyb3IpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgcC5yZXNvbHZlKG1zZy5yZXN1bHQpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG5cbiAgICAgICAgLy8gXHUyNTAwXHUyNTAwXHUyNTAwIFx1NjUzNlx1NTIzMFx1NUJGOVx1N0FFRlx1NjNBOFx1OTAwMVx1NzY4NFx1NEU4Qlx1NEVGNiBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcbiAgICAgICAgaWYgKG1zZy50eXBlID09PSAnZXZlbnQnICYmIG1zZy5ldmVudCkge1xuICAgICAgICAgICAgZXZlbnRIYW5kbGVyPy4obXNnLmV2ZW50LCBtc2cucGF5bG9hZCk7XG4gICAgICAgIH1cbiAgICB9O1xuXG4gICAgZGV0YWNoID0gb25NZXNzYWdlKGxpc3RlbmVyKTtcbiAgICBkZXRhY2hDbG9zZSA9IG9wdHMub25DbG9zZShlcnJvciA9PiBjbG9zZShlcnJvciA/PyBuZXcgRXJyb3IoYFske2xhYmVsfV0gZGlzY29ubmVjdGVkYCkpKTtcblxuICAgIGZ1bmN0aW9uIGludm9rZShjaGFubmVsOiBzdHJpbmcsIGNvbnRleHQ6IEludm9rZUNvbnRleHQgfCB1bmRlZmluZWQsIC4uLmFyZ3M6IHVua25vd25bXSk6IFByb21pc2U8dW5rbm93bj4ge1xuICAgICAgICBpZiAoY2xvc2VkKSB7IHJldHVybiBQcm9taXNlLnJlamVjdCh0cmFuc3BvcnRDbG9zZWQoY2xvc2VkLCAnbm90LXNlbnQnKSk7IH1cbiAgICAgICAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IHJlcXVlc3RJZCA9IGAke2xhYmVsfV9yZXFfJHsrK3JlcXVlc3RDb3VudGVyfWA7XG4gICAgICAgICAgICBwZW5kaW5nLnNldChyZXF1ZXN0SWQsIHsgcmVzb2x2ZSwgcmVqZWN0LCBkZWxpdmVyeTogJ25vdC1zZW50JyB9KTtcbiAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgc2VuZCh7XG4gICAgICAgICAgICAgICAgICAgIHR5cGU6ICdpbnZva2U6cmVxdWVzdCcsXG4gICAgICAgICAgICAgICAgICAgIHJlcXVlc3RJZCxcbiAgICAgICAgICAgICAgICAgICAgY2hhbm5lbCxcbiAgICAgICAgICAgICAgICAgICAgYXJnczogW2NvbnRleHQsIC4uLmFyZ3NdLFxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgICAgICAgICAgcGVuZGluZy5kZWxldGUocmVxdWVzdElkKTtcbiAgICAgICAgICAgICAgICByZWplY3QoZXJyIGluc3RhbmNlb2YgRXJyb3IgPyBlcnIgOiBuZXcgRXJyb3IoU3RyaW5nKGVycikpKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgcmV0dXJuIHtcbiAgICAgICAgc3RvcEFjY2VwdGluZ1JlcXVlc3RzKCk6IHZvaWQgeyBhY2NlcHRpbmdSZXF1ZXN0cyA9IGZhbHNlOyB9LFxuICAgICAgICBoYW5kbGUoY2hhbm5lbDogc3RyaW5nLCBoYW5kbGVyOiBDaGFubmVsSGFuZGxlcik6IHZvaWQge1xuICAgICAgICAgICAgcmVxdWVzdEhhbmRsZXJzLnNldChjaGFubmVsLCBoYW5kbGVyKTtcbiAgICAgICAgfSxcblxuICAgICAgICAvKipcbiAgICAgICAgICogXHU2MzAyXHU5MDFBXHU5MTREIGhhbmRsZXIgXHUyMDE0XHUyMDE0IFx1NEY5QiBicmlkZ2UtaG9zdCBcdTUwNUEgY2F0Y2gtYWxsIFx1NTI0RFx1N0YwMFx1OERFRlx1NzUzMVx1RkYwOHdiLmludm9rZSBcdTkwMDNcdTc1MUZcdTgyMzFcdUZGMDlcdTMwMDJcbiAgICAgICAgICogcGVyLWNoYW5uZWwgXHU3Q0JFXHU3ODZFXHU1MzM5XHU5MTREXHU0RjE4XHU1MTQ4XHVGRjBDbWlzcyBcdTYyNERcdThENzBcdTkwMUFcdTkxNERcdTMwMDJcdTU5MUFcdTZCMjFcdThDMDNcdTc1MjhcdTU0MEVcdTRFMDBcdTZCMjFcdTg5ODZcdTc2RDZcdTUyNERcdTRFMDBcdTZCMjFcdTMwMDJcbiAgICAgICAgICovXG4gICAgICAgIGhhbmRsZUFueShoYW5kbGVyOiBSZXF1ZXN0SGFuZGxlcik6IHZvaWQge1xuICAgICAgICAgICAgYW55SGFuZGxlciA9IGhhbmRsZXI7XG4gICAgICAgIH0sXG5cbiAgICAgICAgYnJvYWRjYXN0KGV2ZW50OiBzdHJpbmcsIHBheWxvYWQ6IHVua25vd24pOiB2b2lkIHtcbiAgICAgICAgICAgIHNlbmQoeyB0eXBlOiAnZXZlbnQnLCBldmVudCwgcGF5bG9hZCB9KTtcbiAgICAgICAgfSxcblxuICAgICAgICBpbnZva2UsXG5cbiAgICAgICAgb24oaGFuZGxlcjogRXZlbnRIYW5kbGVyKTogdm9pZCB7XG4gICAgICAgICAgICBldmVudEhhbmRsZXIgPSBoYW5kbGVyO1xuICAgICAgICB9LFxuXG4gICAgICAgIGRpc3Bvc2U6IGNsb3NlLFxuICAgIH07XG59XG5cbi8vIFx1MjUwMFx1MjUwMFx1MjUwMCBcdTcyMzZcdThGREJcdTdBMEJcdTRGQTdcdUZGMUFIb3N0IFRyYW5zcG9ydCBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblxuZXhwb3J0IGludGVyZmFjZSBQcm9jZXNzSG9zdFRyYW5zcG9ydE9wdGlvbnMge1xuICAgIC8qKiBmb3JrIFx1NTFGQVx1NzY4NFx1NUI1MFx1OEZEQlx1N0EwQlx1NUYxNVx1NzUyOCAqL1xuICAgIGNoaWxkOiBDaGlsZFByb2Nlc3M7XG59XG5cbi8qKlxuICogXHU3MjM2XHU4RkRCXHU3QTBCXHU0RkE3IFRyYW5zcG9ydCBcdTIwMTRcdTIwMTQgXHU1QjlFXHU3M0IwXHU1QjhDXHU2NTc0XHU3Njg0XHU1NkRCXHU0RUY2XHU1OTU3IGBoYW5kbGUgLyBicm9hZGNhc3QgLyBpbnZva2UgLyBvbiAvIGRpc3Bvc2VgXHUzMDAyXG4gKlxuICogXHU0RjdGXHU3NTI4XHU2NUI5XHU1RjBGXHVGRjFBXG4gKiBgYGB0c1xuICogY29uc3QgdHJhbnNwb3J0ID0gY3JlYXRlUHJvY2Vzc0hvc3RUcmFuc3BvcnQoeyBjaGlsZCB9KTtcbiAqIC8vIEhvc3QgXHU2NTM2IGV4dGVuc2lvbiBcdTUzRDFcdTY3NjVcdTc2ODRcdThCRjdcdTZDNDJcbiAqIHRyYW5zcG9ydC5oYW5kbGUobWV0aG9kQ2hhbm5lbC5pbnZva2UpO1xuICogLy8gSG9zdCBcdTYzQThcdTkwMDFcdTRFOEJcdTRFRjZcdTdFRDkgZXh0ZW5zaW9uXG4gKiBidXMub25BbnkoKGV2ZW50LCBwYXlsb2FkKSA9PiB0cmFuc3BvcnQuYnJvYWRjYXN0KGV2ZW50LCBwYXlsb2FkKSk7XG4gKiAvLyBIb3N0IFx1NTNDRFx1NTQxMVx1OEMwMyBleHRlbnNpb24gXHU2Q0U4XHU1MThDXHU3Njg0IG1ldGhvZFxuICogYXdhaXQgdHJhbnNwb3J0Lmludm9rZSgnZ3JlZXQnLCB1bmRlZmluZWQsIHsgbmFtZTogJ1dvcmxkJyB9KTtcbiAqIGBgYFxuICovXG5leHBvcnQgZnVuY3Rpb24gY3JlYXRlUHJvY2Vzc0hvc3RUcmFuc3BvcnQob3B0aW9uczogUHJvY2Vzc0hvc3RUcmFuc3BvcnRPcHRpb25zKTogUHJvY2Vzc1RyYW5zcG9ydCB7XG4gICAgY29uc3QgeyBjaGlsZCB9ID0gb3B0aW9ucztcbiAgICByZXR1cm4gY3JlYXRlUnBjU2lkZSh7XG4gICAgICAgIGxhYmVsOiAnUHJvY2Vzc0hvc3RUcmFuc3BvcnQnLFxuICAgICAgICBpc0Nvbm5lY3RlZDogKCkgPT4gY2hpbGQuY29ubmVjdGVkLFxuICAgICAgICBzZW5kOiAobXNnLCBjYWxsYmFjaykgPT4ge1xuICAgICAgICAgICAgY2hpbGQuc2VuZChtc2csIGNhbGxiYWNrKTtcbiAgICAgICAgfSxcbiAgICAgICAgZGlzY29ubmVjdDogKCkgPT4geyBpZiAoY2hpbGQuY29ubmVjdGVkKSB7IGNoaWxkLmRpc2Nvbm5lY3QoKTsgfSB9LFxuICAgICAgICBvbkNsb3NlOiBsaXN0ZW5lciA9PiB7XG4gICAgICAgICAgICBjb25zdCBvbkV4aXQgPSAoKTogdm9pZCA9PiBsaXN0ZW5lcihuZXcgRXJyb3IoJ1tQcm9jZXNzSG9zdFRyYW5zcG9ydF0gcHJvY2VzcyBleGl0ZWQnKSk7XG4gICAgICAgICAgICBjaGlsZC5vbignZGlzY29ubmVjdCcsIGxpc3RlbmVyKTtcbiAgICAgICAgICAgIGNoaWxkLm9uKCdlcnJvcicsIGxpc3RlbmVyKTtcbiAgICAgICAgICAgIGNoaWxkLm9uKCdleGl0Jywgb25FeGl0KTtcbiAgICAgICAgICAgIHJldHVybiAoKSA9PiB7XG4gICAgICAgICAgICAgICAgY2hpbGQub2ZmKCdkaXNjb25uZWN0JywgbGlzdGVuZXIpO1xuICAgICAgICAgICAgICAgIGNoaWxkLm9mZignZXJyb3InLCBsaXN0ZW5lcik7XG4gICAgICAgICAgICAgICAgY2hpbGQub2ZmKCdleGl0Jywgb25FeGl0KTtcbiAgICAgICAgICAgIH07XG4gICAgICAgIH0sXG4gICAgICAgIG9uTWVzc2FnZTogbGlzdGVuZXIgPT4ge1xuICAgICAgICAgICAgY2hpbGQub24oJ21lc3NhZ2UnLCBsaXN0ZW5lcik7XG4gICAgICAgICAgICByZXR1cm4gKCkgPT4gY2hpbGQub2ZmKCdtZXNzYWdlJywgbGlzdGVuZXIpO1xuICAgICAgICB9LFxuICAgIH0pO1xufVxuXG4vLyBcdTI1MDBcdTI1MDBcdTI1MDAgXHU1QjUwXHU4RkRCXHU3QTBCXHU0RkE3XHVGRjFBQ2xpZW50IFRyYW5zcG9ydCBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblxuLyoqXG4gKiBcdTVCNTBcdThGREJcdTdBMEJcdTRGQTcgVHJhbnNwb3J0IFx1MjAxNFx1MjAxNCBcdTU0MENcdTY4MzdcdTVCOUVcdTczQjBcdTVCOENcdTY1NzRcdTU2REJcdTRFRjZcdTU5NTdcdTMwMDJcbiAqXG4gKiBcdTRGN0ZcdTc1MjhcdTY1QjlcdTVGMEZcdUZGMDhleHRlbnNpb24gXHU1QjUwXHU4RkRCXHU3QTBCXHU1MTY1XHU1M0UzXHVGRjA5XHVGRjFBXG4gKiBgYGB0c1xuICogY29uc3QgdHJhbnNwb3J0ID0gY3JlYXRlUHJvY2Vzc0NsaWVudFRyYW5zcG9ydCgpO1xuICogLy8gQ2xpZW50IFx1NjUzNlx1NzIzNlx1OEZEQlx1N0EwQlx1NTNDRFx1NTQxMVx1OEMwM1x1NzUyOFx1RkYwOGV4dGVuc2lvbiBcdTgxRUFcdTVERjFcdTZDRThcdTUxOENcdTc2ODQgbWV0aG9kc1x1RkYwOVxuICogdHJhbnNwb3J0LmhhbmRsZShhc3luYyAoY2hhbm5lbCwgY3R4LCAuLi5hcmdzKSA9PiBtZXRob2RNYXBbY2hhbm5lbF0/LiguLi5hcmdzKSk7XG4gKiAvLyBDbGllbnQgXHU2RDg4XHU4RDM5XHU3MjM2XHU4RkRCXHU3QTBCIGJ1cyBcdTRFOEJcdTRFRjZcbiAqIHRyYW5zcG9ydC5vbigoZXZlbnQsIHBheWxvYWQpID0+IGxvY2FsQnVzLmVtaXQoZXZlbnQsIHBheWxvYWQpKTtcbiAqIC8vIENsaWVudCBcdThDMDNcdTVCQkZcdTRFM0JcdTgwRkRcdTUyOUJcbiAqIGNvbnN0IHdiID0gY3JlYXRlR3Vlc3RQcm94eSgnaHR0cCcsIHRyYW5zcG9ydC5pbnZva2UpO1xuICogYGBgXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBjcmVhdGVQcm9jZXNzQ2xpZW50VHJhbnNwb3J0KCk6IFByb2Nlc3NUcmFuc3BvcnQge1xuICAgIHJldHVybiBjcmVhdGVScGNTaWRlKHtcbiAgICAgICAgbGFiZWw6ICdQcm9jZXNzQ2xpZW50VHJhbnNwb3J0JyxcbiAgICAgICAgaXNDb25uZWN0ZWQ6ICgpID0+ICEhcHJvY2Vzcy5jb25uZWN0ZWQgJiYgISFwcm9jZXNzLnNlbmQsXG4gICAgICAgIHNlbmQ6IChtc2csIGNhbGxiYWNrKSA9PiB7XG4gICAgICAgICAgICBwcm9jZXNzLnNlbmQhKG1zZywgY2FsbGJhY2spO1xuICAgICAgICB9LFxuICAgICAgICBkaXNjb25uZWN0OiAoKSA9PiB7IGlmIChwcm9jZXNzLmNvbm5lY3RlZCkgeyBwcm9jZXNzLmRpc2Nvbm5lY3Q/LigpOyB9IH0sXG4gICAgICAgIG9uQ2xvc2U6IGxpc3RlbmVyID0+IHtcbiAgICAgICAgICAgIHByb2Nlc3Mub24oJ2Rpc2Nvbm5lY3QnLCBsaXN0ZW5lcik7XG4gICAgICAgICAgICByZXR1cm4gKCkgPT4gcHJvY2Vzcy5vZmYoJ2Rpc2Nvbm5lY3QnLCBsaXN0ZW5lcik7XG4gICAgICAgIH0sXG4gICAgICAgIG9uTWVzc2FnZTogbGlzdGVuZXIgPT4ge1xuICAgICAgICAgICAgcHJvY2Vzcy5vbignbWVzc2FnZScsIGxpc3RlbmVyKTtcbiAgICAgICAgICAgIHJldHVybiAoKSA9PiBwcm9jZXNzLm9mZignbWVzc2FnZScsIGxpc3RlbmVyKTtcbiAgICAgICAgfSxcbiAgICB9KTtcbn1cblxuLy8gXHUyNTAwXHUyNTAwXHUyNTAwIFx1OEY4NVx1NTJBOSBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblxuZnVuY3Rpb24gaXNXaXJlTWVzc2FnZShtc2c6IHVua25vd24pOiBtc2cgaXMgSXBjV2lyZU1lc3NhZ2Uge1xuICAgIHJldHVybiAoXG4gICAgICAgIG1zZyAhPT0gbnVsbFxuICAgICAgICAmJiB0eXBlb2YgbXNnID09PSAnb2JqZWN0J1xuICAgICAgICAmJiAndHlwZScgaW4gbXNnXG4gICAgICAgICYmIHR5cGVvZiAobXNnIGFzIHsgdHlwZTogdW5rbm93biB9KS50eXBlID09PSAnc3RyaW5nJ1xuICAgICk7XG59XG4iLCAiLyoqXG4gKiBgcHJvY2Vzc2AgXHU1QkI5XHU1NjY4IGVudiBcdTVCOUVcdTczQjAgXHUyMDE0XHUyMDE0IFx1NUY1M1x1NTI0RFx1NTUyRlx1NEUwMFx1NUI5RVx1OTY0NVx1NEY3Rlx1NzUyOFx1NzY4NFx1NkEyMVx1NUYwRlx1RkYwOFx1NkJDRlx1NEUyQSBleHRlbnNpb24gXHU3MkVDXHU3QUNCIGZvcmsgXHU1QjUwXHU4RkRCXHU3QTBCXHVGRjA5XHUzMDAyXG4gKlxuICogXHUyNTAwXHUyNTAwIFx1NTk1MVx1N0VBNiBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcbiAqXG4gKiBcdTZFRTFcdThEQjMgYEV4dGVuc2lvblJ1bnRpbWVFbnZgXHUzMDAyXHU4RERGXHU1MTg1XHU2ODM4IGBydW5FeHRlbnNpb25gIFx1N0VDNFx1NTQwOFx1OEQ3N1x1Njc2NVx1RkYwQ1x1N0I0OVx1NEVGN1x1NEU4RVx1NTM5Rlx1Njc2NVx1NzY4NFxuICogXHU4MDAxIGBib290c3RyYXBgIFx1NUI5RVx1NzNCMFx1RkYwQ1x1NEY0NioqXHU5MDNCXHU4RjkxXHU4OEFCXHU1MjA3XHU2MjEwXHU0RTI0XHU1QzQyKipcdUZGMUFcbiAqIC0gXHU1QkI5XHU1NjY4XHU1REVFXHU1RjAyXHVGRjA4XHU2MDBFXHU0RTQ4XHU1RUZBIHRyYW5zcG9ydFx1MzAwMVx1NEY1NVx1NjVGNiBzaHV0ZG93blx1MzAwMVx1NjAwRVx1NEU0OCByZWFkeVx1RkYwOVx1NTcyOFx1OEZEOVx1OTFDQ1xuICogLSBcdTkwMUFcdTc1MjhcdTg4QzVcdTkxNERcdUZGMDhcdTkwMjAgd2JcdTMwMDFcdThERDEgYWN0aXZhdGVcdTMwMDFcdTYzMDIgbWV0aG9kXHVGRjA5XHU1NzI4IGBydW5FeHRlbnNpb25gIFx1NTE4NVx1NjgzOFxuICpcbiAqIFx1MjUwMFx1MjUwMCBcdTg5RTZcdTUzRDFcdTY1RjZcdTY3M0FcdTY2MjBcdTVDMDQgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG4gKlxuICogfCBlbnYgXHU1OTUxXHU3RUE2XHU3MEI5ICAgICB8IGZvcmsgXHU1QjUwXHU4RkRCXHU3QTBCXHU5MUNDXHU3Njg0XHU3MjY5XHU3NDA2XHU1QjlFXHU3M0IwICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHxcbiAqIHwtLS0tLS0tLS0tLS0tLS0tfC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS18XG4gKiB8IGBvblNodXRkb3duYCAgIHwgYHByb2Nlc3Mub24oJ1NJR1RFUk0nLCAuLi4pYCArIGBwcm9jZXNzLm9uY2UoJ2Rpc2Nvbm5lY3QnLCAuLi4pYCAgICAgfFxuICogfCBgc2lnbmFsUmVhZHlgICB8IGBwcm9jZXNzLnNlbmQoeyB0eXBlOiAnd2ItZXh0ZW5zaW9uLXJlYWR5JywgZXh0ZW5zaW9uSWQsIHBpZCB9KWAgICAgIHxcbiAqIHwgYHRlcm1pbmF0ZWAgICAgfCBgcHJvY2Vzcy5leGl0KDApYCAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB8XG4gKlxuICogYGRpc2Nvbm5lY3RgIFx1NjYyRlwiXHU3MjM2IGRhZW1vbiBcdTc2ODQgSVBDIFx1OTAxQVx1OTA1M1x1NjVBRFx1NUYwMFwiXHUyMDE0XHUyMDE0IFx1NzIzNlx1NUQyOVx1NkU4M1x1NjIxNlx1NEUzQlx1NTJBOCBkaXNjb25uZWN0IFx1NjVGNlx1ODlFNlx1NTNEMVx1RkYwQ1xuICogXHU5MDdGXHU1MTREXHU5MDU3XHU3NTU5XHU1QjY0XHU1MTNGIGV4dGVuc2lvbiBcdTVCNTBcdThGREJcdTdBMEJcdTMwMDJTSUdURVJNIFx1NjYyRiBob3N0LW1hbmFnZXIgXHU3Njg0IGdyYWNlZnVsIHNodXRkb3duIFx1OERFRlx1NUY4NFx1MzAwMlxuICogXHU0RTI0XHU2NzYxXHU4REVGXHU1Rjg0XHU5MEZEXHU4OUU2XHU1M0QxIHNodXRkb3duXHVGRjBDYHJ1bkV4dGVuc2lvbmAgXHU1MTg1XHU5MEU4XHU3Njg0XHU1RTQyXHU3QjQ5XHU0RkREXHU2MkE0XHU0RjFBXHU0RkREXHU4QkMxIHVzZXIgZGlzcG9zZSBcdTUzRUFcdThERDFcdTRFMDBcdTZCMjFcdTMwMDJcbiAqL1xuXG5pbXBvcnQgeyBjcmVhdGVQcm9jZXNzQ2xpZW50VHJhbnNwb3J0IH0gZnJvbSAnLi4vLi4vYnJpZGdlL3RyYW5zcG9ydC1wcm9jZXNzJztcbmltcG9ydCB0eXBlIHsgRXh0ZW5zaW9uUnVudGltZUVudiB9IGZyb20gJy4vcnVuLWV4dGVuc2lvbic7XG5cbi8qKlxuICogXHU1MjFCXHU1RUZBIGBwcm9jZXNzYCBcdTZBMjFcdTVGMEZcdTc2ODQgZW52IFx1MjAxNFx1MjAxNCBcdTRGOUIgZm9yayBcdTVCNTBcdThGREJcdTdBMEJcdThDMDNcdTc1MjhcdTRFMDBcdTZCMjFcdTMwMDJcbiAqXG4gKiBcdTU5MERcdTc1MjhcdTczQjBcdTY3MDkgYGNyZWF0ZVByb2Nlc3NDbGllbnRUcmFuc3BvcnRgXHVGRjA4YGJyaWRnZS90cmFuc3BvcnQtcHJvY2Vzcy50c2BcdUZGMDlcdTIwMTRcdTIwMTQgXHU1REYyXHU3RUNGXHU2NjJGXG4gKiBcdTdBMzNcdTVCOUFcdTc2ODQgYHByb2Nlc3Muc2VuZGAgLyBgcHJvY2Vzcy5vbignbWVzc2FnZScpYCBcdTVDMDFcdTg4QzVcdUZGMENcdTU0MDRcdTc5Q0Qgd2lyZSBcdThCRURcdTRFNDkgLyBcdTk1MTlcdThCRUZcdTU5MDRcdTc0MDZcbiAqIFx1OTBGRFx1NTcyOFx1OTFDQ1x1OTc2Mlx1RkYwQ1x1NjcyQ1x1NjU4N1x1NEVGNlx1NEUwRFx1OTFDRFx1NTkwRFx1MzAwMlxuICovXG5leHBvcnQgZnVuY3Rpb24gY3JlYXRlUHJvY2Vzc0VudigpOiBFeHRlbnNpb25SdW50aW1lRW52IHtcbiAgICBjb25zdCB0cmFuc3BvcnQgPSBjcmVhdGVQcm9jZXNzQ2xpZW50VHJhbnNwb3J0KCk7XG5cbiAgICBjb25zdCBzaHV0ZG93bkhvb2tzOiBBcnJheTwoKSA9PiB2b2lkIHwgUHJvbWlzZTx2b2lkPj4gPSBbXTtcbiAgICBsZXQgc2h1dGRvd25UcmlnZ2VyZWQgPSBmYWxzZTtcblxuICAgIC8qKiBcdTg5RTZcdTUzRDEgc2h1dGRvd24gaG9va3MgXHUyMDE0XHUyMDE0IFx1NUU0Mlx1N0I0OVx1RkYxQlx1OEZENFx1NTZERSBQcm9taXNlIFx1NEY5QiBzaWduYWwgaGFuZGxlciBcdThGRkRcdThFMkFcdTMwMDIgKi9cbiAgICBjb25zdCBydW5TaHV0ZG93biA9IGFzeW5jICgpOiBQcm9taXNlPHZvaWQ+ID0+IHtcbiAgICAgICAgaWYgKHNodXRkb3duVHJpZ2dlcmVkKSB7IHJldHVybjsgfVxuICAgICAgICBzaHV0ZG93blRyaWdnZXJlZCA9IHRydWU7XG4gICAgICAgIC8vIFx1NjMwOVx1NkNFOFx1NTE4Q1x1OTg3QVx1NUU4Rlx1NEY5RFx1NkIyMSBhd2FpdFx1RkYwQ1x1NEZERFx1OEJDMSB1c2VyIGRpc3Bvc2UgXHU1MTQ4XHU4REQxXHUzMDAxdHJhbnNwb3J0IFx1NTQwRVx1NjJDNlx1MzAwMlxuICAgICAgICAvLyBydW5FeHRlbnNpb24gXHU1MTg1XHU2ODM4XHU1M0VBXHU2MzAyXHU0RTAwXHU0RTJBIGhvb2tcdUZGMENcdTRGNDZcdThCQkVcdThCQTFcdTRFMEFcdTUxNDFcdThCQjhcdTU5MUFcdTRFMkEgXHUyMDE0XHUyMDE0IFx1NjcyQVx1Njc2NSBodWItc2lkZVxuICAgICAgICAvLyBcdTg4QzVcdTkxNERcdTVDNDJcdTUzRUZcdTgwRkRcdThGRkRcdTUyQTBcdTk4OURcdTU5MTZcdTZFMDVcdTc0MDZcdUZGMDhcdTU5ODIgZmx1c2ggXHU1N0NCXHU3MEI5XHUzMDAxXHU1M0QxXHU0RTBCXHU3RUJGXHU0RkUxXHU1M0Y3XHVGRjA5XHUzMDAyXG4gICAgICAgIGZvciAoY29uc3QgZm4gb2Ygc2h1dGRvd25Ib29rcykge1xuICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICBhd2FpdCBmbigpO1xuICAgICAgICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcignW1Byb2Nlc3NFbnZdIHNodXRkb3duIGhvb2sgZXJyb3I6JywgZXJyKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH07XG5cbiAgICAvLyBTSUdURVJNIFx1MjAxNFx1MjAxNCBob3N0LW1hbmFnZXIgXHU3Njg0IGdyYWNlZnVsIHNodXRkb3duIFx1OERFRlx1NUY4NFx1RkYwOGBjaGlsZC5raWxsKCdTSUdURVJNJylgXHVGRjA5XHUzMDAyXG4gICAgLy8gM3MgXHU1NDBFIGhvc3QtbWFuYWdlciBcdTRGMUFcdTUxNUNcdTVFOTUgU0lHS0lMTFx1RkYwQ1x1NjI0MFx1NEVFNSB1c2VyIGRpc3Bvc2UgXHU1RkM1XHU5ODdCXHU1QzNEXHU1RkVCXHU4REQxXHU1QjhDXHUzMDAyXG4gICAgLy9cbiAgICAvLyBcdTc1MjggYC50aGVuKG5vb3AsIG5vb3ApYCBcdTZEODhcdTUzMTYgUHJvbWlzZSBcdThGRDRcdTU2REVcdTUwM0NcdUZGMUFzaWduYWwgaGFuZGxlciBcdTY2MkZcdTU0MENcdTZCNjVcdThCRURcdTRFNDlcdUZGMENcbiAgICAvLyBzaHV0ZG93biBcdTY2MkYgYXN5bmMgXHU0RjQ2XHU0RTBEIGF3YWl0XHVGRjFCXHU5NTE5XHU4QkVGXHU1REYyXHU1NzI4IHJ1blNodXRkb3duIFx1NTE4NVx1OTBFOFx1OTAxMFx1Njc2MSBjYXRjaFx1RkYwQ1x1NkI2NFx1NTkwNFx1NTNFQVx1OTcwMFxuICAgIC8vIFx1NjMwMlx1NEUwMFx1NEUyQSBuby1vcCBcdTkwN0ZcdTUxNEQgZXNsaW50IGBuby12b2lkYCAvIHVuaGFuZGxlZCByZWplY3Rpb25cdTMwMDJcbiAgICBjb25zdCBub29wID0gKCk6IHZvaWQgPT4geyAvKiBpbnRlbnRpb25hbGx5IGVtcHR5ICovIH07XG4gICAgcHJvY2Vzcy5vbignU0lHVEVSTScsICgpID0+IHsgcnVuU2h1dGRvd24oKS50aGVuKG5vb3AsIG5vb3ApOyB9KTtcblxuICAgIC8vIGRpc2Nvbm5lY3QgXHUyMDE0XHUyMDE0IFx1NzIzNiBkYWVtb24gSVBDIFx1OTAxQVx1OTA1M1x1NjVBRFx1NUYwMFx1RkYwOFx1NzIzNlx1NUQyOVx1NkU4M1x1NjIxNiBkaXNjb25uZWN0IFx1NjYzRVx1NUYwRlx1OEMwM1x1RkYwOVx1MzAwMlxuICAgIC8vIFx1NEUwRFx1NTkwNFx1NzQwNlx1NEYxQVx1OTA1N1x1NzU1OVx1NUI2NFx1NTEzRiBleHRlbnNpb24gXHU1QjUwXHU4RkRCXHU3QTBCXHU1MzYwXHU1MTg1XHU1QjU4IFx1MjAxNFx1MjAxNCBcdThGRDlcdTY3NjFcdTkwMUFcdTkwNTNcdTY1QURcdTRFODYgZXh0ZW5zaW9uIFx1NEU1Rlx1NkNBMVx1NjEwRlx1NEU0OVx1MzAwMlxuICAgIHByb2Nlc3Mub25jZSgnZGlzY29ubmVjdCcsICgpID0+IHsgcnVuU2h1dGRvd24oKS50aGVuKG5vb3AsIG5vb3ApOyB9KTtcblxuICAgIGNvbnN0IGV4dGVuc2lvbklkID0gcHJvY2Vzcy5lbnYuV0JfRVhURU5TSU9OX0lEID8/ICc8dW5rbm93bj4nO1xuICAgIGxldCByZWFkeVNlbnQgPSBmYWxzZTtcblxuICAgIHJldHVybiB7XG4gICAgICAgIGtpbmQ6ICdwcm9jZXNzJyxcbiAgICAgICAgdHJhbnNwb3J0LFxuXG4gICAgICAgIG9uU2h1dGRvd24oZm4pIHtcbiAgICAgICAgICAgIHNodXRkb3duSG9va3MucHVzaChmbik7XG4gICAgICAgIH0sXG5cbiAgICAgICAgc2lnbmFsUmVhZHkoKSB7XG4gICAgICAgICAgICBpZiAocmVhZHlTZW50KSB7IHJldHVybjsgfVxuICAgICAgICAgICAgcmVhZHlTZW50ID0gdHJ1ZTtcbiAgICAgICAgICAgIC8vIFx1MjUwMFx1MjUwMFx1MjUwMCBSZWFkeSBcdTRGRTFcdTUzRjcgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG4gICAgICAgICAgICAvL1xuICAgICAgICAgICAgLy8gXHU4RDcwIElQQyBgY2hpbGQuc2VuZCh7IHR5cGU6ICd3Yi1leHRlbnNpb24tcmVhZHknIH0pYCBcdTkwMUFcdTc3RTVcdTVCQkZcdTRFM0JcdUZGMUFcbiAgICAgICAgICAgIC8vIC0gYHRyYW5zcG9ydC5oYW5kbGUoLi4uKWAgXHU1REYyXHU2Q0U4XHU1MThDXHU1OTdEXHVGRjA4XHU1NDI2XHU1MjE5XHU1QkJGXHU0RTNCXHU1M0QxXHU4RkM3XHU2NzY1XHU3Njg0IGludm9rZSBcdTRGMUFcdTYyRkZcdTUyMzBcbiAgICAgICAgICAgIC8vICAgXCJubyByZXF1ZXN0IGhhbmRsZXJcIlx1RkYwOVxuICAgICAgICAgICAgLy8gLSBgYWN0aXZhdGUoKWAgXHU1REYyXHU4REQxXHU1QjhDXHVGRjA4XHU3NTI4XHU2MjM3IGRpc3Bvc2UgXHU1REYyXHU2Q0U4XHU1MThDXHVGRjBDZW1pdCBcdTRFOEJcdTRFRjZcdThERUZcdTVGODRcdTVERjJcdTkwMUFcdUZGMDlcbiAgICAgICAgICAgIC8vXG4gICAgICAgICAgICAvLyBcdTVCQkZcdTRFM0IgaG9zdC1tYW5hZ2VyIFx1NjUzNlx1NTIzMFx1OEZEOVx1NEUyQVx1NEZFMVx1NTNGN1x1NTQwRVx1NjI0RFx1NTIwNyByZWdpc3RyeS5zdGF0ZT0nYWN0aXZlJyBcdTVFNzZcbiAgICAgICAgICAgIC8vIGVtaXQgYGV4dGVuc2lvbi5saWZlY3ljbGU6IGFjdGl2ZWBcdTMwMDJSYWNlIFx1NEZERFx1NjJBNFx1RkYxQWZvcmsgXHU1QjhDXHU0RjQ2XHU1QjUwXHU4RkRCXHU3QTBCXG4gICAgICAgICAgICAvLyBcdThGRDhcdTU3MjggaGFuZGxlciBcdTZDRThcdTUxOENcdTUyNERcdTc2ODRcdThGRDlcdTRFMkFcdTdBOTdcdTUzRTNcdTUxODVcdUZGMENgd2IuZXh0ZW5zaW9ucy5pbnZva2VgIFx1NEYxQVx1OEQ3MCBodWIgXHU3Njg0XG4gICAgICAgICAgICAvLyBsYXp5IGFjdGl2YXRlIFx1NTIwNlx1NjUyRlx1RkYwQ1x1ODhBQiBgYXdhaXQgaGFuZGxlLnJlYWR5YCBcdTk2M0JcdTU4NUVcdTc2RjRcdTUyMzAgaGFuZGxlciBcdTVDMzFcdTdFRUFcdTMwMDJcbiAgICAgICAgICAgIC8vXG4gICAgICAgICAgICAvLyBcdTY1RTAgSVBDIGNoYW5uZWwgXHU2NUY2XHVGRjA4XHU2QkQ0XHU1OTgyXHU2NzJBXHU2NzY1IHRzeCBcdTcyRUNcdTdBQ0JcdThERDEgc3BlYyBcdTU3M0FcdTY2NkZcdUZGMDlcdTk3NTlcdTlFRDhcdThERjNcdThGQzcgXHUyMDE0XHUyMDE0XG4gICAgICAgICAgICAvLyByZWFkeSBcdTRGRTFcdTUzRjdcdTUzRUFcdTU3MjhcdTg4QUJcdTVCQkZcdTRFM0IgZm9yayBcdTY1RjZcdTY3MDlcdTYxMEZcdTRFNDlcdTMwMDJcbiAgICAgICAgICAgIGlmICh0eXBlb2YgcHJvY2Vzcy5zZW5kID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAgICAgcHJvY2Vzcy5zZW5kKHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU6ICd3Yi1leHRlbnNpb24tcmVhZHknLFxuICAgICAgICAgICAgICAgICAgICAgICAgZXh0ZW5zaW9uSWQsXG4gICAgICAgICAgICAgICAgICAgICAgICBwaWQ6IHByb2Nlc3MucGlkLFxuICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcihgW0V4dGVuc2lvbjoke2V4dGVuc2lvbklkfV0gc2VuZCByZWFkeSBzaWduYWwgZmFpbGVkOmAsIGVycik7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9LFxuXG4gICAgICAgIHRlcm1pbmF0ZSgpIHtcbiAgICAgICAgICAgIC8vIGZvcmsgXHU2QTIxXHU1RjBGID0gXHU0RTAwXHU0RTJBXHU4RkRCXHU3QTBCXHU0RTAwXHU0RTJBIGV4dGVuc2lvblx1RkYwQ1x1OTAwMFx1NTFGQVx1OEZEQlx1N0EwQlx1NTM3M1wiXHU1Mzc4XHU4RjdEIGV4dGVuc2lvblwiXHUzMDAyXG4gICAgICAgICAgICAvLyBzaHV0ZG93biBob29rcyBcdTVERjJcdTdFQ0ZcdThERDFcdThGQzdcdUZGMDhydW5FeHRlbnNpb24uZG9TaHV0ZG93biBcdTRGMUFcdTUxNDhcdThERDEgZGlzcG9zZSBcdTUxOERcdThDMDNcbiAgICAgICAgICAgIC8vIHRlcm1pbmF0ZVx1RkYwOVx1RkYwQ1x1NkI2NFx1NTkwNFx1NzZGNFx1NjNBNVx1OTAwMFx1MzAwMlxuICAgICAgICAgICAgcHJvY2Vzcy5leGl0KDApO1xuICAgICAgICB9LFxuICAgIH07XG59XG5cbi8vIFx1MjUwMFx1MjUwMFx1MjUwMCBsZWdhY3kgXHU4Rjg1XHU1MkE5XHVGRjA4XHU0RjlCIHNwZWMgXHU0RTBFXHU4RkMxXHU3OUZCXHU2NzFGXHU1MTdDXHU1QkI5XHU3NTI4XHVGRjA5IFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXG4vKipcbiAqIFx1MjZBMFx1RkUwRiAqKmxlZ2FjeSBcdTUxN0NcdTVCQjlcdTUxRkRcdTY1NzAqKiBcdTIwMTRcdTIwMTQgXHU2NUU5XHU2NzFGIGBib290c3RyYXBgIFx1OTFDQ1x1NjI0Qlx1NTE5OVx1NEU4Nlx1OEZEOVx1NkJCNVx1OTAzQlx1OEY5MVx1RkYwQ2BleHRlbnNpb24tZW50cnkuc3BlYy50c2BcbiAqIFx1NzZGNFx1NjNBNSBpbXBvcnQgXHU1QjgzXHU1MDVBXHU1MzU1XHU2RDRCXHUzMDAyXHU2MkJEIGVudiBcdTVDNDJcdTU0MEVcdThGRDlcdTZCQjVcdTkwM0JcdThGOTFcdTVERjJcdTdFQ0ZcdTUxODVcdTUzMTZcdTUyMzAgYGNyZWF0ZVByb2Nlc3NFbnZgIFx1OTFDQ1x1NzY4NFxuICogYHByb2Nlc3Mub25jZSgnZGlzY29ubmVjdCcpYCBcdTUyMDZcdTY1MkZcdUZGMENcdTRGNDZcdTRGRERcdTc1NTlcdTVCRkNcdTUxRkFcdThCQTlcdTgwMDFcdTUzNTVcdTZENEJcdTRFMERcdTc1MjhcdTY1MzlcdTMwMDJcbiAqXG4gKiBcdTY1QjBcdTRFRTNcdTc4MDEqKlx1NEUwRFx1ODk4MSoqXHU3NTI4XHU4RkQ5XHU0RTJBIFx1MjAxNFx1MjAxNCBcdTc2RjRcdTYzQTVcdTc1MjggYGNyZWF0ZVByb2Nlc3NFbnZgICsgYHJ1bkV4dGVuc2lvbmBcdTMwMDJcbiAqL1xuaW50ZXJmYWNlIEV4dGVuc2lvbkNoaWxkUHJvY2Vzc0xpZmVjeWNsZSB7XG4gICAgb25jZShldmVudDogJ2Rpc2Nvbm5lY3QnLCBsaXN0ZW5lcjogKCkgPT4gdm9pZCk6IHVua25vd247XG4gICAgZXhpdChjb2RlPzogbnVtYmVyKTogbmV2ZXIgfCB2b2lkO1xufVxuXG4vKiogQGRlcHJlY2F0ZWQgXHU4RDcwIGBjcmVhdGVQcm9jZXNzRW52YCBcdTkxQ0NcdTc2ODQgZGlzY29ubmVjdCBcdTUyMDZcdTY1MkZcdUZGMENcdTZCNjRcdTUxRkRcdTY1NzBcdTRFQzVcdTRFM0FcdTgwMDEgc3BlYyBcdTRGRERcdTc1NTlcdTMwMDIgKi9cbmV4cG9ydCBmdW5jdGlvbiBpbnN0YWxsUGFyZW50RGlzY29ubmVjdEV4aXQoXG4gICAgcHJvY2Vzc0xpZmVjeWNsZTogRXh0ZW5zaW9uQ2hpbGRQcm9jZXNzTGlmZWN5Y2xlLFxuICAgIGRpc3Bvc2VUcmFuc3BvcnQ6ICgpID0+IHZvaWQsXG4pOiB2b2lkIHtcbiAgICBwcm9jZXNzTGlmZWN5Y2xlLm9uY2UoJ2Rpc2Nvbm5lY3QnLCAoKSA9PiB7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBkaXNwb3NlVHJhbnNwb3J0KCk7XG4gICAgICAgIH0gZmluYWxseSB7XG4gICAgICAgICAgICBwcm9jZXNzTGlmZWN5Y2xlLmV4aXQoMCk7XG4gICAgICAgIH1cbiAgICB9KTtcbn1cbiIsICIvKipcbiAqIEV4dGVuc2lvbiBydW50aW1lIFx1NTE4NVx1NjgzOCBcdTIwMTRcdTIwMTQgKipcdTVCQjlcdTU2NjhcdTY1RTBcdTUxNzMqKlx1MzAwMlxuICpcbiAqIFx1MjUwMFx1MjUwMCBcdTRFM0FcdTRFQzBcdTRFNDhcdTg5ODFcdThGRDlcdTRFMDBcdTVDNDIgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG4gKlxuICogRXh0ZW5zaW9uIFx1NjcyQVx1Njc2NVx1NEYxQVx1NjcwOVx1NTkxQVx1NzlDRFx1OEZEMFx1ODg0Q1x1NUJCOVx1NTY2OFx1RkYxQVxuICpcbiAqIDEuICoqZm9yayBwcm9jZXNzKipcdUZGMDhcdTVGNTNcdTUyNERcdUZGMDlcdTIwMTRcdTIwMTQgXHU2QkNGXHU0RTJBIGV4dGVuc2lvbiBcdTcyRUNcdTdBQ0IgTm9kZS5qcyBcdTVCNTBcdThGREJcdTdBMEJcdUZGMENcdThGREJcdTdBMEJcdTdFQTdcdTk2OTRcdTc5QkJcdUZGMENcbiAqICAgIFx1OTAxQVx1OEZDNyBgcHJvY2Vzcy5zZW5kYCAvIGBwcm9jZXNzLm9uKCdtZXNzYWdlJylgIFx1OEQ3MCBJUENcdTMwMDJcbiAqIDIuICoqd29ya2VyX3RocmVhZHMqKlx1RkYwOFx1ODlDNFx1NTIxMlx1NEUyRFx1RkYwOVx1MjAxNFx1MjAxNCBcdTZCQ0ZcdTRFMkEgZXh0ZW5zaW9uIFx1NzJFQ1x1N0FDQiB3b3JrZXJcdUZGMENcdTdFQkZcdTdBMEJcdTdFQTdcdTk2OTRcdTc5QkJcdUZGMENWOFxuICogICAgaXNvbGF0ZSBcdTU5MjlcdTcxMzZcdTUyMDZcdTVGMDBcdUZGMENcdThENzdcdTUwNUNcdTVGMDBcdTk1MDBcdTZCRDQgZm9yayBcdTRGNEVcdTRFMDBcdTUyMzBcdTRFMjRcdTRFMkFcdTY1NzBcdTkxQ0ZcdTdFQTdcdUZGMENcdTUxNzFcdTRFQUIgTm9kZSBydW50aW1lXHUzMDAyXG4gKiAzLiAqKlx1NTQwOFx1NUU3Nlx1OEZEQlx1N0EwQiAvIHNoYXJlZC1ob3N0KipcdUZGMDhcdTg5QzRcdTUyMTJcdTRFMkRcdUZGMDlcdTIwMTRcdTIwMTQgXHU1OTFBXHU0RTJBIGV4dGVuc2lvbiBcdThERDFcdTU3MjhcdTU0MENcdTRFMDBcdTRFMkEgTm9kZSBcdThGREJcdTdBMEJcbiAqICAgIFx1OTFDQ1x1RkYwQ1x1OTc2MCB3YiArIGJ1cyBcdTUzNTVcdTRGOEJcdTUyMDZcdTcyNDdcdTVCOUVcdTczQjBcIlx1OEY2Rlx1OTY5NFx1NzlCQlwiXHVGRjBDXHU3NTI4XHU2NzY1XHU4REQxXHU0RTAwXHU2Mjc5XHU1M0VGXHU0RkUxIGJ1aWx0aW4gZXh0ZW5zaW9uXHVGRjBDXG4gKiAgICBcdTc3MDFcdThGREJcdTdBMEJcdTY1NzBcdUZGMDhQT0MgXHU5NjM2XHU2QkI1XHU3Njg0IDEyIFx1NEUyQSBidWlsdGluIFx1NkJDRlx1NEUyQVx1OTBGRCBmb3JrIFx1NTkyQVx1OEQzNVx1RkYwOVx1MzAwMlxuICogNC4gKippbmxpbmUgLyByZW5kZXJlciBcdTc2RjRcdThGREUqKlx1RkYwOFx1NjcyQVx1Njc2NSBkZXYgLyBlMmVcdUZGMDlcdTIwMTRcdTIwMTQgXHU3NkY0XHU2M0E1IHJlbmRlcmVyIFx1OEZEQlx1N0EwQlx1NTE4NVx1NTJBMFx1OEY3RFxuICogICAgXHU0RTAwXHU0RTJBXHU3NTI4XHU2MjM3XHU2QTIxXHU1NzU3XHVGRjBDXHU4RDcwXHU2NzJDXHU1NzMwIG1ldGhvZENoYW5uZWwgXHU4MDBDXHU0RTBEXHU2NjJGIElQQ1x1MzAwMlxuICpcbiAqIFx1OEZEOVx1NEU5Qlx1NUJCOVx1NTY2OFx1NjcwOVx1NEUwMFx1NEVGNlx1NEU4Qlx1NUI4Q1x1NTE2OFx1NEUwMFx1ODFGNFx1RkYxQSoqXHU4OEM1XHU5MTREIGB3YmAgXHU1RTc2XHU4QzAzXHU3NTI4XHU3NTI4XHU2MjM3IGBhY3RpdmF0ZWAqKlx1MzAwMlx1NTI2OVx1NEUwQlx1NzY4NFx1OTBGRFx1NjYyRlxuICogXHU1QkI5XHU1NjY4XHU1REVFXHU1RjAyXHUzMDAyXHU2NzJDXHU2NTg3XHU0RUY2XHU2MjhBXCJcdTRFMDBcdTgxRjRcdTc2ODRcdTkwQTNcdTRFRjZcdTRFOEJcIlx1NjJCRFx1NjIxMCBgcnVuRXh0ZW5zaW9uYFx1RkYwQ1x1NUJCOVx1NTY2OFx1NURFRVx1NUYwMlx1OTBGRFx1NTg1RVx1OEZEQlxuICogYEV4dGVuc2lvblJ1bnRpbWVFbnZgIFx1NTk1MVx1N0VBNlx1OTFDQ1x1NzUzMSBwcmVsb2FkIC8gXHU4OEM1XHU5MTREXHU1QzQyXHU1QjlFXHU3M0IwXHUzMDAyXG4gKlxuICogXHUyNTAwXHUyNTAwIFx1OEJCRVx1OEJBMVx1NTM5Rlx1NTIxOSBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcbiAqXG4gKiAxLiAqKlx1NEUwRCBpbXBvcnQgXHU0RUZCXHU0RjU1IHByb2Nlc3Mvd29ya2VyL2VsZWN0cm9uIFx1NzZGOFx1NTE3MyBBUEkqKiBcdTIwMTRcdTIwMTQgXHU1MTg1XHU2ODM4XHU1M0VBXHU0RjlEXHU4RDU2IGNvcmUgXHU3Njg0XG4gKiAgICBgY3JlYXRlR3Vlc3RXYmAgXHU1NDhDIGBUcmFuc3BvcnRgIFx1NjNBNVx1NTNFM1x1RkYwQ1x1NTNFRlx1NEVFNVx1ODhBQlx1NEVGQlx1NEY1NVx1NUJCOVx1NTY2OFx1NTkwRFx1NzUyOFx1MzAwMlxuICogMi4gKipzaHV0ZG93biBcdThCRURcdTRFNDlcdTYyQkRcdThDNjFcdTUzMTYqKiBcdTIwMTRcdTIwMTQgXHU1QkI5XHU1NjY4XHU1MUIzXHU1QjlBXCJcdTRGNTVcdTY1RjZcdTg5RTZcdTUzRDEgc2h1dGRvd25cIlx1RkYwOFNJR1RFUk0gLyB3b3JrZXJcbiAqICAgIGNsb3NlIC8gaHViIHVubG9hZEV4dGVuc2lvblx1RkYwOVx1RkYwQ1x1NTE4NVx1NjgzOFx1NTFCM1x1NUI5QVwiXHU4OUU2XHU1M0QxXHU2NUY2XHU1MDVBXHU0RUMwXHU0RTQ4XCJcdUZGMDhcdThERDEgZGlzcG9zZVx1MzAwMVx1NkUwNSB0cmFuc3BvcnRcdUZGMDlcdTMwMDJcbiAqIDMuICoqcmVhZHkgXHU0RkUxXHU1M0Y3XHU2MkJEXHU4QzYxXHU1MzE2KiogXHUyMDE0XHUyMDE0IFx1NUJCOVx1NTY2OFx1NTFCM1x1NUI5QVwiXHU0RkUxXHU1M0Y3XHU1M0QxXHU1MjMwXHU1NEVBXCJcdUZGMDhgcHJvY2Vzcy5zZW5kYCAvIGBwYXJlbnRQb3J0YCAvXG4gKiAgICBodWIgXHU1MTg1XHU5MEU4XHU2ODA3XHU4QkIwXHVGRjA5XHVGRjBDXHU1MTg1XHU2ODM4XHU1M0VBXHU1NzI4IGFjdGl2YXRlIFx1NUI4Q1x1NjIxMFx1NTQwRVx1OEMwMyBgZW52LnNpZ25hbFJlYWR5KClgXHUzMDAyXG4gKiA0LiAqKnRlcm1pbmF0ZSBcdThCRURcdTRFNDlcdTYyQkRcdThDNjFcdTUzMTYqKiBcdTIwMTRcdTIwMTQgZm9yayBcdTZBMjFcdTVGMEZcdTkwMDBcdTUxRkFcdTY1NzRcdTRFMkFcdThGREJcdTdBMEJcdUZGMEN3b3JrZXIgXHU2QTIxXHU1RjBGXHU1MTczIHdvcmtlclx1RkYwQ1xuICogICAgXHU1NDA4XHU1RTc2XHU4RkRCXHU3QTBCXHU2QTIxXHU1RjBGXHU1M0VBXHU4OUUzIGh1YiBcdThCQjBcdTVGNTVcdUZGMDhcdTRFMERcdTgwRkRcdTYyRDZcdTdEMkZcdTUyMkJcdTc2ODQgZXh0ZW5zaW9uXHVGRjA5XHUzMDAyXG4gKlxuICogXHUyNTAwXHUyNTAwIFx1NzUyOFx1NjIzN1x1NTk1MVx1N0VBNlx1NzY4NFx1NTE3Q1x1NUJCOVx1NjAyNyBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcbiAqXG4gKiBcdTczQjBcdTU3MjhcdTc1MjhcdTYyMzdcdTUxOTlcdUZGMUFcbiAqIGBgYHRzXG4gKiBpbXBvcnQgeyBib290c3RyYXAgfSBmcm9tICdAZ2VuaWUvd29ya2J1ZGR5LWV4dGVuc2lvbnMvcnVudGltZSc7XG4gKiBib290c3RyYXAoYXN5bmMgKHdiKSA9PiB7IC4uLiB9KTtcbiAqIGBgYFxuICpcbiAqIGBib290c3RyYXBgIFx1NzNCMFx1NTcyOFx1NjYyRlx1NjcyQ1x1NTE4NVx1NjgzOFx1NzY4NFx1ODU4NFx1NThGM1x1RkYwOFx1ODlDMSBgZXh0ZW5zaW9uLWVudHJ5LnRzYFx1RkYwOVx1MzAwMlx1NjcyQVx1Njc2NVx1NUYxNVx1NTE2NVxuICogYGV4cG9ydCBmdW5jdGlvbiBhY3RpdmF0ZSh3YikgeyAuLi4gfWAgXHU2NUIwXHU1OTUxXHU3RUE2XHU2NUY2XHVGRjBDXHU1QkI5XHU1NjY4XHVGRjA4cHJlbG9hZCAvIGh1Ylx1RkYwOVxuICogXHU3NkY0XHU2M0E1IGBpbXBvcnQodXNlckJ1bmRsZSkuYWN0aXZhdGVgIFx1NjJGRlx1NTIzMCBhY3RpdmF0ZSBcdTUxRkRcdTY1NzBcdThDMDMgYHJ1bkV4dGVuc2lvbmAgXHU1MzczXHU1M0VGXHUzMDAyXG4gKiBcdTgwMDFcdTU5NTFcdTdFQTYgYGJvb3RzdHJhcChmbilgIFx1NEZERFx1NzU1OVx1NEUwMFx1NkJCNVx1NjVGNlx1OTVGNFx1NTE3Q1x1NUJCOVx1NjcxRlx1MzAwMlxuICovXG5cbmltcG9ydCB7IGNyZWF0ZUd1ZXN0V2IsIHR5cGUgVHJhbnNwb3J0LCB0eXBlIFdvcmtidWRkeVNESyB9IGZyb20gJ0BnZW5pZS93b3JrYnVkZHktY29yZS93Yic7XG5cbi8vIFx1MjUwMFx1MjUwMFx1MjUwMCBcdTdDN0JcdTU3OEIgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cbi8qKlxuICogRXh0ZW5zaW9uIFx1NUI1MFx1OEZEQlx1N0EwQiAvIHdvcmtlciAvIHNoYXJlZC1ob3N0IFx1OTFDQ1x1NjJGRlx1NTIzMFx1NzY4NCBgd2JgIFNESyBcdTRFRTNcdTc0MDZcdTVCRjlcdThDNjFcdTMwMDJcbiAqXG4gKiBcdTVCOENcdTY1NzQgYFdvcmtidWRkeVNES2AgXHU3QzdCXHU1NzhCXHVGRjBDXHU4RERGIGhvc3QgLyBpZnJhbWUgXHU0RkE3XHU0RTAwXHU4MUY0IFx1MjAxNFx1MjAxNCBleHRlbnNpb24gXHU0RjVDXHU4MDA1XHU1MTk5XG4gKiBgd2IuZXhwZXJ0cy5saXN0KClgXHUzMDAxYHdiLnNraWxscy5pbnN0YWxsZWQoKWAgXHU2NzA5XHU1QjhDXHU2NTc0XHU4ODY1XHU1MTY4ICsgXHU3QzdCXHU1NzhCXHU2OEMwXHU2N0U1XHUzMDAyXG4gKlxuICogXHU4RkQwXHU4ODRDXHU2NUY2XHU2NjJGXHU2MEYwXHU2MDI3IG5hbWVzcGFjZSBwcm94eSBcdTIwMTRcdTIwMTQgYHdiLjxuYW1lc3BhY2U+YCBcdThCQkZcdTk1RUVcdTY1RjZcdTYyNEQgYGNyZWF0ZUd1ZXN0UHJveHkoLi4uKWBcdTMwMDJcbiAqXG4gKiBcdTI2QTBcdUZFMEYgKipob3N0LW9ubHkgXHU1QjU3XHU2QkI1KipcdUZGMDhgJHByb3ZpZGVgIC8gYCRkZXN0cm95YCAvIGB2ZXJzaW9uYCBcdTdCNDkgU0RLIFx1ODhDNVx1OTE0RFx1OTc2Mlx1RkYwOVx1NTcyOFxuICogZXh0ZW5zaW9uIFx1NEZBN1x1OEMwM1x1NEYxQVx1OEQ3MCB3aXJlIFx1MjE5MiBkYWVtb24gXHU0RTBEXHU4QkE0XHU4RkQ5XHU0RTlCIGNoYW5uZWwgXHUyMTkyIFx1NjJBNSBjaGFubmVsIG5vdCBmb3VuZFx1MzAwMlxuICogXHU4RkQ5XHU2NjJGXHU2NzA5XHU2MTBGXHU3Njg0XHVGRjFBXHU3QzdCXHU1NzhCXHU0RTBBXHU2NkI0XHU5NzMyXHU0RjQ2XHU4RkQwXHU4ODRDXHU2NUY2XHU2MkQyXHU3RUREXHVGRjBDXHU2QkQ0XCJcdThGRDBcdTg4NENcdTY1RjZcdTgwRkRcdThDMDNcdTRGNDZcdTdDN0JcdTU3OEJcdTRFMERcdThCQTRcIlx1NjZGNFx1N0IyNlx1NTQwOFwiZXh0ZW5zaW9uXG4gKiBcdTY2MkYgd2IgXHU2RDg4XHU4RDM5XHU2NUI5XCJcdTc2ODRcdTVGQzNcdTY2N0FcdTMwMDJcbiAqL1xuZXhwb3J0IHR5cGUgRXh0ZW5zaW9uV2IgPSBXb3JrYnVkZHlTREs7XG5cbi8qKlxuICogRXh0ZW5zaW9uIGFjdGl2YXRlIFx1OEZENFx1NTZERVx1NTAzQ1x1RkYxQVxuICogLSBgbWV0aG9kc2AgXHU1M0NEXHU1NDExXHU2NkI0XHU5NzMyXHU3RUQ5XHU1QkJGXHU0RTNCXHU3Njg0XHU2NUI5XHU2Q0Q1XHU1QjU3XHU1MTc4XHUzMDAyXHU1QkJGXHU0RTNCXHU4QzAzIGB0cmFuc3BvcnQuaW52b2tlKG1ldGhvZE5hbWUsIC4uLilgIFx1NTQ3RFx1NEUyRFx1MzAwMlxuICogLSBgZGlzcG9zZWAgXHU3NTI4XHU2MjM3XHU2RTA1XHU3NDA2XHU5NEE5XHU1QjUwXHUzMDAyXHU1QkI5XHU1NjY4XHU4OUU2XHU1M0QxIHNodXRkb3duIFx1NjVGNlx1NEYxOFx1NTE0OFx1OEMwM1x1NzUyOFx1RkYwOGZvcmsgXHU2QTIxXHU1RjBGXHU2NjJGIFNJR1RFUk1cdUZGMENcbiAqICAgd29ya2VyIFx1NkEyMVx1NUYwRlx1NjYyRiBwYXJlbnRQb3J0IFx1NjUzNlx1NTIzMCBzaHV0ZG93biBcdTZEODhcdTYwNkZcdUZGMENcdTU0MDhcdTVFNzZcdThGREJcdTdBMEJcdTZBMjFcdTVGMEZcdTY2MkYgaHViIFx1NEUzQlx1NTJBOCB1bmxvYWRcdUZGMDlcdTMwMDJcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBFeHRlbnNpb25BY3RpdmF0ZVJlc3VsdCB7XG4gICAgbWV0aG9kcz86IFJlY29yZDxzdHJpbmcsICguLi5hcmdzOiB1bmtub3duW10pID0+IHVua25vd24gfCBQcm9taXNlPHVua25vd24+PjtcbiAgICBkaXNwb3NlPzogKCkgPT4gdm9pZCB8IFByb21pc2U8dm9pZD47XG59XG5cbi8qKlxuICogXHU3NTI4XHU2MjM3IGFjdGl2YXRlIFx1NTFGRFx1NjU3MFx1N0I3RVx1NTQwRFx1MzAwMlxuICpcbiAqIFx1NzNCMFx1NTcyOFx1OTAxQVx1OEZDNyBgYm9vdHN0cmFwKGZuKWAgXHU0RjIwXHU1MTY1XHVGRjBDXHU2NzJBXHU2NzY1XHU0RjFBXHU2M0E4XHU4MzUwIGBleHBvcnQgZnVuY3Rpb24gYWN0aXZhdGUod2IpYCBcdTY1QjBcdTU5NTFcdTdFQTZcbiAqIFx1MjAxNFx1MjAxNCBcdTRFMjRcdTc5Q0RcdTdCN0VcdTU0MERcdTc2RjhcdTU0MENcdUZGMENcdThGRDBcdTg4NENcdTY1RjZcdTkwRkRcdTY2MkZcdTRFMDBcdTdCNDlcdTUxNkNcdTZDMTFcdTMwMDJcbiAqL1xuZXhwb3J0IHR5cGUgRXh0ZW5zaW9uQWN0aXZhdGUgPSAod2I6IEV4dGVuc2lvbldiKSA9PlxuICAgIHwgdm9pZFxuICAgIHwgRXh0ZW5zaW9uQWN0aXZhdGVSZXN1bHRcbiAgICB8IFByb21pc2U8dm9pZCB8IEV4dGVuc2lvbkFjdGl2YXRlUmVzdWx0PjtcblxuLyoqXG4gKiBFeHRlbnNpb24gXHU4RkQwXHU4ODRDXHU3M0FGXHU1ODgzXHU1OTUxXHU3RUE2IFx1MjAxNFx1MjAxNCBcdTc1MzEqKlx1NUJCOVx1NTY2OCoqXHVGRjA4cHJlbG9hZCAvIHdvcmtlciBlbnRyeSAvIGh1Ylx1RkYwOVx1NjNEMFx1NEY5Qlx1MzAwMlxuICpcbiAqIFx1NTE4NVx1NjgzOFx1NEUwRCBpbXBvcnQgXHU0RUZCXHU0RjU1IHByb2Nlc3Mvd29ya2VyIFx1NzZGOFx1NTE3MyBBUElcdUZGMENcdTUzRUFcdTYzMDkgZW52IFx1NjNEMFx1NEY5Qlx1NzY4NFx1ODBGRFx1NTI5Qlx1NjRDRFx1NEY1Q1x1MzAwMlx1NjBGM1x1NjVCMFx1NTg5RVxuICogXHU0RTAwXHU3OUNEXHU1QkI5XHU1NjY4XHU1QzMxXHU1QjlFXHU3M0IwXHU0RTAwXHU0RUZEIGVudiBmYWN0b3J5XHVGRjFBXG4gKlxuICogfCBFbnYga2luZCAgICAgIHwgb25TaHV0ZG93biBcdTg5RTZcdTUzRDFcdTY1RjZcdTY3M0EgICAgICAgICAgICAgICAgICAgICAgIHwgc2lnbmFsUmVhZHkgXHU3NkVFXHU2ODA3ICAgICAgICAgICAgICAgICAgICB8IHRlcm1pbmF0ZSBcdThCRURcdTRFNDkgICAgICAgICAgICAgICAgICB8XG4gKiB8LS0tLS0tLS0tLS0tLS0tfC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS18LS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLXwtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS18XG4gKiB8IGBwcm9jZXNzYCAgICAgfCBTSUdURVJNIC8gcGFyZW50IGRpc2Nvbm5lY3QgICAgICAgICAgICAgICB8IGBwcm9jZXNzLnNlbmQoe3R5cGU6J3diLXJlYWR5J30pYCAgIHwgYHByb2Nlc3MuZXhpdCgwKWAgICAgICAgICAgICAgICB8XG4gKiB8IGB3b3JrZXJgICAgICAgfCBgcGFyZW50UG9ydC5vbignbWVzc2FnZScsIHNodXRkb3duKWAgICAgICB8IGBwYXJlbnRQb3J0LnBvc3RNZXNzYWdlKC4uLilgICAgICAgIHwgYHByb2Nlc3MuZXhpdCgwKWAgKGluIHdvcmtlcikgICB8XG4gKiB8IGBzaGFyZWQtaG9zdGAgfCBodWIgXHU4QzAzIGBoYW5kbGUuZGlzcG9zZSgpYCAgICAgICAgICAgICAgICAgfCBodWIgXHU1MTg1XHU5MEU4XHU2ODA3XHU4QkIwICAgICAgICAgICAgICAgICAgICAgICAgfCBuby1vcFx1RkYwOFx1NEUwRFx1ODBGRFx1NjJENlx1N0QyRlx1NTIyQlx1NzY4NCBleHRcdUZGMDkgICAgICAgfFxuICogfCBgaW5saW5lYCAgICAgIHwgXHU3RUM0XHU0RUY2IHVubW91bnQgLyBkZXYtc2VydmVyIFx1OTFDRFx1NTQyRiAgICAgICAgICAgIHwgXHU2NzJDXHU1NzMwXHU0RThCXHU0RUY2XHU1NkRFXHU4QzAzICAgICAgICAgICAgICAgICAgICAgICAgfCBuby1vcFx1RkYwOHJlbmRlcmVyIFx1NEUwRFx1ODBGRFx1OTAwMFx1NTFGQVx1OEZEQlx1N0EwQlx1RkYwOSAgfFxuICovXG5leHBvcnQgaW50ZXJmYWNlIEV4dGVuc2lvblJ1bnRpbWVFbnYge1xuICAgIC8qKiBcdTVCQjlcdTU2NjhcdTdDN0JcdTU3OEIgXHUyMDE0XHUyMDE0IFx1NjVFNVx1NUZENyAvIFx1OEMwM1x1OEJENVx1NzUyOFx1MzAwMiAqL1xuICAgIGtpbmQ6ICdwcm9jZXNzJyB8ICd3b3JrZXInIHwgJ3NoYXJlZC1ob3N0JyB8ICdpbmxpbmUnO1xuXG4gICAgLyoqXG4gICAgICogVHJhbnNwb3J0IFx1MjAxNFx1MjAxNCBleHRlbnNpb24gXHU0RTBFXHU1QkJGXHU0RTNCIGRhZW1vbiBcdTRFNEJcdTk1RjRcdTc2ODQgUlBDICsgXHU0RThCXHU0RUY2XHU5MDFBXHU5MDUzXHUzMDAyXG4gICAgICpcbiAgICAgKiBcdTU5NTFcdTdFQTZcdUZGMUFcbiAgICAgKiAtIGB0cmFuc3BvcnQuaW52b2tlKGNoYW5uZWwsIGN0eCwgLi4uYXJncylgIFx1MjAxNFx1MjAxNCBleHRlbnNpb24gXHU4QzAzIGRhZW1vblxuICAgICAqIC0gYHRyYW5zcG9ydC5oYW5kbGUoY2hhbm5lbCwgaGFuZGxlcilgIFx1MjAxNFx1MjAxNCBleHRlbnNpb24gXHU2Q0U4XHU1MThDIG1ldGhvZFx1RkYwQ1x1NEY5QiBkYWVtb24gXHU1M0NEXHU1NDExXHU4QzAzXG4gICAgICogLSBgdHJhbnNwb3J0Lm9uKGV2ZW50SGFuZGxlcilgIFx1MjAxNFx1MjAxNCBcdTY1MzYgZGFlbW9uIFx1NjNBOFx1Njc2NVx1NzY4NCBidXMgXHU0RThCXHU0RUY2XG4gICAgICogLSBgdHJhbnNwb3J0LmRpc3Bvc2UoKWAgXHUyMDE0XHUyMDE0IFx1NTE3M1x1OTVFRFx1OTAxQVx1OTA1M1xuICAgICAqXG4gICAgICogXHU2QkNGXHU0RTJBIGV4dGVuc2lvbiBcdTRFMDBcdTRFRkQqKlx1NzJFQ1x1N0FDQioqXHU3Njg0IHRyYW5zcG9ydFx1MzAwMlx1NTQwOFx1NUU3Nlx1OEZEQlx1N0EwQlx1NkEyMVx1NUYwRlx1OTFDQ1x1RkYwQ2h1YiBcdTRGMUFcdTdFRDlcdTZCQ0ZcdTRFMkFcbiAgICAgKiBleHRlbnNpb24gXHU1MjA2XHU2RDNFXHU0RTAwXHU0RUZEXCJcdTkwM0JcdThGOTEgdHJhbnNwb3J0XCJcdUZGMDhcdTVFOTVcdTVDNDJcdTU5MERcdTc1MjhcdTRFMDBcdTY3NjFcdTcyNjlcdTc0MDZcdThGREVcdTYzQTUgKyBleHRJZCBcdTRGRTFcdTVDMDFcdThERUZcdTc1MzFcdUZGMDlcdTMwMDJcbiAgICAgKi9cbiAgICB0cmFuc3BvcnQ6IFRyYW5zcG9ydDtcblxuICAgIC8qKlxuICAgICAqIFx1NkNFOFx1NTE4QyBzaHV0ZG93biBcdTk0QTlcdTVCNTBcdTMwMDJcbiAgICAgKlxuICAgICAqIFx1NUJCOVx1NTY2OFx1RkYwOGZvcmsgLyB3b3JrZXIgLyBodWJcdUZGMDlcdTUxQjNcdTVCOUFcIlx1NEVDMFx1NEU0OFx1NjVGNlx1NTAxOVx1ODlFNlx1NTNEMSBzaHV0ZG93blwiXHVGRjBDXHU2NzJDXHU1MUZEXHU2NTcwXHU2NjJGKipcdTc2N0JcdThCQjAqKlx1NTJBOFx1NEY1Q1x1MzAwMlxuICAgICAqIFx1ODlFNlx1NTNEMVx1NjVGNlx1NjczQVx1NzUzMVx1NUJCOVx1NTY2OFx1NUI5RVx1NzNCMFx1RkYxQVxuICAgICAqIC0gYHByb2Nlc3NgOiBcdTYzMDJcdTUyMzAgYHByb2Nlc3Mub24oJ1NJR1RFUk0nKWAgXHU2MjE2IGBwcm9jZXNzLm9uY2UoJ2Rpc2Nvbm5lY3QnKWBcbiAgICAgKiAtIGB3b3JrZXJgOiBcdTYzMDJcdTUyMzAgYHBhcmVudFBvcnQub24oJ21lc3NhZ2UnLCAoe3R5cGV9KSA9PiB0eXBlID09PSAnc2h1dGRvd24nKWBcbiAgICAgKiAtIGBzaGFyZWQtaG9zdGA6IGh1YiBcdThDMDMgYGhhbmRsZS5kaXNwb3NlKClgIFx1NjVGNlx1NTQwQ1x1NkI2NVx1OEMwM1x1NzUyOFx1NzY3Qlx1OEJCMFx1NzY4NCBmblxuICAgICAqXG4gICAgICogXHU1OTFBXHU2QjIxXHU4QzAzIGBvblNodXRkb3duKGZuKWAgXHU0RjFBXHU3RDJGXHU1MkEwXHU2MjQwXHU2NzA5IGZuXHVGRjBDXHU4OUU2XHU1M0QxXHU2NUY2XHU2MzA5XHU2Q0U4XHU1MThDXHU5ODdBXHU1RThGXHU0RjlEXHU2QjIxIGF3YWl0XHUzMDAyXG4gICAgICovXG4gICAgb25TaHV0ZG93bjogKGZuOiAoKSA9PiB2b2lkIHwgUHJvbWlzZTx2b2lkPikgPT4gdm9pZDtcblxuICAgIC8qKlxuICAgICAqIFx1OTAxQVx1NzdFNVx1NUJCRlx1NEUzQiBhY3RpdmF0ZSBcdTVERjJcdTVCOENcdTYyMTBcdTMwMDFoYW5kbGVyIFx1NUMzMVx1N0VFQVx1MzAwMlxuICAgICAqXG4gICAgICogXHU1QkI5XHU1NjY4XHU1MUIzXHU1QjlBXHU0RkUxXHU1M0Y3XHU3Njg0XHU1MTc3XHU0RjUzXHU1RjYyXHU1RjBGXHVGRjFBXG4gICAgICogLSBgcHJvY2Vzc2A6IGBwcm9jZXNzLnNlbmQoeyB0eXBlOiAnd2ItZXh0ZW5zaW9uLXJlYWR5JywgZXh0ZW5zaW9uSWQsIHBpZCB9KWBcbiAgICAgKiAtIGB3b3JrZXJgOiBgcGFyZW50UG9ydC5wb3N0TWVzc2FnZSh7IHR5cGU6ICd3Yi1leHRlbnNpb24tcmVhZHknLCBleHRlbnNpb25JZCB9KWBcbiAgICAgKiAtIGBzaGFyZWQtaG9zdGA6IGh1YiBcdTUxODVcdTkwRThcdTY4MDdcdThCQjAgYHJlYWR5RXh0ZW5zaW9ucy5hZGQoZXh0SWQpYFxuICAgICAqXG4gICAgICogXHU1RTQyXHU3QjQ5IFx1MjAxNFx1MjAxNCBcdTUxODVcdTY4MzhcdTUzRUFcdThDMDNcdTRFMDBcdTZCMjFcdTMwMDJcbiAgICAgKi9cbiAgICBzaWduYWxSZWFkeTogKCkgPT4gdm9pZDtcblxuICAgIC8qKlxuICAgICAqIFx1NUI4Q1x1NTE2OFx1N0VDOFx1NkI2Mlx1NjcyQyBleHRlbnNpb24gXHU3Njg0XHU2MjY3XHU4ODRDXHU0RTBBXHU0RTBCXHU2NTg3XHUzMDAyXG4gICAgICpcbiAgICAgKiAtIGBwcm9jZXNzYDogYHByb2Nlc3MuZXhpdCgwKWBcbiAgICAgKiAtIGB3b3JrZXJgOiBgcHJvY2Vzcy5leGl0KDApYFx1RkYwOGluIHdvcmtlciBcdTRFMEFcdTRFMEJcdTY1ODdcdUZGMENcdTUzRUFcdTUxNzNcdTY3MkMgd29ya2VyXHVGRjA5XG4gICAgICogLSBgc2hhcmVkLWhvc3RgOiAqKm5vLW9wKiogXHUyMDE0XHUyMDE0IFx1NTQwOFx1NUU3Nlx1OEZEQlx1N0EwQlx1NkEyMVx1NUYwRlx1OTFDQ1x1NEUwRFx1ODBGRFx1NzcxRlx1NzY4NCBleGl0XHVGRjBDXHU0RjFBXHU2MkQ2XHU3RDJGXHU1MjJCXHU3Njg0IGV4dFx1RkYxQlxuICAgICAqICAgaHViIFx1NjUzNlx1NTIzMCBzaHV0ZG93biBcdTVCOENcdTYyMTBcdTU0MEVcdTgxRUFcdTVERjFcdTZFMDVcdTc0MDZcdThCQjBcdTVGNTVcdTUzNzNcdTUzRUZcbiAgICAgKiAtIGBpbmxpbmVgOiAqKm5vLW9wKiogXHUyMDE0XHUyMDE0IHJlbmRlcmVyIFx1OTFDQ1x1OTAwMFx1NTFGQVx1OEZEQlx1N0EwQiA9IFx1NjU3NFx1NEUyQSBhcHAgY3Jhc2hcbiAgICAgKi9cbiAgICB0ZXJtaW5hdGU6ICgpID0+IHZvaWQ7XG59XG5cbi8qKlxuICogYHJ1bkV4dGVuc2lvbmAgXHU4RkQ0XHU1NkRFXHU3Njg0XHU1M0U1XHU2N0M0XHUzMDAyXG4gKlxuICogXHU0RTNCXHU4OTgxXHU3RUQ5KipcdTU0MDhcdTVFNzZcdThGREJcdTdBMEJcdTZBMjFcdTVGMEYqKlx1NzUyOFx1RkYxQWh1YiBcdTk3MDBcdTg5ODFcdTgwRkRcdTRFM0JcdTUyQThcdTg5RTZcdTUzRDFcdTY3RDBcdTRFMkEgZXh0ZW5zaW9uIFx1NzY4NCBkaXNwb3NlXHVGRjBDXG4gKiBcdTgwMENcdTRFMERcdTY2MkZcdTdCNDkgc2lnbmFsXHVGRjA4c2lnbmFsIFx1NEYxQVx1Njc0MFx1NjU3NFx1NEUyQSBob3N0IFx1OEZEQlx1N0EwQlx1RkYwOVx1MzAwMmZvcmsvd29ya2VyIFx1NkEyMVx1NUYwRlx1NEUwMFx1ODIyQ1x1NEUwRFx1NzUyOFxuICogXHU3NkY0XHU2M0E1XHU4QzAzIGhhbmRsZS5kaXNwb3NlIFx1MjAxNFx1MjAxNCBcdTk3NjAgZW52Lm9uU2h1dGRvd24gXHU2MzAyXHU3Njg0XHU5NEE5XHU1QjUwXHU0RjFBXHU1NzI4IHNpZ25hbCBcdTUyMzBcdTY3NjVcdTY1RjZcdTgxRUFcdTUyQThcdThERDFcdTMwMDJcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBFeHRlbnNpb25SdW50aW1lSGFuZGxlIHtcbiAgICAvKipcbiAgICAgKiBcdTg5RTZcdTUzRDEgZGlzcG9zZSBcdTZENDFcdTdBMEIgXHUyMDE0XHUyMDE0ICoqXHU0RTBEIHRlcm1pbmF0ZSoqXHVGRjBDXHU1M0VBXHU4RDcwIHVzZXIgZGlzcG9zZSArIHRyYW5zcG9ydCBkaXNwb3NlXHUzMDAyXG4gICAgICogXHU1RTQyXHU3QjQ5XHVGRjFBXHU1OTFBXHU2QjIxXHU4QzAzXHU3NTI4XHU1M0VBXHU3QjJDXHU0RTAwXHU2QjIxXHU3NTFGXHU2NTQ4XHUzMDAyXG4gICAgICpcbiAgICAgKiBcdTRGN0ZcdTc1MjhcdTU3M0FcdTY2NkZcdUZGMUFcbiAgICAgKiAtIFx1NTQwOFx1NUU3Nlx1OEZEQlx1N0EwQlx1NkEyMVx1NUYwRlx1NzY4NCBodWIgXHU2MEYzXHU1Mzc4XHU4RjdEXHU2N0QwXHU0RTJBIGV4dFx1RkYwOFx1NEUwRFx1NUY3MVx1NTRDRFx1NTIyQlx1NzY4NCBleHRcdUZGMDlcbiAgICAgKiAtIFx1NTM1NVx1NkQ0Qlx1NjBGM1x1NkQ0QiBkaXNwb3NlIFx1OTAzQlx1OEY5MVxuICAgICAqL1xuICAgIGRpc3Bvc2U6ICgpID0+IFByb21pc2U8dm9pZD47XG59XG5cbi8vIFx1MjUwMFx1MjUwMFx1MjUwMCBcdTVCOUVcdTczQjAgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cbi8qKlxuICogRXh0ZW5zaW9uIHJ1bnRpbWUgXHU1MTg1XHU2ODM4XHVGRjFBXHU4OEM1XHU5MTREIGB3YmAgKyBcdThDMDMgYGFjdGl2YXRlYCArIFx1NjMwMiBzaHV0ZG93biAvIHJlYWR5XHUzMDAyXG4gKlxuICogKipcdTVCQjlcdTU2NjhcdTY1RTBcdTUxNzMqKiBcdTIwMTRcdTIwMTQgXHU1M0VBXHU0RjlEXHU4RDU2IGBlbnZgIFx1NjNEMFx1NEY5Qlx1NzY4NFx1ODBGRFx1NTI5Qlx1RkYwQ1x1NEUwRCBpbXBvcnQgXHU0RUZCXHU0RjU1IHByb2Nlc3Mvd29ya2VyL2VsZWN0cm9uIEFQSVx1MzAwMlxuICpcbiAqIFx1OEMwM1x1NzUyOFx1NjVCOVx1RkYwOGJvb3RzdHJhcCBzaGltIC8gcHJlbG9hZCAvIGh1Ylx1RkYwOVx1OEQxRlx1OEQyM1x1RkYxQVxuICogMS4gXHU5MDIwXHU1OTdEIGVudlx1RkYwOHRyYW5zcG9ydCAvIG9uU2h1dGRvd24gLyBzaWduYWxSZWFkeSAvIHRlcm1pbmF0ZVx1RkYwOVxuICogMi4gXHU2M0QwXHU0RjlCIGV4dGVuc2lvbklkXG4gKiAzLiBcdTYzRDBcdTRGOUIgYWN0aXZhdGUgXHU1MUZEXHU2NTcwXG4gKlxuICogXHU2NzJDXHU1MUZEXHU2NTcwXHU4RDFGXHU4RDIzXHVGRjFBXG4gKiAxLiBcdTc1MjggZW52LnRyYW5zcG9ydCBcdTkwMjAgd2JcdUZGMDhcdThENzAgY29yZSBcdTc2ODQgYGNyZWF0ZUd1ZXN0V2JgXHVGRjBDXHU4RERGIGlmcmFtZS93ZWJ2aWV3IGd1ZXN0IFx1NEUwMFx1NEVGRFx1NUI5RVx1NzNCMFx1RkYwOVxuICogMi4gXHU5MDFBXHU4RkM3IGBlbnYub25TaHV0ZG93bmAgXHU3NjdCXHU4QkIwXCJzaHV0ZG93biBcdTY1RjZcdThCRTVcdTUwNUFcdTRFQzBcdTRFNDhcIlxuICogMy4gXHU4QzAzIGFjdGl2YXRlIFx1NjJGRiBtZXRob2RzIC8gZGlzcG9zZVxuICogNC4gXHU2MjhBIG1ldGhvZHMgXHU2Q0U4XHU1MThDXHU1MjMwIGVudi50cmFuc3BvcnRcbiAqIDUuIFx1OEMwMyBlbnYuc2lnbmFsUmVhZHkgXHU5MDFBXHU3N0U1XHU1QkJGXHU0RTNCXG4gKiA2LiBcdThGRDRcdTU2REUgaGFuZGxlIFx1NEY5Qlx1NTkxNlx1OTBFOFx1NEUzQlx1NTJBOCBkaXNwb3NlXHVGRjA4XHU1NDA4XHU1RTc2XHU4RkRCXHU3QTBCXHU2QTIxXHU1RjBGXHU1RkM1XHU3NTI4XHVGRjA5XG4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBydW5FeHRlbnNpb24ob3B0czoge1xuICAgIGV4dGVuc2lvbklkOiBzdHJpbmc7XG4gICAgZW52OiBFeHRlbnNpb25SdW50aW1lRW52O1xuICAgIGFjdGl2YXRlOiBFeHRlbnNpb25BY3RpdmF0ZTtcbn0pOiBQcm9taXNlPEV4dGVuc2lvblJ1bnRpbWVIYW5kbGU+IHtcbiAgICBjb25zdCB7IGV4dGVuc2lvbklkLCBlbnYsIGFjdGl2YXRlIH0gPSBvcHRzO1xuICAgIGNvbnN0IHsgdHJhbnNwb3J0IH0gPSBlbnY7XG5cbiAgICAvLyBcdTI1MDBcdTI1MDBcdTI1MDAgd2IgXHU4OEM1XHU5MTREIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuICAgIC8vXG4gICAgLy8gXHU4RDcwIGNvcmUgXHU3Njg0IGBjcmVhdGVHdWVzdFdiYFx1RkYwQ1x1OERERiBpZnJhbWUgLyB3ZWJ2aWV3IGd1ZXN0IFx1OEQ3MFx1NEUwMFx1NEVGRFx1NUI5RVx1NzNCMFx1MzAwMlxuICAgIC8vXG4gICAgLy8gXHU4QkVEXHU0RTQ5XHVGRjFBXG4gICAgLy8gICBcdTAwQjcgYHdiLjxuYW1lc3BhY2U+LjxtZXRob2Q+KC4uLmFyZ3MpYCBcdTIxOTIgUlBDIFx1NTIzMCBkYWVtb25cdUZGMDhcdThENzAgR3Vlc3RQcm94eSBcdTYyRkNcbiAgICAvLyAgICAgYHdiOntuc306e21ldGhvZH1gIGNoYW5uZWxcdUZGMDlcbiAgICAvLyAgIFx1MDBCNyBgd2Iub24oZXZlbnQsIGgpIC8gd2Iub2ZmIC8gd2Iub25BbnkoaClgIFx1MjE5MiBcdTU5RDRcdTZEM0VcdTY3MkNcdThGREJcdTdBMEIgZ2V0QnVzKClcdUZGMUJcbiAgICAvLyAgICAgYHN1YnNjcmliZWAgXHU2MjhBIHRyYW5zcG9ydCBcdTYzQThcdTY3NjVcdTc2ODRcdThGRENcdTdBRUZcdTRFOEJcdTRFRjYgZW1pdCBcdTUyMzAgYnVzXHVGRjBDYHdiLm9uYCBcdTc2RjRcdTYzQTVcdTY2MkZcbiAgICAvLyAgICAgYGJ1cy5vbi5iaW5kKGJ1cylgXG4gICAgLy8gICBcdTAwQjcgYHdiLmludm9rZShjaGFubmVsLCAuLi5hcmdzKWAgXHUyMTkyIFx1OTAwM1x1NzUxRlx1ODIzMVx1RkYwQ2NoYW5uZWwgXHU3NTMxXHU3NTI4XHU2MjM3XHU0RjIwXHVGRjA4XHU4RDcwIGRhZW1vbiBSUENcbiAgICAvLyAgICAgXHU5MDFBXHU3NTI4XHU4REVGXHU3NTMxXHVGRjA5XG4gICAgLy9cbiAgICAvLyBcdTI2QTBcdUZFMEYgVHJhbnNwb3J0Lmludm9rZSAvIC5vbiBcdTU3MjhcdTdDN0JcdTU3OEJcdTRFMEFcdTY2MkYgb3B0aW9uYWxcdUZGMDhodWItb3JjaGVzdHJhdGlvbiBcdTU3M0FcdTY2NkZcdTRFMEJcbiAgICAvLyBcdTY3MDlcdTc2ODQgdHJhbnNwb3J0IFx1NTNFQVx1NTA1QVx1NTM1NVx1NTQxMVx1OTAxQVx1NEZFMVx1RkYwOVx1MjAxNFx1MjAxNCBcdTc1MjhcdTdBN0FcdTVCOUVcdTczQjBcdTUxNUNcdTVFOTVcdUZGMENcdTdCN0VcdTU0MERcdTRGRERcdTYzMDEgbm9uLW51bGxcdUZGMENcdTY1QjlcdTRGQkZcdTRFMEJcdTZFMzhcdTc1MjhcdTMwMDJcbiAgICBjb25zdCBpbnZva2VGbiA9IHRyYW5zcG9ydC5pbnZva2UgPz8gKGFzeW5jICgpID0+IHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBbRXh0ZW5zaW9uOiR7ZXh0ZW5zaW9uSWR9XSB0cmFuc3BvcnQuaW52b2tlIG5vdCByZWFkeWApO1xuICAgIH0pO1xuICAgIGNvbnN0IHN1YnNjcmliZUZuID0gdHJhbnNwb3J0Lm9uID8/ICgoKSA9PiB7IC8qIHRyYW5zcG9ydCBcdTY1RTBcdTRFOEJcdTRFRjZcdTk3NjJcdTY1RjYgd2Iub24gXHU5NzU5XHU5RUQ4IG5vLW9wICovIH0pO1xuICAgIGNvbnN0IHdiID0gY3JlYXRlR3Vlc3RXYihpbnZva2VGbiwge1xuICAgICAgICBzdWJzY3JpYmU6IHN1YnNjcmliZUZuLFxuICAgIH0pIGFzIHVua25vd24gYXMgRXh0ZW5zaW9uV2I7XG5cbiAgICAvLyBcdTI1MDBcdTI1MDBcdTI1MDAgc2h1dGRvd24gaG9vayBcdTc2N0JcdThCQjAgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG4gICAgLy9cbiAgICAvLyBcdTUxODVcdTY4MzhcdTUxQjNcdTVCOUFcInNodXRkb3duIFx1NjVGNlx1NTA1QVx1NEVDMFx1NEU0OFwiXHVGRjA4XHU4REQxIHVzZXIgZGlzcG9zZSArIFx1NjJDNiB0cmFuc3BvcnQgKyB0ZXJtaW5hdGUgXHU1QkI5XHU1NjY4XHVGRjA5XHVGRjBDXG4gICAgLy8gZW52IFx1NTFCM1x1NUI5QVwiXHU0RUMwXHU0RTQ4XHU2NUY2XHU1MDE5XHU4OUU2XHU1M0QxXCJcdTMwMDJcdTU0MENcdTRFMDBcdTRFRkRcdTkwM0JcdThGOTFcdTUzRUZcdTc1MjhcdTRFOEUgZm9yayAvIHdvcmtlciAvIFx1NTQwOFx1NUU3Nlx1OEZEQlx1N0EwQlx1NEUwOVx1NzlDRFx1NTczQVx1NjY2Rlx1MzAwMlxuICAgIC8vXG4gICAgLy8gXHU1RTQyXHU3QjQ5XHU0RkREXHU2MkE0XHVGRjFBXHU1QkI5XHU1NjY4XHU1M0VGXHU4MEZEXHU1NDBDXHU2NUY2XHU2MzAyIFNJR1RFUk0gXHU1NDhDIGRpc2Nvbm5lY3RcdUZGMENcdTkwRkRcdTRGMUFcdTU0N0RcdTRFMkRcdUZGMUJcdTc1Mjggc2h1dGRvd25TdGFydGVkXG4gICAgLy8gXHU2ODA3XHU1RkQ3XHU5MDdGXHU1MTREIHVzZXIgZGlzcG9zZSBcdThERDFcdTRFMjRcdTkwNERcdTMwMDJcbiAgICBsZXQgdXNlckRpc3Bvc2U6ICgoKSA9PiB2b2lkIHwgUHJvbWlzZTx2b2lkPikgfCB1bmRlZmluZWQ7XG4gICAgbGV0IHNodXRkb3duU3RhcnRlZCA9IGZhbHNlO1xuXG4gICAgY29uc3QgZG9TaHV0ZG93biA9IGFzeW5jICgpOiBQcm9taXNlPHZvaWQ+ID0+IHtcbiAgICAgICAgaWYgKHNodXRkb3duU3RhcnRlZCkgeyByZXR1cm47IH1cbiAgICAgICAgc2h1dGRvd25TdGFydGVkID0gdHJ1ZTtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGF3YWl0IHVzZXJEaXNwb3NlPy4oKTtcbiAgICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKGBbRXh0ZW5zaW9uOiR7ZXh0ZW5zaW9uSWR9XSBkaXNwb3NlIGVycm9yOmAsIGVycik7XG4gICAgICAgIH1cbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIHRyYW5zcG9ydC5kaXNwb3NlPy4oKTtcbiAgICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKGBbRXh0ZW5zaW9uOiR7ZXh0ZW5zaW9uSWR9XSB0cmFuc3BvcnQgZGlzcG9zZSBlcnJvcjpgLCBlcnIpO1xuICAgICAgICB9XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBlbnYudGVybWluYXRlKCk7XG4gICAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICAgICAgY29uc29sZS5lcnJvcihgW0V4dGVuc2lvbjoke2V4dGVuc2lvbklkfV0gZW52LnRlcm1pbmF0ZSBlcnJvcjpgLCBlcnIpO1xuICAgICAgICB9XG4gICAgfTtcblxuICAgIGVudi5vblNodXRkb3duKGRvU2h1dGRvd24pO1xuXG4gICAgLy8gXHUyNTAwXHUyNTAwXHUyNTAwIFx1OEREMVx1NzUyOFx1NjIzNyBhY3RpdmF0ZSBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcbiAgICB0cnkge1xuICAgICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBhY3RpdmF0ZSh3Yik7XG4gICAgICAgIGlmIChyZXN1bHQgJiYgdHlwZW9mIHJlc3VsdCA9PT0gJ29iamVjdCcpIHtcbiAgICAgICAgICAgIGNvbnN0IHsgbWV0aG9kcywgZGlzcG9zZSB9ID0gcmVzdWx0O1xuICAgICAgICAgICAgdXNlckRpc3Bvc2UgPSBkaXNwb3NlO1xuXG4gICAgICAgICAgICBpZiAobWV0aG9kcykge1xuICAgICAgICAgICAgICAgIC8vIFRyYW5zcG9ydC5oYW5kbGUoY2hhbm5lbCwgaGFuZGxlcikgXHUyMDE0XHUyMDE0IFx1NkJDRlx1NEUyQSBtZXRob2QgXHU3MkVDXHU3QUNCXHU2Q0U4XHU1MThDIGNoYW5uZWxcdTMwMDJcbiAgICAgICAgICAgICAgICAvLyBcdTUxODVcdTY4MzhcdTRFMERcdTUwNUEgd3JhcHBpbmcvYXJndW1lbnQtbm9ybWFsaXphdGlvblx1RkYwQ1x1NzZGNFx1NjNBNVx1NjI4QVx1NzUyOFx1NjIzNyBtZXRob2QgXHU2MzAyXHU0RTBBXHU1M0JCXHVGRjFCXG4gICAgICAgICAgICAgICAgLy8gY29udGV4dCBcdTUzQzJcdTY1NzBcdTc1MzEgYnJpZGdlLWhvc3QgXHU0RkE3XHU1ODZCXHU1MTQ1XHVGRjA4XHU3NTI4XHU2MjM3IG1ldGhvZCBcdTdCN0VcdTU0MERcdTkxQ0NcdTc2ODQgYXJncyBcdTVERjJcdTdFQ0ZcdTY2MkZcbiAgICAgICAgICAgICAgICAvLyBcdTUzQkJcdTYzODkgY29udGV4dCBcdTU0MEVcdTc2ODRcdTRFMUFcdTUyQTFcdTUzQzJcdTY1NzBcdUZGMDlcdTMwMDJcbiAgICAgICAgICAgICAgICBmb3IgKGNvbnN0IGNoYW5uZWwgb2YgT2JqZWN0LmtleXMobWV0aG9kcykpIHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgZm4gPSBtZXRob2RzW2NoYW5uZWxdO1xuICAgICAgICAgICAgICAgICAgICB0cmFuc3BvcnQuaGFuZGxlKGNoYW5uZWwsIGFzeW5jICguLi5hcmdzOiB1bmtub3duW10pID0+IGZuKC4uLmFyZ3MpKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coXG4gICAgICAgICAgICAgICAgICAgIGBbRXh0ZW5zaW9uOiR7ZXh0ZW5zaW9uSWR9XSByZWdpc3RlcmVkIG1ldGhvZHM6IFske09iamVjdC5rZXlzKG1ldGhvZHMpLmpvaW4oJywgJyl9XWAsXG4gICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICBjb25zb2xlLmVycm9yKGBbRXh0ZW5zaW9uOiR7ZXh0ZW5zaW9uSWR9XSBhY3RpdmF0ZSBmYWlsZWQ6YCwgZXJyKTtcbiAgICAgICAgLy8gXHU0RTBEXHU4MEZEXHU3NkY0XHU2M0E1IHByb2Nlc3MuZXhpdCBcdTIwMTRcdTIwMTQgXHU1NDA4XHU1RTc2XHU4RkRCXHU3QTBCXHU2QTIxXHU1RjBGXHU5MUNDXHU5MEEzXHU0RjFBXHU2MkQ2XHU3RDJGXHU1MjJCXHU3Njg0IGV4dFx1MzAwMlxuICAgICAgICAvLyBcdTkwMUFcdThGQzcgZW52LnRlcm1pbmF0ZSBcdThCQTlcdTVCQjlcdTU2NjhcdTUxQjNcdTVCOUFcdTYwMEVcdTRFNDhcdTU5MDRcdTc0MDZcImFjdGl2YXRlIFx1NTkzMVx1OEQyNVx1OTAwMFx1NTFGQVwiXHVGRjFBXG4gICAgICAgIC8vICAgLSBwcm9jZXNzL3dvcmtlcjogZW52LnRlcm1pbmF0ZSBcdTRGMUEgZXhpdFxuICAgICAgICAvLyAgIC0gc2hhcmVkLWhvc3Q6IGVudi50ZXJtaW5hdGUgbm8tb3BcdUZGMENodWIgXHU0RkE3XHU3Njg0IGhhbmRsZS5kaXNwb3NlIFx1NEYxQVxuICAgICAgICAvLyAgICAgXHU2MkZGXHU1MjMwXHU2NzJDXHU1MUZEXHU2NTcwXHU2MjlCXHU1MUZBXHU3Njg0IGVycm9yXHVGRjA4cmUtdGhyb3cgXHU0RTBCXHU5NzYyXHVGRjA5XHU4MUVBXHU4ODRDXHU2RTA1XHU3NDA2XG4gICAgICAgIHRyeSB7IGVudi50ZXJtaW5hdGUoKTsgfSBjYXRjaCB7IC8qIGlnbm9yZSAqLyB9XG4gICAgICAgIHRocm93IGVycjtcbiAgICB9XG5cbiAgICAvLyBcdTI1MDBcdTI1MDBcdTI1MDAgUmVhZHkgXHU0RkUxXHU1M0Y3IFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuICAgIC8vXG4gICAgLy8gXHU5MDFBXHU3N0U1XHU1QkJGXHU0RTNCXHVGRjFBYWN0aXZhdGUgXHU1REYyXHU4REQxXHU1QjhDICsgaGFuZGxlciBcdTZDRThcdTUxOENcdTU5N0QgKyBcdTRFOEJcdTRFRjZcdThCQTJcdTk2MDVcdThERUZcdTVGODRcdTVERjJcdTkwMUFcdTMwMDJcbiAgICAvL1xuICAgIC8vIFx1NjVGNlx1NjczQVx1NUY4OFx1NTE3M1x1OTUyRVx1RkYxQSoqXHU1RkM1XHU5ODdCKipcdTU3MjggdHJhbnNwb3J0LmhhbmRsZSguLi4pIFx1NTE2OFx1OTBFOFx1NkNFOFx1NTE4Q1x1NTQwRVx1NTE4RFx1NTNEMVx1MzAwMlx1NTQyNlx1NTIxOVx1NUJCRlx1NEUzQlx1NjJGRlx1NTIzMFxuICAgIC8vIHJlYWR5IFx1NTQwRVx1N0FDQlx1NTM3MyBpbnZva2UgXHU0RjFBXHU2NDlFIFwibm8gcmVxdWVzdCBoYW5kbGVyIGF0dGFjaGVkXCIgcmFjZVx1MzAwMlxuICAgIHRyeSB7XG4gICAgICAgIGVudi5zaWduYWxSZWFkeSgpO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICAvLyBzaWduYWxSZWFkeSBcdTU5MzFcdThEMjVcdTRFMEQgZmF0YWwgXHUyMDE0XHUyMDE0IFx1NUJCRlx1NEUzQlx1NjcwOSAxMHMgXHU4RDg1XHU2NUY2XHU1MTVDXHU1RTk1XHVGRjA4XHU4OUMxIGhvc3QtbWFuYWdlciBcdTkxQ0NcbiAgICAgICAgLy8gcmVhZHlUaW1lb3V0XHVGRjA5XHVGRjBDXHU0RjFBXHU4MUVBXHU1MkE4XHU2NTNFXHU4ODRDXHUzMDAyXHU2NUU1XHU1RkQ3XHU4QkIwXHU0RTAwXHU0RTBCXHU0RkJGXHU0RThFXHU2MzkyXHU5NjlDXHUzMDAyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoYFtFeHRlbnNpb246JHtleHRlbnNpb25JZH1dIHNpZ25hbFJlYWR5IGZhaWxlZDpgLCBlcnIpO1xuICAgIH1cblxuICAgIC8vIFx1MjUwMFx1MjUwMFx1MjUwMCBcdThGRDRcdTU2REUgaGFuZGxlIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuICAgIHJldHVybiB7XG4gICAgICAgIGRpc3Bvc2U6IGRvU2h1dGRvd24sXG4gICAgfTtcbn1cbiIsICIvKipcbiAqIEV4dGVuc2lvbiBcdTVCNTBcdThGREJcdTdBMEIgKipmb3JrIHByZWxvYWQqKiBcdTIwMTRcdTIwMTQgXHU2NTJGXHU2MzAxXCJcdTk2RjYgaW1wb3J0XCJcdTc2ODRcdTc1MjhcdTYyMzdcdTU5NTFcdTdFQTZcdTMwMDJcbiAqXG4gKiBcdTI1MDBcdTI1MDAgXHU0RTNBXHU0RUMwXHU0RTQ4XHU5NzAwXHU4OTgxXHU4RkQ5XHU0RTAwXHU1QzQyIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuICpcbiAqIFx1ODAwMVx1NTk1MVx1N0VBNlx1RkYxQVx1NzUyOFx1NjIzNyBidW5kbGUgXHU5ODc2XHU1QzQyXHU4QzAzIGBib290c3RyYXAoYXN5bmMgd2IgPT4gey4uLn0pYFx1RkYwQ1x1NTI2Rlx1NEY1Q1x1NzUyOFx1NUYwRlx1NTQyRlx1NTJBOFx1MzAwMlxuICogICAtIFx1N0YzQVx1NzBCOVx1RkYxQVx1NkJDRlx1NEUyQSBleHRlbnNpb24gXHU1RkM1XHU5ODdCIGBpbXBvcnQgeyBib290c3RyYXAgfSBmcm9tICdAZ2VuaWUvd29ya2J1ZGR5LWV4dGVuc2lvbnMvcnVudGltZSdgXG4gKiAgIC0gXHU3RjNBXHU3MEI5XHVGRjFBYGJvb3RzdHJhcCgpYCBcdTc4NkNcdTdFRDEgYHByb2Nlc3MuKmBcdUZGMENcdTUyMDdcdTYzNjJcdTUyMzAgd29ya2VyIC8gXHU1NDA4XHU1RTc2XHU4RkRCXHU3QTBCXHU2NUY2XHU3NTI4XHU2MjM3XHU0RUUzXHU3ODAxXHU4OTgxXHU5MUNEXHU3RjE2XG4gKlxuICogXHU2NUIwXHU1OTUxXHU3RUE2XHVGRjFBXHU3NTI4XHU2MjM3IGJ1bmRsZSBcdTUzRUEgYGV4cG9ydCBhc3luYyBmdW5jdGlvbiBhY3RpdmF0ZSh3Yikgey4uLn1gXHVGRjBDXHU0RTBEIGltcG9ydCBcdTRFRkJcdTRGNTVcdTRFMUNcdTg5N0ZcdTMwMDJcbiAqICAgLSBcdThDMDFcdThDMDMgYWN0aXZhdGVcdUZGMUZcdTIwMTRcdTIwMTQgXHU2NzJDIHByZWxvYWQgXHU4RDFGXHU4RDIzXG4gKiAgIC0gUHJlbG9hZCBcdThGREJcdTdBMEIgPSBmb3JrIFx1NTFGQVx1NzY4NCBOb2RlIFx1NUI1MFx1OEZEQlx1N0EwQlx1RkYwQ1x1NTE0OFx1OEREMSBwcmVsb2FkIFx1OTAzQlx1OEY5MVx1RkYwOFx1NjNBMlx1NkQ0QiBhY3RpdmF0ZSArIFx1ODhDNVx1OTE0RCBlbnZcbiAqICAgICArIFx1OEMwMyBgcnVuRXh0ZW5zaW9uYFx1RkYwOVx1RkYwQ1x1NzUyOFx1NjIzNyBidW5kbGUgXHU4RDcwIGByZXF1aXJlKClgIFx1NTJBMFx1OEY3RFxuICpcbiAqIFx1MjUwMFx1MjUwMCBcdTg4QzVcdTkxNERcdTVDNDJcdTY2MkZcdTYwMEVcdTRFNDhcdTc1MjhcdTc2ODQgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG4gKlxuICogYGV4dGVuc2lvbi1ob3N0LW1hbmFnZXIudHNgIFx1OTFDQ1x1RkYxQVxuICogICBmb3JrKHByZWxvYWRDanNQYXRoLCBbbWFuaWZlc3QubWFpbl0sIHsgLi4uLCBlbnY6IHsgV0JfRVhURU5TSU9OX0lELCAuLi4gfSB9KVxuICogXHU4MDBDXHU0RTBEXHU2NjJGXHU4MDAxXHU3Njg0XHVGRjFBXG4gKiAgIGZvcmsobWFuaWZlc3QubWFpbiwgW10sIHsgLi4uIH0pXG4gKlxuICogXHU0RTVGXHU1QzMxXHU2NjJGXHU4QkY0IGZvcmsgXHU2NUY2IGFyZ3ZbMl0gXHU1QzMxXHU2NjJGXHU3NTI4XHU2MjM3IGJ1bmRsZSBcdTdFRERcdTVCRjlcdThERUZcdTVGODRcdUZGMENwcmVsb2FkIFx1OTFDQyBgcmVxdWlyZShwcm9jZXNzLmFyZ3ZbMl0pYFxuICogXHU1QjhDXHU2MjEwXHU1MkEwXHU4RjdEXHUzMDAyXG4gKlxuICogXHUyNTAwXHUyNTAwIFx1NTE3Q1x1NUJCOVx1NjcxRlx1RkYxQVx1NTQwQ1x1NjVGNlx1NjUyRlx1NjMwMVx1NjVCMFx1ODAwMVx1NTk1MVx1N0VBNiBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcbiAqXG4gKiAxLiBcdTc1MjhcdTYyMzcgYnVuZGxlIGV4cG9ydCBgYWN0aXZhdGVgIFx1MjE5MiBcdThENzBcdTY1QjBcdTU5NTFcdTdFQTZcdUZGMDhcdTY3MkMgcHJlbG9hZCBcdThDMDMgYHJ1bkV4dGVuc2lvbmBcdUZGMDlcbiAqIDIuIFx1NzUyOFx1NjIzNyBidW5kbGUgXHU5ODc2XHU1QzQyXHU4QzAzIGBib290c3RyYXAoKWAgXHU1MjZGXHU0RjVDXHU3NTI4IFx1MjE5MiBcdTgwMDFcdTU5NTFcdTdFQTZcdUZGMDhgcmVxdWlyZSgpYCBcdTY1RjZcdTUyNkZcdTRGNUNcdTc1MjhcdTVERjJcdThERDFcdTVCOENcdUZGMENcbiAqICAgIHByZWxvYWQgXHU2OEMwXHU2RDRCXHU0RTBEXHU1MjMwIGFjdGl2YXRlIGV4cG9ydFx1RkYwQ1x1NEVDMFx1NEU0OFx1OTBGRFx1NEUwRFx1NTA1QVx1NTM3M1x1NTNFRiBcdTIwMTRcdTIwMTQgXHU4MDAxIGJvb3RzdHJhcCBzaGltIFx1NTE4NVx1OTBFOFxuICogICAgXHU4MUVBXHU1REYxXHU0RjFBIGRldGVjdEVudiArIHJ1bkV4dGVuc2lvblx1RkYwQ1x1N0FFRlx1NTIzMFx1N0FFRlx1N0I0OVx1NEVGN1x1RkYwOVxuICogMy4gXHU0RTI0XHU4MDA1XHU5MEZEXHU2NzA5IFx1MjE5MiBcdTRGMThcdTUxNDggYWN0aXZhdGVcdUZGMENcdTVGRkRcdTc1NjUgYm9vdHN0cmFwIFx1OEMwM1x1NzUyOFx1RkYwOGBib290c3RyYXAoKWAgXHU5MUNDXHU3Njg0IGRldGVjdEVudiBcdTRGMUFcbiAqICAgIFx1NjhDMFx1NkQ0Qlx1NTIzMCBlbnYgXHU1REYyXHU4OEFCXHU2NzJDIHByZWxvYWQgXHU1MzYwXHU3NTI4XHU4MDBDXHU2MjlCXHU5NTE5XHVGRjFGXHU1QjlFXHU5NjQ1XHU0RTBBXHU0RTI0XHU4MDA1XHU0RTkyXHU0RTBEXHU3N0U1XHU5MDUzXHVGRjFCXHU4MDAxIGJvb3RzdHJhcCBcdThGRDhcdTY2MkZcdTRGMUFcbiAqICAgIFx1NTE4RFx1NUVGQVx1NEUwMFx1NEVGRCB0cmFuc3BvcnQgXHU4OTg2XHU3NkQ2XHVGRjBDXHU0RjQ2XHU1NkUwXHU0RTNBIElQQyBjaGFubmVsIFx1NTNFQVx1NjcwOVx1NEUwMFx1Njc2MVx1RkYwQ1x1NEYxQVx1OEUyOVx1OTFDRFx1RkYwOVxuICpcbiAqIFx1MjUwMFx1MjUwMCBcdTdCODBcdTUzMTYgJiBcdTYyNTNcdTUzMDUgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG4gKlxuICogXHU2NzJDXHU2NTg3XHU0RUY2XHU4RDcwIGVzYnVpbGQgXHU1MzU1XHU3MkVDXHU2MjUzXHU1MzA1XHU2MjEwIGBsaWIvcnVudGltZS9wcmVsb2FkL2ZvcmstcHJlbG9hZC5janNgXHVGRjBDXG4gKiBzZWxmLWNvbnRhaW5lZFx1RkYwOFx1NEUwRFx1NEY5RFx1OEQ1NiB3b3JrYnVkZHktZXh0ZW5zaW9ucyBcdTUxNzZcdTRFRDYgbGliIFx1NEVBN1x1NzI2OVx1RkYwOVx1RkYwQ1x1ODhDNVx1OTE0RFx1NUM0MiBmb3JrIFx1NjVGNlx1NzUyOFxuICogXHU3RUREXHU1QkY5XHU4REVGXHU1Rjg0XHU1QkZCXHU1NzQwXHU1MzczXHU1M0VGXHUzMDAyXG4gKi9cblxuaW1wb3J0IHsgY3JlYXRlUHJvY2Vzc0VudiB9IGZyb20gJy4uL2NvcmUvcHJvY2Vzcy1lbnYnO1xuaW1wb3J0IHsgdHlwZSBFeHRlbnNpb25BY3RpdmF0ZSwgcnVuRXh0ZW5zaW9uIH0gZnJvbSAnLi4vY29yZS9ydW4tZXh0ZW5zaW9uJztcblxuLyoqIFx1NEVDRSBDSlMvRVNNIFx1NkRGN1x1NTQwOCBtb2R1bGUgXHU1QkZDXHU1MUZBXHU5MUNDXHU2M0EyXHU2RDRCIGFjdGl2YXRlIFx1NTFGRFx1NjU3MFx1MzAwMiAqL1xuZnVuY3Rpb24gcmVzb2x2ZUFjdGl2YXRlKG1vZDogdW5rbm93bik6IEV4dGVuc2lvbkFjdGl2YXRlIHwgdW5kZWZpbmVkIHtcbiAgICBpZiAoIW1vZCB8fCB0eXBlb2YgbW9kICE9PSAnb2JqZWN0JykgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gICAgY29uc3QgbSA9IG1vZCBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPjtcblxuICAgIC8vIDEuIEVTTSBpbnRlcm9wXHVGRjFBYGV4cG9ydCBhc3luYyBmdW5jdGlvbiBhY3RpdmF0ZWAgXHUyMTkyIGVzYnVpbGQgQ0pTIFx1NEVBN1x1NzI2OVx1NjYyRiBgZXhwb3J0cy5hY3RpdmF0ZWBcbiAgICBpZiAodHlwZW9mIG0uYWN0aXZhdGUgPT09ICdmdW5jdGlvbicpIHtcbiAgICAgICAgcmV0dXJuIG0uYWN0aXZhdGUgYXMgRXh0ZW5zaW9uQWN0aXZhdGU7XG4gICAgfVxuICAgIC8vIDIuIEVTTSBkZWZhdWx0IGV4cG9ydCBcdTkxQ0NcdTYzMDIgYWN0aXZhdGVcdUZGMUFgZXhwb3J0IGRlZmF1bHQgeyBhY3RpdmF0ZSB9YFxuICAgIGNvbnN0IGRlZiA9IG0uZGVmYXVsdDtcbiAgICBpZiAoZGVmICYmIHR5cGVvZiBkZWYgPT09ICdvYmplY3QnICYmIHR5cGVvZiAoZGVmIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+KS5hY3RpdmF0ZSA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgICByZXR1cm4gKGRlZiBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPikuYWN0aXZhdGUgYXMgRXh0ZW5zaW9uQWN0aXZhdGU7XG4gICAgfVxuICAgIC8vIDMuIGBleHBvcnQgZGVmYXVsdCBhc3luYyBmdW5jdGlvbiBhY3RpdmF0ZWAgXHUyMTkyIFx1NTM1NVx1NzJFQ1x1NEUwMFx1NEUyQVx1NTFGRFx1NjU3MFx1NUY1MyBkZWZhdWx0XG4gICAgaWYgKHR5cGVvZiBkZWYgPT09ICdmdW5jdGlvbicpIHtcbiAgICAgICAgcmV0dXJuIGRlZiBhcyBFeHRlbnNpb25BY3RpdmF0ZTtcbiAgICB9XG4gICAgcmV0dXJuIHVuZGVmaW5lZDtcbn1cblxuYXN5bmMgZnVuY3Rpb24gbWFpbigpOiBQcm9taXNlPHZvaWQ+IHtcbiAgICBjb25zdCBleHRlbnNpb25JZCA9IHByb2Nlc3MuZW52LldCX0VYVEVOU0lPTl9JRCA/PyAnPHVua25vd24+JztcbiAgICBjb25zdCB1c2VyRW50cnkgPSBwcm9jZXNzLmFyZ3ZbMl07XG5cbiAgICBpZiAoIXVzZXJFbnRyeSkge1xuICAgICAgICBjb25zb2xlLmVycm9yKGBbZm9yay1wcmVsb2FkOiR7ZXh0ZW5zaW9uSWR9XSB1c2VyIGVudHJ5IHBhdGggbWlzc2luZyAoYXJndlsyXSlgKTtcbiAgICAgICAgcHJvY2Vzcy5leGl0KDEpO1xuICAgIH1cblxuICAgIC8vIFx1NTJBMFx1OEY3RFx1NzUyOFx1NjIzNyBidW5kbGVcdTMwMDJcbiAgICAvL1xuICAgIC8vIFx1MjZBMFx1RkUwRiBcdTY1RjZcdTVFOEZcdThCQkVcdThCQTFcdUZGMUEqKlx1NTE0OCoqIHJlcXVpcmUgXHU3NTI4XHU2MjM3IGJ1bmRsZVx1RkYwQyoqXHU1NDBFKiogXHU1RUZBIGVudiAvIFx1OEMwMyBydW5FeHRlbnNpb25cdTMwMDJcbiAgICAvL1xuICAgIC8vIFx1NTM5Rlx1NTZFMFx1RkYxQVx1NzUyOFx1NjIzNyBidW5kbGUgXHU5ODc2XHU1QzQyXHU1M0VGXHU4MEZEXHU2NjJGXHU4MDAxXHU1OTUxXHU3RUE2IGBib290c3RyYXAoZm4pYCBcdTUyNkZcdTRGNUNcdTc1MjhcdTVGMEZcdTU0MkZcdTUyQThcdTMwMDJcbiAgICAvLyBgcmVxdWlyZSgpYCBcdTVCOENcdTYyMTBcdTY1RjZcdUZGMUFcbiAgICAvLyAgIC0gXHU2NUIwXHU1OTUxXHU3RUE2XHVGRjFBZXhwb3J0cy5hY3RpdmF0ZSBcdTVERjJcdTYzMDJcdTRFMEFcdUZGMENcdTY3MkMgcHJlbG9hZCBcdTdFRTdcdTdFRURcdThENzAgYWN0aXZhdGUgXHU4REVGXHU1Rjg0XG4gICAgLy8gICAtIFx1ODAwMVx1NTk1MVx1N0VBNlx1RkYxQWJvb3RzdHJhcCgpIFx1NURGMlx1ODhBQlx1OTg3Nlx1NUM0Mlx1OEMwM1x1NzUyOFx1RkYwOFx1NTE4NVx1OTBFOFx1NEYxQVx1ODFFQVx1NURGMSBkZXRlY3RFbnYgKyBjcmVhdGVQcm9jZXNzRW52ICtcbiAgICAvLyAgICAgcnVuRXh0ZW5zaW9uXHVGRjA5XHVGRjBDXHU2NzJDIHByZWxvYWQgXHU2OEMwXHU2RDRCXHU0RTBEXHU1MjMwIGFjdGl2YXRlIGV4cG9ydFx1RkYwQ1x1NzZGNFx1NjNBNSByZXR1cm5cdUZGMENcdTRFMERcdTUxOERcdTkxQ0RcdTU5MERcdTVFRkEgZW52XG4gICAgLy9cbiAgICAvLyBcdTRFM0FcdTRFQzBcdTRFNDhcdTgwMDFcdTU5NTFcdTdFQTZcdTgwRkRcIlx1ODFFQVx1NjEwOFwiXHVGRjFBXHU4MDAxIGJvb3RzdHJhcCBzaGltIChgZXh0ZW5zaW9uLWVudHJ5LnRzYCkgXHU3Njg0IGBkZXRlY3RFbnYoKWBcbiAgICAvLyBcdTRGMUFcdThENzAgYHR5cGVvZiBwcm9jZXNzLnNlbmQgPT09ICdmdW5jdGlvbidgIFx1NTIwNlx1NjUyRlx1ODFFQVx1NURGMVx1NUVGQSBQcm9jZXNzRW52XHUzMDAycHJlbG9hZCBcdTkxQ0NcdTRFMERcbiAgICAvLyBcdTYzRDBcdTUyNERcdTVFRkEgZW52XHVGRjBDXHU5MDdGXHU1MTREXHU0RTI0XHU0RUZEIHRyYW5zcG9ydCBcdTYyQTJcdTU0MENcdTRFMDBcdTY3NjEgSVBDIGNoYW5uZWxcdTMwMDJcbiAgICAvL1xuICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvbm8tcmVxdWlyZS1pbXBvcnRzXG4gICAgY29uc3QgdXNlck1vZHVsZSA9IHJlcXVpcmUodXNlckVudHJ5KSBhcyB1bmtub3duO1xuXG4gICAgY29uc3QgYWN0aXZhdGUgPSByZXNvbHZlQWN0aXZhdGUodXNlck1vZHVsZSk7XG4gICAgaWYgKCFhY3RpdmF0ZSkge1xuICAgICAgICAvLyBcdTgwMDFcdTU5NTFcdTdFQTZcdTUxNUNcdTVFOTVcdUZGMUFidW5kbGUgXHU5ODc2XHU1QzQyIGJvb3RzdHJhcChmbikgXHU1MjZGXHU0RjVDXHU3NTI4XHU1REYyXHU4REQxXHU1QjhDXHVGRjBDcHJlbG9hZCBcdTY1RTBcdTk3MDBcdTUxOERcdTUwNUFcdTMwMDJcbiAgICAgICAgLy8gXHU1OTgyXHU2NzlDIGJ1bmRsZSBcdTkxQ0NcdTY1RTJcdTZDQTEgYWN0aXZhdGUgXHU1M0M4XHU2Q0ExXHU4QzAzIGJvb3RzdHJhcCBcdTIwMTRcdTIwMTQgXHU5MEEzXHU1QzMxXHU2NjJGXHU0RTJBXHU3QTdBIGV4dGVuc2lvblx1RkYwQ1xuICAgICAgICAvLyBcdTRFNUZcdTY1RTBcdTYyNDBcdThDMTNcdUZGMENcdThGREJcdTdBMEJcdTRGMUFcdTU2RTBcdTRFM0EgSVBDIGNoYW5uZWwgXHU0RkREXHU2MzAxXHU4RkRFXHU2M0E1XHU4MDBDXHU0RTBEXHU5MDAwXHU1MUZBXHUzMDAyXG4gICAgICAgIGNvbnNvbGUubG9nKFxuICAgICAgICAgICAgYFtmb3JrLXByZWxvYWQ6JHtleHRlbnNpb25JZH1dIG5vICdhY3RpdmF0ZScgZXhwb3J0OyBhc3N1bWluZyBsZWdhY3kgYm9vdHN0cmFwKCkgc2lkZS1lZmZlY3RgLFxuICAgICAgICApO1xuICAgICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgLy8gXHU2NUIwXHU1OTUxXHU3RUE2XHVGRjFBXHU2NzJDIHByZWxvYWQgXHU1QjhDXHU2MjEwXHU4OEM1XHU5MTREICsgXHU4QzAzIGFjdGl2YXRlXHUzMDAyXG4gICAgY29uc3QgZW52ID0gY3JlYXRlUHJvY2Vzc0VudigpO1xuICAgIGF3YWl0IHJ1bkV4dGVuc2lvbih7IGV4dGVuc2lvbklkLCBlbnYsIGFjdGl2YXRlIH0pO1xufVxuXG5tYWluKCkuY2F0Y2goKGVycjogdW5rbm93bikgPT4ge1xuICAgIGNvbnNvbGUuZXJyb3IoXG4gICAgICAgIGBbZm9yay1wcmVsb2FkOiR7cHJvY2Vzcy5lbnYuV0JfRVhURU5TSU9OX0lEID8/ICc8dW5rbm93bj4nfV0gZmF0YWw6YCxcbiAgICAgICAgZXJyIGluc3RhbmNlb2YgRXJyb3IgPyBlcnIuc3RhY2sgPz8gZXJyLm1lc3NhZ2UgOiBlcnIsXG4gICAgKTtcbiAgICBwcm9jZXNzLmV4aXQoMSk7XG59KTtcbiJdLAogICJtYXBwaW5ncyI6ICI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQUEsaUdBQUFBLFVBQUFDLFNBQUE7QUFBQSxJQUFBQSxRQUFPLFVBQVU7QUFFakIsYUFBUyxPQUFPLEtBQUssS0FBSztBQUN4QixVQUFJLENBQUM7QUFDSCxjQUFNLElBQUksTUFBTSxPQUFPLGtCQUFrQjtBQUFBLElBQzdDO0FBRUEsV0FBTyxRQUFRLFNBQVMsWUFBWSxHQUFHLEdBQUcsS0FBSztBQUM3QyxVQUFJLEtBQUs7QUFDUCxjQUFNLElBQUksTUFBTSxPQUFRLHVCQUF1QixJQUFJLFNBQVMsQ0FBRTtBQUFBLElBQ2xFO0FBQUE7QUFBQTs7O0FDVkE7QUFBQSxzRkFBQUMsVUFBQUMsU0FBQTtBQUFBLFFBQUksT0FBTyxPQUFPLFdBQVcsWUFBWTtBQUV2QyxNQUFBQSxRQUFPLFVBQVUsU0FBUyxTQUFTLE1BQU0sV0FBVztBQUNsRCxZQUFJLFdBQVc7QUFDYixlQUFLLFNBQVM7QUFDZCxlQUFLLFlBQVksT0FBTyxPQUFPLFVBQVUsV0FBVztBQUFBLFlBQ2xELGFBQWE7QUFBQSxjQUNYLE9BQU87QUFBQSxjQUNQLFlBQVk7QUFBQSxjQUNaLFVBQVU7QUFBQSxjQUNWLGNBQWM7QUFBQSxZQUNoQjtBQUFBLFVBQ0YsQ0FBQztBQUFBLFFBQ0g7QUFBQSxNQUNGO0FBQUEsSUFDRixPQUFPO0FBRUwsTUFBQUEsUUFBTyxVQUFVLFNBQVMsU0FBUyxNQUFNLFdBQVc7QUFDbEQsWUFBSSxXQUFXO0FBQ2IsZUFBSyxTQUFTO0FBQ2QsY0FBSSxXQUFXLFdBQVk7QUFBQSxVQUFDO0FBQzVCLG1CQUFTLFlBQVksVUFBVTtBQUMvQixlQUFLLFlBQVksSUFBSSxTQUFTO0FBQzlCLGVBQUssVUFBVSxjQUFjO0FBQUEsUUFDL0I7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUFBO0FBQUE7OztBQzFCQTtBQUFBLDhFQUFBQyxVQUFBQyxTQUFBO0FBQUEsUUFBSTtBQUNFLGFBQU8sUUFBUSxNQUFNO0FBRXpCLFVBQUksT0FBTyxLQUFLLGFBQWE7QUFBWSxjQUFNO0FBQy9DLE1BQUFBLFFBQU8sVUFBVSxLQUFLO0FBQUEsSUFDeEIsU0FBUyxHQUFHO0FBRVYsTUFBQUEsUUFBTyxVQUFVO0FBQUEsSUFDbkI7QUFQTTtBQUFBO0FBQUE7OztBQ0ROO0FBQUEsa0ZBQUFDLFVBQUE7QUFBQTtBQUVBLFFBQUksU0FBUztBQUNiLFFBQUksV0FBVztBQUVmLElBQUFBLFNBQVEsV0FBVztBQUVuQixhQUFTLGdCQUFnQixLQUFLLEdBQUc7QUFDL0IsV0FBSyxJQUFJLFdBQVcsQ0FBQyxJQUFJLFdBQVksT0FBUTtBQUMzQyxlQUFPO0FBQUEsTUFDVDtBQUNBLFVBQUksSUFBSSxLQUFLLElBQUksS0FBSyxJQUFJLFFBQVE7QUFDaEMsZUFBTztBQUFBLE1BQ1Q7QUFDQSxjQUFRLElBQUksV0FBVyxJQUFJLENBQUMsSUFBSSxXQUFZO0FBQUEsSUFDOUM7QUFFQSxhQUFTLFFBQVEsS0FBSyxLQUFLO0FBQ3pCLFVBQUksTUFBTSxRQUFRLEdBQUc7QUFDbkIsZUFBTyxJQUFJLE1BQU07QUFDbkIsVUFBSSxDQUFDO0FBQ0gsZUFBTyxDQUFDO0FBQ1YsVUFBSSxNQUFNLENBQUM7QUFDWCxVQUFJLE9BQU8sUUFBUSxVQUFVO0FBQzNCLFlBQUksQ0FBQyxLQUFLO0FBS1IsY0FBSSxJQUFJO0FBQ1IsbUJBQVMsSUFBSSxHQUFHLElBQUksSUFBSSxRQUFRLEtBQUs7QUFDbkMsZ0JBQUksSUFBSSxJQUFJLFdBQVcsQ0FBQztBQUN4QixnQkFBSSxJQUFJLEtBQUs7QUFDWCxrQkFBSSxHQUFHLElBQUk7QUFBQSxZQUNiLFdBQVcsSUFBSSxNQUFNO0FBQ25CLGtCQUFJLEdBQUcsSUFBSyxLQUFLLElBQUs7QUFDdEIsa0JBQUksR0FBRyxJQUFLLElBQUksS0FBTTtBQUFBLFlBQ3hCLFdBQVcsZ0JBQWdCLEtBQUssQ0FBQyxHQUFHO0FBQ2xDLGtCQUFJLFVBQVksSUFBSSxTQUFXLE9BQU8sSUFBSSxXQUFXLEVBQUUsQ0FBQyxJQUFJO0FBQzVELGtCQUFJLEdBQUcsSUFBSyxLQUFLLEtBQU07QUFDdkIsa0JBQUksR0FBRyxJQUFNLEtBQUssS0FBTSxLQUFNO0FBQzlCLGtCQUFJLEdBQUcsSUFBTSxLQUFLLElBQUssS0FBTTtBQUM3QixrQkFBSSxHQUFHLElBQUssSUFBSSxLQUFNO0FBQUEsWUFDeEIsT0FBTztBQUNMLGtCQUFJLEdBQUcsSUFBSyxLQUFLLEtBQU07QUFDdkIsa0JBQUksR0FBRyxJQUFNLEtBQUssSUFBSyxLQUFNO0FBQzdCLGtCQUFJLEdBQUcsSUFBSyxJQUFJLEtBQU07QUFBQSxZQUN4QjtBQUFBLFVBQ0Y7QUFBQSxRQUNGLFdBQVcsUUFBUSxPQUFPO0FBQ3hCLGdCQUFNLElBQUksUUFBUSxnQkFBZ0IsRUFBRTtBQUNwQyxjQUFJLElBQUksU0FBUyxNQUFNO0FBQ3JCLGtCQUFNLE1BQU07QUFDZCxlQUFLLElBQUksR0FBRyxJQUFJLElBQUksUUFBUSxLQUFLO0FBQy9CLGdCQUFJLEtBQUssU0FBUyxJQUFJLENBQUMsSUFBSSxJQUFJLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQztBQUFBLFFBQzlDO0FBQUEsTUFDRixPQUFPO0FBQ0wsYUFBSyxJQUFJLEdBQUcsSUFBSSxJQUFJLFFBQVE7QUFDMUIsY0FBSSxDQUFDLElBQUksSUFBSSxDQUFDLElBQUk7QUFBQSxNQUN0QjtBQUNBLGFBQU87QUFBQSxJQUNUO0FBQ0EsSUFBQUEsU0FBUSxVQUFVO0FBRWxCLGFBQVMsTUFBTSxLQUFLO0FBQ2xCLFVBQUksTUFBTTtBQUNWLGVBQVMsSUFBSSxHQUFHLElBQUksSUFBSSxRQUFRO0FBQzlCLGVBQU8sTUFBTSxJQUFJLENBQUMsRUFBRSxTQUFTLEVBQUUsQ0FBQztBQUNsQyxhQUFPO0FBQUEsSUFDVDtBQUNBLElBQUFBLFNBQVEsUUFBUTtBQUVoQixhQUFTLE1BQU0sR0FBRztBQUNoQixVQUFJLE1BQU8sTUFBTSxLQUNMLE1BQU0sSUFBSyxRQUNYLEtBQUssSUFBSyxZQUNWLElBQUksUUFBUztBQUN6QixhQUFPLFFBQVE7QUFBQSxJQUNqQjtBQUNBLElBQUFBLFNBQVEsUUFBUTtBQUVoQixhQUFTLFFBQVEsS0FBSyxRQUFRO0FBQzVCLFVBQUksTUFBTTtBQUNWLGVBQVMsSUFBSSxHQUFHLElBQUksSUFBSSxRQUFRLEtBQUs7QUFDbkMsWUFBSSxJQUFJLElBQUksQ0FBQztBQUNiLFlBQUksV0FBVztBQUNiLGNBQUksTUFBTSxDQUFDO0FBQ2IsZUFBTyxNQUFNLEVBQUUsU0FBUyxFQUFFLENBQUM7QUFBQSxNQUM3QjtBQUNBLGFBQU87QUFBQSxJQUNUO0FBQ0EsSUFBQUEsU0FBUSxVQUFVO0FBRWxCLGFBQVMsTUFBTSxNQUFNO0FBQ25CLFVBQUksS0FBSyxXQUFXO0FBQ2xCLGVBQU8sTUFBTTtBQUFBO0FBRWIsZUFBTztBQUFBLElBQ1g7QUFDQSxJQUFBQSxTQUFRLFFBQVE7QUFFaEIsYUFBUyxNQUFNLE1BQU07QUFDbkIsVUFBSSxLQUFLLFdBQVc7QUFDbEIsZUFBTyxNQUFNO0FBQUEsZUFDTixLQUFLLFdBQVc7QUFDdkIsZUFBTyxPQUFPO0FBQUEsZUFDUCxLQUFLLFdBQVc7QUFDdkIsZUFBTyxRQUFRO0FBQUEsZUFDUixLQUFLLFdBQVc7QUFDdkIsZUFBTyxTQUFTO0FBQUEsZUFDVCxLQUFLLFdBQVc7QUFDdkIsZUFBTyxVQUFVO0FBQUEsZUFDVixLQUFLLFdBQVc7QUFDdkIsZUFBTyxXQUFXO0FBQUEsZUFDWCxLQUFLLFdBQVc7QUFDdkIsZUFBTyxZQUFZO0FBQUE7QUFFbkIsZUFBTztBQUFBLElBQ1g7QUFDQSxJQUFBQSxTQUFRLFFBQVE7QUFFaEIsYUFBUyxPQUFPLEtBQUssT0FBTyxLQUFLLFFBQVE7QUFDdkMsVUFBSSxNQUFNLE1BQU07QUFDaEIsYUFBTyxNQUFNLE1BQU0sQ0FBQztBQUNwQixVQUFJLE1BQU0sSUFBSSxNQUFNLE1BQU0sQ0FBQztBQUMzQixlQUFTLElBQUksR0FBRyxJQUFJLE9BQU8sSUFBSSxJQUFJLFFBQVEsS0FBSyxLQUFLLEdBQUc7QUFDdEQsWUFBSTtBQUNKLFlBQUksV0FBVztBQUNiLGNBQUssSUFBSSxDQUFDLEtBQUssS0FBTyxJQUFJLElBQUksQ0FBQyxLQUFLLEtBQU8sSUFBSSxJQUFJLENBQUMsS0FBSyxJQUFLLElBQUksSUFBSSxDQUFDO0FBQUE7QUFFdkUsY0FBSyxJQUFJLElBQUksQ0FBQyxLQUFLLEtBQU8sSUFBSSxJQUFJLENBQUMsS0FBSyxLQUFPLElBQUksSUFBSSxDQUFDLEtBQUssSUFBSyxJQUFJLENBQUM7QUFDekUsWUFBSSxDQUFDLElBQUksTUFBTTtBQUFBLE1BQ2pCO0FBQ0EsYUFBTztBQUFBLElBQ1Q7QUFDQSxJQUFBQSxTQUFRLFNBQVM7QUFFakIsYUFBUyxRQUFRLEtBQUssUUFBUTtBQUM1QixVQUFJLE1BQU0sSUFBSSxNQUFNLElBQUksU0FBUyxDQUFDO0FBQ2xDLGVBQVMsSUFBSSxHQUFHLElBQUksR0FBRyxJQUFJLElBQUksUUFBUSxLQUFLLEtBQUssR0FBRztBQUNsRCxZQUFJLElBQUksSUFBSSxDQUFDO0FBQ2IsWUFBSSxXQUFXLE9BQU87QUFDcEIsY0FBSSxDQUFDLElBQUksTUFBTTtBQUNmLGNBQUksSUFBSSxDQUFDLElBQUssTUFBTSxLQUFNO0FBQzFCLGNBQUksSUFBSSxDQUFDLElBQUssTUFBTSxJQUFLO0FBQ3pCLGNBQUksSUFBSSxDQUFDLElBQUksSUFBSTtBQUFBLFFBQ25CLE9BQU87QUFDTCxjQUFJLElBQUksQ0FBQyxJQUFJLE1BQU07QUFDbkIsY0FBSSxJQUFJLENBQUMsSUFBSyxNQUFNLEtBQU07QUFDMUIsY0FBSSxJQUFJLENBQUMsSUFBSyxNQUFNLElBQUs7QUFDekIsY0FBSSxDQUFDLElBQUksSUFBSTtBQUFBLFFBQ2Y7QUFBQSxNQUNGO0FBQ0EsYUFBTztBQUFBLElBQ1Q7QUFDQSxJQUFBQSxTQUFRLFVBQVU7QUFFbEIsYUFBUyxPQUFPLEdBQUcsR0FBRztBQUNwQixhQUFRLE1BQU0sSUFBTSxLQUFNLEtBQUs7QUFBQSxJQUNqQztBQUNBLElBQUFBLFNBQVEsU0FBUztBQUVqQixhQUFTLE9BQU8sR0FBRyxHQUFHO0FBQ3BCLGFBQVEsS0FBSyxJQUFNLE1BQU8sS0FBSztBQUFBLElBQ2pDO0FBQ0EsSUFBQUEsU0FBUSxTQUFTO0FBRWpCLGFBQVMsTUFBTSxHQUFHLEdBQUc7QUFDbkIsYUFBUSxJQUFJLE1BQU87QUFBQSxJQUNyQjtBQUNBLElBQUFBLFNBQVEsUUFBUTtBQUVoQixhQUFTLFFBQVEsR0FBRyxHQUFHLEdBQUc7QUFDeEIsYUFBUSxJQUFJLElBQUksTUFBTztBQUFBLElBQ3pCO0FBQ0EsSUFBQUEsU0FBUSxVQUFVO0FBRWxCLGFBQVMsUUFBUSxHQUFHLEdBQUcsR0FBRyxHQUFHO0FBQzNCLGFBQVEsSUFBSSxJQUFJLElBQUksTUFBTztBQUFBLElBQzdCO0FBQ0EsSUFBQUEsU0FBUSxVQUFVO0FBRWxCLGFBQVMsUUFBUSxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUc7QUFDOUIsYUFBUSxJQUFJLElBQUksSUFBSSxJQUFJLE1BQU87QUFBQSxJQUNqQztBQUNBLElBQUFBLFNBQVEsVUFBVTtBQUVsQixhQUFTLE1BQU0sS0FBSyxLQUFLLElBQUksSUFBSTtBQUMvQixVQUFJLEtBQUssSUFBSSxHQUFHO0FBQ2hCLFVBQUksS0FBSyxJQUFJLE1BQU0sQ0FBQztBQUVwQixVQUFJLEtBQU0sS0FBSyxPQUFRO0FBQ3ZCLFVBQUksTUFBTSxLQUFLLEtBQUssSUFBSSxLQUFLLEtBQUs7QUFDbEMsVUFBSSxHQUFHLElBQUksT0FBTztBQUNsQixVQUFJLE1BQU0sQ0FBQyxJQUFJO0FBQUEsSUFDakI7QUFDQSxJQUFBQSxTQUFRLFFBQVE7QUFFaEIsYUFBUyxTQUFTLElBQUksSUFBSSxJQUFJLElBQUk7QUFDaEMsVUFBSSxLQUFNLEtBQUssT0FBUTtBQUN2QixVQUFJLE1BQU0sS0FBSyxLQUFLLElBQUksS0FBSyxLQUFLO0FBQ2xDLGFBQU8sT0FBTztBQUFBLElBQ2hCO0FBQ0EsSUFBQUEsU0FBUSxXQUFXO0FBRW5CLGFBQVMsU0FBUyxJQUFJLElBQUksSUFBSSxJQUFJO0FBQ2hDLFVBQUksS0FBSyxLQUFLO0FBQ2QsYUFBTyxPQUFPO0FBQUEsSUFDaEI7QUFDQSxJQUFBQSxTQUFRLFdBQVc7QUFFbkIsYUFBUyxXQUFXLElBQUksSUFBSSxJQUFJLElBQUksSUFBSSxJQUFJLElBQUksSUFBSTtBQUNsRCxVQUFJLFFBQVE7QUFDWixVQUFJLEtBQUs7QUFDVCxXQUFNLEtBQUssT0FBUTtBQUNuQixlQUFTLEtBQUssS0FBSyxJQUFJO0FBQ3ZCLFdBQU0sS0FBSyxPQUFRO0FBQ25CLGVBQVMsS0FBSyxLQUFLLElBQUk7QUFDdkIsV0FBTSxLQUFLLE9BQVE7QUFDbkIsZUFBUyxLQUFLLEtBQUssSUFBSTtBQUV2QixVQUFJLEtBQUssS0FBSyxLQUFLLEtBQUssS0FBSztBQUM3QixhQUFPLE9BQU87QUFBQSxJQUNoQjtBQUNBLElBQUFBLFNBQVEsYUFBYTtBQUVyQixhQUFTLFdBQVcsSUFBSSxJQUFJLElBQUksSUFBSSxJQUFJLElBQUksSUFBSSxJQUFJO0FBQ2xELFVBQUksS0FBSyxLQUFLLEtBQUssS0FBSztBQUN4QixhQUFPLE9BQU87QUFBQSxJQUNoQjtBQUNBLElBQUFBLFNBQVEsYUFBYTtBQUVyQixhQUFTLFdBQVcsSUFBSSxJQUFJLElBQUksSUFBSSxJQUFJLElBQUksSUFBSSxJQUFJLElBQUksSUFBSTtBQUMxRCxVQUFJLFFBQVE7QUFDWixVQUFJLEtBQUs7QUFDVCxXQUFNLEtBQUssT0FBUTtBQUNuQixlQUFTLEtBQUssS0FBSyxJQUFJO0FBQ3ZCLFdBQU0sS0FBSyxPQUFRO0FBQ25CLGVBQVMsS0FBSyxLQUFLLElBQUk7QUFDdkIsV0FBTSxLQUFLLE9BQVE7QUFDbkIsZUFBUyxLQUFLLEtBQUssSUFBSTtBQUN2QixXQUFNLEtBQUssT0FBUTtBQUNuQixlQUFTLEtBQUssS0FBSyxJQUFJO0FBRXZCLFVBQUksS0FBSyxLQUFLLEtBQUssS0FBSyxLQUFLLEtBQUs7QUFDbEMsYUFBTyxPQUFPO0FBQUEsSUFDaEI7QUFDQSxJQUFBQSxTQUFRLGFBQWE7QUFFckIsYUFBUyxXQUFXLElBQUksSUFBSSxJQUFJLElBQUksSUFBSSxJQUFJLElBQUksSUFBSSxJQUFJLElBQUk7QUFDMUQsVUFBSSxLQUFLLEtBQUssS0FBSyxLQUFLLEtBQUs7QUFFN0IsYUFBTyxPQUFPO0FBQUEsSUFDaEI7QUFDQSxJQUFBQSxTQUFRLGFBQWE7QUFFckIsYUFBUyxVQUFVLElBQUksSUFBSSxLQUFLO0FBQzlCLFVBQUksSUFBSyxNQUFPLEtBQUssTUFBUyxPQUFPO0FBQ3JDLGFBQU8sTUFBTTtBQUFBLElBQ2Y7QUFDQSxJQUFBQSxTQUFRLFlBQVk7QUFFcEIsYUFBUyxVQUFVLElBQUksSUFBSSxLQUFLO0FBQzlCLFVBQUksSUFBSyxNQUFPLEtBQUssTUFBUyxPQUFPO0FBQ3JDLGFBQU8sTUFBTTtBQUFBLElBQ2Y7QUFDQSxJQUFBQSxTQUFRLFlBQVk7QUFFcEIsYUFBUyxTQUFTLElBQUksSUFBSSxLQUFLO0FBQzdCLGFBQU8sT0FBTztBQUFBLElBQ2hCO0FBQ0EsSUFBQUEsU0FBUSxXQUFXO0FBRW5CLGFBQVMsU0FBUyxJQUFJLElBQUksS0FBSztBQUM3QixVQUFJLElBQUssTUFBTyxLQUFLLE1BQVMsT0FBTztBQUNyQyxhQUFPLE1BQU07QUFBQSxJQUNmO0FBQ0EsSUFBQUEsU0FBUSxXQUFXO0FBQUE7QUFBQTs7O0FDclJuQjtBQUFBLG1GQUFBQyxVQUFBO0FBQUE7QUFFQSxRQUFJLFFBQVE7QUFDWixRQUFJLFNBQVM7QUFFYixhQUFTLFlBQVk7QUFDbkIsV0FBSyxVQUFVO0FBQ2YsV0FBSyxlQUFlO0FBQ3BCLFdBQUssWUFBWSxLQUFLLFlBQVk7QUFDbEMsV0FBSyxVQUFVLEtBQUssWUFBWTtBQUNoQyxXQUFLLGVBQWUsS0FBSyxZQUFZO0FBQ3JDLFdBQUssWUFBWSxLQUFLLFlBQVksWUFBWTtBQUM5QyxXQUFLLFNBQVM7QUFFZCxXQUFLLFVBQVUsS0FBSyxZQUFZO0FBQ2hDLFdBQUssV0FBVyxLQUFLLFlBQVk7QUFBQSxJQUNuQztBQUNBLElBQUFBLFNBQVEsWUFBWTtBQUVwQixjQUFVLFVBQVUsU0FBUyxTQUFTLE9BQU8sS0FBSyxLQUFLO0FBRXJELFlBQU0sTUFBTSxRQUFRLEtBQUssR0FBRztBQUM1QixVQUFJLENBQUMsS0FBSztBQUNSLGFBQUssVUFBVTtBQUFBO0FBRWYsYUFBSyxVQUFVLEtBQUssUUFBUSxPQUFPLEdBQUc7QUFDeEMsV0FBSyxnQkFBZ0IsSUFBSTtBQUd6QixVQUFJLEtBQUssUUFBUSxVQUFVLEtBQUssU0FBUztBQUN2QyxjQUFNLEtBQUs7QUFHWCxZQUFJLElBQUksSUFBSSxTQUFTLEtBQUs7QUFDMUIsYUFBSyxVQUFVLElBQUksTUFBTSxJQUFJLFNBQVMsR0FBRyxJQUFJLE1BQU07QUFDbkQsWUFBSSxLQUFLLFFBQVEsV0FBVztBQUMxQixlQUFLLFVBQVU7QUFFakIsY0FBTSxNQUFNLE9BQU8sS0FBSyxHQUFHLElBQUksU0FBUyxHQUFHLEtBQUssTUFBTTtBQUN0RCxpQkFBUyxJQUFJLEdBQUcsSUFBSSxJQUFJLFFBQVEsS0FBSyxLQUFLO0FBQ3hDLGVBQUssUUFBUSxLQUFLLEdBQUcsSUFBSSxLQUFLLFFBQVE7QUFBQSxNQUMxQztBQUVBLGFBQU87QUFBQSxJQUNUO0FBRUEsY0FBVSxVQUFVLFNBQVMsU0FBUyxPQUFPLEtBQUs7QUFDaEQsV0FBSyxPQUFPLEtBQUssS0FBSyxDQUFDO0FBQ3ZCLGFBQU8sS0FBSyxZQUFZLElBQUk7QUFFNUIsYUFBTyxLQUFLLFFBQVEsR0FBRztBQUFBLElBQ3pCO0FBRUEsY0FBVSxVQUFVLE9BQU8sU0FBUyxNQUFNO0FBQ3hDLFVBQUksTUFBTSxLQUFLO0FBQ2YsVUFBSSxRQUFRLEtBQUs7QUFDakIsVUFBSSxJQUFJLFNBQVUsTUFBTSxLQUFLLGFBQWE7QUFDMUMsVUFBSSxNQUFNLElBQUksTUFBTSxJQUFJLEtBQUssU0FBUztBQUN0QyxVQUFJLENBQUMsSUFBSTtBQUNULGVBQVMsSUFBSSxHQUFHLElBQUksR0FBRztBQUNyQixZQUFJLENBQUMsSUFBSTtBQUdYLGNBQVE7QUFDUixVQUFJLEtBQUssV0FBVyxPQUFPO0FBQ3pCLGlCQUFTLElBQUksR0FBRyxJQUFJLEtBQUssV0FBVztBQUNsQyxjQUFJLEdBQUcsSUFBSTtBQUViLFlBQUksR0FBRyxJQUFJO0FBQ1gsWUFBSSxHQUFHLElBQUk7QUFDWCxZQUFJLEdBQUcsSUFBSTtBQUNYLFlBQUksR0FBRyxJQUFJO0FBQ1gsWUFBSSxHQUFHLElBQUssUUFBUSxLQUFNO0FBQzFCLFlBQUksR0FBRyxJQUFLLFFBQVEsS0FBTTtBQUMxQixZQUFJLEdBQUcsSUFBSyxRQUFRLElBQUs7QUFDekIsWUFBSSxHQUFHLElBQUksTUFBTTtBQUFBLE1BQ25CLE9BQU87QUFDTCxZQUFJLEdBQUcsSUFBSSxNQUFNO0FBQ2pCLFlBQUksR0FBRyxJQUFLLFFBQVEsSUFBSztBQUN6QixZQUFJLEdBQUcsSUFBSyxRQUFRLEtBQU07QUFDMUIsWUFBSSxHQUFHLElBQUssUUFBUSxLQUFNO0FBQzFCLFlBQUksR0FBRyxJQUFJO0FBQ1gsWUFBSSxHQUFHLElBQUk7QUFDWCxZQUFJLEdBQUcsSUFBSTtBQUNYLFlBQUksR0FBRyxJQUFJO0FBRVgsYUFBSyxJQUFJLEdBQUcsSUFBSSxLQUFLLFdBQVc7QUFDOUIsY0FBSSxHQUFHLElBQUk7QUFBQSxNQUNmO0FBRUEsYUFBTztBQUFBLElBQ1Q7QUFBQTtBQUFBOzs7QUMzRkEsSUFBQUMsa0JBQUE7QUFBQSx1RkFBQUMsVUFBQTtBQUFBO0FBRUEsUUFBSSxRQUFRO0FBQ1osUUFBSSxTQUFTLE1BQU07QUFFbkIsYUFBUyxLQUFLLEdBQUcsR0FBRyxHQUFHLEdBQUc7QUFDeEIsVUFBSSxNQUFNO0FBQ1IsZUFBTyxLQUFLLEdBQUcsR0FBRyxDQUFDO0FBQ3JCLFVBQUksTUFBTSxLQUFLLE1BQU07QUFDbkIsZUFBTyxJQUFJLEdBQUcsR0FBRyxDQUFDO0FBQ3BCLFVBQUksTUFBTTtBQUNSLGVBQU8sTUFBTSxHQUFHLEdBQUcsQ0FBQztBQUFBLElBQ3hCO0FBQ0EsSUFBQUEsU0FBUSxPQUFPO0FBRWYsYUFBUyxLQUFLLEdBQUcsR0FBRyxHQUFHO0FBQ3JCLGFBQVEsSUFBSSxJQUFPLENBQUMsSUFBSztBQUFBLElBQzNCO0FBQ0EsSUFBQUEsU0FBUSxPQUFPO0FBRWYsYUFBUyxNQUFNLEdBQUcsR0FBRyxHQUFHO0FBQ3RCLGFBQVEsSUFBSSxJQUFNLElBQUksSUFBTSxJQUFJO0FBQUEsSUFDbEM7QUFDQSxJQUFBQSxTQUFRLFFBQVE7QUFFaEIsYUFBUyxJQUFJLEdBQUcsR0FBRyxHQUFHO0FBQ3BCLGFBQU8sSUFBSSxJQUFJO0FBQUEsSUFDakI7QUFDQSxJQUFBQSxTQUFRLE1BQU07QUFFZCxhQUFTLE9BQU8sR0FBRztBQUNqQixhQUFPLE9BQU8sR0FBRyxDQUFDLElBQUksT0FBTyxHQUFHLEVBQUUsSUFBSSxPQUFPLEdBQUcsRUFBRTtBQUFBLElBQ3BEO0FBQ0EsSUFBQUEsU0FBUSxTQUFTO0FBRWpCLGFBQVMsT0FBTyxHQUFHO0FBQ2pCLGFBQU8sT0FBTyxHQUFHLENBQUMsSUFBSSxPQUFPLEdBQUcsRUFBRSxJQUFJLE9BQU8sR0FBRyxFQUFFO0FBQUEsSUFDcEQ7QUFDQSxJQUFBQSxTQUFRLFNBQVM7QUFFakIsYUFBUyxPQUFPLEdBQUc7QUFDakIsYUFBTyxPQUFPLEdBQUcsQ0FBQyxJQUFJLE9BQU8sR0FBRyxFQUFFLElBQUssTUFBTTtBQUFBLElBQy9DO0FBQ0EsSUFBQUEsU0FBUSxTQUFTO0FBRWpCLGFBQVMsT0FBTyxHQUFHO0FBQ2pCLGFBQU8sT0FBTyxHQUFHLEVBQUUsSUFBSSxPQUFPLEdBQUcsRUFBRSxJQUFLLE1BQU07QUFBQSxJQUNoRDtBQUNBLElBQUFBLFNBQVEsU0FBUztBQUFBO0FBQUE7OztBQ2hEakI7QUFBQSxrRkFBQUMsVUFBQUMsU0FBQTtBQUFBO0FBRUEsUUFBSSxRQUFRO0FBQ1osUUFBSSxTQUFTO0FBQ2IsUUFBSSxZQUFZO0FBRWhCLFFBQUksU0FBUyxNQUFNO0FBQ25CLFFBQUksUUFBUSxNQUFNO0FBQ2xCLFFBQUksVUFBVSxNQUFNO0FBQ3BCLFFBQUksT0FBTyxVQUFVO0FBQ3JCLFFBQUksWUFBWSxPQUFPO0FBRXZCLFFBQUksU0FBUztBQUFBLE1BQ1g7QUFBQSxNQUFZO0FBQUEsTUFDWjtBQUFBLE1BQVk7QUFBQSxJQUNkO0FBRUEsYUFBUyxPQUFPO0FBQ2QsVUFBSSxFQUFFLGdCQUFnQjtBQUNwQixlQUFPLElBQUksS0FBSztBQUVsQixnQkFBVSxLQUFLLElBQUk7QUFDbkIsV0FBSyxJQUFJO0FBQUEsUUFDUDtBQUFBLFFBQVk7QUFBQSxRQUFZO0FBQUEsUUFDeEI7QUFBQSxRQUFZO0FBQUEsTUFBVztBQUN6QixXQUFLLElBQUksSUFBSSxNQUFNLEVBQUU7QUFBQSxJQUN2QjtBQUVBLFVBQU0sU0FBUyxNQUFNLFNBQVM7QUFDOUIsSUFBQUEsUUFBTyxVQUFVO0FBRWpCLFNBQUssWUFBWTtBQUNqQixTQUFLLFVBQVU7QUFDZixTQUFLLGVBQWU7QUFDcEIsU0FBSyxZQUFZO0FBRWpCLFNBQUssVUFBVSxVQUFVLFNBQVMsUUFBUSxLQUFLLE9BQU87QUFDcEQsVUFBSSxJQUFJLEtBQUs7QUFFYixlQUFTLElBQUksR0FBRyxJQUFJLElBQUk7QUFDdEIsVUFBRSxDQUFDLElBQUksSUFBSSxRQUFRLENBQUM7QUFFdEIsYUFBTSxJQUFJLEVBQUUsUUFBUTtBQUNsQixVQUFFLENBQUMsSUFBSSxPQUFPLEVBQUUsSUFBSSxDQUFDLElBQUksRUFBRSxJQUFJLENBQUMsSUFBSSxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLEdBQUcsQ0FBQztBQUU5RCxVQUFJLElBQUksS0FBSyxFQUFFLENBQUM7QUFDaEIsVUFBSSxJQUFJLEtBQUssRUFBRSxDQUFDO0FBQ2hCLFVBQUksSUFBSSxLQUFLLEVBQUUsQ0FBQztBQUNoQixVQUFJLElBQUksS0FBSyxFQUFFLENBQUM7QUFDaEIsVUFBSSxJQUFJLEtBQUssRUFBRSxDQUFDO0FBRWhCLFdBQUssSUFBSSxHQUFHLElBQUksRUFBRSxRQUFRLEtBQUs7QUFDN0IsWUFBSSxJQUFJLENBQUMsRUFBRSxJQUFJO0FBQ2YsWUFBSSxJQUFJLFFBQVEsT0FBTyxHQUFHLENBQUMsR0FBRyxLQUFLLEdBQUcsR0FBRyxHQUFHLENBQUMsR0FBRyxHQUFHLEVBQUUsQ0FBQyxHQUFHLE9BQU8sQ0FBQyxDQUFDO0FBQ2xFLFlBQUk7QUFDSixZQUFJO0FBQ0osWUFBSSxPQUFPLEdBQUcsRUFBRTtBQUNoQixZQUFJO0FBQ0osWUFBSTtBQUFBLE1BQ047QUFFQSxXQUFLLEVBQUUsQ0FBQyxJQUFJLE1BQU0sS0FBSyxFQUFFLENBQUMsR0FBRyxDQUFDO0FBQzlCLFdBQUssRUFBRSxDQUFDLElBQUksTUFBTSxLQUFLLEVBQUUsQ0FBQyxHQUFHLENBQUM7QUFDOUIsV0FBSyxFQUFFLENBQUMsSUFBSSxNQUFNLEtBQUssRUFBRSxDQUFDLEdBQUcsQ0FBQztBQUM5QixXQUFLLEVBQUUsQ0FBQyxJQUFJLE1BQU0sS0FBSyxFQUFFLENBQUMsR0FBRyxDQUFDO0FBQzlCLFdBQUssRUFBRSxDQUFDLElBQUksTUFBTSxLQUFLLEVBQUUsQ0FBQyxHQUFHLENBQUM7QUFBQSxJQUNoQztBQUVBLFNBQUssVUFBVSxVQUFVLFNBQVMsT0FBTyxLQUFLO0FBQzVDLFVBQUksUUFBUTtBQUNWLGVBQU8sTUFBTSxRQUFRLEtBQUssR0FBRyxLQUFLO0FBQUE7QUFFbEMsZUFBTyxNQUFNLFFBQVEsS0FBSyxHQUFHLEtBQUs7QUFBQSxJQUN0QztBQUFBO0FBQUE7OztBQ3pFQSxJQUFBQyxhQUFBO0FBQUEsb0ZBQUFDLFVBQUFDLFNBQUE7QUFBQTtBQUVBLFFBQUksUUFBUTtBQUNaLFFBQUksU0FBUztBQUNiLFFBQUksWUFBWTtBQUNoQixRQUFJLFNBQVM7QUFFYixRQUFJLFFBQVEsTUFBTTtBQUNsQixRQUFJLFVBQVUsTUFBTTtBQUNwQixRQUFJLFVBQVUsTUFBTTtBQUNwQixRQUFJLE9BQU8sVUFBVTtBQUNyQixRQUFJLFFBQVEsVUFBVTtBQUN0QixRQUFJLFNBQVMsVUFBVTtBQUN2QixRQUFJLFNBQVMsVUFBVTtBQUN2QixRQUFJLFNBQVMsVUFBVTtBQUN2QixRQUFJLFNBQVMsVUFBVTtBQUV2QixRQUFJLFlBQVksT0FBTztBQUV2QixRQUFJLFdBQVc7QUFBQSxNQUNiO0FBQUEsTUFBWTtBQUFBLE1BQVk7QUFBQSxNQUFZO0FBQUEsTUFDcEM7QUFBQSxNQUFZO0FBQUEsTUFBWTtBQUFBLE1BQVk7QUFBQSxNQUNwQztBQUFBLE1BQVk7QUFBQSxNQUFZO0FBQUEsTUFBWTtBQUFBLE1BQ3BDO0FBQUEsTUFBWTtBQUFBLE1BQVk7QUFBQSxNQUFZO0FBQUEsTUFDcEM7QUFBQSxNQUFZO0FBQUEsTUFBWTtBQUFBLE1BQVk7QUFBQSxNQUNwQztBQUFBLE1BQVk7QUFBQSxNQUFZO0FBQUEsTUFBWTtBQUFBLE1BQ3BDO0FBQUEsTUFBWTtBQUFBLE1BQVk7QUFBQSxNQUFZO0FBQUEsTUFDcEM7QUFBQSxNQUFZO0FBQUEsTUFBWTtBQUFBLE1BQVk7QUFBQSxNQUNwQztBQUFBLE1BQVk7QUFBQSxNQUFZO0FBQUEsTUFBWTtBQUFBLE1BQ3BDO0FBQUEsTUFBWTtBQUFBLE1BQVk7QUFBQSxNQUFZO0FBQUEsTUFDcEM7QUFBQSxNQUFZO0FBQUEsTUFBWTtBQUFBLE1BQVk7QUFBQSxNQUNwQztBQUFBLE1BQVk7QUFBQSxNQUFZO0FBQUEsTUFBWTtBQUFBLE1BQ3BDO0FBQUEsTUFBWTtBQUFBLE1BQVk7QUFBQSxNQUFZO0FBQUEsTUFDcEM7QUFBQSxNQUFZO0FBQUEsTUFBWTtBQUFBLE1BQVk7QUFBQSxNQUNwQztBQUFBLE1BQVk7QUFBQSxNQUFZO0FBQUEsTUFBWTtBQUFBLE1BQ3BDO0FBQUEsTUFBWTtBQUFBLE1BQVk7QUFBQSxNQUFZO0FBQUEsSUFDdEM7QUFFQSxhQUFTLFNBQVM7QUFDaEIsVUFBSSxFQUFFLGdCQUFnQjtBQUNwQixlQUFPLElBQUksT0FBTztBQUVwQixnQkFBVSxLQUFLLElBQUk7QUFDbkIsV0FBSyxJQUFJO0FBQUEsUUFDUDtBQUFBLFFBQVk7QUFBQSxRQUFZO0FBQUEsUUFBWTtBQUFBLFFBQ3BDO0FBQUEsUUFBWTtBQUFBLFFBQVk7QUFBQSxRQUFZO0FBQUEsTUFDdEM7QUFDQSxXQUFLLElBQUk7QUFDVCxXQUFLLElBQUksSUFBSSxNQUFNLEVBQUU7QUFBQSxJQUN2QjtBQUNBLFVBQU0sU0FBUyxRQUFRLFNBQVM7QUFDaEMsSUFBQUEsUUFBTyxVQUFVO0FBRWpCLFdBQU8sWUFBWTtBQUNuQixXQUFPLFVBQVU7QUFDakIsV0FBTyxlQUFlO0FBQ3RCLFdBQU8sWUFBWTtBQUVuQixXQUFPLFVBQVUsVUFBVSxTQUFTLFFBQVEsS0FBSyxPQUFPO0FBQ3RELFVBQUksSUFBSSxLQUFLO0FBRWIsZUFBUyxJQUFJLEdBQUcsSUFBSSxJQUFJO0FBQ3RCLFVBQUUsQ0FBQyxJQUFJLElBQUksUUFBUSxDQUFDO0FBQ3RCLGFBQU8sSUFBSSxFQUFFLFFBQVE7QUFDbkIsVUFBRSxDQUFDLElBQUksUUFBUSxPQUFPLEVBQUUsSUFBSSxDQUFDLENBQUMsR0FBRyxFQUFFLElBQUksQ0FBQyxHQUFHLE9BQU8sRUFBRSxJQUFJLEVBQUUsQ0FBQyxHQUFHLEVBQUUsSUFBSSxFQUFFLENBQUM7QUFFekUsVUFBSSxJQUFJLEtBQUssRUFBRSxDQUFDO0FBQ2hCLFVBQUksSUFBSSxLQUFLLEVBQUUsQ0FBQztBQUNoQixVQUFJLElBQUksS0FBSyxFQUFFLENBQUM7QUFDaEIsVUFBSSxJQUFJLEtBQUssRUFBRSxDQUFDO0FBQ2hCLFVBQUksSUFBSSxLQUFLLEVBQUUsQ0FBQztBQUNoQixVQUFJLElBQUksS0FBSyxFQUFFLENBQUM7QUFDaEIsVUFBSSxJQUFJLEtBQUssRUFBRSxDQUFDO0FBQ2hCLFVBQUksSUFBSSxLQUFLLEVBQUUsQ0FBQztBQUVoQixhQUFPLEtBQUssRUFBRSxXQUFXLEVBQUUsTUFBTTtBQUNqQyxXQUFLLElBQUksR0FBRyxJQUFJLEVBQUUsUUFBUSxLQUFLO0FBQzdCLFlBQUksS0FBSyxRQUFRLEdBQUcsT0FBTyxDQUFDLEdBQUcsS0FBSyxHQUFHLEdBQUcsQ0FBQyxHQUFHLEtBQUssRUFBRSxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUM7QUFDN0QsWUFBSSxLQUFLLE1BQU0sT0FBTyxDQUFDLEdBQUcsTUFBTSxHQUFHLEdBQUcsQ0FBQyxDQUFDO0FBQ3hDLFlBQUk7QUFDSixZQUFJO0FBQ0osWUFBSTtBQUNKLFlBQUksTUFBTSxHQUFHLEVBQUU7QUFDZixZQUFJO0FBQ0osWUFBSTtBQUNKLFlBQUk7QUFDSixZQUFJLE1BQU0sSUFBSSxFQUFFO0FBQUEsTUFDbEI7QUFFQSxXQUFLLEVBQUUsQ0FBQyxJQUFJLE1BQU0sS0FBSyxFQUFFLENBQUMsR0FBRyxDQUFDO0FBQzlCLFdBQUssRUFBRSxDQUFDLElBQUksTUFBTSxLQUFLLEVBQUUsQ0FBQyxHQUFHLENBQUM7QUFDOUIsV0FBSyxFQUFFLENBQUMsSUFBSSxNQUFNLEtBQUssRUFBRSxDQUFDLEdBQUcsQ0FBQztBQUM5QixXQUFLLEVBQUUsQ0FBQyxJQUFJLE1BQU0sS0FBSyxFQUFFLENBQUMsR0FBRyxDQUFDO0FBQzlCLFdBQUssRUFBRSxDQUFDLElBQUksTUFBTSxLQUFLLEVBQUUsQ0FBQyxHQUFHLENBQUM7QUFDOUIsV0FBSyxFQUFFLENBQUMsSUFBSSxNQUFNLEtBQUssRUFBRSxDQUFDLEdBQUcsQ0FBQztBQUM5QixXQUFLLEVBQUUsQ0FBQyxJQUFJLE1BQU0sS0FBSyxFQUFFLENBQUMsR0FBRyxDQUFDO0FBQzlCLFdBQUssRUFBRSxDQUFDLElBQUksTUFBTSxLQUFLLEVBQUUsQ0FBQyxHQUFHLENBQUM7QUFBQSxJQUNoQztBQUVBLFdBQU8sVUFBVSxVQUFVLFNBQVMsT0FBTyxLQUFLO0FBQzlDLFVBQUksUUFBUTtBQUNWLGVBQU8sTUFBTSxRQUFRLEtBQUssR0FBRyxLQUFLO0FBQUE7QUFFbEMsZUFBTyxNQUFNLFFBQVEsS0FBSyxHQUFHLEtBQUs7QUFBQSxJQUN0QztBQUFBO0FBQUE7OztBQ3hHQSxJQUFBQyxhQUFBO0FBQUEsb0ZBQUFDLFVBQUFDLFNBQUE7QUFBQTtBQUVBLFFBQUksUUFBUTtBQUNaLFFBQUksU0FBUztBQUViLGFBQVMsU0FBUztBQUNoQixVQUFJLEVBQUUsZ0JBQWdCO0FBQ3BCLGVBQU8sSUFBSSxPQUFPO0FBRXBCLGFBQU8sS0FBSyxJQUFJO0FBQ2hCLFdBQUssSUFBSTtBQUFBLFFBQ1A7QUFBQSxRQUFZO0FBQUEsUUFBWTtBQUFBLFFBQVk7QUFBQSxRQUNwQztBQUFBLFFBQVk7QUFBQSxRQUFZO0FBQUEsUUFBWTtBQUFBLE1BQVc7QUFBQSxJQUNuRDtBQUNBLFVBQU0sU0FBUyxRQUFRLE1BQU07QUFDN0IsSUFBQUEsUUFBTyxVQUFVO0FBRWpCLFdBQU8sWUFBWTtBQUNuQixXQUFPLFVBQVU7QUFDakIsV0FBTyxlQUFlO0FBQ3RCLFdBQU8sWUFBWTtBQUVuQixXQUFPLFVBQVUsVUFBVSxTQUFTLE9BQU8sS0FBSztBQUU5QyxVQUFJLFFBQVE7QUFDVixlQUFPLE1BQU0sUUFBUSxLQUFLLEVBQUUsTUFBTSxHQUFHLENBQUMsR0FBRyxLQUFLO0FBQUE7QUFFOUMsZUFBTyxNQUFNLFFBQVEsS0FBSyxFQUFFLE1BQU0sR0FBRyxDQUFDLEdBQUcsS0FBSztBQUFBLElBQ2xEO0FBQUE7QUFBQTs7O0FDNUJBLElBQUFDLGFBQUE7QUFBQSxvRkFBQUMsVUFBQUMsU0FBQTtBQUFBO0FBRUEsUUFBSSxRQUFRO0FBQ1osUUFBSSxTQUFTO0FBQ2IsUUFBSSxTQUFTO0FBRWIsUUFBSSxZQUFZLE1BQU07QUFDdEIsUUFBSSxZQUFZLE1BQU07QUFDdEIsUUFBSSxXQUFXLE1BQU07QUFDckIsUUFBSSxXQUFXLE1BQU07QUFDckIsUUFBSSxRQUFRLE1BQU07QUFDbEIsUUFBSSxXQUFXLE1BQU07QUFDckIsUUFBSSxXQUFXLE1BQU07QUFDckIsUUFBSSxhQUFhLE1BQU07QUFDdkIsUUFBSSxhQUFhLE1BQU07QUFDdkIsUUFBSSxhQUFhLE1BQU07QUFDdkIsUUFBSSxhQUFhLE1BQU07QUFFdkIsUUFBSSxZQUFZLE9BQU87QUFFdkIsUUFBSSxXQUFXO0FBQUEsTUFDYjtBQUFBLE1BQVk7QUFBQSxNQUFZO0FBQUEsTUFBWTtBQUFBLE1BQ3BDO0FBQUEsTUFBWTtBQUFBLE1BQVk7QUFBQSxNQUFZO0FBQUEsTUFDcEM7QUFBQSxNQUFZO0FBQUEsTUFBWTtBQUFBLE1BQVk7QUFBQSxNQUNwQztBQUFBLE1BQVk7QUFBQSxNQUFZO0FBQUEsTUFBWTtBQUFBLE1BQ3BDO0FBQUEsTUFBWTtBQUFBLE1BQVk7QUFBQSxNQUFZO0FBQUEsTUFDcEM7QUFBQSxNQUFZO0FBQUEsTUFBWTtBQUFBLE1BQVk7QUFBQSxNQUNwQztBQUFBLE1BQVk7QUFBQSxNQUFZO0FBQUEsTUFBWTtBQUFBLE1BQ3BDO0FBQUEsTUFBWTtBQUFBLE1BQVk7QUFBQSxNQUFZO0FBQUEsTUFDcEM7QUFBQSxNQUFZO0FBQUEsTUFBWTtBQUFBLE1BQVk7QUFBQSxNQUNwQztBQUFBLE1BQVk7QUFBQSxNQUFZO0FBQUEsTUFBWTtBQUFBLE1BQ3BDO0FBQUEsTUFBWTtBQUFBLE1BQVk7QUFBQSxNQUFZO0FBQUEsTUFDcEM7QUFBQSxNQUFZO0FBQUEsTUFBWTtBQUFBLE1BQVk7QUFBQSxNQUNwQztBQUFBLE1BQVk7QUFBQSxNQUFZO0FBQUEsTUFBWTtBQUFBLE1BQ3BDO0FBQUEsTUFBWTtBQUFBLE1BQVk7QUFBQSxNQUFZO0FBQUEsTUFDcEM7QUFBQSxNQUFZO0FBQUEsTUFBWTtBQUFBLE1BQVk7QUFBQSxNQUNwQztBQUFBLE1BQVk7QUFBQSxNQUFZO0FBQUEsTUFBWTtBQUFBLE1BQ3BDO0FBQUEsTUFBWTtBQUFBLE1BQVk7QUFBQSxNQUFZO0FBQUEsTUFDcEM7QUFBQSxNQUFZO0FBQUEsTUFBWTtBQUFBLE1BQVk7QUFBQSxNQUNwQztBQUFBLE1BQVk7QUFBQSxNQUFZO0FBQUEsTUFBWTtBQUFBLE1BQ3BDO0FBQUEsTUFBWTtBQUFBLE1BQVk7QUFBQSxNQUFZO0FBQUEsTUFDcEM7QUFBQSxNQUFZO0FBQUEsTUFBWTtBQUFBLE1BQVk7QUFBQSxNQUNwQztBQUFBLE1BQVk7QUFBQSxNQUFZO0FBQUEsTUFBWTtBQUFBLE1BQ3BDO0FBQUEsTUFBWTtBQUFBLE1BQVk7QUFBQSxNQUFZO0FBQUEsTUFDcEM7QUFBQSxNQUFZO0FBQUEsTUFBWTtBQUFBLE1BQVk7QUFBQSxNQUNwQztBQUFBLE1BQVk7QUFBQSxNQUFZO0FBQUEsTUFBWTtBQUFBLE1BQ3BDO0FBQUEsTUFBWTtBQUFBLE1BQVk7QUFBQSxNQUFZO0FBQUEsTUFDcEM7QUFBQSxNQUFZO0FBQUEsTUFBWTtBQUFBLE1BQVk7QUFBQSxNQUNwQztBQUFBLE1BQVk7QUFBQSxNQUFZO0FBQUEsTUFBWTtBQUFBLE1BQ3BDO0FBQUEsTUFBWTtBQUFBLE1BQVk7QUFBQSxNQUFZO0FBQUEsTUFDcEM7QUFBQSxNQUFZO0FBQUEsTUFBWTtBQUFBLE1BQVk7QUFBQSxNQUNwQztBQUFBLE1BQVk7QUFBQSxNQUFZO0FBQUEsTUFBWTtBQUFBLE1BQ3BDO0FBQUEsTUFBWTtBQUFBLE1BQVk7QUFBQSxNQUFZO0FBQUEsTUFDcEM7QUFBQSxNQUFZO0FBQUEsTUFBWTtBQUFBLE1BQVk7QUFBQSxNQUNwQztBQUFBLE1BQVk7QUFBQSxNQUFZO0FBQUEsTUFBWTtBQUFBLE1BQ3BDO0FBQUEsTUFBWTtBQUFBLE1BQVk7QUFBQSxNQUFZO0FBQUEsTUFDcEM7QUFBQSxNQUFZO0FBQUEsTUFBWTtBQUFBLE1BQVk7QUFBQSxNQUNwQztBQUFBLE1BQVk7QUFBQSxNQUFZO0FBQUEsTUFBWTtBQUFBLE1BQ3BDO0FBQUEsTUFBWTtBQUFBLE1BQVk7QUFBQSxNQUFZO0FBQUEsTUFDcEM7QUFBQSxNQUFZO0FBQUEsTUFBWTtBQUFBLE1BQVk7QUFBQSxNQUNwQztBQUFBLE1BQVk7QUFBQSxNQUFZO0FBQUEsTUFBWTtBQUFBLElBQ3RDO0FBRUEsYUFBUyxTQUFTO0FBQ2hCLFVBQUksRUFBRSxnQkFBZ0I7QUFDcEIsZUFBTyxJQUFJLE9BQU87QUFFcEIsZ0JBQVUsS0FBSyxJQUFJO0FBQ25CLFdBQUssSUFBSTtBQUFBLFFBQ1A7QUFBQSxRQUFZO0FBQUEsUUFDWjtBQUFBLFFBQVk7QUFBQSxRQUNaO0FBQUEsUUFBWTtBQUFBLFFBQ1o7QUFBQSxRQUFZO0FBQUEsUUFDWjtBQUFBLFFBQVk7QUFBQSxRQUNaO0FBQUEsUUFBWTtBQUFBLFFBQ1o7QUFBQSxRQUFZO0FBQUEsUUFDWjtBQUFBLFFBQVk7QUFBQSxNQUFXO0FBQ3pCLFdBQUssSUFBSTtBQUNULFdBQUssSUFBSSxJQUFJLE1BQU0sR0FBRztBQUFBLElBQ3hCO0FBQ0EsVUFBTSxTQUFTLFFBQVEsU0FBUztBQUNoQyxJQUFBQSxRQUFPLFVBQVU7QUFFakIsV0FBTyxZQUFZO0FBQ25CLFdBQU8sVUFBVTtBQUNqQixXQUFPLGVBQWU7QUFDdEIsV0FBTyxZQUFZO0FBRW5CLFdBQU8sVUFBVSxnQkFBZ0IsU0FBUyxjQUFjLEtBQUssT0FBTztBQUNsRSxVQUFJLElBQUksS0FBSztBQUdiLGVBQVMsSUFBSSxHQUFHLElBQUksSUFBSTtBQUN0QixVQUFFLENBQUMsSUFBSSxJQUFJLFFBQVEsQ0FBQztBQUN0QixhQUFPLElBQUksRUFBRSxRQUFRLEtBQUssR0FBRztBQUMzQixZQUFJLFFBQVEsVUFBVSxFQUFFLElBQUksQ0FBQyxHQUFHLEVBQUUsSUFBSSxDQUFDLENBQUM7QUFDeEMsWUFBSSxRQUFRLFVBQVUsRUFBRSxJQUFJLENBQUMsR0FBRyxFQUFFLElBQUksQ0FBQyxDQUFDO0FBQ3hDLFlBQUksUUFBUSxFQUFFLElBQUksRUFBRTtBQUNwQixZQUFJLFFBQVEsRUFBRSxJQUFJLEVBQUU7QUFDcEIsWUFBSSxRQUFRLFVBQVUsRUFBRSxJQUFJLEVBQUUsR0FBRyxFQUFFLElBQUksRUFBRSxDQUFDO0FBQzFDLFlBQUksUUFBUSxVQUFVLEVBQUUsSUFBSSxFQUFFLEdBQUcsRUFBRSxJQUFJLEVBQUUsQ0FBQztBQUMxQyxZQUFJLFFBQVEsRUFBRSxJQUFJLEVBQUU7QUFDcEIsWUFBSSxRQUFRLEVBQUUsSUFBSSxFQUFFO0FBRXBCLFVBQUUsQ0FBQyxJQUFJO0FBQUEsVUFDTDtBQUFBLFVBQU87QUFBQSxVQUNQO0FBQUEsVUFBTztBQUFBLFVBQ1A7QUFBQSxVQUFPO0FBQUEsVUFDUDtBQUFBLFVBQU87QUFBQSxRQUFLO0FBQ2QsVUFBRSxJQUFJLENBQUMsSUFBSTtBQUFBLFVBQ1Q7QUFBQSxVQUFPO0FBQUEsVUFDUDtBQUFBLFVBQU87QUFBQSxVQUNQO0FBQUEsVUFBTztBQUFBLFVBQ1A7QUFBQSxVQUFPO0FBQUEsUUFBSztBQUFBLE1BQ2hCO0FBQUEsSUFDRjtBQUVBLFdBQU8sVUFBVSxVQUFVLFNBQVMsUUFBUSxLQUFLLE9BQU87QUFDdEQsV0FBSyxjQUFjLEtBQUssS0FBSztBQUU3QixVQUFJLElBQUksS0FBSztBQUViLFVBQUksS0FBSyxLQUFLLEVBQUUsQ0FBQztBQUNqQixVQUFJLEtBQUssS0FBSyxFQUFFLENBQUM7QUFDakIsVUFBSSxLQUFLLEtBQUssRUFBRSxDQUFDO0FBQ2pCLFVBQUksS0FBSyxLQUFLLEVBQUUsQ0FBQztBQUNqQixVQUFJLEtBQUssS0FBSyxFQUFFLENBQUM7QUFDakIsVUFBSSxLQUFLLEtBQUssRUFBRSxDQUFDO0FBQ2pCLFVBQUksS0FBSyxLQUFLLEVBQUUsQ0FBQztBQUNqQixVQUFJLEtBQUssS0FBSyxFQUFFLENBQUM7QUFDakIsVUFBSSxLQUFLLEtBQUssRUFBRSxDQUFDO0FBQ2pCLFVBQUksS0FBSyxLQUFLLEVBQUUsQ0FBQztBQUNqQixVQUFJLEtBQUssS0FBSyxFQUFFLEVBQUU7QUFDbEIsVUFBSSxLQUFLLEtBQUssRUFBRSxFQUFFO0FBQ2xCLFVBQUksS0FBSyxLQUFLLEVBQUUsRUFBRTtBQUNsQixVQUFJLEtBQUssS0FBSyxFQUFFLEVBQUU7QUFDbEIsVUFBSSxLQUFLLEtBQUssRUFBRSxFQUFFO0FBQ2xCLFVBQUksS0FBSyxLQUFLLEVBQUUsRUFBRTtBQUVsQixhQUFPLEtBQUssRUFBRSxXQUFXLEVBQUUsTUFBTTtBQUNqQyxlQUFTLElBQUksR0FBRyxJQUFJLEVBQUUsUUFBUSxLQUFLLEdBQUc7QUFDcEMsWUFBSSxRQUFRO0FBQ1osWUFBSSxRQUFRO0FBQ1osWUFBSSxRQUFRLFVBQVUsSUFBSSxFQUFFO0FBQzVCLFlBQUksUUFBUSxVQUFVLElBQUksRUFBRTtBQUM1QixZQUFJLFFBQVEsUUFBUSxJQUFJLElBQUksSUFBSSxJQUFJLElBQUksRUFBRTtBQUMxQyxZQUFJLFFBQVEsUUFBUSxJQUFJLElBQUksSUFBSSxJQUFJLElBQUksRUFBRTtBQUMxQyxZQUFJLFFBQVEsS0FBSyxFQUFFLENBQUM7QUFDcEIsWUFBSSxRQUFRLEtBQUssRUFBRSxJQUFJLENBQUM7QUFDeEIsWUFBSSxRQUFRLEVBQUUsQ0FBQztBQUNmLFlBQUksUUFBUSxFQUFFLElBQUksQ0FBQztBQUVuQixZQUFJLFFBQVE7QUFBQSxVQUNWO0FBQUEsVUFBTztBQUFBLFVBQ1A7QUFBQSxVQUFPO0FBQUEsVUFDUDtBQUFBLFVBQU87QUFBQSxVQUNQO0FBQUEsVUFBTztBQUFBLFVBQ1A7QUFBQSxVQUFPO0FBQUEsUUFBSztBQUNkLFlBQUksUUFBUTtBQUFBLFVBQ1Y7QUFBQSxVQUFPO0FBQUEsVUFDUDtBQUFBLFVBQU87QUFBQSxVQUNQO0FBQUEsVUFBTztBQUFBLFVBQ1A7QUFBQSxVQUFPO0FBQUEsVUFDUDtBQUFBLFVBQU87QUFBQSxRQUFLO0FBRWQsZ0JBQVEsVUFBVSxJQUFJLEVBQUU7QUFDeEIsZ0JBQVEsVUFBVSxJQUFJLEVBQUU7QUFDeEIsZ0JBQVEsU0FBUyxJQUFJLElBQUksSUFBSSxJQUFJLElBQUksRUFBRTtBQUN2QyxnQkFBUSxTQUFTLElBQUksSUFBSSxJQUFJLElBQUksSUFBSSxFQUFFO0FBRXZDLFlBQUksUUFBUSxTQUFTLE9BQU8sT0FBTyxPQUFPLEtBQUs7QUFDL0MsWUFBSSxRQUFRLFNBQVMsT0FBTyxPQUFPLE9BQU8sS0FBSztBQUUvQyxhQUFLO0FBQ0wsYUFBSztBQUVMLGFBQUs7QUFDTCxhQUFLO0FBRUwsYUFBSztBQUNMLGFBQUs7QUFFTCxhQUFLLFNBQVMsSUFBSSxJQUFJLE9BQU8sS0FBSztBQUNsQyxhQUFLLFNBQVMsSUFBSSxJQUFJLE9BQU8sS0FBSztBQUVsQyxhQUFLO0FBQ0wsYUFBSztBQUVMLGFBQUs7QUFDTCxhQUFLO0FBRUwsYUFBSztBQUNMLGFBQUs7QUFFTCxhQUFLLFNBQVMsT0FBTyxPQUFPLE9BQU8sS0FBSztBQUN4QyxhQUFLLFNBQVMsT0FBTyxPQUFPLE9BQU8sS0FBSztBQUFBLE1BQzFDO0FBRUEsWUFBTSxLQUFLLEdBQUcsR0FBRyxJQUFJLEVBQUU7QUFDdkIsWUFBTSxLQUFLLEdBQUcsR0FBRyxJQUFJLEVBQUU7QUFDdkIsWUFBTSxLQUFLLEdBQUcsR0FBRyxJQUFJLEVBQUU7QUFDdkIsWUFBTSxLQUFLLEdBQUcsR0FBRyxJQUFJLEVBQUU7QUFDdkIsWUFBTSxLQUFLLEdBQUcsR0FBRyxJQUFJLEVBQUU7QUFDdkIsWUFBTSxLQUFLLEdBQUcsSUFBSSxJQUFJLEVBQUU7QUFDeEIsWUFBTSxLQUFLLEdBQUcsSUFBSSxJQUFJLEVBQUU7QUFDeEIsWUFBTSxLQUFLLEdBQUcsSUFBSSxJQUFJLEVBQUU7QUFBQSxJQUMxQjtBQUVBLFdBQU8sVUFBVSxVQUFVLFNBQVMsT0FBTyxLQUFLO0FBQzlDLFVBQUksUUFBUTtBQUNWLGVBQU8sTUFBTSxRQUFRLEtBQUssR0FBRyxLQUFLO0FBQUE7QUFFbEMsZUFBTyxNQUFNLFFBQVEsS0FBSyxHQUFHLEtBQUs7QUFBQSxJQUN0QztBQUVBLGFBQVMsUUFBUSxJQUFJLElBQUksSUFBSSxJQUFJLElBQUk7QUFDbkMsVUFBSSxJQUFLLEtBQUssS0FBUSxDQUFDLEtBQU07QUFDN0IsVUFBSSxJQUFJO0FBQ04sYUFBSztBQUNQLGFBQU87QUFBQSxJQUNUO0FBRUEsYUFBUyxRQUFRLElBQUksSUFBSSxJQUFJLElBQUksSUFBSSxJQUFJO0FBQ3ZDLFVBQUksSUFBSyxLQUFLLEtBQVEsQ0FBQyxLQUFNO0FBQzdCLFVBQUksSUFBSTtBQUNOLGFBQUs7QUFDUCxhQUFPO0FBQUEsSUFDVDtBQUVBLGFBQVMsU0FBUyxJQUFJLElBQUksSUFBSSxJQUFJLElBQUk7QUFDcEMsVUFBSSxJQUFLLEtBQUssS0FBTyxLQUFLLEtBQU8sS0FBSztBQUN0QyxVQUFJLElBQUk7QUFDTixhQUFLO0FBQ1AsYUFBTztBQUFBLElBQ1Q7QUFFQSxhQUFTLFNBQVMsSUFBSSxJQUFJLElBQUksSUFBSSxJQUFJLElBQUk7QUFDeEMsVUFBSSxJQUFLLEtBQUssS0FBTyxLQUFLLEtBQU8sS0FBSztBQUN0QyxVQUFJLElBQUk7QUFDTixhQUFLO0FBQ1AsYUFBTztBQUFBLElBQ1Q7QUFFQSxhQUFTLFVBQVUsSUFBSSxJQUFJO0FBQ3pCLFVBQUksUUFBUSxVQUFVLElBQUksSUFBSSxFQUFFO0FBQ2hDLFVBQUksUUFBUSxVQUFVLElBQUksSUFBSSxDQUFDO0FBQy9CLFVBQUksUUFBUSxVQUFVLElBQUksSUFBSSxDQUFDO0FBRS9CLFVBQUksSUFBSSxRQUFRLFFBQVE7QUFDeEIsVUFBSSxJQUFJO0FBQ04sYUFBSztBQUNQLGFBQU87QUFBQSxJQUNUO0FBRUEsYUFBUyxVQUFVLElBQUksSUFBSTtBQUN6QixVQUFJLFFBQVEsVUFBVSxJQUFJLElBQUksRUFBRTtBQUNoQyxVQUFJLFFBQVEsVUFBVSxJQUFJLElBQUksQ0FBQztBQUMvQixVQUFJLFFBQVEsVUFBVSxJQUFJLElBQUksQ0FBQztBQUUvQixVQUFJLElBQUksUUFBUSxRQUFRO0FBQ3hCLFVBQUksSUFBSTtBQUNOLGFBQUs7QUFDUCxhQUFPO0FBQUEsSUFDVDtBQUVBLGFBQVMsVUFBVSxJQUFJLElBQUk7QUFDekIsVUFBSSxRQUFRLFVBQVUsSUFBSSxJQUFJLEVBQUU7QUFDaEMsVUFBSSxRQUFRLFVBQVUsSUFBSSxJQUFJLEVBQUU7QUFDaEMsVUFBSSxRQUFRLFVBQVUsSUFBSSxJQUFJLENBQUM7QUFFL0IsVUFBSSxJQUFJLFFBQVEsUUFBUTtBQUN4QixVQUFJLElBQUk7QUFDTixhQUFLO0FBQ1AsYUFBTztBQUFBLElBQ1Q7QUFFQSxhQUFTLFVBQVUsSUFBSSxJQUFJO0FBQ3pCLFVBQUksUUFBUSxVQUFVLElBQUksSUFBSSxFQUFFO0FBQ2hDLFVBQUksUUFBUSxVQUFVLElBQUksSUFBSSxFQUFFO0FBQ2hDLFVBQUksUUFBUSxVQUFVLElBQUksSUFBSSxDQUFDO0FBRS9CLFVBQUksSUFBSSxRQUFRLFFBQVE7QUFDeEIsVUFBSSxJQUFJO0FBQ04sYUFBSztBQUNQLGFBQU87QUFBQSxJQUNUO0FBRUEsYUFBUyxVQUFVLElBQUksSUFBSTtBQUN6QixVQUFJLFFBQVEsVUFBVSxJQUFJLElBQUksQ0FBQztBQUMvQixVQUFJLFFBQVEsVUFBVSxJQUFJLElBQUksQ0FBQztBQUMvQixVQUFJLFFBQVEsU0FBUyxJQUFJLElBQUksQ0FBQztBQUU5QixVQUFJLElBQUksUUFBUSxRQUFRO0FBQ3hCLFVBQUksSUFBSTtBQUNOLGFBQUs7QUFDUCxhQUFPO0FBQUEsSUFDVDtBQUVBLGFBQVMsVUFBVSxJQUFJLElBQUk7QUFDekIsVUFBSSxRQUFRLFVBQVUsSUFBSSxJQUFJLENBQUM7QUFDL0IsVUFBSSxRQUFRLFVBQVUsSUFBSSxJQUFJLENBQUM7QUFDL0IsVUFBSSxRQUFRLFNBQVMsSUFBSSxJQUFJLENBQUM7QUFFOUIsVUFBSSxJQUFJLFFBQVEsUUFBUTtBQUN4QixVQUFJLElBQUk7QUFDTixhQUFLO0FBQ1AsYUFBTztBQUFBLElBQ1Q7QUFFQSxhQUFTLFVBQVUsSUFBSSxJQUFJO0FBQ3pCLFVBQUksUUFBUSxVQUFVLElBQUksSUFBSSxFQUFFO0FBQ2hDLFVBQUksUUFBUSxVQUFVLElBQUksSUFBSSxFQUFFO0FBQ2hDLFVBQUksUUFBUSxTQUFTLElBQUksSUFBSSxDQUFDO0FBRTlCLFVBQUksSUFBSSxRQUFRLFFBQVE7QUFDeEIsVUFBSSxJQUFJO0FBQ04sYUFBSztBQUNQLGFBQU87QUFBQSxJQUNUO0FBRUEsYUFBUyxVQUFVLElBQUksSUFBSTtBQUN6QixVQUFJLFFBQVEsVUFBVSxJQUFJLElBQUksRUFBRTtBQUNoQyxVQUFJLFFBQVEsVUFBVSxJQUFJLElBQUksRUFBRTtBQUNoQyxVQUFJLFFBQVEsU0FBUyxJQUFJLElBQUksQ0FBQztBQUU5QixVQUFJLElBQUksUUFBUSxRQUFRO0FBQ3hCLFVBQUksSUFBSTtBQUNOLGFBQUs7QUFDUCxhQUFPO0FBQUEsSUFDVDtBQUFBO0FBQUE7OztBQ3pVQSxJQUFBQyxhQUFBO0FBQUEsb0ZBQUFDLFVBQUFDLFNBQUE7QUFBQTtBQUVBLFFBQUksUUFBUTtBQUVaLFFBQUksU0FBUztBQUViLGFBQVMsU0FBUztBQUNoQixVQUFJLEVBQUUsZ0JBQWdCO0FBQ3BCLGVBQU8sSUFBSSxPQUFPO0FBRXBCLGFBQU8sS0FBSyxJQUFJO0FBQ2hCLFdBQUssSUFBSTtBQUFBLFFBQ1A7QUFBQSxRQUFZO0FBQUEsUUFDWjtBQUFBLFFBQVk7QUFBQSxRQUNaO0FBQUEsUUFBWTtBQUFBLFFBQ1o7QUFBQSxRQUFZO0FBQUEsUUFDWjtBQUFBLFFBQVk7QUFBQSxRQUNaO0FBQUEsUUFBWTtBQUFBLFFBQ1o7QUFBQSxRQUFZO0FBQUEsUUFDWjtBQUFBLFFBQVk7QUFBQSxNQUFXO0FBQUEsSUFDM0I7QUFDQSxVQUFNLFNBQVMsUUFBUSxNQUFNO0FBQzdCLElBQUFBLFFBQU8sVUFBVTtBQUVqQixXQUFPLFlBQVk7QUFDbkIsV0FBTyxVQUFVO0FBQ2pCLFdBQU8sZUFBZTtBQUN0QixXQUFPLFlBQVk7QUFFbkIsV0FBTyxVQUFVLFVBQVUsU0FBUyxPQUFPLEtBQUs7QUFDOUMsVUFBSSxRQUFRO0FBQ1YsZUFBTyxNQUFNLFFBQVEsS0FBSyxFQUFFLE1BQU0sR0FBRyxFQUFFLEdBQUcsS0FBSztBQUFBO0FBRS9DLGVBQU8sTUFBTSxRQUFRLEtBQUssRUFBRSxNQUFNLEdBQUcsRUFBRSxHQUFHLEtBQUs7QUFBQSxJQUNuRDtBQUFBO0FBQUE7OztBQ2xDQTtBQUFBLGdGQUFBQyxVQUFBO0FBQUE7QUFFQSxJQUFBQSxTQUFRLE9BQU87QUFDZixJQUFBQSxTQUFRLFNBQVM7QUFDakIsSUFBQUEsU0FBUSxTQUFTO0FBQ2pCLElBQUFBLFNBQVEsU0FBUztBQUNqQixJQUFBQSxTQUFRLFNBQVM7QUFBQTtBQUFBOzs7QUNOakI7QUFBQSxtRkFBQUMsVUFBQTtBQUFBO0FBRUEsUUFBSSxRQUFRO0FBQ1osUUFBSSxTQUFTO0FBRWIsUUFBSSxTQUFTLE1BQU07QUFDbkIsUUFBSSxRQUFRLE1BQU07QUFDbEIsUUFBSSxVQUFVLE1BQU07QUFDcEIsUUFBSSxVQUFVLE1BQU07QUFDcEIsUUFBSSxZQUFZLE9BQU87QUFFdkIsYUFBUyxZQUFZO0FBQ25CLFVBQUksRUFBRSxnQkFBZ0I7QUFDcEIsZUFBTyxJQUFJLFVBQVU7QUFFdkIsZ0JBQVUsS0FBSyxJQUFJO0FBRW5CLFdBQUssSUFBSSxDQUFFLFlBQVksWUFBWSxZQUFZLFdBQVksVUFBVztBQUN0RSxXQUFLLFNBQVM7QUFBQSxJQUNoQjtBQUNBLFVBQU0sU0FBUyxXQUFXLFNBQVM7QUFDbkMsSUFBQUEsU0FBUSxZQUFZO0FBRXBCLGNBQVUsWUFBWTtBQUN0QixjQUFVLFVBQVU7QUFDcEIsY0FBVSxlQUFlO0FBQ3pCLGNBQVUsWUFBWTtBQUV0QixjQUFVLFVBQVUsVUFBVSxTQUFTLE9BQU8sS0FBSyxPQUFPO0FBQ3hELFVBQUksSUFBSSxLQUFLLEVBQUUsQ0FBQztBQUNoQixVQUFJLElBQUksS0FBSyxFQUFFLENBQUM7QUFDaEIsVUFBSSxJQUFJLEtBQUssRUFBRSxDQUFDO0FBQ2hCLFVBQUksSUFBSSxLQUFLLEVBQUUsQ0FBQztBQUNoQixVQUFJLElBQUksS0FBSyxFQUFFLENBQUM7QUFDaEIsVUFBSSxLQUFLO0FBQ1QsVUFBSSxLQUFLO0FBQ1QsVUFBSSxLQUFLO0FBQ1QsVUFBSSxLQUFLO0FBQ1QsVUFBSSxLQUFLO0FBQ1QsZUFBUyxJQUFJLEdBQUcsSUFBSSxJQUFJLEtBQUs7QUFDM0IsWUFBSSxJQUFJO0FBQUEsVUFDTjtBQUFBLFlBQ0UsUUFBUSxHQUFHLEVBQUUsR0FBRyxHQUFHLEdBQUcsQ0FBQyxHQUFHLElBQUksRUFBRSxDQUFDLElBQUksS0FBSyxHQUFHLEVBQUUsQ0FBQyxDQUFDO0FBQUEsWUFDakQsRUFBRSxDQUFDO0FBQUEsVUFBQztBQUFBLFVBQ047QUFBQSxRQUFDO0FBQ0gsWUFBSTtBQUNKLFlBQUk7QUFDSixZQUFJLE9BQU8sR0FBRyxFQUFFO0FBQ2hCLFlBQUk7QUFDSixZQUFJO0FBQ0osWUFBSTtBQUFBLFVBQ0Y7QUFBQSxZQUNFLFFBQVEsSUFBSSxFQUFFLEtBQUssR0FBRyxJQUFJLElBQUksRUFBRSxHQUFHLElBQUksR0FBRyxDQUFDLElBQUksS0FBSyxHQUFHLEdBQUcsQ0FBQyxDQUFDO0FBQUEsWUFDNUQsR0FBRyxDQUFDO0FBQUEsVUFBQztBQUFBLFVBQ1A7QUFBQSxRQUFFO0FBQ0osYUFBSztBQUNMLGFBQUs7QUFDTCxhQUFLLE9BQU8sSUFBSSxFQUFFO0FBQ2xCLGFBQUs7QUFDTCxhQUFLO0FBQUEsTUFDUDtBQUNBLFVBQUksUUFBUSxLQUFLLEVBQUUsQ0FBQyxHQUFHLEdBQUcsRUFBRTtBQUM1QixXQUFLLEVBQUUsQ0FBQyxJQUFJLFFBQVEsS0FBSyxFQUFFLENBQUMsR0FBRyxHQUFHLEVBQUU7QUFDcEMsV0FBSyxFQUFFLENBQUMsSUFBSSxRQUFRLEtBQUssRUFBRSxDQUFDLEdBQUcsR0FBRyxFQUFFO0FBQ3BDLFdBQUssRUFBRSxDQUFDLElBQUksUUFBUSxLQUFLLEVBQUUsQ0FBQyxHQUFHLEdBQUcsRUFBRTtBQUNwQyxXQUFLLEVBQUUsQ0FBQyxJQUFJLFFBQVEsS0FBSyxFQUFFLENBQUMsR0FBRyxHQUFHLEVBQUU7QUFDcEMsV0FBSyxFQUFFLENBQUMsSUFBSTtBQUFBLElBQ2Q7QUFFQSxjQUFVLFVBQVUsVUFBVSxTQUFTLE9BQU8sS0FBSztBQUNqRCxVQUFJLFFBQVE7QUFDVixlQUFPLE1BQU0sUUFBUSxLQUFLLEdBQUcsUUFBUTtBQUFBO0FBRXJDLGVBQU8sTUFBTSxRQUFRLEtBQUssR0FBRyxRQUFRO0FBQUEsSUFDekM7QUFFQSxhQUFTLEVBQUUsR0FBRyxHQUFHLEdBQUcsR0FBRztBQUNyQixVQUFJLEtBQUs7QUFDUCxlQUFPLElBQUksSUFBSTtBQUFBLGVBQ1IsS0FBSztBQUNaLGVBQVEsSUFBSSxJQUFPLENBQUMsSUFBSztBQUFBLGVBQ2xCLEtBQUs7QUFDWixnQkFBUSxJQUFLLENBQUMsS0FBTTtBQUFBLGVBQ2IsS0FBSztBQUNaLGVBQVEsSUFBSSxJQUFNLElBQUssQ0FBQztBQUFBO0FBRXhCLGVBQU8sS0FBSyxJQUFLLENBQUM7QUFBQSxJQUN0QjtBQUVBLGFBQVMsRUFBRSxHQUFHO0FBQ1osVUFBSSxLQUFLO0FBQ1AsZUFBTztBQUFBLGVBQ0EsS0FBSztBQUNaLGVBQU87QUFBQSxlQUNBLEtBQUs7QUFDWixlQUFPO0FBQUEsZUFDQSxLQUFLO0FBQ1osZUFBTztBQUFBO0FBRVAsZUFBTztBQUFBLElBQ1g7QUFFQSxhQUFTLEdBQUcsR0FBRztBQUNiLFVBQUksS0FBSztBQUNQLGVBQU87QUFBQSxlQUNBLEtBQUs7QUFDWixlQUFPO0FBQUEsZUFDQSxLQUFLO0FBQ1osZUFBTztBQUFBLGVBQ0EsS0FBSztBQUNaLGVBQU87QUFBQTtBQUVQLGVBQU87QUFBQSxJQUNYO0FBRUEsUUFBSSxJQUFJO0FBQUEsTUFDTjtBQUFBLE1BQUc7QUFBQSxNQUFHO0FBQUEsTUFBRztBQUFBLE1BQUc7QUFBQSxNQUFHO0FBQUEsTUFBRztBQUFBLE1BQUc7QUFBQSxNQUFHO0FBQUEsTUFBRztBQUFBLE1BQUc7QUFBQSxNQUFJO0FBQUEsTUFBSTtBQUFBLE1BQUk7QUFBQSxNQUFJO0FBQUEsTUFBSTtBQUFBLE1BQ2xEO0FBQUEsTUFBRztBQUFBLE1BQUc7QUFBQSxNQUFJO0FBQUEsTUFBRztBQUFBLE1BQUk7QUFBQSxNQUFHO0FBQUEsTUFBSTtBQUFBLE1BQUc7QUFBQSxNQUFJO0FBQUEsTUFBRztBQUFBLE1BQUc7QUFBQSxNQUFHO0FBQUEsTUFBRztBQUFBLE1BQUk7QUFBQSxNQUFJO0FBQUEsTUFDbkQ7QUFBQSxNQUFHO0FBQUEsTUFBSTtBQUFBLE1BQUk7QUFBQSxNQUFHO0FBQUEsTUFBRztBQUFBLE1BQUk7QUFBQSxNQUFHO0FBQUEsTUFBRztBQUFBLE1BQUc7QUFBQSxNQUFHO0FBQUEsTUFBRztBQUFBLE1BQUc7QUFBQSxNQUFJO0FBQUEsTUFBSTtBQUFBLE1BQUc7QUFBQSxNQUNsRDtBQUFBLE1BQUc7QUFBQSxNQUFHO0FBQUEsTUFBSTtBQUFBLE1BQUk7QUFBQSxNQUFHO0FBQUEsTUFBRztBQUFBLE1BQUk7QUFBQSxNQUFHO0FBQUEsTUFBSTtBQUFBLE1BQUc7QUFBQSxNQUFHO0FBQUEsTUFBSTtBQUFBLE1BQUk7QUFBQSxNQUFHO0FBQUEsTUFBRztBQUFBLE1BQ25EO0FBQUEsTUFBRztBQUFBLE1BQUc7QUFBQSxNQUFHO0FBQUEsTUFBRztBQUFBLE1BQUc7QUFBQSxNQUFJO0FBQUEsTUFBRztBQUFBLE1BQUk7QUFBQSxNQUFJO0FBQUEsTUFBRztBQUFBLE1BQUc7QUFBQSxNQUFHO0FBQUEsTUFBSTtBQUFBLE1BQUc7QUFBQSxNQUFJO0FBQUEsSUFDcEQ7QUFFQSxRQUFJLEtBQUs7QUFBQSxNQUNQO0FBQUEsTUFBRztBQUFBLE1BQUk7QUFBQSxNQUFHO0FBQUEsTUFBRztBQUFBLE1BQUc7QUFBQSxNQUFHO0FBQUEsTUFBSTtBQUFBLE1BQUc7QUFBQSxNQUFJO0FBQUEsTUFBRztBQUFBLE1BQUk7QUFBQSxNQUFHO0FBQUEsTUFBRztBQUFBLE1BQUk7QUFBQSxNQUFHO0FBQUEsTUFDbEQ7QUFBQSxNQUFHO0FBQUEsTUFBSTtBQUFBLE1BQUc7QUFBQSxNQUFHO0FBQUEsTUFBRztBQUFBLE1BQUk7QUFBQSxNQUFHO0FBQUEsTUFBSTtBQUFBLE1BQUk7QUFBQSxNQUFJO0FBQUEsTUFBRztBQUFBLE1BQUk7QUFBQSxNQUFHO0FBQUEsTUFBRztBQUFBLE1BQUc7QUFBQSxNQUNuRDtBQUFBLE1BQUk7QUFBQSxNQUFHO0FBQUEsTUFBRztBQUFBLE1BQUc7QUFBQSxNQUFHO0FBQUEsTUFBSTtBQUFBLE1BQUc7QUFBQSxNQUFHO0FBQUEsTUFBSTtBQUFBLE1BQUc7QUFBQSxNQUFJO0FBQUEsTUFBRztBQUFBLE1BQUk7QUFBQSxNQUFHO0FBQUEsTUFBRztBQUFBLE1BQ2xEO0FBQUEsTUFBRztBQUFBLE1BQUc7QUFBQSxNQUFHO0FBQUEsTUFBRztBQUFBLE1BQUc7QUFBQSxNQUFJO0FBQUEsTUFBSTtBQUFBLE1BQUc7QUFBQSxNQUFHO0FBQUEsTUFBSTtBQUFBLE1BQUc7QUFBQSxNQUFJO0FBQUEsTUFBRztBQUFBLE1BQUc7QUFBQSxNQUFJO0FBQUEsTUFDbEQ7QUFBQSxNQUFJO0FBQUEsTUFBSTtBQUFBLE1BQUk7QUFBQSxNQUFHO0FBQUEsTUFBRztBQUFBLE1BQUc7QUFBQSxNQUFHO0FBQUEsTUFBRztBQUFBLE1BQUc7QUFBQSxNQUFHO0FBQUEsTUFBSTtBQUFBLE1BQUk7QUFBQSxNQUFHO0FBQUEsTUFBRztBQUFBLE1BQUc7QUFBQSxJQUNwRDtBQUVBLFFBQUksSUFBSTtBQUFBLE1BQ047QUFBQSxNQUFJO0FBQUEsTUFBSTtBQUFBLE1BQUk7QUFBQSxNQUFJO0FBQUEsTUFBRztBQUFBLE1BQUc7QUFBQSxNQUFHO0FBQUEsTUFBRztBQUFBLE1BQUk7QUFBQSxNQUFJO0FBQUEsTUFBSTtBQUFBLE1BQUk7QUFBQSxNQUFHO0FBQUEsTUFBRztBQUFBLE1BQUc7QUFBQSxNQUNyRDtBQUFBLE1BQUc7QUFBQSxNQUFHO0FBQUEsTUFBRztBQUFBLE1BQUk7QUFBQSxNQUFJO0FBQUEsTUFBRztBQUFBLE1BQUc7QUFBQSxNQUFJO0FBQUEsTUFBRztBQUFBLE1BQUk7QUFBQSxNQUFJO0FBQUEsTUFBRztBQUFBLE1BQUk7QUFBQSxNQUFHO0FBQUEsTUFBSTtBQUFBLE1BQ3BEO0FBQUEsTUFBSTtBQUFBLE1BQUk7QUFBQSxNQUFHO0FBQUEsTUFBRztBQUFBLE1BQUk7QUFBQSxNQUFHO0FBQUEsTUFBSTtBQUFBLE1BQUk7QUFBQSxNQUFJO0FBQUEsTUFBRztBQUFBLE1BQUk7QUFBQSxNQUFHO0FBQUEsTUFBRztBQUFBLE1BQUk7QUFBQSxNQUFHO0FBQUEsTUFDckQ7QUFBQSxNQUFJO0FBQUEsTUFBSTtBQUFBLE1BQUk7QUFBQSxNQUFJO0FBQUEsTUFBSTtBQUFBLE1BQUk7QUFBQSxNQUFHO0FBQUEsTUFBRztBQUFBLE1BQUc7QUFBQSxNQUFJO0FBQUEsTUFBRztBQUFBLE1BQUc7QUFBQSxNQUFHO0FBQUEsTUFBRztBQUFBLE1BQUc7QUFBQSxNQUNwRDtBQUFBLE1BQUc7QUFBQSxNQUFJO0FBQUEsTUFBRztBQUFBLE1BQUk7QUFBQSxNQUFHO0FBQUEsTUFBRztBQUFBLE1BQUk7QUFBQSxNQUFJO0FBQUEsTUFBRztBQUFBLE1BQUk7QUFBQSxNQUFJO0FBQUEsTUFBSTtBQUFBLE1BQUk7QUFBQSxNQUFHO0FBQUEsTUFBRztBQUFBLElBQ3ZEO0FBRUEsUUFBSSxLQUFLO0FBQUEsTUFDUDtBQUFBLE1BQUc7QUFBQSxNQUFHO0FBQUEsTUFBRztBQUFBLE1BQUk7QUFBQSxNQUFJO0FBQUEsTUFBSTtBQUFBLE1BQUk7QUFBQSxNQUFHO0FBQUEsTUFBRztBQUFBLE1BQUc7QUFBQSxNQUFHO0FBQUEsTUFBSTtBQUFBLE1BQUk7QUFBQSxNQUFJO0FBQUEsTUFBSTtBQUFBLE1BQ3JEO0FBQUEsTUFBRztBQUFBLE1BQUk7QUFBQSxNQUFJO0FBQUEsTUFBRztBQUFBLE1BQUk7QUFBQSxNQUFHO0FBQUEsTUFBRztBQUFBLE1BQUk7QUFBQSxNQUFHO0FBQUEsTUFBRztBQUFBLE1BQUk7QUFBQSxNQUFHO0FBQUEsTUFBRztBQUFBLE1BQUk7QUFBQSxNQUFJO0FBQUEsTUFDcEQ7QUFBQSxNQUFHO0FBQUEsTUFBRztBQUFBLE1BQUk7QUFBQSxNQUFJO0FBQUEsTUFBRztBQUFBLE1BQUc7QUFBQSxNQUFHO0FBQUEsTUFBSTtBQUFBLE1BQUk7QUFBQSxNQUFJO0FBQUEsTUFBRztBQUFBLE1BQUk7QUFBQSxNQUFJO0FBQUEsTUFBSTtBQUFBLE1BQUc7QUFBQSxNQUNyRDtBQUFBLE1BQUk7QUFBQSxNQUFHO0FBQUEsTUFBRztBQUFBLE1BQUk7QUFBQSxNQUFJO0FBQUEsTUFBSTtBQUFBLE1BQUc7QUFBQSxNQUFJO0FBQUEsTUFBRztBQUFBLE1BQUc7QUFBQSxNQUFJO0FBQUEsTUFBRztBQUFBLE1BQUk7QUFBQSxNQUFHO0FBQUEsTUFBSTtBQUFBLE1BQ3JEO0FBQUEsTUFBRztBQUFBLE1BQUc7QUFBQSxNQUFJO0FBQUEsTUFBRztBQUFBLE1BQUk7QUFBQSxNQUFHO0FBQUEsTUFBSTtBQUFBLE1BQUc7QUFBQSxNQUFHO0FBQUEsTUFBSTtBQUFBLE1BQUc7QUFBQSxNQUFHO0FBQUEsTUFBSTtBQUFBLE1BQUk7QUFBQSxNQUFJO0FBQUEsSUFDdEQ7QUFBQTtBQUFBOzs7QUNqSkE7QUFBQSxpRkFBQUMsVUFBQUMsU0FBQTtBQUFBO0FBRUEsUUFBSSxRQUFRO0FBQ1osUUFBSSxTQUFTO0FBRWIsYUFBUyxLQUFLLE1BQU0sS0FBSyxLQUFLO0FBQzVCLFVBQUksRUFBRSxnQkFBZ0I7QUFDcEIsZUFBTyxJQUFJLEtBQUssTUFBTSxLQUFLLEdBQUc7QUFDaEMsV0FBSyxPQUFPO0FBQ1osV0FBSyxZQUFZLEtBQUssWUFBWTtBQUNsQyxXQUFLLFVBQVUsS0FBSyxVQUFVO0FBQzlCLFdBQUssUUFBUTtBQUNiLFdBQUssUUFBUTtBQUViLFdBQUssTUFBTSxNQUFNLFFBQVEsS0FBSyxHQUFHLENBQUM7QUFBQSxJQUNwQztBQUNBLElBQUFBLFFBQU8sVUFBVTtBQUVqQixTQUFLLFVBQVUsUUFBUSxTQUFTLEtBQUssS0FBSztBQUV4QyxVQUFJLElBQUksU0FBUyxLQUFLO0FBQ3BCLGNBQU0sSUFBSSxLQUFLLEtBQUssRUFBRSxPQUFPLEdBQUcsRUFBRSxPQUFPO0FBQzNDLGFBQU8sSUFBSSxVQUFVLEtBQUssU0FBUztBQUduQyxlQUFTLElBQUksSUFBSSxRQUFRLElBQUksS0FBSyxXQUFXO0FBQzNDLFlBQUksS0FBSyxDQUFDO0FBRVosV0FBSyxJQUFJLEdBQUcsSUFBSSxJQUFJLFFBQVE7QUFDMUIsWUFBSSxDQUFDLEtBQUs7QUFDWixXQUFLLFFBQVEsSUFBSSxLQUFLLEtBQUssRUFBRSxPQUFPLEdBQUc7QUFHdkMsV0FBSyxJQUFJLEdBQUcsSUFBSSxJQUFJLFFBQVE7QUFDMUIsWUFBSSxDQUFDLEtBQUs7QUFDWixXQUFLLFFBQVEsSUFBSSxLQUFLLEtBQUssRUFBRSxPQUFPLEdBQUc7QUFBQSxJQUN6QztBQUVBLFNBQUssVUFBVSxTQUFTLFNBQVMsT0FBTyxLQUFLLEtBQUs7QUFDaEQsV0FBSyxNQUFNLE9BQU8sS0FBSyxHQUFHO0FBQzFCLGFBQU87QUFBQSxJQUNUO0FBRUEsU0FBSyxVQUFVLFNBQVMsU0FBUyxPQUFPLEtBQUs7QUFDM0MsV0FBSyxNQUFNLE9BQU8sS0FBSyxNQUFNLE9BQU8sQ0FBQztBQUNyQyxhQUFPLEtBQUssTUFBTSxPQUFPLEdBQUc7QUFBQSxJQUM5QjtBQUFBO0FBQUE7OztBQzlDQTtBQUFBLDRFQUFBQyxVQUFBO0FBQUEsUUFBSSxPQUFPQTtBQUVYLFNBQUssUUFBUTtBQUNiLFNBQUssU0FBUztBQUNkLFNBQUssTUFBTTtBQUNYLFNBQUssU0FBUztBQUNkLFNBQUssT0FBTztBQUdaLFNBQUssT0FBTyxLQUFLLElBQUk7QUFDckIsU0FBSyxTQUFTLEtBQUssSUFBSTtBQUN2QixTQUFLLFNBQVMsS0FBSyxJQUFJO0FBQ3ZCLFNBQUssU0FBUyxLQUFLLElBQUk7QUFDdkIsU0FBSyxTQUFTLEtBQUssSUFBSTtBQUN2QixTQUFLLFlBQVksS0FBSyxPQUFPO0FBQUE7QUFBQTs7O0FDZDdCO0FBQUEsb0ZBQUFDLFVBQUFDLFNBQUE7QUFBQTtBQUlBLFFBQU0sc0JBQXNCO0FBRTVCLFFBQU0sYUFBYTtBQUNuQixRQUFNLG1CQUFtQixPQUFPO0FBQUEsSUFDTDtBQUczQixRQUFNLDRCQUE0QjtBQUlsQyxRQUFNLHdCQUF3QixhQUFhO0FBRTNDLFFBQU0sZ0JBQWdCO0FBQUEsTUFDcEI7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxJQUNGO0FBRUEsSUFBQUEsUUFBTyxVQUFVO0FBQUEsTUFDZjtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQSx5QkFBeUI7QUFBQSxNQUN6QixZQUFZO0FBQUEsSUFDZDtBQUFBO0FBQUE7OztBQ3BDQTtBQUFBLGdGQUFBQyxVQUFBQyxTQUFBO0FBQUE7QUFFQSxRQUFNLFFBQ0osT0FBTyxZQUFZLFlBQ25CLFFBQVEsT0FDUixRQUFRLElBQUksY0FDWixjQUFjLEtBQUssUUFBUSxJQUFJLFVBQVUsSUFDdkMsSUFBSSxTQUFTLFFBQVEsTUFBTSxVQUFVLEdBQUcsSUFBSSxJQUM1QyxNQUFNO0FBQUEsSUFBQztBQUVYLElBQUFBLFFBQU8sVUFBVTtBQUFBO0FBQUE7OztBQ1ZqQjtBQUFBLDZFQUFBQyxVQUFBQyxTQUFBO0FBQUE7QUFFQSxRQUFNO0FBQUEsTUFDSjtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsSUFDRixJQUFJO0FBQ0osUUFBTSxRQUFRO0FBQ2QsSUFBQUQsV0FBVUMsUUFBTyxVQUFVLENBQUM7QUFHNUIsUUFBTSxLQUFLRCxTQUFRLEtBQUssQ0FBQztBQUN6QixRQUFNLFNBQVNBLFNBQVEsU0FBUyxDQUFDO0FBQ2pDLFFBQU0sTUFBTUEsU0FBUSxNQUFNLENBQUM7QUFDM0IsUUFBTSxVQUFVQSxTQUFRLFVBQVUsQ0FBQztBQUNuQyxRQUFNLElBQUlBLFNBQVEsSUFBSSxDQUFDO0FBQ3ZCLFFBQUksSUFBSTtBQUVSLFFBQU0sbUJBQW1CO0FBUXpCLFFBQU0sd0JBQXdCO0FBQUEsTUFDNUIsQ0FBQyxPQUFPLENBQUM7QUFBQSxNQUNULENBQUMsT0FBTyxVQUFVO0FBQUEsTUFDbEIsQ0FBQyxrQkFBa0IscUJBQXFCO0FBQUEsSUFDMUM7QUFFQSxRQUFNLGdCQUFnQixDQUFDLFVBQVU7QUFDL0IsaUJBQVcsQ0FBQyxPQUFPLEdBQUcsS0FBSyx1QkFBdUI7QUFDaEQsZ0JBQVEsTUFDTCxNQUFNLEdBQUcsS0FBSyxHQUFHLEVBQUUsS0FBSyxHQUFHLEtBQUssTUFBTSxHQUFHLEdBQUcsRUFDNUMsTUFBTSxHQUFHLEtBQUssR0FBRyxFQUFFLEtBQUssR0FBRyxLQUFLLE1BQU0sR0FBRyxHQUFHO0FBQUEsTUFDakQ7QUFDQSxhQUFPO0FBQUEsSUFDVDtBQUVBLFFBQU0sY0FBYyxDQUFDLE1BQU0sT0FBTyxhQUFhO0FBQzdDLFlBQU0sT0FBTyxjQUFjLEtBQUs7QUFDaEMsWUFBTSxRQUFRO0FBQ2QsWUFBTSxNQUFNLE9BQU8sS0FBSztBQUN4QixRQUFFLElBQUksSUFBSTtBQUNWLFVBQUksS0FBSyxJQUFJO0FBQ2IsY0FBUSxLQUFLLElBQUk7QUFDakIsU0FBRyxLQUFLLElBQUksSUFBSSxPQUFPLE9BQU8sV0FBVyxNQUFNLE1BQVM7QUFDeEQsYUFBTyxLQUFLLElBQUksSUFBSSxPQUFPLE1BQU0sV0FBVyxNQUFNLE1BQVM7QUFBQSxJQUM3RDtBQVFBLGdCQUFZLHFCQUFxQixhQUFhO0FBQzlDLGdCQUFZLDBCQUEwQixNQUFNO0FBTTVDLGdCQUFZLHdCQUF3QixnQkFBZ0IsZ0JBQWdCLEdBQUc7QUFLdkUsZ0JBQVksZUFBZSxJQUFJLElBQUksRUFBRSxpQkFBaUIsQ0FBQyxRQUNoQyxJQUFJLEVBQUUsaUJBQWlCLENBQUMsUUFDeEIsSUFBSSxFQUFFLGlCQUFpQixDQUFDLEdBQUc7QUFFbEQsZ0JBQVksb0JBQW9CLElBQUksSUFBSSxFQUFFLHNCQUFzQixDQUFDLFFBQ3JDLElBQUksRUFBRSxzQkFBc0IsQ0FBQyxRQUM3QixJQUFJLEVBQUUsc0JBQXNCLENBQUMsR0FBRztBQU81RCxnQkFBWSx3QkFBd0IsTUFBTSxJQUFJLEVBQUUsb0JBQW9CLENBQ3BFLElBQUksSUFBSSxFQUFFLGlCQUFpQixDQUFDLEdBQUc7QUFFL0IsZ0JBQVksNkJBQTZCLE1BQU0sSUFBSSxFQUFFLG9CQUFvQixDQUN6RSxJQUFJLElBQUksRUFBRSxzQkFBc0IsQ0FBQyxHQUFHO0FBTXBDLGdCQUFZLGNBQWMsUUFBUSxJQUFJLEVBQUUsb0JBQW9CLENBQzVELFNBQVMsSUFBSSxFQUFFLG9CQUFvQixDQUFDLE1BQU07QUFFMUMsZ0JBQVksbUJBQW1CLFNBQVMsSUFBSSxFQUFFLHlCQUF5QixDQUN2RSxTQUFTLElBQUksRUFBRSx5QkFBeUIsQ0FBQyxNQUFNO0FBSy9DLGdCQUFZLG1CQUFtQixHQUFHLGdCQUFnQixHQUFHO0FBTXJELGdCQUFZLFNBQVMsVUFBVSxJQUFJLEVBQUUsZUFBZSxDQUNwRCxTQUFTLElBQUksRUFBRSxlQUFlLENBQUMsTUFBTTtBQVdyQyxnQkFBWSxhQUFhLEtBQUssSUFBSSxFQUFFLFdBQVcsQ0FDL0MsR0FBRyxJQUFJLEVBQUUsVUFBVSxDQUFDLElBQ2xCLElBQUksRUFBRSxLQUFLLENBQUMsR0FBRztBQUVqQixnQkFBWSxRQUFRLElBQUksSUFBSSxFQUFFLFNBQVMsQ0FBQyxHQUFHO0FBSzNDLGdCQUFZLGNBQWMsV0FBVyxJQUFJLEVBQUUsZ0JBQWdCLENBQzNELEdBQUcsSUFBSSxFQUFFLGVBQWUsQ0FBQyxJQUN2QixJQUFJLEVBQUUsS0FBSyxDQUFDLEdBQUc7QUFFakIsZ0JBQVksU0FBUyxJQUFJLElBQUksRUFBRSxVQUFVLENBQUMsR0FBRztBQUU3QyxnQkFBWSxRQUFRLGNBQWM7QUFLbEMsZ0JBQVkseUJBQXlCLEdBQUcsSUFBSSxFQUFFLHNCQUFzQixDQUFDLFVBQVU7QUFDL0UsZ0JBQVksb0JBQW9CLEdBQUcsSUFBSSxFQUFFLGlCQUFpQixDQUFDLFVBQVU7QUFFckUsZ0JBQVksZUFBZSxZQUFZLElBQUksRUFBRSxnQkFBZ0IsQ0FBQyxXQUNqQyxJQUFJLEVBQUUsZ0JBQWdCLENBQUMsV0FDdkIsSUFBSSxFQUFFLGdCQUFnQixDQUFDLE9BQzNCLElBQUksRUFBRSxVQUFVLENBQUMsS0FDckIsSUFBSSxFQUFFLEtBQUssQ0FBQyxPQUNSO0FBRXpCLGdCQUFZLG9CQUFvQixZQUFZLElBQUksRUFBRSxxQkFBcUIsQ0FBQyxXQUN0QyxJQUFJLEVBQUUscUJBQXFCLENBQUMsV0FDNUIsSUFBSSxFQUFFLHFCQUFxQixDQUFDLE9BQ2hDLElBQUksRUFBRSxlQUFlLENBQUMsS0FDMUIsSUFBSSxFQUFFLEtBQUssQ0FBQyxPQUNSO0FBRTlCLGdCQUFZLFVBQVUsSUFBSSxJQUFJLEVBQUUsSUFBSSxDQUFDLE9BQU8sSUFBSSxFQUFFLFdBQVcsQ0FBQyxHQUFHO0FBQ2pFLGdCQUFZLGVBQWUsSUFBSSxJQUFJLEVBQUUsSUFBSSxDQUFDLE9BQU8sSUFBSSxFQUFFLGdCQUFnQixDQUFDLEdBQUc7QUFJM0UsZ0JBQVksZUFBZSxHQUFHLG1CQUNQLEdBQUcseUJBQXlCLGtCQUNyQix5QkFBeUIsb0JBQ3pCLHlCQUF5QixNQUFNO0FBQzdELGdCQUFZLFVBQVUsR0FBRyxJQUFJLEVBQUUsV0FBVyxDQUFDLGNBQWM7QUFDekQsZ0JBQVksY0FBYyxJQUFJLEVBQUUsV0FBVyxJQUM3QixNQUFNLElBQUksRUFBRSxVQUFVLENBQUMsUUFDakIsSUFBSSxFQUFFLEtBQUssQ0FBQyxnQkFDSjtBQUM1QixnQkFBWSxhQUFhLElBQUksRUFBRSxNQUFNLEdBQUcsSUFBSTtBQUM1QyxnQkFBWSxpQkFBaUIsSUFBSSxFQUFFLFVBQVUsR0FBRyxJQUFJO0FBSXBELGdCQUFZLGFBQWEsU0FBUztBQUVsQyxnQkFBWSxhQUFhLFNBQVMsSUFBSSxFQUFFLFNBQVMsQ0FBQyxRQUFRLElBQUk7QUFDOUQsSUFBQUEsU0FBUSxtQkFBbUI7QUFFM0IsZ0JBQVksU0FBUyxJQUFJLElBQUksRUFBRSxTQUFTLENBQUMsR0FBRyxJQUFJLEVBQUUsV0FBVyxDQUFDLEdBQUc7QUFDakUsZ0JBQVksY0FBYyxJQUFJLElBQUksRUFBRSxTQUFTLENBQUMsR0FBRyxJQUFJLEVBQUUsZ0JBQWdCLENBQUMsR0FBRztBQUkzRSxnQkFBWSxhQUFhLFNBQVM7QUFFbEMsZ0JBQVksYUFBYSxTQUFTLElBQUksRUFBRSxTQUFTLENBQUMsUUFBUSxJQUFJO0FBQzlELElBQUFBLFNBQVEsbUJBQW1CO0FBRTNCLGdCQUFZLFNBQVMsSUFBSSxJQUFJLEVBQUUsU0FBUyxDQUFDLEdBQUcsSUFBSSxFQUFFLFdBQVcsQ0FBQyxHQUFHO0FBQ2pFLGdCQUFZLGNBQWMsSUFBSSxJQUFJLEVBQUUsU0FBUyxDQUFDLEdBQUcsSUFBSSxFQUFFLGdCQUFnQixDQUFDLEdBQUc7QUFHM0UsZ0JBQVksbUJBQW1CLElBQUksSUFBSSxFQUFFLElBQUksQ0FBQyxRQUFRLElBQUksRUFBRSxVQUFVLENBQUMsT0FBTztBQUM5RSxnQkFBWSxjQUFjLElBQUksSUFBSSxFQUFFLElBQUksQ0FBQyxRQUFRLElBQUksRUFBRSxTQUFTLENBQUMsT0FBTztBQUl4RSxnQkFBWSxrQkFBa0IsU0FBUyxJQUFJLEVBQUUsSUFBSSxDQUNqRCxRQUFRLElBQUksRUFBRSxVQUFVLENBQUMsSUFBSSxJQUFJLEVBQUUsV0FBVyxDQUFDLEtBQUssSUFBSTtBQUN4RCxJQUFBQSxTQUFRLHdCQUF3QjtBQU1oQyxnQkFBWSxlQUFlLFNBQVMsSUFBSSxFQUFFLFdBQVcsQ0FBQyxjQUUvQixJQUFJLEVBQUUsV0FBVyxDQUFDLFFBQ2Y7QUFFMUIsZ0JBQVksb0JBQW9CLFNBQVMsSUFBSSxFQUFFLGdCQUFnQixDQUFDLGNBRXBDLElBQUksRUFBRSxnQkFBZ0IsQ0FBQyxRQUNwQjtBQUcvQixnQkFBWSxRQUFRLGlCQUFpQjtBQUVyQyxnQkFBWSxRQUFRLDJCQUEyQjtBQUMvQyxnQkFBWSxXQUFXLDZCQUE2QjtBQUFBO0FBQUE7OztBQzlOcEQ7QUFBQSx3RkFBQUUsVUFBQUMsU0FBQTtBQUFBO0FBR0EsUUFBTSxjQUFjLE9BQU8sT0FBTyxFQUFFLE9BQU8sS0FBSyxDQUFDO0FBQ2pELFFBQU0sWUFBWSxPQUFPLE9BQU8sQ0FBRSxDQUFDO0FBQ25DLFFBQU0sZUFBZSxhQUFXO0FBQzlCLFVBQUksQ0FBQyxTQUFTO0FBQ1osZUFBTztBQUFBLE1BQ1Q7QUFFQSxVQUFJLE9BQU8sWUFBWSxVQUFVO0FBQy9CLGVBQU87QUFBQSxNQUNUO0FBRUEsYUFBTztBQUFBLElBQ1Q7QUFDQSxJQUFBQSxRQUFPLFVBQVU7QUFBQTtBQUFBOzs7QUNoQmpCO0FBQUEsc0ZBQUFDLFVBQUFDLFNBQUE7QUFBQTtBQUVBLFFBQU0sVUFBVTtBQUNoQixRQUFNLHFCQUFxQixDQUFDLEdBQUcsTUFBTTtBQUNuQyxVQUFJLE9BQU8sTUFBTSxZQUFZLE9BQU8sTUFBTSxVQUFVO0FBQ2xELGVBQU8sTUFBTSxJQUFJLElBQUksSUFBSSxJQUFJLEtBQUs7QUFBQSxNQUNwQztBQUVBLFlBQU0sT0FBTyxRQUFRLEtBQUssQ0FBQztBQUMzQixZQUFNLE9BQU8sUUFBUSxLQUFLLENBQUM7QUFFM0IsVUFBSSxRQUFRLE1BQU07QUFDaEIsWUFBSSxDQUFDO0FBQ0wsWUFBSSxDQUFDO0FBQUEsTUFDUDtBQUVBLGFBQU8sTUFBTSxJQUFJLElBQ1osUUFBUSxDQUFDLE9BQVEsS0FDakIsUUFBUSxDQUFDLE9BQVEsSUFDbEIsSUFBSSxJQUFJLEtBQ1I7QUFBQSxJQUNOO0FBRUEsUUFBTSxzQkFBc0IsQ0FBQyxHQUFHLE1BQU0sbUJBQW1CLEdBQUcsQ0FBQztBQUU3RCxJQUFBQSxRQUFPLFVBQVU7QUFBQSxNQUNmO0FBQUEsTUFDQTtBQUFBLElBQ0Y7QUFBQTtBQUFBOzs7QUM1QkE7QUFBQSxnRkFBQUMsVUFBQUMsU0FBQTtBQUFBO0FBRUEsUUFBTSxRQUFRO0FBQ2QsUUFBTSxFQUFFLFlBQVksaUJBQWlCLElBQUk7QUFDekMsUUFBTSxFQUFFLFFBQVEsSUFBSSxFQUFFLElBQUk7QUFFMUIsUUFBTSxlQUFlO0FBQ3JCLFFBQU0sRUFBRSxtQkFBbUIsSUFBSTtBQUUvQixRQUFNLHlCQUF5QixDQUFDLFlBQVksZUFBZTtBQUN6RCxZQUFNLGNBQWMsV0FBVyxNQUFNLEdBQUc7QUFDeEMsVUFBSSxZQUFZLFNBQVMsV0FBVyxRQUFRO0FBQzFDLGVBQU87QUFBQSxNQUNUO0FBRUEsZUFBUyxJQUFJLEdBQUcsSUFBSSxZQUFZLFFBQVEsS0FBSztBQUMzQyxZQUFJLG1CQUFtQixXQUFXLENBQUMsR0FBRyxZQUFZLENBQUMsQ0FBQyxNQUFNLEdBQUc7QUFDM0QsaUJBQU87QUFBQSxRQUNUO0FBQUEsTUFDRjtBQUVBLGFBQU87QUFBQSxJQUNUO0FBRUEsUUFBTSxTQUFOLE1BQU0sUUFBTztBQUFBLE1BQ1gsWUFBYSxTQUFTLFNBQVM7QUFDN0Isa0JBQVUsYUFBYSxPQUFPO0FBRTlCLFlBQUksbUJBQW1CLFNBQVE7QUFDN0IsY0FBSSxRQUFRLFVBQVUsQ0FBQyxDQUFDLFFBQVEsU0FDOUIsUUFBUSxzQkFBc0IsQ0FBQyxDQUFDLFFBQVEsbUJBQW1CO0FBQzNELG1CQUFPO0FBQUEsVUFDVCxPQUFPO0FBQ0wsc0JBQVUsUUFBUTtBQUFBLFVBQ3BCO0FBQUEsUUFDRixXQUFXLE9BQU8sWUFBWSxVQUFVO0FBQ3RDLGdCQUFNLElBQUksVUFBVSxnREFBZ0QsT0FBTyxPQUFPLElBQUk7QUFBQSxRQUN4RjtBQUVBLFlBQUksUUFBUSxTQUFTLFlBQVk7QUFDL0IsZ0JBQU0sSUFBSTtBQUFBLFlBQ1IsMEJBQTBCLFVBQVU7QUFBQSxVQUN0QztBQUFBLFFBQ0Y7QUFFQSxjQUFNLFVBQVUsU0FBUyxPQUFPO0FBQ2hDLGFBQUssVUFBVTtBQUNmLGFBQUssUUFBUSxDQUFDLENBQUMsUUFBUTtBQUd2QixhQUFLLG9CQUFvQixDQUFDLENBQUMsUUFBUTtBQUVuQyxjQUFNLElBQUksUUFBUSxLQUFLLEVBQUUsTUFBTSxRQUFRLFFBQVEsR0FBRyxFQUFFLEtBQUssSUFBSSxHQUFHLEVBQUUsSUFBSSxDQUFDO0FBRXZFLFlBQUksQ0FBQyxHQUFHO0FBQ04sZ0JBQU0sSUFBSSxVQUFVLG9CQUFvQixPQUFPLEVBQUU7QUFBQSxRQUNuRDtBQUVBLGFBQUssTUFBTTtBQUdYLGFBQUssUUFBUSxDQUFDLEVBQUUsQ0FBQztBQUNqQixhQUFLLFFBQVEsQ0FBQyxFQUFFLENBQUM7QUFDakIsYUFBSyxRQUFRLENBQUMsRUFBRSxDQUFDO0FBRWpCLFlBQUksS0FBSyxRQUFRLG9CQUFvQixLQUFLLFFBQVEsR0FBRztBQUNuRCxnQkFBTSxJQUFJLFVBQVUsdUJBQXVCO0FBQUEsUUFDN0M7QUFFQSxZQUFJLEtBQUssUUFBUSxvQkFBb0IsS0FBSyxRQUFRLEdBQUc7QUFDbkQsZ0JBQU0sSUFBSSxVQUFVLHVCQUF1QjtBQUFBLFFBQzdDO0FBRUEsWUFBSSxLQUFLLFFBQVEsb0JBQW9CLEtBQUssUUFBUSxHQUFHO0FBQ25ELGdCQUFNLElBQUksVUFBVSx1QkFBdUI7QUFBQSxRQUM3QztBQUdBLFlBQUksQ0FBQyxFQUFFLENBQUMsR0FBRztBQUNULGVBQUssYUFBYSxDQUFDO0FBQUEsUUFDckIsT0FBTztBQUNMLGVBQUssYUFBYSxFQUFFLENBQUMsRUFBRSxNQUFNLEdBQUcsRUFBRSxJQUFJLENBQUMsT0FBTztBQUM1QyxnQkFBSSxXQUFXLEtBQUssRUFBRSxHQUFHO0FBQ3ZCLG9CQUFNLE1BQU0sQ0FBQztBQUNiLGtCQUFJLE9BQU8sS0FBSyxNQUFNLGtCQUFrQjtBQUN0Qyx1QkFBTztBQUFBLGNBQ1Q7QUFBQSxZQUNGO0FBQ0EsbUJBQU87QUFBQSxVQUNULENBQUM7QUFBQSxRQUNIO0FBRUEsYUFBSyxRQUFRLEVBQUUsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxFQUFFLE1BQU0sR0FBRyxJQUFJLENBQUM7QUFDdkMsYUFBSyxPQUFPO0FBQUEsTUFDZDtBQUFBLE1BRUEsU0FBVTtBQUNSLGFBQUssVUFBVSxHQUFHLEtBQUssS0FBSyxJQUFJLEtBQUssS0FBSyxJQUFJLEtBQUssS0FBSztBQUN4RCxZQUFJLEtBQUssV0FBVyxRQUFRO0FBQzFCLGVBQUssV0FBVyxJQUFJLEtBQUssV0FBVyxLQUFLLEdBQUcsQ0FBQztBQUFBLFFBQy9DO0FBQ0EsZUFBTyxLQUFLO0FBQUEsTUFDZDtBQUFBLE1BRUEsV0FBWTtBQUNWLGVBQU8sS0FBSztBQUFBLE1BQ2Q7QUFBQSxNQUVBLFFBQVMsT0FBTztBQUNkLGNBQU0sa0JBQWtCLEtBQUssU0FBUyxLQUFLLFNBQVMsS0FBSztBQUN6RCxZQUFJLEVBQUUsaUJBQWlCLFVBQVM7QUFDOUIsY0FBSSxPQUFPLFVBQVUsWUFBWSxVQUFVLEtBQUssU0FBUztBQUN2RCxtQkFBTztBQUFBLFVBQ1Q7QUFDQSxrQkFBUSxJQUFJLFFBQU8sT0FBTyxLQUFLLE9BQU87QUFBQSxRQUN4QztBQUVBLFlBQUksTUFBTSxZQUFZLEtBQUssU0FBUztBQUNsQyxpQkFBTztBQUFBLFFBQ1Q7QUFFQSxlQUFPLEtBQUssWUFBWSxLQUFLLEtBQUssS0FBSyxXQUFXLEtBQUs7QUFBQSxNQUN6RDtBQUFBLE1BRUEsWUFBYSxPQUFPO0FBQ2xCLFlBQUksRUFBRSxpQkFBaUIsVUFBUztBQUM5QixrQkFBUSxJQUFJLFFBQU8sT0FBTyxLQUFLLE9BQU87QUFBQSxRQUN4QztBQUVBLFlBQUksS0FBSyxRQUFRLE1BQU0sT0FBTztBQUM1QixpQkFBTztBQUFBLFFBQ1Q7QUFDQSxZQUFJLEtBQUssUUFBUSxNQUFNLE9BQU87QUFDNUIsaUJBQU87QUFBQSxRQUNUO0FBQ0EsWUFBSSxLQUFLLFFBQVEsTUFBTSxPQUFPO0FBQzVCLGlCQUFPO0FBQUEsUUFDVDtBQUNBLFlBQUksS0FBSyxRQUFRLE1BQU0sT0FBTztBQUM1QixpQkFBTztBQUFBLFFBQ1Q7QUFDQSxZQUFJLEtBQUssUUFBUSxNQUFNLE9BQU87QUFDNUIsaUJBQU87QUFBQSxRQUNUO0FBQ0EsWUFBSSxLQUFLLFFBQVEsTUFBTSxPQUFPO0FBQzVCLGlCQUFPO0FBQUEsUUFDVDtBQUNBLGVBQU87QUFBQSxNQUNUO0FBQUEsTUFFQSxXQUFZLE9BQU87QUFDakIsWUFBSSxFQUFFLGlCQUFpQixVQUFTO0FBQzlCLGtCQUFRLElBQUksUUFBTyxPQUFPLEtBQUssT0FBTztBQUFBLFFBQ3hDO0FBR0EsWUFBSSxLQUFLLFdBQVcsVUFBVSxDQUFDLE1BQU0sV0FBVyxRQUFRO0FBQ3RELGlCQUFPO0FBQUEsUUFDVCxXQUFXLENBQUMsS0FBSyxXQUFXLFVBQVUsTUFBTSxXQUFXLFFBQVE7QUFDN0QsaUJBQU87QUFBQSxRQUNULFdBQVcsQ0FBQyxLQUFLLFdBQVcsVUFBVSxDQUFDLE1BQU0sV0FBVyxRQUFRO0FBQzlELGlCQUFPO0FBQUEsUUFDVDtBQUVBLFlBQUksSUFBSTtBQUNSLFdBQUc7QUFDRCxnQkFBTSxJQUFJLEtBQUssV0FBVyxDQUFDO0FBQzNCLGdCQUFNLElBQUksTUFBTSxXQUFXLENBQUM7QUFDNUIsZ0JBQU0sc0JBQXNCLEdBQUcsR0FBRyxDQUFDO0FBQ25DLGNBQUksTUFBTSxVQUFhLE1BQU0sUUFBVztBQUN0QyxtQkFBTztBQUFBLFVBQ1QsV0FBVyxNQUFNLFFBQVc7QUFDMUIsbUJBQU87QUFBQSxVQUNULFdBQVcsTUFBTSxRQUFXO0FBQzFCLG1CQUFPO0FBQUEsVUFDVCxXQUFXLE1BQU0sR0FBRztBQUNsQjtBQUFBLFVBQ0YsT0FBTztBQUNMLG1CQUFPLG1CQUFtQixHQUFHLENBQUM7QUFBQSxVQUNoQztBQUFBLFFBQ0YsU0FBUyxFQUFFO0FBQUEsTUFDYjtBQUFBLE1BRUEsYUFBYyxPQUFPO0FBQ25CLFlBQUksRUFBRSxpQkFBaUIsVUFBUztBQUM5QixrQkFBUSxJQUFJLFFBQU8sT0FBTyxLQUFLLE9BQU87QUFBQSxRQUN4QztBQUVBLFlBQUksSUFBSTtBQUNSLFdBQUc7QUFDRCxnQkFBTSxJQUFJLEtBQUssTUFBTSxDQUFDO0FBQ3RCLGdCQUFNLElBQUksTUFBTSxNQUFNLENBQUM7QUFDdkIsZ0JBQU0saUJBQWlCLEdBQUcsR0FBRyxDQUFDO0FBQzlCLGNBQUksTUFBTSxVQUFhLE1BQU0sUUFBVztBQUN0QyxtQkFBTztBQUFBLFVBQ1QsV0FBVyxNQUFNLFFBQVc7QUFDMUIsbUJBQU87QUFBQSxVQUNULFdBQVcsTUFBTSxRQUFXO0FBQzFCLG1CQUFPO0FBQUEsVUFDVCxXQUFXLE1BQU0sR0FBRztBQUNsQjtBQUFBLFVBQ0YsT0FBTztBQUNMLG1CQUFPLG1CQUFtQixHQUFHLENBQUM7QUFBQSxVQUNoQztBQUFBLFFBQ0YsU0FBUyxFQUFFO0FBQUEsTUFDYjtBQUFBO0FBQUE7QUFBQSxNQUlBLElBQUssU0FBUyxZQUFZLGdCQUFnQjtBQUN4QyxZQUFJLFFBQVEsV0FBVyxLQUFLLEdBQUc7QUFDN0IsY0FBSSxDQUFDLGNBQWMsbUJBQW1CLE9BQU87QUFDM0Msa0JBQU0sSUFBSSxNQUFNLGlEQUFpRDtBQUFBLFVBQ25FO0FBRUEsY0FBSSxZQUFZO0FBQ2Qsa0JBQU0sUUFBUSxJQUFJLFVBQVUsR0FBRyxNQUFNLEtBQUssUUFBUSxRQUFRLEdBQUcsRUFBRSxlQUFlLElBQUksR0FBRyxFQUFFLFVBQVUsQ0FBQztBQUNsRyxnQkFBSSxDQUFDLFNBQVMsTUFBTSxDQUFDLE1BQU0sWUFBWTtBQUNyQyxvQkFBTSxJQUFJLE1BQU0sdUJBQXVCLFVBQVUsRUFBRTtBQUFBLFlBQ3JEO0FBQUEsVUFDRjtBQUFBLFFBQ0Y7QUFFQSxnQkFBUSxTQUFTO0FBQUEsVUFDZixLQUFLO0FBQ0gsaUJBQUssV0FBVyxTQUFTO0FBQ3pCLGlCQUFLLFFBQVE7QUFDYixpQkFBSyxRQUFRO0FBQ2IsaUJBQUs7QUFDTCxpQkFBSyxJQUFJLE9BQU8sWUFBWSxjQUFjO0FBQzFDO0FBQUEsVUFDRixLQUFLO0FBQ0gsaUJBQUssV0FBVyxTQUFTO0FBQ3pCLGlCQUFLLFFBQVE7QUFDYixpQkFBSztBQUNMLGlCQUFLLElBQUksT0FBTyxZQUFZLGNBQWM7QUFDMUM7QUFBQSxVQUNGLEtBQUs7QUFJSCxpQkFBSyxXQUFXLFNBQVM7QUFDekIsaUJBQUssSUFBSSxTQUFTLFlBQVksY0FBYztBQUM1QyxpQkFBSyxJQUFJLE9BQU8sWUFBWSxjQUFjO0FBQzFDO0FBQUEsVUFHRixLQUFLO0FBQ0gsZ0JBQUksS0FBSyxXQUFXLFdBQVcsR0FBRztBQUNoQyxtQkFBSyxJQUFJLFNBQVMsWUFBWSxjQUFjO0FBQUEsWUFDOUM7QUFDQSxpQkFBSyxJQUFJLE9BQU8sWUFBWSxjQUFjO0FBQzFDO0FBQUEsVUFDRixLQUFLO0FBQ0gsZ0JBQUksS0FBSyxXQUFXLFdBQVcsR0FBRztBQUNoQyxvQkFBTSxJQUFJLE1BQU0sV0FBVyxLQUFLLEdBQUcsc0JBQXNCO0FBQUEsWUFDM0Q7QUFDQSxpQkFBSyxXQUFXLFNBQVM7QUFDekI7QUFBQSxVQUVGLEtBQUs7QUFLSCxnQkFDRSxLQUFLLFVBQVUsS0FDZixLQUFLLFVBQVUsS0FDZixLQUFLLFdBQVcsV0FBVyxHQUMzQjtBQUNBLG1CQUFLO0FBQUEsWUFDUDtBQUNBLGlCQUFLLFFBQVE7QUFDYixpQkFBSyxRQUFRO0FBQ2IsaUJBQUssYUFBYSxDQUFDO0FBQ25CO0FBQUEsVUFDRixLQUFLO0FBS0gsZ0JBQUksS0FBSyxVQUFVLEtBQUssS0FBSyxXQUFXLFdBQVcsR0FBRztBQUNwRCxtQkFBSztBQUFBLFlBQ1A7QUFDQSxpQkFBSyxRQUFRO0FBQ2IsaUJBQUssYUFBYSxDQUFDO0FBQ25CO0FBQUEsVUFDRixLQUFLO0FBS0gsZ0JBQUksS0FBSyxXQUFXLFdBQVcsR0FBRztBQUNoQyxtQkFBSztBQUFBLFlBQ1A7QUFDQSxpQkFBSyxhQUFhLENBQUM7QUFDbkI7QUFBQSxVQUdGLEtBQUssT0FBTztBQUNWLGtCQUFNLE9BQU8sT0FBTyxjQUFjLElBQUksSUFBSTtBQUUxQyxnQkFBSSxLQUFLLFdBQVcsV0FBVyxHQUFHO0FBQ2hDLG1CQUFLLGFBQWEsQ0FBQyxJQUFJO0FBQUEsWUFDekIsT0FBTztBQUNMLGtCQUFJLElBQUksS0FBSyxXQUFXO0FBQ3hCLHFCQUFPLEVBQUUsS0FBSyxHQUFHO0FBQ2Ysb0JBQUksT0FBTyxLQUFLLFdBQVcsQ0FBQyxNQUFNLFVBQVU7QUFDMUMsdUJBQUssV0FBVyxDQUFDO0FBQ2pCLHNCQUFJO0FBQUEsZ0JBQ047QUFBQSxjQUNGO0FBQ0Esa0JBQUksTUFBTSxJQUFJO0FBRVosb0JBQUksZUFBZSxLQUFLLFdBQVcsS0FBSyxHQUFHLEtBQUssbUJBQW1CLE9BQU87QUFDeEUsd0JBQU0sSUFBSSxNQUFNLHVEQUF1RDtBQUFBLGdCQUN6RTtBQUNBLHFCQUFLLFdBQVcsS0FBSyxJQUFJO0FBQUEsY0FDM0I7QUFBQSxZQUNGO0FBQ0EsZ0JBQUksWUFBWTtBQUdkLGtCQUFJLGFBQWEsQ0FBQyxZQUFZLElBQUk7QUFDbEMsa0JBQUksbUJBQW1CLE9BQU87QUFDNUIsNkJBQWEsQ0FBQyxVQUFVO0FBQUEsY0FDMUI7QUFDQSxrQkFBSSx1QkFBdUIsS0FBSyxZQUFZLFVBQVUsR0FBRztBQUN2RCxzQkFBTSxpQkFBaUIsS0FBSyxXQUFXLFdBQVcsTUFBTSxHQUFHLEVBQUUsTUFBTTtBQUNuRSxvQkFBSSxNQUFNLGNBQWMsR0FBRztBQUN6Qix1QkFBSyxhQUFhO0FBQUEsZ0JBQ3BCO0FBQUEsY0FDRixPQUFPO0FBQ0wscUJBQUssYUFBYTtBQUFBLGNBQ3BCO0FBQUEsWUFDRjtBQUNBO0FBQUEsVUFDRjtBQUFBLFVBQ0E7QUFDRSxrQkFBTSxJQUFJLE1BQU0sK0JBQStCLE9BQU8sRUFBRTtBQUFBLFFBQzVEO0FBQ0EsYUFBSyxNQUFNLEtBQUssT0FBTztBQUN2QixZQUFJLEtBQUssTUFBTSxRQUFRO0FBQ3JCLGVBQUssT0FBTyxJQUFJLEtBQUssTUFBTSxLQUFLLEdBQUcsQ0FBQztBQUFBLFFBQ3RDO0FBQ0EsZUFBTztBQUFBLE1BQ1Q7QUFBQSxJQUNGO0FBRUEsSUFBQUEsUUFBTyxVQUFVO0FBQUE7QUFBQTs7O0FDN1ZqQjtBQUFBLGlGQUFBQyxVQUFBQyxTQUFBO0FBQUE7QUFFQSxRQUFNLFNBQVM7QUFDZixRQUFNLFFBQVEsQ0FBQyxTQUFTLFNBQVMsY0FBYyxVQUFVO0FBQ3ZELFVBQUksbUJBQW1CLFFBQVE7QUFDN0IsZUFBTztBQUFBLE1BQ1Q7QUFDQSxVQUFJO0FBQ0YsZUFBTyxJQUFJLE9BQU8sU0FBUyxPQUFPO0FBQUEsTUFDcEMsU0FBUyxJQUFJO0FBQ1gsWUFBSSxDQUFDLGFBQWE7QUFDaEIsaUJBQU87QUFBQSxRQUNUO0FBQ0EsY0FBTTtBQUFBLE1BQ1I7QUFBQSxJQUNGO0FBRUEsSUFBQUEsUUFBTyxVQUFVO0FBQUE7QUFBQTs7O0FDakJqQjtBQUFBLGlGQUFBQyxVQUFBQyxTQUFBO0FBQUE7QUFFQSxRQUFNLFFBQVE7QUFDZCxRQUFNLFFBQVEsQ0FBQyxTQUFTLFlBQVk7QUFDbEMsWUFBTSxJQUFJLE1BQU0sU0FBUyxPQUFPO0FBQ2hDLGFBQU8sSUFBSSxFQUFFLFVBQVU7QUFBQSxJQUN6QjtBQUNBLElBQUFBLFFBQU8sVUFBVTtBQUFBO0FBQUE7OztBQ1BqQjtBQUFBLGlGQUFBQyxVQUFBQyxTQUFBO0FBQUE7QUFFQSxRQUFNLFFBQVE7QUFDZCxRQUFNLFFBQVEsQ0FBQyxTQUFTLFlBQVk7QUFDbEMsWUFBTSxJQUFJLE1BQU0sUUFBUSxLQUFLLEVBQUUsUUFBUSxVQUFVLEVBQUUsR0FBRyxPQUFPO0FBQzdELGFBQU8sSUFBSSxFQUFFLFVBQVU7QUFBQSxJQUN6QjtBQUNBLElBQUFBLFFBQU8sVUFBVTtBQUFBO0FBQUE7OztBQ1BqQjtBQUFBLCtFQUFBQyxVQUFBQyxTQUFBO0FBQUE7QUFFQSxRQUFNLFNBQVM7QUFFZixRQUFNLE1BQU0sQ0FBQyxTQUFTLFNBQVMsU0FBUyxZQUFZLG1CQUFtQjtBQUNyRSxVQUFJLE9BQVEsWUFBYSxVQUFVO0FBQ2pDLHlCQUFpQjtBQUNqQixxQkFBYTtBQUNiLGtCQUFVO0FBQUEsTUFDWjtBQUVBLFVBQUk7QUFDRixlQUFPLElBQUk7QUFBQSxVQUNULG1CQUFtQixTQUFTLFFBQVEsVUFBVTtBQUFBLFVBQzlDO0FBQUEsUUFDRixFQUFFLElBQUksU0FBUyxZQUFZLGNBQWMsRUFBRTtBQUFBLE1BQzdDLFNBQVMsSUFBSTtBQUNYLGVBQU87QUFBQSxNQUNUO0FBQUEsSUFDRjtBQUNBLElBQUFBLFFBQU8sVUFBVTtBQUFBO0FBQUE7OztBQ3BCakI7QUFBQSxnRkFBQUMsVUFBQUMsU0FBQTtBQUFBO0FBRUEsUUFBTSxRQUFRO0FBRWQsUUFBTSxPQUFPLENBQUMsVUFBVSxhQUFhO0FBQ25DLFlBQU0sS0FBSyxNQUFNLFVBQVUsTUFBTSxJQUFJO0FBQ3JDLFlBQU0sS0FBSyxNQUFNLFVBQVUsTUFBTSxJQUFJO0FBQ3JDLFlBQU0sYUFBYSxHQUFHLFFBQVEsRUFBRTtBQUVoQyxVQUFJLGVBQWUsR0FBRztBQUNwQixlQUFPO0FBQUEsTUFDVDtBQUVBLFlBQU0sV0FBVyxhQUFhO0FBQzlCLFlBQU0sY0FBYyxXQUFXLEtBQUs7QUFDcEMsWUFBTSxhQUFhLFdBQVcsS0FBSztBQUNuQyxZQUFNLGFBQWEsQ0FBQyxDQUFDLFlBQVksV0FBVztBQUM1QyxZQUFNLFlBQVksQ0FBQyxDQUFDLFdBQVcsV0FBVztBQUUxQyxVQUFJLGFBQWEsQ0FBQyxZQUFZO0FBUTVCLFlBQUksQ0FBQyxXQUFXLFNBQVMsQ0FBQyxXQUFXLE9BQU87QUFDMUMsaUJBQU87QUFBQSxRQUNUO0FBR0EsWUFBSSxXQUFXLFlBQVksV0FBVyxNQUFNLEdBQUc7QUFDN0MsY0FBSSxXQUFXLFNBQVMsQ0FBQyxXQUFXLE9BQU87QUFDekMsbUJBQU87QUFBQSxVQUNUO0FBQ0EsaUJBQU87QUFBQSxRQUNUO0FBQUEsTUFDRjtBQUdBLFlBQU0sU0FBUyxhQUFhLFFBQVE7QUFFcEMsVUFBSSxHQUFHLFVBQVUsR0FBRyxPQUFPO0FBQ3pCLGVBQU8sU0FBUztBQUFBLE1BQ2xCO0FBRUEsVUFBSSxHQUFHLFVBQVUsR0FBRyxPQUFPO0FBQ3pCLGVBQU8sU0FBUztBQUFBLE1BQ2xCO0FBRUEsVUFBSSxHQUFHLFVBQVUsR0FBRyxPQUFPO0FBQ3pCLGVBQU8sU0FBUztBQUFBLE1BQ2xCO0FBR0EsYUFBTztBQUFBLElBQ1Q7QUFFQSxJQUFBQSxRQUFPLFVBQVU7QUFBQTtBQUFBOzs7QUMzRGpCO0FBQUEsaUZBQUFDLFVBQUFDLFNBQUE7QUFBQTtBQUVBLFFBQU0sU0FBUztBQUNmLFFBQU0sUUFBUSxDQUFDLEdBQUcsVUFBVSxJQUFJLE9BQU8sR0FBRyxLQUFLLEVBQUU7QUFDakQsSUFBQUEsUUFBTyxVQUFVO0FBQUE7QUFBQTs7O0FDSmpCO0FBQUEsaUZBQUFDLFVBQUFDLFNBQUE7QUFBQTtBQUVBLFFBQU0sU0FBUztBQUNmLFFBQU0sUUFBUSxDQUFDLEdBQUcsVUFBVSxJQUFJLE9BQU8sR0FBRyxLQUFLLEVBQUU7QUFDakQsSUFBQUEsUUFBTyxVQUFVO0FBQUE7QUFBQTs7O0FDSmpCO0FBQUEsaUZBQUFDLFVBQUFDLFNBQUE7QUFBQTtBQUVBLFFBQU0sU0FBUztBQUNmLFFBQU0sUUFBUSxDQUFDLEdBQUcsVUFBVSxJQUFJLE9BQU8sR0FBRyxLQUFLLEVBQUU7QUFDakQsSUFBQUEsUUFBTyxVQUFVO0FBQUE7QUFBQTs7O0FDSmpCO0FBQUEsc0ZBQUFDLFVBQUFDLFNBQUE7QUFBQTtBQUVBLFFBQU0sUUFBUTtBQUNkLFFBQU0sYUFBYSxDQUFDLFNBQVMsWUFBWTtBQUN2QyxZQUFNLFNBQVMsTUFBTSxTQUFTLE9BQU87QUFDckMsYUFBUSxVQUFVLE9BQU8sV0FBVyxTQUFVLE9BQU8sYUFBYTtBQUFBLElBQ3BFO0FBQ0EsSUFBQUEsUUFBTyxVQUFVO0FBQUE7QUFBQTs7O0FDUGpCO0FBQUEsbUZBQUFDLFVBQUFDLFNBQUE7QUFBQTtBQUVBLFFBQU0sU0FBUztBQUNmLFFBQU0sVUFBVSxDQUFDLEdBQUcsR0FBRyxVQUNyQixJQUFJLE9BQU8sR0FBRyxLQUFLLEVBQUUsUUFBUSxJQUFJLE9BQU8sR0FBRyxLQUFLLENBQUM7QUFFbkQsSUFBQUEsUUFBTyxVQUFVO0FBQUE7QUFBQTs7O0FDTmpCO0FBQUEsb0ZBQUFDLFVBQUFDLFNBQUE7QUFBQTtBQUVBLFFBQU0sVUFBVTtBQUNoQixRQUFNLFdBQVcsQ0FBQyxHQUFHLEdBQUcsVUFBVSxRQUFRLEdBQUcsR0FBRyxLQUFLO0FBQ3JELElBQUFBLFFBQU8sVUFBVTtBQUFBO0FBQUE7OztBQ0pqQjtBQUFBLHlGQUFBQyxVQUFBQyxTQUFBO0FBQUE7QUFFQSxRQUFNLFVBQVU7QUFDaEIsUUFBTSxlQUFlLENBQUMsR0FBRyxNQUFNLFFBQVEsR0FBRyxHQUFHLElBQUk7QUFDakQsSUFBQUEsUUFBTyxVQUFVO0FBQUE7QUFBQTs7O0FDSmpCO0FBQUEseUZBQUFDLFVBQUFDLFNBQUE7QUFBQTtBQUVBLFFBQU0sU0FBUztBQUNmLFFBQU0sZUFBZSxDQUFDLEdBQUcsR0FBRyxVQUFVO0FBQ3BDLFlBQU0sV0FBVyxJQUFJLE9BQU8sR0FBRyxLQUFLO0FBQ3BDLFlBQU0sV0FBVyxJQUFJLE9BQU8sR0FBRyxLQUFLO0FBQ3BDLGFBQU8sU0FBUyxRQUFRLFFBQVEsS0FBSyxTQUFTLGFBQWEsUUFBUTtBQUFBLElBQ3JFO0FBQ0EsSUFBQUEsUUFBTyxVQUFVO0FBQUE7QUFBQTs7O0FDUmpCO0FBQUEsZ0ZBQUFDLFVBQUFDLFNBQUE7QUFBQTtBQUVBLFFBQU0sZUFBZTtBQUNyQixRQUFNLE9BQU8sQ0FBQyxNQUFNLFVBQVUsS0FBSyxLQUFLLENBQUMsR0FBRyxNQUFNLGFBQWEsR0FBRyxHQUFHLEtBQUssQ0FBQztBQUMzRSxJQUFBQSxRQUFPLFVBQVU7QUFBQTtBQUFBOzs7QUNKakI7QUFBQSxpRkFBQUMsVUFBQUMsU0FBQTtBQUFBO0FBRUEsUUFBTSxlQUFlO0FBQ3JCLFFBQU0sUUFBUSxDQUFDLE1BQU0sVUFBVSxLQUFLLEtBQUssQ0FBQyxHQUFHLE1BQU0sYUFBYSxHQUFHLEdBQUcsS0FBSyxDQUFDO0FBQzVFLElBQUFBLFFBQU8sVUFBVTtBQUFBO0FBQUE7OztBQ0pqQjtBQUFBLDhFQUFBQyxVQUFBQyxTQUFBO0FBQUE7QUFFQSxRQUFNLFVBQVU7QUFDaEIsUUFBTSxLQUFLLENBQUMsR0FBRyxHQUFHLFVBQVUsUUFBUSxHQUFHLEdBQUcsS0FBSyxJQUFJO0FBQ25ELElBQUFBLFFBQU8sVUFBVTtBQUFBO0FBQUE7OztBQ0pqQjtBQUFBLDhFQUFBQyxVQUFBQyxTQUFBO0FBQUE7QUFFQSxRQUFNLFVBQVU7QUFDaEIsUUFBTSxLQUFLLENBQUMsR0FBRyxHQUFHLFVBQVUsUUFBUSxHQUFHLEdBQUcsS0FBSyxJQUFJO0FBQ25ELElBQUFBLFFBQU8sVUFBVTtBQUFBO0FBQUE7OztBQ0pqQjtBQUFBLDhFQUFBQyxVQUFBQyxTQUFBO0FBQUE7QUFFQSxRQUFNLFVBQVU7QUFDaEIsUUFBTSxLQUFLLENBQUMsR0FBRyxHQUFHLFVBQVUsUUFBUSxHQUFHLEdBQUcsS0FBSyxNQUFNO0FBQ3JELElBQUFBLFFBQU8sVUFBVTtBQUFBO0FBQUE7OztBQ0pqQjtBQUFBLCtFQUFBQyxVQUFBQyxTQUFBO0FBQUE7QUFFQSxRQUFNLFVBQVU7QUFDaEIsUUFBTSxNQUFNLENBQUMsR0FBRyxHQUFHLFVBQVUsUUFBUSxHQUFHLEdBQUcsS0FBSyxNQUFNO0FBQ3RELElBQUFBLFFBQU8sVUFBVTtBQUFBO0FBQUE7OztBQ0pqQjtBQUFBLCtFQUFBQyxVQUFBQyxTQUFBO0FBQUE7QUFFQSxRQUFNLFVBQVU7QUFDaEIsUUFBTSxNQUFNLENBQUMsR0FBRyxHQUFHLFVBQVUsUUFBUSxHQUFHLEdBQUcsS0FBSyxLQUFLO0FBQ3JELElBQUFBLFFBQU8sVUFBVTtBQUFBO0FBQUE7OztBQ0pqQjtBQUFBLCtFQUFBQyxVQUFBQyxTQUFBO0FBQUE7QUFFQSxRQUFNLFVBQVU7QUFDaEIsUUFBTSxNQUFNLENBQUMsR0FBRyxHQUFHLFVBQVUsUUFBUSxHQUFHLEdBQUcsS0FBSyxLQUFLO0FBQ3JELElBQUFBLFFBQU8sVUFBVTtBQUFBO0FBQUE7OztBQ0pqQjtBQUFBLCtFQUFBQyxVQUFBQyxTQUFBO0FBQUE7QUFFQSxRQUFNLEtBQUs7QUFDWCxRQUFNLE1BQU07QUFDWixRQUFNLEtBQUs7QUFDWCxRQUFNLE1BQU07QUFDWixRQUFNLEtBQUs7QUFDWCxRQUFNLE1BQU07QUFFWixRQUFNLE1BQU0sQ0FBQyxHQUFHLElBQUksR0FBRyxVQUFVO0FBQy9CLGNBQVEsSUFBSTtBQUFBLFFBQ1YsS0FBSztBQUNILGNBQUksT0FBTyxNQUFNLFVBQVU7QUFDekIsZ0JBQUksRUFBRTtBQUFBLFVBQ1I7QUFDQSxjQUFJLE9BQU8sTUFBTSxVQUFVO0FBQ3pCLGdCQUFJLEVBQUU7QUFBQSxVQUNSO0FBQ0EsaUJBQU8sTUFBTTtBQUFBLFFBRWYsS0FBSztBQUNILGNBQUksT0FBTyxNQUFNLFVBQVU7QUFDekIsZ0JBQUksRUFBRTtBQUFBLFVBQ1I7QUFDQSxjQUFJLE9BQU8sTUFBTSxVQUFVO0FBQ3pCLGdCQUFJLEVBQUU7QUFBQSxVQUNSO0FBQ0EsaUJBQU8sTUFBTTtBQUFBLFFBRWYsS0FBSztBQUFBLFFBQ0wsS0FBSztBQUFBLFFBQ0wsS0FBSztBQUNILGlCQUFPLEdBQUcsR0FBRyxHQUFHLEtBQUs7QUFBQSxRQUV2QixLQUFLO0FBQ0gsaUJBQU8sSUFBSSxHQUFHLEdBQUcsS0FBSztBQUFBLFFBRXhCLEtBQUs7QUFDSCxpQkFBTyxHQUFHLEdBQUcsR0FBRyxLQUFLO0FBQUEsUUFFdkIsS0FBSztBQUNILGlCQUFPLElBQUksR0FBRyxHQUFHLEtBQUs7QUFBQSxRQUV4QixLQUFLO0FBQ0gsaUJBQU8sR0FBRyxHQUFHLEdBQUcsS0FBSztBQUFBLFFBRXZCLEtBQUs7QUFDSCxpQkFBTyxJQUFJLEdBQUcsR0FBRyxLQUFLO0FBQUEsUUFFeEI7QUFDRSxnQkFBTSxJQUFJLFVBQVUscUJBQXFCLEVBQUUsRUFBRTtBQUFBLE1BQ2pEO0FBQUEsSUFDRjtBQUNBLElBQUFBLFFBQU8sVUFBVTtBQUFBO0FBQUE7OztBQ3JEakI7QUFBQSxrRkFBQUMsVUFBQUMsU0FBQTtBQUFBO0FBRUEsUUFBTSxTQUFTO0FBQ2YsUUFBTSxRQUFRO0FBQ2QsUUFBTSxFQUFFLFFBQVEsSUFBSSxFQUFFLElBQUk7QUFFMUIsUUFBTSxTQUFTLENBQUMsU0FBUyxZQUFZO0FBQ25DLFVBQUksbUJBQW1CLFFBQVE7QUFDN0IsZUFBTztBQUFBLE1BQ1Q7QUFFQSxVQUFJLE9BQU8sWUFBWSxVQUFVO0FBQy9CLGtCQUFVLE9BQU8sT0FBTztBQUFBLE1BQzFCO0FBRUEsVUFBSSxPQUFPLFlBQVksVUFBVTtBQUMvQixlQUFPO0FBQUEsTUFDVDtBQUVBLGdCQUFVLFdBQVcsQ0FBQztBQUV0QixVQUFJLFFBQVE7QUFDWixVQUFJLENBQUMsUUFBUSxLQUFLO0FBQ2hCLGdCQUFRLFFBQVEsTUFBTSxRQUFRLG9CQUFvQixHQUFHLEVBQUUsVUFBVSxJQUFJLEdBQUcsRUFBRSxNQUFNLENBQUM7QUFBQSxNQUNuRixPQUFPO0FBVUwsY0FBTSxpQkFBaUIsUUFBUSxvQkFBb0IsR0FBRyxFQUFFLGFBQWEsSUFBSSxHQUFHLEVBQUUsU0FBUztBQUN2RixZQUFJO0FBQ0osZ0JBQVEsT0FBTyxlQUFlLEtBQUssT0FBTyxPQUNyQyxDQUFDLFNBQVMsTUFBTSxRQUFRLE1BQU0sQ0FBQyxFQUFFLFdBQVcsUUFBUSxTQUN2RDtBQUNBLGNBQUksQ0FBQyxTQUNDLEtBQUssUUFBUSxLQUFLLENBQUMsRUFBRSxXQUFXLE1BQU0sUUFBUSxNQUFNLENBQUMsRUFBRSxRQUFRO0FBQ25FLG9CQUFRO0FBQUEsVUFDVjtBQUNBLHlCQUFlLFlBQVksS0FBSyxRQUFRLEtBQUssQ0FBQyxFQUFFLFNBQVMsS0FBSyxDQUFDLEVBQUU7QUFBQSxRQUNuRTtBQUVBLHVCQUFlLFlBQVk7QUFBQSxNQUM3QjtBQUVBLFVBQUksVUFBVSxNQUFNO0FBQ2xCLGVBQU87QUFBQSxNQUNUO0FBRUEsWUFBTSxRQUFRLE1BQU0sQ0FBQztBQUNyQixZQUFNLFFBQVEsTUFBTSxDQUFDLEtBQUs7QUFDMUIsWUFBTSxRQUFRLE1BQU0sQ0FBQyxLQUFLO0FBQzFCLFlBQU0sYUFBYSxRQUFRLHFCQUFxQixNQUFNLENBQUMsSUFBSSxJQUFJLE1BQU0sQ0FBQyxDQUFDLEtBQUs7QUFDNUUsWUFBTSxRQUFRLFFBQVEscUJBQXFCLE1BQU0sQ0FBQyxJQUFJLElBQUksTUFBTSxDQUFDLENBQUMsS0FBSztBQUV2RSxhQUFPLE1BQU0sR0FBRyxLQUFLLElBQUksS0FBSyxJQUFJLEtBQUssR0FBRyxVQUFVLEdBQUcsS0FBSyxJQUFJLE9BQU87QUFBQSxJQUN6RTtBQUNBLElBQUFBLFFBQU8sVUFBVTtBQUFBO0FBQUE7OztBQzdEakI7QUFBQSxvRkFBQUMsVUFBQUMsU0FBQTtBQUFBO0FBRUEsUUFBTSxRQUFRO0FBQ2QsUUFBTSxZQUFZO0FBQ2xCLFFBQU0sU0FBUztBQUVmLFFBQU0sV0FBVyxDQUFDLFNBQVMsWUFBWSxZQUFZO0FBQ2pELFVBQUksQ0FBQyxVQUFVLGNBQWMsU0FBUyxVQUFVLEdBQUc7QUFDakQsZUFBTztBQUFBLE1BQ1Q7QUFFQSxZQUFNLGdCQUFnQixrQkFBa0IsU0FBUyxPQUFPO0FBQ3hELGFBQU8saUJBQWlCLGFBQWEsZUFBZSxVQUFVO0FBQUEsSUFDaEU7QUFFQSxRQUFNLG9CQUFvQixDQUFDLFNBQVMsWUFBWTtBQUM5QyxZQUFNLHVCQUNKLG1CQUFtQixTQUFTLFFBQVEsVUFBVTtBQUdoRCxhQUFPLE1BQU0sc0JBQXNCLE9BQU87QUFBQSxJQUM1QztBQUVBLFFBQU0sZUFBZSxDQUFDLFNBQVMsZUFBZTtBQUM1QyxVQUFJLGFBQWEsVUFBVSxHQUFHO0FBQzVCLGVBQU8sUUFBUTtBQUFBLE1BQ2pCO0FBRUEsY0FBUSxhQUFhLENBQUM7QUFFdEIsY0FBUSxZQUFZO0FBQUEsUUFDbEIsS0FBSztBQUNILGtCQUFRLFFBQVE7QUFDaEIsa0JBQVEsUUFBUTtBQUNoQjtBQUFBLFFBQ0YsS0FBSztBQUNILGtCQUFRLFFBQVE7QUFDaEI7QUFBQSxNQUNKO0FBRUEsYUFBTyxRQUFRLE9BQU87QUFBQSxJQUN4QjtBQUVBLFFBQU0sZUFBZSxDQUFDLFNBQVM7QUFDN0IsYUFBTyxLQUFLLFdBQVcsS0FBSztBQUFBLElBQzlCO0FBRUEsSUFBQUEsUUFBTyxVQUFVO0FBQUE7QUFBQTs7O0FDL0NqQjtBQUFBLG1GQUFBQyxVQUFBQyxTQUFBO0FBQUE7QUFFQSxRQUFNLFdBQU4sTUFBZTtBQUFBLE1BQ2IsY0FBZTtBQUNiLGFBQUssTUFBTTtBQUNYLGFBQUssTUFBTSxvQkFBSSxJQUFJO0FBQUEsTUFDckI7QUFBQSxNQUVBLElBQUssS0FBSztBQUNSLGNBQU0sUUFBUSxLQUFLLElBQUksSUFBSSxHQUFHO0FBQzlCLFlBQUksVUFBVSxRQUFXO0FBQ3ZCLGlCQUFPO0FBQUEsUUFDVCxPQUFPO0FBRUwsZUFBSyxJQUFJLE9BQU8sR0FBRztBQUNuQixlQUFLLElBQUksSUFBSSxLQUFLLEtBQUs7QUFDdkIsaUJBQU87QUFBQSxRQUNUO0FBQUEsTUFDRjtBQUFBLE1BRUEsT0FBUSxLQUFLO0FBQ1gsZUFBTyxLQUFLLElBQUksT0FBTyxHQUFHO0FBQUEsTUFDNUI7QUFBQSxNQUVBLElBQUssS0FBSyxPQUFPO0FBQ2YsY0FBTSxVQUFVLEtBQUssT0FBTyxHQUFHO0FBRS9CLFlBQUksQ0FBQyxXQUFXLFVBQVUsUUFBVztBQUVuQyxjQUFJLEtBQUssSUFBSSxRQUFRLEtBQUssS0FBSztBQUM3QixrQkFBTSxXQUFXLEtBQUssSUFBSSxLQUFLLEVBQUUsS0FBSyxFQUFFO0FBQ3hDLGlCQUFLLE9BQU8sUUFBUTtBQUFBLFVBQ3RCO0FBRUEsZUFBSyxJQUFJLElBQUksS0FBSyxLQUFLO0FBQUEsUUFDekI7QUFFQSxlQUFPO0FBQUEsTUFDVDtBQUFBLElBQ0Y7QUFFQSxJQUFBQSxRQUFPLFVBQVU7QUFBQTtBQUFBOzs7QUN6Q2pCO0FBQUEsK0VBQUFDLFVBQUFDLFNBQUE7QUFBQTtBQUVBLFFBQU0sbUJBQW1CO0FBR3pCLFFBQU0sUUFBTixNQUFNLE9BQU07QUFBQSxNQUNWLFlBQWEsT0FBTyxTQUFTO0FBQzNCLGtCQUFVLGFBQWEsT0FBTztBQUU5QixZQUFJLGlCQUFpQixRQUFPO0FBQzFCLGNBQ0UsTUFBTSxVQUFVLENBQUMsQ0FBQyxRQUFRLFNBQzFCLE1BQU0sc0JBQXNCLENBQUMsQ0FBQyxRQUFRLG1CQUN0QztBQUNBLG1CQUFPO0FBQUEsVUFDVCxPQUFPO0FBQ0wsbUJBQU8sSUFBSSxPQUFNLE1BQU0sS0FBSyxPQUFPO0FBQUEsVUFDckM7QUFBQSxRQUNGO0FBRUEsWUFBSSxpQkFBaUIsWUFBWTtBQUUvQixlQUFLLE1BQU0sTUFBTTtBQUNqQixlQUFLLE1BQU0sQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUNuQixlQUFLLFlBQVk7QUFDakIsaUJBQU87QUFBQSxRQUNUO0FBRUEsYUFBSyxVQUFVO0FBQ2YsYUFBSyxRQUFRLENBQUMsQ0FBQyxRQUFRO0FBQ3ZCLGFBQUssb0JBQW9CLENBQUMsQ0FBQyxRQUFRO0FBS25DLGFBQUssTUFBTSxNQUFNLEtBQUssRUFBRSxRQUFRLGtCQUFrQixHQUFHO0FBR3JELGFBQUssTUFBTSxLQUFLLElBQ2IsTUFBTSxJQUFJLEVBRVYsSUFBSSxPQUFLLEtBQUssV0FBVyxFQUFFLEtBQUssQ0FBQyxDQUFDLEVBSWxDLE9BQU8sT0FBSyxFQUFFLE1BQU07QUFFdkIsWUFBSSxDQUFDLEtBQUssSUFBSSxRQUFRO0FBQ3BCLGdCQUFNLElBQUksVUFBVSx5QkFBeUIsS0FBSyxHQUFHLEVBQUU7QUFBQSxRQUN6RDtBQUdBLFlBQUksS0FBSyxJQUFJLFNBQVMsR0FBRztBQUV2QixnQkFBTSxRQUFRLEtBQUssSUFBSSxDQUFDO0FBQ3hCLGVBQUssTUFBTSxLQUFLLElBQUksT0FBTyxPQUFLLENBQUMsVUFBVSxFQUFFLENBQUMsQ0FBQyxDQUFDO0FBQ2hELGNBQUksS0FBSyxJQUFJLFdBQVcsR0FBRztBQUN6QixpQkFBSyxNQUFNLENBQUMsS0FBSztBQUFBLFVBQ25CLFdBQVcsS0FBSyxJQUFJLFNBQVMsR0FBRztBQUU5Qix1QkFBVyxLQUFLLEtBQUssS0FBSztBQUN4QixrQkFBSSxFQUFFLFdBQVcsS0FBSyxNQUFNLEVBQUUsQ0FBQyxDQUFDLEdBQUc7QUFDakMscUJBQUssTUFBTSxDQUFDLENBQUM7QUFDYjtBQUFBLGNBQ0Y7QUFBQSxZQUNGO0FBQUEsVUFDRjtBQUFBLFFBQ0Y7QUFFQSxhQUFLLFlBQVk7QUFBQSxNQUNuQjtBQUFBLE1BRUEsSUFBSSxRQUFTO0FBQ1gsWUFBSSxLQUFLLGNBQWMsUUFBVztBQUNoQyxlQUFLLFlBQVk7QUFDakIsbUJBQVMsSUFBSSxHQUFHLElBQUksS0FBSyxJQUFJLFFBQVEsS0FBSztBQUN4QyxnQkFBSSxJQUFJLEdBQUc7QUFDVCxtQkFBSyxhQUFhO0FBQUEsWUFDcEI7QUFDQSxrQkFBTSxRQUFRLEtBQUssSUFBSSxDQUFDO0FBQ3hCLHFCQUFTLElBQUksR0FBRyxJQUFJLE1BQU0sUUFBUSxLQUFLO0FBQ3JDLGtCQUFJLElBQUksR0FBRztBQUNULHFCQUFLLGFBQWE7QUFBQSxjQUNwQjtBQUNBLG1CQUFLLGFBQWEsTUFBTSxDQUFDLEVBQUUsU0FBUyxFQUFFLEtBQUs7QUFBQSxZQUM3QztBQUFBLFVBQ0Y7QUFBQSxRQUNGO0FBQ0EsZUFBTyxLQUFLO0FBQUEsTUFDZDtBQUFBLE1BRUEsU0FBVTtBQUNSLGVBQU8sS0FBSztBQUFBLE1BQ2Q7QUFBQSxNQUVBLFdBQVk7QUFDVixlQUFPLEtBQUs7QUFBQSxNQUNkO0FBQUEsTUFFQSxXQUFZLE9BQU87QUFFakIsZ0JBQVEsTUFBTSxRQUFRLGNBQWMsRUFBRTtBQUl0QyxjQUFNLFlBQ0gsS0FBSyxRQUFRLHFCQUFxQiw0QkFDbEMsS0FBSyxRQUFRLFNBQVM7QUFDekIsY0FBTSxVQUFVLFdBQVcsTUFBTTtBQUNqQyxjQUFNLFNBQVMsTUFBTSxJQUFJLE9BQU87QUFDaEMsWUFBSSxRQUFRO0FBQ1YsaUJBQU87QUFBQSxRQUNUO0FBRUEsY0FBTSxRQUFRLEtBQUssUUFBUTtBQUUzQixjQUFNLEtBQUssUUFBUSxHQUFHLEVBQUUsZ0JBQWdCLElBQUksR0FBRyxFQUFFLFdBQVc7QUFDNUQsZ0JBQVEsTUFBTSxRQUFRLElBQUksY0FBYyxLQUFLLFFBQVEsaUJBQWlCLENBQUM7QUFDdkUsY0FBTSxrQkFBa0IsS0FBSztBQUc3QixnQkFBUSxNQUFNLFFBQVEsR0FBRyxFQUFFLGNBQWMsR0FBRyxxQkFBcUI7QUFDakUsY0FBTSxtQkFBbUIsS0FBSztBQUc5QixnQkFBUSxNQUFNLFFBQVEsR0FBRyxFQUFFLFNBQVMsR0FBRyxnQkFBZ0I7QUFDdkQsY0FBTSxjQUFjLEtBQUs7QUFHekIsZ0JBQVEsTUFBTSxRQUFRLEdBQUcsRUFBRSxTQUFTLEdBQUcsZ0JBQWdCO0FBQ3ZELGNBQU0sY0FBYyxLQUFLO0FBS3pCLFlBQUksWUFBWSxNQUNiLE1BQU0sR0FBRyxFQUNULElBQUksVUFBUSxnQkFBZ0IsTUFBTSxLQUFLLE9BQU8sQ0FBQyxFQUMvQyxLQUFLLEdBQUcsRUFDUixNQUFNLEtBQUssRUFFWCxJQUFJLFVBQVEsWUFBWSxNQUFNLEtBQUssT0FBTyxDQUFDO0FBRTlDLFlBQUksT0FBTztBQUVULHNCQUFZLFVBQVUsT0FBTyxVQUFRO0FBQ25DLGtCQUFNLHdCQUF3QixNQUFNLEtBQUssT0FBTztBQUNoRCxtQkFBTyxDQUFDLENBQUMsS0FBSyxNQUFNLEdBQUcsRUFBRSxlQUFlLENBQUM7QUFBQSxVQUMzQyxDQUFDO0FBQUEsUUFDSDtBQUNBLGNBQU0sY0FBYyxTQUFTO0FBSzdCLGNBQU0sV0FBVyxvQkFBSSxJQUFJO0FBQ3pCLGNBQU0sY0FBYyxVQUFVLElBQUksVUFBUSxJQUFJLFdBQVcsTUFBTSxLQUFLLE9BQU8sQ0FBQztBQUM1RSxtQkFBVyxRQUFRLGFBQWE7QUFDOUIsY0FBSSxVQUFVLElBQUksR0FBRztBQUNuQixtQkFBTyxDQUFDLElBQUk7QUFBQSxVQUNkO0FBQ0EsbUJBQVMsSUFBSSxLQUFLLE9BQU8sSUFBSTtBQUFBLFFBQy9CO0FBQ0EsWUFBSSxTQUFTLE9BQU8sS0FBSyxTQUFTLElBQUksRUFBRSxHQUFHO0FBQ3pDLG1CQUFTLE9BQU8sRUFBRTtBQUFBLFFBQ3BCO0FBRUEsY0FBTSxTQUFTLENBQUMsR0FBRyxTQUFTLE9BQU8sQ0FBQztBQUNwQyxjQUFNLElBQUksU0FBUyxNQUFNO0FBQ3pCLGVBQU87QUFBQSxNQUNUO0FBQUEsTUFFQSxXQUFZLE9BQU8sU0FBUztBQUMxQixZQUFJLEVBQUUsaUJBQWlCLFNBQVE7QUFDN0IsZ0JBQU0sSUFBSSxVQUFVLHFCQUFxQjtBQUFBLFFBQzNDO0FBRUEsZUFBTyxLQUFLLElBQUksS0FBSyxDQUFDLG9CQUFvQjtBQUN4QyxpQkFDRSxjQUFjLGlCQUFpQixPQUFPLEtBQ3RDLE1BQU0sSUFBSSxLQUFLLENBQUMscUJBQXFCO0FBQ25DLG1CQUNFLGNBQWMsa0JBQWtCLE9BQU8sS0FDdkMsZ0JBQWdCLE1BQU0sQ0FBQyxtQkFBbUI7QUFDeEMscUJBQU8saUJBQWlCLE1BQU0sQ0FBQyxvQkFBb0I7QUFDakQsdUJBQU8sZUFBZSxXQUFXLGlCQUFpQixPQUFPO0FBQUEsY0FDM0QsQ0FBQztBQUFBLFlBQ0gsQ0FBQztBQUFBLFVBRUwsQ0FBQztBQUFBLFFBRUwsQ0FBQztBQUFBLE1BQ0g7QUFBQTtBQUFBLE1BR0EsS0FBTSxTQUFTO0FBQ2IsWUFBSSxDQUFDLFNBQVM7QUFDWixpQkFBTztBQUFBLFFBQ1Q7QUFFQSxZQUFJLE9BQU8sWUFBWSxVQUFVO0FBQy9CLGNBQUk7QUFDRixzQkFBVSxJQUFJLE9BQU8sU0FBUyxLQUFLLE9BQU87QUFBQSxVQUM1QyxTQUFTLElBQUk7QUFDWCxtQkFBTztBQUFBLFVBQ1Q7QUFBQSxRQUNGO0FBRUEsaUJBQVMsSUFBSSxHQUFHLElBQUksS0FBSyxJQUFJLFFBQVEsS0FBSztBQUN4QyxjQUFJLFFBQVEsS0FBSyxJQUFJLENBQUMsR0FBRyxTQUFTLEtBQUssT0FBTyxHQUFHO0FBQy9DLG1CQUFPO0FBQUEsVUFDVDtBQUFBLFFBQ0Y7QUFDQSxlQUFPO0FBQUEsTUFDVDtBQUFBLElBQ0Y7QUFFQSxJQUFBQSxRQUFPLFVBQVU7QUFFakIsUUFBTSxNQUFNO0FBQ1osUUFBTSxRQUFRLElBQUksSUFBSTtBQUV0QixRQUFNLGVBQWU7QUFDckIsUUFBTSxhQUFhO0FBQ25CLFFBQU0sUUFBUTtBQUNkLFFBQU0sU0FBUztBQUNmLFFBQU07QUFBQSxNQUNKLFFBQVE7QUFBQSxNQUNSO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLElBQ0YsSUFBSTtBQUNKLFFBQU0sRUFBRSx5QkFBeUIsV0FBVyxJQUFJO0FBR2hELFFBQU0sZUFBZSxJQUFJLE9BQU8sSUFBSSxFQUFFLEtBQUssR0FBRyxHQUFHO0FBRWpELFFBQU0sWUFBWSxPQUFLLEVBQUUsVUFBVTtBQUNuQyxRQUFNLFFBQVEsT0FBSyxFQUFFLFVBQVU7QUFJL0IsUUFBTSxnQkFBZ0IsQ0FBQyxhQUFhLFlBQVk7QUFDOUMsVUFBSSxTQUFTO0FBQ2IsWUFBTSx1QkFBdUIsWUFBWSxNQUFNO0FBQy9DLFVBQUksaUJBQWlCLHFCQUFxQixJQUFJO0FBRTlDLGFBQU8sVUFBVSxxQkFBcUIsUUFBUTtBQUM1QyxpQkFBUyxxQkFBcUIsTUFBTSxDQUFDLG9CQUFvQjtBQUN2RCxpQkFBTyxlQUFlLFdBQVcsaUJBQWlCLE9BQU87QUFBQSxRQUMzRCxDQUFDO0FBRUQseUJBQWlCLHFCQUFxQixJQUFJO0FBQUEsTUFDNUM7QUFFQSxhQUFPO0FBQUEsSUFDVDtBQUtBLFFBQU0sa0JBQWtCLENBQUMsTUFBTSxZQUFZO0FBQ3pDLGFBQU8sS0FBSyxRQUFRLEdBQUcsRUFBRSxLQUFLLEdBQUcsRUFBRTtBQUNuQyxZQUFNLFFBQVEsTUFBTSxPQUFPO0FBQzNCLGFBQU8sY0FBYyxNQUFNLE9BQU87QUFDbEMsWUFBTSxTQUFTLElBQUk7QUFDbkIsYUFBTyxjQUFjLE1BQU0sT0FBTztBQUNsQyxZQUFNLFVBQVUsSUFBSTtBQUNwQixhQUFPLGVBQWUsTUFBTSxPQUFPO0FBQ25DLFlBQU0sVUFBVSxJQUFJO0FBQ3BCLGFBQU8sYUFBYSxNQUFNLE9BQU87QUFDakMsWUFBTSxTQUFTLElBQUk7QUFDbkIsYUFBTztBQUFBLElBQ1Q7QUFFQSxRQUFNLE1BQU0sUUFBTSxDQUFDLE1BQU0sR0FBRyxZQUFZLE1BQU0sT0FBTyxPQUFPO0FBRTVELFFBQU0scUJBQXFCLENBQUMsR0FBRyxHQUFHLE1BQy9CLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLEtBQ2hCLElBQUksQ0FBQyxLQUFLLEtBQUssQ0FBQyxJQUFJLENBQUM7QUFVeEIsUUFBTSxnQkFBZ0IsQ0FBQyxNQUFNLFlBQVk7QUFDdkMsYUFBTyxLQUNKLEtBQUssRUFDTCxNQUFNLEtBQUssRUFDWCxJQUFJLENBQUMsTUFBTSxhQUFhLEdBQUcsT0FBTyxDQUFDLEVBQ25DLEtBQUssR0FBRztBQUFBLElBQ2I7QUFFQSxRQUFNLGVBQWUsQ0FBQyxNQUFNLFlBQVk7QUFDdEMsWUFBTSxJQUFJLFFBQVEsUUFBUSxHQUFHLEVBQUUsVUFBVSxJQUFJLEdBQUcsRUFBRSxLQUFLO0FBSXZELFlBQU0sSUFBSSxRQUFRLG9CQUFvQixPQUFPO0FBQzdDLGFBQU8sS0FBSyxRQUFRLEdBQUcsQ0FBQyxHQUFHLEdBQUcsR0FBRyxHQUFHLE9BQU87QUFDekMsY0FBTSxTQUFTLE1BQU0sR0FBRyxHQUFHLEdBQUcsR0FBRyxFQUFFO0FBQ25DLFlBQUk7QUFFSixZQUFJLElBQUksQ0FBQyxHQUFHO0FBQ1YsZ0JBQU07QUFBQSxRQUNSLFdBQVcsSUFBSSxDQUFDLEdBQUc7QUFDakIsZ0JBQU0sS0FBSyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDO0FBQUEsUUFDakMsV0FBVyxJQUFJLENBQUMsR0FBRztBQUVqQixnQkFBTSxLQUFLLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQztBQUFBLFFBQ3pDLFdBQVcsSUFBSTtBQUNiLGdCQUFNLG1CQUFtQixFQUFFO0FBQzNCLGdCQUFNLEtBQUssQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksRUFDMUIsS0FBSyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7QUFBQSxRQUNsQixPQUFPO0FBRUwsZ0JBQU0sS0FBSyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQ3JCLEtBQUssQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO0FBQUEsUUFDbEI7QUFFQSxjQUFNLGdCQUFnQixHQUFHO0FBQ3pCLGVBQU87QUFBQSxNQUNULENBQUM7QUFBQSxJQUNIO0FBVUEsUUFBTSxnQkFBZ0IsQ0FBQyxNQUFNLFlBQVk7QUFDdkMsYUFBTyxLQUNKLEtBQUssRUFDTCxNQUFNLEtBQUssRUFDWCxJQUFJLENBQUMsTUFBTSxhQUFhLEdBQUcsT0FBTyxDQUFDLEVBQ25DLEtBQUssR0FBRztBQUFBLElBQ2I7QUFFQSxRQUFNLGVBQWUsQ0FBQyxNQUFNLFlBQVk7QUFDdEMsWUFBTSxTQUFTLE1BQU0sT0FBTztBQUM1QixZQUFNLElBQUksUUFBUSxRQUFRLEdBQUcsRUFBRSxVQUFVLElBQUksR0FBRyxFQUFFLEtBQUs7QUFDdkQsWUFBTSxJQUFJLFFBQVEsb0JBQW9CLE9BQU87QUFDN0MsYUFBTyxLQUFLLFFBQVEsR0FBRyxDQUFDLEdBQUcsR0FBRyxHQUFHLEdBQUcsT0FBTztBQUN6QyxjQUFNLFNBQVMsTUFBTSxHQUFHLEdBQUcsR0FBRyxHQUFHLEVBQUU7QUFDbkMsWUFBSTtBQUVKLFlBQUksSUFBSSxDQUFDLEdBQUc7QUFDVixnQkFBTTtBQUFBLFFBQ1IsV0FBVyxJQUFJLENBQUMsR0FBRztBQUNqQixnQkFBTSxLQUFLLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUM7QUFBQSxRQUNqQyxXQUFXLElBQUksQ0FBQyxHQUFHO0FBQ2pCLGNBQUksTUFBTSxLQUFLO0FBQ2Isa0JBQU0sS0FBSyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7QUFBQSxVQUN6QyxPQUFPO0FBQ0wsa0JBQU0sS0FBSyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQztBQUFBLFVBQ3BDO0FBQUEsUUFDRixXQUFXLElBQUk7QUFDYixnQkFBTSxtQkFBbUIsRUFBRTtBQUMzQixjQUFJLE1BQU0sS0FBSztBQUNiLGdCQUFJLE1BQU0sS0FBSztBQUNiLG9CQUFNLEtBQUssQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksRUFDMUIsS0FBSyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO0FBQUEsWUFDdkIsT0FBTztBQUNMLG9CQUFNLEtBQUssQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksRUFDMUIsS0FBSyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7QUFBQSxZQUNsQjtBQUFBLFVBQ0YsT0FBTztBQUNMLGtCQUFNLEtBQUssQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksRUFDMUIsS0FBSyxDQUFDLElBQUksQ0FBQztBQUFBLFVBQ2I7QUFBQSxRQUNGLE9BQU87QUFDTCxnQkFBTSxPQUFPO0FBQ2IsY0FBSSxNQUFNLEtBQUs7QUFDYixnQkFBSSxNQUFNLEtBQUs7QUFDYixvQkFBTSxLQUFLLENBQUMsSUFBSSxDQUFDLElBQUksQ0FDckIsS0FBSyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO0FBQUEsWUFDdkIsT0FBTztBQUNMLG9CQUFNLEtBQUssQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUNyQixLQUFLLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQztBQUFBLFlBQ2xCO0FBQUEsVUFDRixPQUFPO0FBQ0wsa0JBQU0sS0FBSyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQ3JCLEtBQUssQ0FBQyxJQUFJLENBQUM7QUFBQSxVQUNiO0FBQUEsUUFDRjtBQUVBLGNBQU0sZ0JBQWdCLEdBQUc7QUFDekIsZUFBTztBQUFBLE1BQ1QsQ0FBQztBQUFBLElBQ0g7QUFFQSxRQUFNLGlCQUFpQixDQUFDLE1BQU0sWUFBWTtBQUN4QyxZQUFNLGtCQUFrQixNQUFNLE9BQU87QUFDckMsYUFBTyxLQUNKLE1BQU0sS0FBSyxFQUNYLElBQUksQ0FBQyxNQUFNLGNBQWMsR0FBRyxPQUFPLENBQUMsRUFDcEMsS0FBSyxHQUFHO0FBQUEsSUFDYjtBQUVBLFFBQU0sZ0JBQWdCLENBQUMsTUFBTSxZQUFZO0FBQ3ZDLGFBQU8sS0FBSyxLQUFLO0FBQ2pCLFlBQU0sSUFBSSxRQUFRLFFBQVEsR0FBRyxFQUFFLFdBQVcsSUFBSSxHQUFHLEVBQUUsTUFBTTtBQUN6RCxhQUFPLEtBQUssUUFBUSxHQUFHLENBQUMsS0FBSyxNQUFNLEdBQUcsR0FBRyxHQUFHLE9BQU87QUFDakQsY0FBTSxVQUFVLE1BQU0sS0FBSyxNQUFNLEdBQUcsR0FBRyxHQUFHLEVBQUU7QUFDNUMsWUFBSSxtQkFBbUIsR0FBRyxHQUFHLENBQUMsR0FBRztBQUMvQixpQkFBTztBQUFBLFFBQ1Q7QUFFQSxjQUFNLEtBQUssSUFBSSxDQUFDO0FBQ2hCLGNBQU0sS0FBSyxNQUFNLElBQUksQ0FBQztBQUN0QixjQUFNLEtBQUssTUFBTSxJQUFJLENBQUM7QUFDdEIsY0FBTSxPQUFPO0FBRWIsWUFBSSxTQUFTLE9BQU8sTUFBTTtBQUN4QixpQkFBTztBQUFBLFFBQ1Q7QUFJQSxhQUFLLFFBQVEsb0JBQW9CLE9BQU87QUFFeEMsWUFBSSxJQUFJO0FBQ04sY0FBSSxTQUFTLE9BQU8sU0FBUyxLQUFLO0FBRWhDLGtCQUFNO0FBQUEsVUFDUixPQUFPO0FBRUwsa0JBQU07QUFBQSxVQUNSO0FBQUEsUUFDRixXQUFXLFFBQVEsTUFBTTtBQUd2QixjQUFJLElBQUk7QUFDTixnQkFBSTtBQUFBLFVBQ047QUFDQSxjQUFJO0FBRUosY0FBSSxTQUFTLEtBQUs7QUFHaEIsbUJBQU87QUFDUCxnQkFBSSxJQUFJO0FBQ04sa0JBQUksQ0FBQyxJQUFJO0FBQ1Qsa0JBQUk7QUFDSixrQkFBSTtBQUFBLFlBQ04sT0FBTztBQUNMLGtCQUFJLENBQUMsSUFBSTtBQUNULGtCQUFJO0FBQUEsWUFDTjtBQUFBLFVBQ0YsV0FBVyxTQUFTLE1BQU07QUFHeEIsbUJBQU87QUFDUCxnQkFBSSxJQUFJO0FBQ04sa0JBQUksQ0FBQyxJQUFJO0FBQUEsWUFDWCxPQUFPO0FBQ0wsa0JBQUksQ0FBQyxJQUFJO0FBQUEsWUFDWDtBQUFBLFVBQ0Y7QUFFQSxjQUFJLFNBQVMsS0FBSztBQUNoQixpQkFBSztBQUFBLFVBQ1A7QUFFQSxnQkFBTSxHQUFHLE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtBQUFBLFFBQ2xDLFdBQVcsSUFBSTtBQUNiLGdCQUFNLEtBQUssQ0FBQyxPQUFPLEVBQUUsS0FBSyxDQUFDLElBQUksQ0FBQztBQUFBLFFBQ2xDLFdBQVcsSUFBSTtBQUNiLGdCQUFNLEtBQUssQ0FBQyxJQUFJLENBQUMsS0FBSyxFQUN0QixLQUFLLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQztBQUFBLFFBQ2xCO0FBRUEsY0FBTSxpQkFBaUIsR0FBRztBQUUxQixlQUFPO0FBQUEsTUFDVCxDQUFDO0FBQUEsSUFDSDtBQUlBLFFBQU0sZUFBZSxDQUFDLE1BQU0sWUFBWTtBQUN0QyxZQUFNLGdCQUFnQixNQUFNLE9BQU87QUFFbkMsYUFBTyxLQUNKLEtBQUssRUFDTCxRQUFRLEdBQUcsRUFBRSxJQUFJLEdBQUcsRUFBRTtBQUFBLElBQzNCO0FBRUEsUUFBTSxjQUFjLENBQUMsTUFBTSxZQUFZO0FBQ3JDLFlBQU0sZUFBZSxNQUFNLE9BQU87QUFDbEMsYUFBTyxLQUNKLEtBQUssRUFDTCxRQUFRLEdBQUcsUUFBUSxvQkFBb0IsRUFBRSxVQUFVLEVBQUUsSUFBSSxHQUFHLEVBQUU7QUFBQSxJQUNuRTtBQVFBLFFBQU0sZ0JBQWdCLFdBQVMsQ0FBQyxJQUM5QixNQUFNLElBQUksSUFBSSxJQUFJLEtBQUssSUFDdkIsSUFBSSxJQUFJLElBQUksSUFBSSxRQUFRO0FBQ3hCLFVBQUksSUFBSSxFQUFFLEdBQUc7QUFDWCxlQUFPO0FBQUEsTUFDVCxXQUFXLElBQUksRUFBRSxHQUFHO0FBQ2xCLGVBQU8sS0FBSyxFQUFFLE9BQU8sUUFBUSxPQUFPLEVBQUU7QUFBQSxNQUN4QyxXQUFXLElBQUksRUFBRSxHQUFHO0FBQ2xCLGVBQU8sS0FBSyxFQUFFLElBQUksRUFBRSxLQUFLLFFBQVEsT0FBTyxFQUFFO0FBQUEsTUFDNUMsV0FBVyxLQUFLO0FBQ2QsZUFBTyxLQUFLLElBQUk7QUFBQSxNQUNsQixPQUFPO0FBQ0wsZUFBTyxLQUFLLElBQUksR0FBRyxRQUFRLE9BQU8sRUFBRTtBQUFBLE1BQ3RDO0FBRUEsVUFBSSxJQUFJLEVBQUUsR0FBRztBQUNYLGFBQUs7QUFBQSxNQUNQLFdBQVcsSUFBSSxFQUFFLEdBQUc7QUFDbEIsYUFBSyxJQUFJLENBQUMsS0FBSyxDQUFDO0FBQUEsTUFDbEIsV0FBVyxJQUFJLEVBQUUsR0FBRztBQUNsQixhQUFLLElBQUksRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDO0FBQUEsTUFDeEIsV0FBVyxLQUFLO0FBQ2QsYUFBSyxLQUFLLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxJQUFJLEdBQUc7QUFBQSxNQUNqQyxXQUFXLE9BQU87QUFDaEIsYUFBSyxJQUFJLEVBQUUsSUFBSSxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUM7QUFBQSxNQUM5QixPQUFPO0FBQ0wsYUFBSyxLQUFLLEVBQUU7QUFBQSxNQUNkO0FBRUEsYUFBTyxHQUFHLElBQUksSUFBSSxFQUFFLEdBQUcsS0FBSztBQUFBLElBQzlCO0FBRUEsUUFBTSxVQUFVLENBQUMsS0FBSyxTQUFTLFlBQVk7QUFDekMsZUFBUyxJQUFJLEdBQUcsSUFBSSxJQUFJLFFBQVEsS0FBSztBQUNuQyxZQUFJLENBQUMsSUFBSSxDQUFDLEVBQUUsS0FBSyxPQUFPLEdBQUc7QUFDekIsaUJBQU87QUFBQSxRQUNUO0FBQUEsTUFDRjtBQUVBLFVBQUksUUFBUSxXQUFXLFVBQVUsQ0FBQyxRQUFRLG1CQUFtQjtBQU0zRCxpQkFBUyxJQUFJLEdBQUcsSUFBSSxJQUFJLFFBQVEsS0FBSztBQUNuQyxnQkFBTSxJQUFJLENBQUMsRUFBRSxNQUFNO0FBQ25CLGNBQUksSUFBSSxDQUFDLEVBQUUsV0FBVyxXQUFXLEtBQUs7QUFDcEM7QUFBQSxVQUNGO0FBRUEsY0FBSSxJQUFJLENBQUMsRUFBRSxPQUFPLFdBQVcsU0FBUyxHQUFHO0FBQ3ZDLGtCQUFNLFVBQVUsSUFBSSxDQUFDLEVBQUU7QUFDdkIsZ0JBQUksUUFBUSxVQUFVLFFBQVEsU0FDMUIsUUFBUSxVQUFVLFFBQVEsU0FDMUIsUUFBUSxVQUFVLFFBQVEsT0FBTztBQUNuQyxxQkFBTztBQUFBLFlBQ1Q7QUFBQSxVQUNGO0FBQUEsUUFDRjtBQUdBLGVBQU87QUFBQSxNQUNUO0FBRUEsYUFBTztBQUFBLElBQ1Q7QUFBQTtBQUFBOzs7QUNoa0JBO0FBQUEsb0ZBQUFDLFVBQUFDLFNBQUE7QUFBQTtBQUVBLFFBQU0sTUFBTSxPQUFPLFlBQVk7QUFFL0IsUUFBTSxhQUFOLE1BQU0sWUFBVztBQUFBLE1BQ2YsV0FBVyxNQUFPO0FBQ2hCLGVBQU87QUFBQSxNQUNUO0FBQUEsTUFFQSxZQUFhLE1BQU0sU0FBUztBQUMxQixrQkFBVSxhQUFhLE9BQU87QUFFOUIsWUFBSSxnQkFBZ0IsYUFBWTtBQUM5QixjQUFJLEtBQUssVUFBVSxDQUFDLENBQUMsUUFBUSxPQUFPO0FBQ2xDLG1CQUFPO0FBQUEsVUFDVCxPQUFPO0FBQ0wsbUJBQU8sS0FBSztBQUFBLFVBQ2Q7QUFBQSxRQUNGO0FBRUEsZUFBTyxLQUFLLEtBQUssRUFBRSxNQUFNLEtBQUssRUFBRSxLQUFLLEdBQUc7QUFDeEMsY0FBTSxjQUFjLE1BQU0sT0FBTztBQUNqQyxhQUFLLFVBQVU7QUFDZixhQUFLLFFBQVEsQ0FBQyxDQUFDLFFBQVE7QUFDdkIsYUFBSyxNQUFNLElBQUk7QUFFZixZQUFJLEtBQUssV0FBVyxLQUFLO0FBQ3ZCLGVBQUssUUFBUTtBQUFBLFFBQ2YsT0FBTztBQUNMLGVBQUssUUFBUSxLQUFLLFdBQVcsS0FBSyxPQUFPO0FBQUEsUUFDM0M7QUFFQSxjQUFNLFFBQVEsSUFBSTtBQUFBLE1BQ3BCO0FBQUEsTUFFQSxNQUFPLE1BQU07QUFDWCxjQUFNLElBQUksS0FBSyxRQUFRLFFBQVEsR0FBRyxFQUFFLGVBQWUsSUFBSSxHQUFHLEVBQUUsVUFBVTtBQUN0RSxjQUFNLElBQUksS0FBSyxNQUFNLENBQUM7QUFFdEIsWUFBSSxDQUFDLEdBQUc7QUFDTixnQkFBTSxJQUFJLFVBQVUsdUJBQXVCLElBQUksRUFBRTtBQUFBLFFBQ25EO0FBRUEsYUFBSyxXQUFXLEVBQUUsQ0FBQyxNQUFNLFNBQVksRUFBRSxDQUFDLElBQUk7QUFDNUMsWUFBSSxLQUFLLGFBQWEsS0FBSztBQUN6QixlQUFLLFdBQVc7QUFBQSxRQUNsQjtBQUdBLFlBQUksQ0FBQyxFQUFFLENBQUMsR0FBRztBQUNULGVBQUssU0FBUztBQUFBLFFBQ2hCLE9BQU87QUFDTCxlQUFLLFNBQVMsSUFBSSxPQUFPLEVBQUUsQ0FBQyxHQUFHLEtBQUssUUFBUSxLQUFLO0FBQUEsUUFDbkQ7QUFBQSxNQUNGO0FBQUEsTUFFQSxXQUFZO0FBQ1YsZUFBTyxLQUFLO0FBQUEsTUFDZDtBQUFBLE1BRUEsS0FBTSxTQUFTO0FBQ2IsY0FBTSxtQkFBbUIsU0FBUyxLQUFLLFFBQVEsS0FBSztBQUVwRCxZQUFJLEtBQUssV0FBVyxPQUFPLFlBQVksS0FBSztBQUMxQyxpQkFBTztBQUFBLFFBQ1Q7QUFFQSxZQUFJLE9BQU8sWUFBWSxVQUFVO0FBQy9CLGNBQUk7QUFDRixzQkFBVSxJQUFJLE9BQU8sU0FBUyxLQUFLLE9BQU87QUFBQSxVQUM1QyxTQUFTLElBQUk7QUFDWCxtQkFBTztBQUFBLFVBQ1Q7QUFBQSxRQUNGO0FBRUEsZUFBTyxJQUFJLFNBQVMsS0FBSyxVQUFVLEtBQUssUUFBUSxLQUFLLE9BQU87QUFBQSxNQUM5RDtBQUFBLE1BRUEsV0FBWSxNQUFNLFNBQVM7QUFDekIsWUFBSSxFQUFFLGdCQUFnQixjQUFhO0FBQ2pDLGdCQUFNLElBQUksVUFBVSwwQkFBMEI7QUFBQSxRQUNoRDtBQUVBLFlBQUksS0FBSyxhQUFhLElBQUk7QUFDeEIsY0FBSSxLQUFLLFVBQVUsSUFBSTtBQUNyQixtQkFBTztBQUFBLFVBQ1Q7QUFDQSxpQkFBTyxJQUFJLE1BQU0sS0FBSyxPQUFPLE9BQU8sRUFBRSxLQUFLLEtBQUssS0FBSztBQUFBLFFBQ3ZELFdBQVcsS0FBSyxhQUFhLElBQUk7QUFDL0IsY0FBSSxLQUFLLFVBQVUsSUFBSTtBQUNyQixtQkFBTztBQUFBLFVBQ1Q7QUFDQSxpQkFBTyxJQUFJLE1BQU0sS0FBSyxPQUFPLE9BQU8sRUFBRSxLQUFLLEtBQUssTUFBTTtBQUFBLFFBQ3hEO0FBRUEsa0JBQVUsYUFBYSxPQUFPO0FBRzlCLFlBQUksUUFBUSxzQkFDVCxLQUFLLFVBQVUsY0FBYyxLQUFLLFVBQVUsYUFBYTtBQUMxRCxpQkFBTztBQUFBLFFBQ1Q7QUFDQSxZQUFJLENBQUMsUUFBUSxzQkFDVixLQUFLLE1BQU0sV0FBVyxRQUFRLEtBQUssS0FBSyxNQUFNLFdBQVcsUUFBUSxJQUFJO0FBQ3RFLGlCQUFPO0FBQUEsUUFDVDtBQUdBLFlBQUksS0FBSyxTQUFTLFdBQVcsR0FBRyxLQUFLLEtBQUssU0FBUyxXQUFXLEdBQUcsR0FBRztBQUNsRSxpQkFBTztBQUFBLFFBQ1Q7QUFFQSxZQUFJLEtBQUssU0FBUyxXQUFXLEdBQUcsS0FBSyxLQUFLLFNBQVMsV0FBVyxHQUFHLEdBQUc7QUFDbEUsaUJBQU87QUFBQSxRQUNUO0FBRUEsWUFDRyxLQUFLLE9BQU8sWUFBWSxLQUFLLE9BQU8sV0FDckMsS0FBSyxTQUFTLFNBQVMsR0FBRyxLQUFLLEtBQUssU0FBUyxTQUFTLEdBQUcsR0FBRztBQUM1RCxpQkFBTztBQUFBLFFBQ1Q7QUFFQSxZQUFJLElBQUksS0FBSyxRQUFRLEtBQUssS0FBSyxRQUFRLE9BQU8sS0FDNUMsS0FBSyxTQUFTLFdBQVcsR0FBRyxLQUFLLEtBQUssU0FBUyxXQUFXLEdBQUcsR0FBRztBQUNoRSxpQkFBTztBQUFBLFFBQ1Q7QUFFQSxZQUFJLElBQUksS0FBSyxRQUFRLEtBQUssS0FBSyxRQUFRLE9BQU8sS0FDNUMsS0FBSyxTQUFTLFdBQVcsR0FBRyxLQUFLLEtBQUssU0FBUyxXQUFXLEdBQUcsR0FBRztBQUNoRSxpQkFBTztBQUFBLFFBQ1Q7QUFDQSxlQUFPO0FBQUEsTUFDVDtBQUFBLElBQ0Y7QUFFQSxJQUFBQSxRQUFPLFVBQVU7QUFFakIsUUFBTSxlQUFlO0FBQ3JCLFFBQU0sRUFBRSxRQUFRLElBQUksRUFBRSxJQUFJO0FBQzFCLFFBQU0sTUFBTTtBQUNaLFFBQU0sUUFBUTtBQUNkLFFBQU0sU0FBUztBQUNmLFFBQU0sUUFBUTtBQUFBO0FBQUE7OztBQzlJZDtBQUFBLHFGQUFBQyxVQUFBQyxTQUFBO0FBQUE7QUFFQSxRQUFNLFFBQVE7QUFDZCxRQUFNLFlBQVksQ0FBQyxTQUFTLE9BQU8sWUFBWTtBQUM3QyxVQUFJO0FBQ0YsZ0JBQVEsSUFBSSxNQUFNLE9BQU8sT0FBTztBQUFBLE1BQ2xDLFNBQVMsSUFBSTtBQUNYLGVBQU87QUFBQSxNQUNUO0FBQ0EsYUFBTyxNQUFNLEtBQUssT0FBTztBQUFBLElBQzNCO0FBQ0EsSUFBQUEsUUFBTyxVQUFVO0FBQUE7QUFBQTs7O0FDWGpCO0FBQUEsdUZBQUFDLFVBQUFDLFNBQUE7QUFBQTtBQUVBLFFBQU0sUUFBUTtBQUdkLFFBQU0sZ0JBQWdCLENBQUMsT0FBTyxZQUM1QixJQUFJLE1BQU0sT0FBTyxPQUFPLEVBQUUsSUFDdkIsSUFBSSxVQUFRLEtBQUssSUFBSSxPQUFLLEVBQUUsS0FBSyxFQUFFLEtBQUssR0FBRyxFQUFFLEtBQUssRUFBRSxNQUFNLEdBQUcsQ0FBQztBQUVuRSxJQUFBQSxRQUFPLFVBQVU7QUFBQTtBQUFBOzs7QUNUakI7QUFBQSx1RkFBQUMsVUFBQUMsU0FBQTtBQUFBO0FBRUEsUUFBTSxTQUFTO0FBQ2YsUUFBTSxRQUFRO0FBRWQsUUFBTSxnQkFBZ0IsQ0FBQyxVQUFVLE9BQU8sWUFBWTtBQUNsRCxVQUFJLE1BQU07QUFDVixVQUFJLFFBQVE7QUFDWixVQUFJLFdBQVc7QUFDZixVQUFJO0FBQ0YsbUJBQVcsSUFBSSxNQUFNLE9BQU8sT0FBTztBQUFBLE1BQ3JDLFNBQVMsSUFBSTtBQUNYLGVBQU87QUFBQSxNQUNUO0FBQ0EsZUFBUyxRQUFRLENBQUMsTUFBTTtBQUN0QixZQUFJLFNBQVMsS0FBSyxDQUFDLEdBQUc7QUFFcEIsY0FBSSxDQUFDLE9BQU8sTUFBTSxRQUFRLENBQUMsTUFBTSxJQUFJO0FBRW5DLGtCQUFNO0FBQ04sb0JBQVEsSUFBSSxPQUFPLEtBQUssT0FBTztBQUFBLFVBQ2pDO0FBQUEsUUFDRjtBQUFBLE1BQ0YsQ0FBQztBQUNELGFBQU87QUFBQSxJQUNUO0FBQ0EsSUFBQUEsUUFBTyxVQUFVO0FBQUE7QUFBQTs7O0FDMUJqQjtBQUFBLHVGQUFBQyxVQUFBQyxTQUFBO0FBQUE7QUFFQSxRQUFNLFNBQVM7QUFDZixRQUFNLFFBQVE7QUFDZCxRQUFNLGdCQUFnQixDQUFDLFVBQVUsT0FBTyxZQUFZO0FBQ2xELFVBQUksTUFBTTtBQUNWLFVBQUksUUFBUTtBQUNaLFVBQUksV0FBVztBQUNmLFVBQUk7QUFDRixtQkFBVyxJQUFJLE1BQU0sT0FBTyxPQUFPO0FBQUEsTUFDckMsU0FBUyxJQUFJO0FBQ1gsZUFBTztBQUFBLE1BQ1Q7QUFDQSxlQUFTLFFBQVEsQ0FBQyxNQUFNO0FBQ3RCLFlBQUksU0FBUyxLQUFLLENBQUMsR0FBRztBQUVwQixjQUFJLENBQUMsT0FBTyxNQUFNLFFBQVEsQ0FBQyxNQUFNLEdBQUc7QUFFbEMsa0JBQU07QUFDTixvQkFBUSxJQUFJLE9BQU8sS0FBSyxPQUFPO0FBQUEsVUFDakM7QUFBQSxRQUNGO0FBQUEsTUFDRixDQUFDO0FBQ0QsYUFBTztBQUFBLElBQ1Q7QUFDQSxJQUFBQSxRQUFPLFVBQVU7QUFBQTtBQUFBOzs7QUN6QmpCO0FBQUEsb0ZBQUFDLFVBQUFDLFNBQUE7QUFBQTtBQUVBLFFBQU0sU0FBUztBQUNmLFFBQU0sUUFBUTtBQUNkLFFBQU0sS0FBSztBQUVYLFFBQU0sYUFBYSxDQUFDLE9BQU8sVUFBVTtBQUNuQyxjQUFRLElBQUksTUFBTSxPQUFPLEtBQUs7QUFFOUIsVUFBSSxTQUFTLElBQUksT0FBTyxPQUFPO0FBQy9CLFVBQUksTUFBTSxLQUFLLE1BQU0sR0FBRztBQUN0QixlQUFPO0FBQUEsTUFDVDtBQUVBLGVBQVMsSUFBSSxPQUFPLFNBQVM7QUFDN0IsVUFBSSxNQUFNLEtBQUssTUFBTSxHQUFHO0FBQ3RCLGVBQU87QUFBQSxNQUNUO0FBRUEsZUFBUztBQUNULGVBQVMsSUFBSSxHQUFHLElBQUksTUFBTSxJQUFJLFFBQVEsRUFBRSxHQUFHO0FBQ3pDLGNBQU0sY0FBYyxNQUFNLElBQUksQ0FBQztBQUUvQixZQUFJLFNBQVM7QUFDYixvQkFBWSxRQUFRLENBQUMsZUFBZTtBQUVsQyxnQkFBTSxVQUFVLElBQUksT0FBTyxXQUFXLE9BQU8sT0FBTztBQUNwRCxrQkFBUSxXQUFXLFVBQVU7QUFBQSxZQUMzQixLQUFLO0FBQ0gsa0JBQUksUUFBUSxXQUFXLFdBQVcsR0FBRztBQUNuQyx3QkFBUTtBQUFBLGNBQ1YsT0FBTztBQUNMLHdCQUFRLFdBQVcsS0FBSyxDQUFDO0FBQUEsY0FDM0I7QUFDQSxzQkFBUSxNQUFNLFFBQVEsT0FBTztBQUFBLFlBRS9CLEtBQUs7QUFBQSxZQUNMLEtBQUs7QUFDSCxrQkFBSSxDQUFDLFVBQVUsR0FBRyxTQUFTLE1BQU0sR0FBRztBQUNsQyx5QkFBUztBQUFBLGNBQ1g7QUFDQTtBQUFBLFlBQ0YsS0FBSztBQUFBLFlBQ0wsS0FBSztBQUVIO0FBQUEsWUFFRjtBQUNFLG9CQUFNLElBQUksTUFBTSx5QkFBeUIsV0FBVyxRQUFRLEVBQUU7QUFBQSxVQUNsRTtBQUFBLFFBQ0YsQ0FBQztBQUNELFlBQUksV0FBVyxDQUFDLFVBQVUsR0FBRyxRQUFRLE1BQU0sSUFBSTtBQUM3QyxtQkFBUztBQUFBLFFBQ1g7QUFBQSxNQUNGO0FBRUEsVUFBSSxVQUFVLE1BQU0sS0FBSyxNQUFNLEdBQUc7QUFDaEMsZUFBTztBQUFBLE1BQ1Q7QUFFQSxhQUFPO0FBQUEsSUFDVDtBQUNBLElBQUFBLFFBQU8sVUFBVTtBQUFBO0FBQUE7OztBQzlEakIsSUFBQUMsaUJBQUE7QUFBQSw4RUFBQUMsVUFBQUMsU0FBQTtBQUFBO0FBRUEsUUFBTSxRQUFRO0FBQ2QsUUFBTSxhQUFhLENBQUMsT0FBTyxZQUFZO0FBQ3JDLFVBQUk7QUFHRixlQUFPLElBQUksTUFBTSxPQUFPLE9BQU8sRUFBRSxTQUFTO0FBQUEsTUFDNUMsU0FBUyxJQUFJO0FBQ1gsZUFBTztBQUFBLE1BQ1Q7QUFBQSxJQUNGO0FBQ0EsSUFBQUEsUUFBTyxVQUFVO0FBQUE7QUFBQTs7O0FDWmpCO0FBQUEsZ0ZBQUFDLFVBQUFDLFNBQUE7QUFBQTtBQUVBLFFBQU0sU0FBUztBQUNmLFFBQU0sYUFBYTtBQUNuQixRQUFNLEVBQUUsSUFBSSxJQUFJO0FBQ2hCLFFBQU0sUUFBUTtBQUNkLFFBQU0sWUFBWTtBQUNsQixRQUFNLEtBQUs7QUFDWCxRQUFNLEtBQUs7QUFDWCxRQUFNLE1BQU07QUFDWixRQUFNLE1BQU07QUFFWixRQUFNLFVBQVUsQ0FBQyxTQUFTLE9BQU8sTUFBTSxZQUFZO0FBQ2pELGdCQUFVLElBQUksT0FBTyxTQUFTLE9BQU87QUFDckMsY0FBUSxJQUFJLE1BQU0sT0FBTyxPQUFPO0FBRWhDLFVBQUksTUFBTSxPQUFPLE1BQU0sTUFBTTtBQUM3QixjQUFRLE1BQU07QUFBQSxRQUNaLEtBQUs7QUFDSCxpQkFBTztBQUNQLGtCQUFRO0FBQ1IsaUJBQU87QUFDUCxpQkFBTztBQUNQLGtCQUFRO0FBQ1I7QUFBQSxRQUNGLEtBQUs7QUFDSCxpQkFBTztBQUNQLGtCQUFRO0FBQ1IsaUJBQU87QUFDUCxpQkFBTztBQUNQLGtCQUFRO0FBQ1I7QUFBQSxRQUNGO0FBQ0UsZ0JBQU0sSUFBSSxVQUFVLHVDQUF1QztBQUFBLE1BQy9EO0FBR0EsVUFBSSxVQUFVLFNBQVMsT0FBTyxPQUFPLEdBQUc7QUFDdEMsZUFBTztBQUFBLE1BQ1Q7QUFLQSxlQUFTLElBQUksR0FBRyxJQUFJLE1BQU0sSUFBSSxRQUFRLEVBQUUsR0FBRztBQUN6QyxjQUFNLGNBQWMsTUFBTSxJQUFJLENBQUM7QUFFL0IsWUFBSSxPQUFPO0FBQ1gsWUFBSSxNQUFNO0FBRVYsb0JBQVksUUFBUSxDQUFDLGVBQWU7QUFDbEMsY0FBSSxXQUFXLFdBQVcsS0FBSztBQUM3Qix5QkFBYSxJQUFJLFdBQVcsU0FBUztBQUFBLFVBQ3ZDO0FBQ0EsaUJBQU8sUUFBUTtBQUNmLGdCQUFNLE9BQU87QUFDYixjQUFJLEtBQUssV0FBVyxRQUFRLEtBQUssUUFBUSxPQUFPLEdBQUc7QUFDakQsbUJBQU87QUFBQSxVQUNULFdBQVcsS0FBSyxXQUFXLFFBQVEsSUFBSSxRQUFRLE9BQU8sR0FBRztBQUN2RCxrQkFBTTtBQUFBLFVBQ1I7QUFBQSxRQUNGLENBQUM7QUFJRCxZQUFJLEtBQUssYUFBYSxRQUFRLEtBQUssYUFBYSxPQUFPO0FBQ3JELGlCQUFPO0FBQUEsUUFDVDtBQUlBLGFBQUssQ0FBQyxJQUFJLFlBQVksSUFBSSxhQUFhLFNBQ25DLE1BQU0sU0FBUyxJQUFJLE1BQU0sR0FBRztBQUM5QixpQkFBTztBQUFBLFFBQ1QsV0FBVyxJQUFJLGFBQWEsU0FBUyxLQUFLLFNBQVMsSUFBSSxNQUFNLEdBQUc7QUFDOUQsaUJBQU87QUFBQSxRQUNUO0FBQUEsTUFDRjtBQUNBLGFBQU87QUFBQSxJQUNUO0FBRUEsSUFBQUEsUUFBTyxVQUFVO0FBQUE7QUFBQTs7O0FDakZqQjtBQUFBLDRFQUFBQyxVQUFBQyxTQUFBO0FBQUE7QUFHQSxRQUFNLFVBQVU7QUFDaEIsUUFBTSxNQUFNLENBQUMsU0FBUyxPQUFPLFlBQVksUUFBUSxTQUFTLE9BQU8sS0FBSyxPQUFPO0FBQzdFLElBQUFBLFFBQU8sVUFBVTtBQUFBO0FBQUE7OztBQ0xqQjtBQUFBLDRFQUFBQyxVQUFBQyxTQUFBO0FBQUE7QUFFQSxRQUFNLFVBQVU7QUFFaEIsUUFBTSxNQUFNLENBQUMsU0FBUyxPQUFPLFlBQVksUUFBUSxTQUFTLE9BQU8sS0FBSyxPQUFPO0FBQzdFLElBQUFBLFFBQU8sVUFBVTtBQUFBO0FBQUE7OztBQ0xqQjtBQUFBLG1GQUFBQyxVQUFBQyxTQUFBO0FBQUE7QUFFQSxRQUFNLFFBQVE7QUFDZCxRQUFNLGFBQWEsQ0FBQyxJQUFJLElBQUksWUFBWTtBQUN0QyxXQUFLLElBQUksTUFBTSxJQUFJLE9BQU87QUFDMUIsV0FBSyxJQUFJLE1BQU0sSUFBSSxPQUFPO0FBQzFCLGFBQU8sR0FBRyxXQUFXLElBQUksT0FBTztBQUFBLElBQ2xDO0FBQ0EsSUFBQUEsUUFBTyxVQUFVO0FBQUE7QUFBQTs7O0FDUmpCO0FBQUEsaUZBQUFDLFVBQUFDLFNBQUE7QUFBQTtBQUtBLFFBQU0sWUFBWTtBQUNsQixRQUFNLFVBQVU7QUFDaEIsSUFBQUEsUUFBTyxVQUFVLENBQUMsVUFBVSxPQUFPLFlBQVk7QUFDN0MsWUFBTSxNQUFNLENBQUM7QUFDYixVQUFJLFFBQVE7QUFDWixVQUFJLE9BQU87QUFDWCxZQUFNLElBQUksU0FBUyxLQUFLLENBQUMsR0FBRyxNQUFNLFFBQVEsR0FBRyxHQUFHLE9BQU8sQ0FBQztBQUN4RCxpQkFBVyxXQUFXLEdBQUc7QUFDdkIsY0FBTSxXQUFXLFVBQVUsU0FBUyxPQUFPLE9BQU87QUFDbEQsWUFBSSxVQUFVO0FBQ1osaUJBQU87QUFDUCxjQUFJLENBQUMsT0FBTztBQUNWLG9CQUFRO0FBQUEsVUFDVjtBQUFBLFFBQ0YsT0FBTztBQUNMLGNBQUksTUFBTTtBQUNSLGdCQUFJLEtBQUssQ0FBQyxPQUFPLElBQUksQ0FBQztBQUFBLFVBQ3hCO0FBQ0EsaUJBQU87QUFDUCxrQkFBUTtBQUFBLFFBQ1Y7QUFBQSxNQUNGO0FBQ0EsVUFBSSxPQUFPO0FBQ1QsWUFBSSxLQUFLLENBQUMsT0FBTyxJQUFJLENBQUM7QUFBQSxNQUN4QjtBQUVBLFlBQU0sU0FBUyxDQUFDO0FBQ2hCLGlCQUFXLENBQUMsS0FBSyxHQUFHLEtBQUssS0FBSztBQUM1QixZQUFJLFFBQVEsS0FBSztBQUNmLGlCQUFPLEtBQUssR0FBRztBQUFBLFFBQ2pCLFdBQVcsQ0FBQyxPQUFPLFFBQVEsRUFBRSxDQUFDLEdBQUc7QUFDL0IsaUJBQU8sS0FBSyxHQUFHO0FBQUEsUUFDakIsV0FBVyxDQUFDLEtBQUs7QUFDZixpQkFBTyxLQUFLLEtBQUssR0FBRyxFQUFFO0FBQUEsUUFDeEIsV0FBVyxRQUFRLEVBQUUsQ0FBQyxHQUFHO0FBQ3ZCLGlCQUFPLEtBQUssS0FBSyxHQUFHLEVBQUU7QUFBQSxRQUN4QixPQUFPO0FBQ0wsaUJBQU8sS0FBSyxHQUFHLEdBQUcsTUFBTSxHQUFHLEVBQUU7QUFBQSxRQUMvQjtBQUFBLE1BQ0Y7QUFDQSxZQUFNLGFBQWEsT0FBTyxLQUFLLE1BQU07QUFDckMsWUFBTSxXQUFXLE9BQU8sTUFBTSxRQUFRLFdBQVcsTUFBTSxNQUFNLE9BQU8sS0FBSztBQUN6RSxhQUFPLFdBQVcsU0FBUyxTQUFTLFNBQVMsYUFBYTtBQUFBLElBQzVEO0FBQUE7QUFBQTs7O0FDaERBO0FBQUEsK0VBQUFDLFVBQUFDLFNBQUE7QUFBQTtBQUVBLFFBQU0sUUFBUTtBQUNkLFFBQU0sYUFBYTtBQUNuQixRQUFNLEVBQUUsSUFBSSxJQUFJO0FBQ2hCLFFBQU0sWUFBWTtBQUNsQixRQUFNLFVBQVU7QUFzQ2hCLFFBQU0sU0FBUyxDQUFDLEtBQUssS0FBSyxVQUFVLENBQUMsTUFBTTtBQUN6QyxVQUFJLFFBQVEsS0FBSztBQUNmLGVBQU87QUFBQSxNQUNUO0FBRUEsWUFBTSxJQUFJLE1BQU0sS0FBSyxPQUFPO0FBQzVCLFlBQU0sSUFBSSxNQUFNLEtBQUssT0FBTztBQUM1QixVQUFJLGFBQWE7QUFFakI7QUFBTyxtQkFBVyxhQUFhLElBQUksS0FBSztBQUN0QyxxQkFBVyxhQUFhLElBQUksS0FBSztBQUMvQixrQkFBTSxRQUFRLGFBQWEsV0FBVyxXQUFXLE9BQU87QUFDeEQseUJBQWEsY0FBYyxVQUFVO0FBQ3JDLGdCQUFJLE9BQU87QUFDVCx1QkFBUztBQUFBLFlBQ1g7QUFBQSxVQUNGO0FBS0EsY0FBSSxZQUFZO0FBQ2QsbUJBQU87QUFBQSxVQUNUO0FBQUEsUUFDRjtBQUNBLGFBQU87QUFBQSxJQUNUO0FBRUEsUUFBTSwrQkFBK0IsQ0FBQyxJQUFJLFdBQVcsV0FBVyxDQUFDO0FBQ2pFLFFBQU0saUJBQWlCLENBQUMsSUFBSSxXQUFXLFNBQVMsQ0FBQztBQUVqRCxRQUFNLGVBQWUsQ0FBQyxLQUFLLEtBQUssWUFBWTtBQUMxQyxVQUFJLFFBQVEsS0FBSztBQUNmLGVBQU87QUFBQSxNQUNUO0FBRUEsVUFBSSxJQUFJLFdBQVcsS0FBSyxJQUFJLENBQUMsRUFBRSxXQUFXLEtBQUs7QUFDN0MsWUFBSSxJQUFJLFdBQVcsS0FBSyxJQUFJLENBQUMsRUFBRSxXQUFXLEtBQUs7QUFDN0MsaUJBQU87QUFBQSxRQUNULFdBQVcsUUFBUSxtQkFBbUI7QUFDcEMsZ0JBQU07QUFBQSxRQUNSLE9BQU87QUFDTCxnQkFBTTtBQUFBLFFBQ1I7QUFBQSxNQUNGO0FBRUEsVUFBSSxJQUFJLFdBQVcsS0FBSyxJQUFJLENBQUMsRUFBRSxXQUFXLEtBQUs7QUFDN0MsWUFBSSxRQUFRLG1CQUFtQjtBQUM3QixpQkFBTztBQUFBLFFBQ1QsT0FBTztBQUNMLGdCQUFNO0FBQUEsUUFDUjtBQUFBLE1BQ0Y7QUFFQSxZQUFNLFFBQVEsb0JBQUksSUFBSTtBQUN0QixVQUFJLElBQUk7QUFDUixpQkFBVyxLQUFLLEtBQUs7QUFDbkIsWUFBSSxFQUFFLGFBQWEsT0FBTyxFQUFFLGFBQWEsTUFBTTtBQUM3QyxlQUFLLFNBQVMsSUFBSSxHQUFHLE9BQU87QUFBQSxRQUM5QixXQUFXLEVBQUUsYUFBYSxPQUFPLEVBQUUsYUFBYSxNQUFNO0FBQ3BELGVBQUssUUFBUSxJQUFJLEdBQUcsT0FBTztBQUFBLFFBQzdCLE9BQU87QUFDTCxnQkFBTSxJQUFJLEVBQUUsTUFBTTtBQUFBLFFBQ3BCO0FBQUEsTUFDRjtBQUVBLFVBQUksTUFBTSxPQUFPLEdBQUc7QUFDbEIsZUFBTztBQUFBLE1BQ1Q7QUFFQSxVQUFJO0FBQ0osVUFBSSxNQUFNLElBQUk7QUFDWixtQkFBVyxRQUFRLEdBQUcsUUFBUSxHQUFHLFFBQVEsT0FBTztBQUNoRCxZQUFJLFdBQVcsR0FBRztBQUNoQixpQkFBTztBQUFBLFFBQ1QsV0FBVyxhQUFhLE1BQU0sR0FBRyxhQUFhLFFBQVEsR0FBRyxhQUFhLE9BQU87QUFDM0UsaUJBQU87QUFBQSxRQUNUO0FBQUEsTUFDRjtBQUdBLGlCQUFXLE1BQU0sT0FBTztBQUN0QixZQUFJLE1BQU0sQ0FBQyxVQUFVLElBQUksT0FBTyxFQUFFLEdBQUcsT0FBTyxHQUFHO0FBQzdDLGlCQUFPO0FBQUEsUUFDVDtBQUVBLFlBQUksTUFBTSxDQUFDLFVBQVUsSUFBSSxPQUFPLEVBQUUsR0FBRyxPQUFPLEdBQUc7QUFDN0MsaUJBQU87QUFBQSxRQUNUO0FBRUEsbUJBQVcsS0FBSyxLQUFLO0FBQ25CLGNBQUksQ0FBQyxVQUFVLElBQUksT0FBTyxDQUFDLEdBQUcsT0FBTyxHQUFHO0FBQ3RDLG1CQUFPO0FBQUEsVUFDVDtBQUFBLFFBQ0Y7QUFFQSxlQUFPO0FBQUEsTUFDVDtBQUVBLFVBQUksUUFBUTtBQUNaLFVBQUksVUFBVTtBQUdkLFVBQUksZUFBZSxNQUNqQixDQUFDLFFBQVEscUJBQ1QsR0FBRyxPQUFPLFdBQVcsU0FBUyxHQUFHLFNBQVM7QUFDNUMsVUFBSSxlQUFlLE1BQ2pCLENBQUMsUUFBUSxxQkFDVCxHQUFHLE9BQU8sV0FBVyxTQUFTLEdBQUcsU0FBUztBQUU1QyxVQUFJLGdCQUFnQixhQUFhLFdBQVcsV0FBVyxLQUNuRCxHQUFHLGFBQWEsT0FBTyxhQUFhLFdBQVcsQ0FBQyxNQUFNLEdBQUc7QUFDM0QsdUJBQWU7QUFBQSxNQUNqQjtBQUVBLGlCQUFXLEtBQUssS0FBSztBQUNuQixtQkFBVyxZQUFZLEVBQUUsYUFBYSxPQUFPLEVBQUUsYUFBYTtBQUM1RCxtQkFBVyxZQUFZLEVBQUUsYUFBYSxPQUFPLEVBQUUsYUFBYTtBQUM1RCxZQUFJLElBQUk7QUFDTixjQUFJLGNBQWM7QUFDaEIsZ0JBQUksRUFBRSxPQUFPLGNBQWMsRUFBRSxPQUFPLFdBQVcsVUFDM0MsRUFBRSxPQUFPLFVBQVUsYUFBYSxTQUNoQyxFQUFFLE9BQU8sVUFBVSxhQUFhLFNBQ2hDLEVBQUUsT0FBTyxVQUFVLGFBQWEsT0FBTztBQUN6Qyw2QkFBZTtBQUFBLFlBQ2pCO0FBQUEsVUFDRjtBQUNBLGNBQUksRUFBRSxhQUFhLE9BQU8sRUFBRSxhQUFhLE1BQU07QUFDN0MscUJBQVMsU0FBUyxJQUFJLEdBQUcsT0FBTztBQUNoQyxnQkFBSSxXQUFXLEtBQUssV0FBVyxJQUFJO0FBQ2pDLHFCQUFPO0FBQUEsWUFDVDtBQUFBLFVBQ0YsV0FBVyxHQUFHLGFBQWEsUUFBUSxDQUFDLEVBQUUsS0FBSyxHQUFHLE1BQU0sR0FBRztBQUNyRCxtQkFBTztBQUFBLFVBQ1Q7QUFBQSxRQUNGO0FBQ0EsWUFBSSxJQUFJO0FBQ04sY0FBSSxjQUFjO0FBQ2hCLGdCQUFJLEVBQUUsT0FBTyxjQUFjLEVBQUUsT0FBTyxXQUFXLFVBQzNDLEVBQUUsT0FBTyxVQUFVLGFBQWEsU0FDaEMsRUFBRSxPQUFPLFVBQVUsYUFBYSxTQUNoQyxFQUFFLE9BQU8sVUFBVSxhQUFhLE9BQU87QUFDekMsNkJBQWU7QUFBQSxZQUNqQjtBQUFBLFVBQ0Y7QUFDQSxjQUFJLEVBQUUsYUFBYSxPQUFPLEVBQUUsYUFBYSxNQUFNO0FBQzdDLG9CQUFRLFFBQVEsSUFBSSxHQUFHLE9BQU87QUFDOUIsZ0JBQUksVUFBVSxLQUFLLFVBQVUsSUFBSTtBQUMvQixxQkFBTztBQUFBLFlBQ1Q7QUFBQSxVQUNGLFdBQVcsR0FBRyxhQUFhLFFBQVEsQ0FBQyxFQUFFLEtBQUssR0FBRyxNQUFNLEdBQUc7QUFDckQsbUJBQU87QUFBQSxVQUNUO0FBQUEsUUFDRjtBQUNBLFlBQUksQ0FBQyxFQUFFLGFBQWEsTUFBTSxPQUFPLGFBQWEsR0FBRztBQUMvQyxpQkFBTztBQUFBLFFBQ1Q7QUFBQSxNQUNGO0FBS0EsVUFBSSxNQUFNLFlBQVksQ0FBQyxNQUFNLGFBQWEsR0FBRztBQUMzQyxlQUFPO0FBQUEsTUFDVDtBQUVBLFVBQUksTUFBTSxZQUFZLENBQUMsTUFBTSxhQUFhLEdBQUc7QUFDM0MsZUFBTztBQUFBLE1BQ1Q7QUFLQSxVQUFJLGdCQUFnQixjQUFjO0FBQ2hDLGVBQU87QUFBQSxNQUNUO0FBRUEsYUFBTztBQUFBLElBQ1Q7QUFHQSxRQUFNLFdBQVcsQ0FBQyxHQUFHLEdBQUcsWUFBWTtBQUNsQyxVQUFJLENBQUMsR0FBRztBQUNOLGVBQU87QUFBQSxNQUNUO0FBQ0EsWUFBTSxPQUFPLFFBQVEsRUFBRSxRQUFRLEVBQUUsUUFBUSxPQUFPO0FBQ2hELGFBQU8sT0FBTyxJQUFJLElBQ2QsT0FBTyxJQUFJLElBQ1gsRUFBRSxhQUFhLE9BQU8sRUFBRSxhQUFhLE9BQU8sSUFDNUM7QUFBQSxJQUNOO0FBR0EsUUFBTSxVQUFVLENBQUMsR0FBRyxHQUFHLFlBQVk7QUFDakMsVUFBSSxDQUFDLEdBQUc7QUFDTixlQUFPO0FBQUEsTUFDVDtBQUNBLFlBQU0sT0FBTyxRQUFRLEVBQUUsUUFBUSxFQUFFLFFBQVEsT0FBTztBQUNoRCxhQUFPLE9BQU8sSUFBSSxJQUNkLE9BQU8sSUFBSSxJQUNYLEVBQUUsYUFBYSxPQUFPLEVBQUUsYUFBYSxPQUFPLElBQzVDO0FBQUEsSUFDTjtBQUVBLElBQUFBLFFBQU8sVUFBVTtBQUFBO0FBQUE7OztBQ3hQakIsSUFBQUMsa0JBQUE7QUFBQSx1RUFBQUMsVUFBQUMsU0FBQTtBQUFBO0FBR0EsUUFBTSxhQUFhO0FBQ25CLFFBQU0sWUFBWTtBQUNsQixRQUFNLFNBQVM7QUFDZixRQUFNLGNBQWM7QUFDcEIsUUFBTSxRQUFRO0FBQ2QsUUFBTSxRQUFRO0FBQ2QsUUFBTSxRQUFRO0FBQ2QsUUFBTSxNQUFNO0FBQ1osUUFBTSxPQUFPO0FBQ2IsUUFBTSxRQUFRO0FBQ2QsUUFBTSxRQUFRO0FBQ2QsUUFBTSxRQUFRO0FBQ2QsUUFBTSxhQUFhO0FBQ25CLFFBQU0sVUFBVTtBQUNoQixRQUFNLFdBQVc7QUFDakIsUUFBTSxlQUFlO0FBQ3JCLFFBQU0sZUFBZTtBQUNyQixRQUFNLE9BQU87QUFDYixRQUFNLFFBQVE7QUFDZCxRQUFNLEtBQUs7QUFDWCxRQUFNLEtBQUs7QUFDWCxRQUFNLEtBQUs7QUFDWCxRQUFNLE1BQU07QUFDWixRQUFNLE1BQU07QUFDWixRQUFNLE1BQU07QUFDWixRQUFNLE1BQU07QUFDWixRQUFNLFNBQVM7QUFDZixRQUFNLFdBQVc7QUFDakIsUUFBTSxhQUFhO0FBQ25CLFFBQU0sUUFBUTtBQUNkLFFBQU0sWUFBWTtBQUNsQixRQUFNLGdCQUFnQjtBQUN0QixRQUFNLGdCQUFnQjtBQUN0QixRQUFNLGdCQUFnQjtBQUN0QixRQUFNLGFBQWE7QUFDbkIsUUFBTSxhQUFhO0FBQ25CLFFBQU0sVUFBVTtBQUNoQixRQUFNLE1BQU07QUFDWixRQUFNLE1BQU07QUFDWixRQUFNLGFBQWE7QUFDbkIsUUFBTSxnQkFBZ0I7QUFDdEIsUUFBTSxTQUFTO0FBQ2YsSUFBQUEsUUFBTyxVQUFVO0FBQUEsTUFDZjtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQSxJQUFJLFdBQVc7QUFBQSxNQUNmLEtBQUssV0FBVztBQUFBLE1BQ2hCLFFBQVEsV0FBVztBQUFBLE1BQ25CLHFCQUFxQixVQUFVO0FBQUEsTUFDL0IsZUFBZSxVQUFVO0FBQUEsTUFDekIsb0JBQW9CLFlBQVk7QUFBQSxNQUNoQyxxQkFBcUIsWUFBWTtBQUFBLElBQ25DO0FBQUE7QUFBQTs7O0FDaEJPLElBQU0sUUFBTixNQUFZO0FBQUEsRUFDRSxXQUFXLG9CQUFJLElBQStCO0FBQUEsRUFDOUMsbUJBQW1CLG9CQUFJLElBQXVCO0FBQUE7QUFBQSxFQUcvRCxHQUFnQixPQUFlLFNBQXVDO0FBQ2xFLFFBQUksTUFBTSxLQUFLLFNBQVMsSUFBSSxLQUFLO0FBQ2pDLFFBQUksQ0FBQyxLQUFLO0FBQ04sWUFBTSxvQkFBSSxJQUFJO0FBQ2QsV0FBSyxTQUFTLElBQUksT0FBTyxHQUFHO0FBQUEsSUFDaEM7QUFDQSxRQUFJLElBQUksT0FBdUI7QUFDL0IsV0FBTyxNQUFNO0FBQ1QsVUFBSSxPQUFPLE9BQXVCO0FBQ2xDLFVBQUksSUFBSSxTQUFTLEdBQUc7QUFDaEIsYUFBSyxTQUFTLE9BQU8sS0FBSztBQUFBLE1BQzlCO0FBQUEsSUFDSjtBQUFBLEVBQ0o7QUFBQTtBQUFBLEVBR0EsSUFBaUIsT0FBZSxTQUFnQztBQUM1RCxVQUFNLE1BQU0sS0FBSyxTQUFTLElBQUksS0FBSztBQUNuQyxRQUFJLENBQUMsS0FBSztBQUFDO0FBQUEsSUFBTztBQUNsQixRQUFJLE9BQU8sT0FBdUI7QUFDbEMsUUFBSSxJQUFJLFNBQVMsR0FBRztBQUNoQixXQUFLLFNBQVMsT0FBTyxLQUFLO0FBQUEsSUFDOUI7QUFBQSxFQUNKO0FBQUE7QUFBQSxFQUdBLEtBQWtCLE9BQWUsU0FBa0I7QUFFL0MsVUFBTSxNQUFNLEtBQUssU0FBUyxJQUFJLEtBQUs7QUFDbkMsUUFBSSxPQUFPLElBQUksT0FBTyxHQUFHO0FBQ3JCLGlCQUFXLFdBQVcsQ0FBQyxHQUFHLEdBQUcsR0FBRztBQUM1QixZQUFJO0FBQ0Esa0JBQVEsT0FBTztBQUFBLFFBQ25CLFFBQVE7QUFBQSxRQUVSO0FBQUEsTUFDSjtBQUFBLElBQ0o7QUFFQSxRQUFJLEtBQUssaUJBQWlCLE9BQU8sR0FBRztBQUNoQyxpQkFBVyxNQUFNLENBQUMsR0FBRyxLQUFLLGdCQUFnQixHQUFHO0FBQ3pDLFlBQUk7QUFDQSxhQUFHLE9BQU8sT0FBTztBQUFBLFFBQ3JCLFFBQVE7QUFBQSxRQUVSO0FBQUEsTUFDSjtBQUFBLElBQ0o7QUFBQSxFQUNKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQU1BLE1BQU0sU0FBeUM7QUFDM0MsU0FBSyxpQkFBaUIsSUFBSSxPQUFPO0FBQ2pDLFdBQU8sTUFBTTtBQUNULFdBQUssaUJBQWlCLE9BQU8sT0FBTztBQUFBLElBQ3hDO0FBQUEsRUFDSjtBQUFBO0FBQUEsRUFHQSxNQUFNLE9BQXNCO0FBQ3hCLFFBQUksVUFBVSxRQUFXO0FBQ3JCLFdBQUssU0FBUyxNQUFNO0FBQ3BCLFdBQUssaUJBQWlCLE1BQU07QUFBQSxJQUNoQyxPQUFPO0FBQ0gsV0FBSyxTQUFTLE9BQU8sS0FBSztBQUFBLElBQzlCO0FBQUEsRUFDSjtBQUNKO0FBUUEsSUFBSSxXQUF5QjtBQUd0QixTQUFTLFNBQWdCO0FBQzVCLE1BQUksQ0FBQyxVQUFVO0FBQ1gsZUFBVyxJQUFJLE1BQU07QUFBQSxFQUN6QjtBQUNBLFNBQU87QUFDWDs7O0FDOUZBLElBQU0sdUJBQXVCLElBQUk7QUFVMUIsU0FBUyxxQkFBcUIsT0FBdUM7QUFDeEUsUUFBTSxNQUFNO0FBd0JaLE1BQUk7QUFDSixNQUFJLEtBQUssWUFBWSxLQUFLLFVBQVUsS0FBSyxjQUFjO0FBQ25ELG9CQUFnQixDQUFDO0FBQ2pCLFFBQUksSUFBSSxVQUFVO0FBQ2Qsb0JBQWMsV0FBVztBQUFBLFFBQ3JCLEdBQUksSUFBSSxTQUFTLFdBQVcsU0FBWSxFQUFFLFFBQVEsSUFBSSxTQUFTLE9BQU8sSUFBSSxDQUFDO0FBQUEsUUFDM0UsR0FBSSxJQUFJLFNBQVMsYUFBYSxFQUFFLFlBQVksSUFBSSxTQUFTLFdBQVcsSUFBSSxDQUFDO0FBQUEsUUFDekUsR0FBSSxJQUFJLFNBQVMsU0FBUyxTQUNwQixFQUFFLE1BQU0sZUFBZSxJQUFJLFNBQVMsSUFBSSxFQUFFLElBQzFDLENBQUM7QUFBQSxNQUNYO0FBQUEsSUFDSjtBQUNBLFFBQUksSUFBSSxRQUFRO0FBQ1osb0JBQWMsU0FBUztBQUFBLFFBQ25CLEdBQUksSUFBSSxPQUFPLE1BQU0sRUFBRSxLQUFLLElBQUksT0FBTyxJQUFJLElBQUksQ0FBQztBQUFBLFFBQ2hELEdBQUksSUFBSSxPQUFPLFNBQVMsRUFBRSxRQUFRLElBQUksT0FBTyxPQUFPLElBQUksQ0FBQztBQUFBLE1BQzdEO0FBQUEsSUFDSjtBQUNBLFFBQUksSUFBSSxNQUFNO0FBQ1Ysb0JBQWMsT0FBTyxJQUFJO0FBQUEsSUFDN0I7QUFBQSxFQUNKO0FBRUEsU0FBTztBQUFBLElBQ0gsV0FBVztBQUFBLElBQ1gsU0FBUyxLQUFLLFdBQVcsT0FBTyxLQUFLO0FBQUEsSUFDckMsR0FBSSxLQUFLLE9BQU8sRUFBRSxNQUFNLElBQUksS0FBSyxJQUFJLENBQUM7QUFBQSxJQUN0QyxHQUFJLEtBQUssWUFBWSxTQUFZLEVBQUUsU0FBUyxJQUFJLFFBQVEsSUFBSSxDQUFDO0FBQUEsSUFDN0QsR0FBSSxLQUFLLFNBQVMsRUFBRSxRQUFRLElBQUksT0FBTyxJQUFJLENBQUM7QUFBQSxJQUM1QyxHQUFJLEtBQUssZUFBZSxTQUFZLEVBQUUsWUFBWSxJQUFJLFdBQVcsSUFBSSxDQUFDO0FBQUE7QUFBQTtBQUFBLElBR3RFLEdBQUksS0FBSyxlQUFlLFVBQWEsS0FBSyxVQUFVLFdBQVcsU0FDekQsRUFBRSxZQUFZLElBQUksU0FBUyxPQUFPLElBQ2xDLENBQUM7QUFBQSxJQUNQLEdBQUksS0FBSyxTQUFTLFNBQVksRUFBRSxNQUFNLElBQUksS0FBSyxJQUFJLENBQUM7QUFBQSxJQUNwRCxHQUFJLGdCQUFnQixFQUFFLE9BQU8sY0FBYyxJQUFJLENBQUM7QUFBQSxFQUNwRDtBQUNKO0FBV0EsU0FBUyxlQUFlLE1BQXdCO0FBQzVDLE1BQUk7QUFDQSxVQUFNLElBQUksT0FBTyxTQUFTLFdBQVcsT0FBTyxLQUFLLFVBQVUsSUFBSTtBQUMvRCxRQUFJLE9BQU8sTUFBTSxVQUFVO0FBQUUsYUFBTztBQUFBLElBQXlCO0FBQzdELFFBQUksT0FBTyxXQUFXLEdBQUcsT0FBTyxLQUFLLHNCQUFzQjtBQUV2RCxhQUFPLE9BQU8sU0FBUyxXQUFXLElBQUk7QUFBQSxJQUMxQztBQUNBLFVBQU0sWUFBWSxFQUFFLE1BQU0sR0FBRyxvQkFBb0I7QUFDakQsV0FBTyxHQUFHLFNBQVMsaUJBQWlCLEVBQUUsU0FBUyxvQkFBb0I7QUFBQSxFQUN2RSxRQUFRO0FBQ0osV0FBTztBQUFBLEVBQ1g7QUFDSjtBQU9PLFNBQVMsd0JBQXdCLE9BQWdEO0FBQ3BGLFNBQ0ksVUFBVSxRQUNQLE9BQU8sVUFBVSxZQUNoQixNQUFrQyxjQUFjO0FBRTVEO0FBYU8sU0FBUyxrQkFBa0IsUUFBMEI7QUFDeEQsTUFBSSxDQUFDLHdCQUF3QixNQUFNLEdBQUc7QUFDbEMsV0FBTztBQUFBLEVBQ1g7QUFDQSxRQUFNLEVBQUUsU0FBUyxNQUFNLFNBQVMsUUFBUSxZQUFZLE1BQU0sTUFBTSxJQUFJO0FBQ3BFLFFBQU0sTUFBTSxJQUFJLE1BQU0sT0FBTztBQVk3QixNQUFJLE9BQU87QUFDWCxNQUFJLE1BQU07QUFBQyxRQUFJLE9BQU87QUFBQSxFQUFLO0FBQzNCLE1BQUksWUFBWSxRQUFXO0FBQUMsUUFBSSxVQUFVO0FBQUEsRUFBUTtBQUNsRCxNQUFJLFFBQVE7QUFBQyxRQUFJLFNBQVM7QUFBQSxFQUFPO0FBQ2pDLE1BQUksZUFBZSxRQUFXO0FBQUMsUUFBSSxhQUFhO0FBQUEsRUFBVztBQUMzRCxNQUFJLFNBQVMsUUFBVztBQUFDLFFBQUksT0FBTztBQUFBLEVBQUs7QUFLekMsTUFBSSxPQUFPO0FBQ1AsUUFBSSxNQUFNLFVBQVU7QUFDaEIsVUFBSSxXQUFXLEVBQUUsR0FBRyxNQUFNLFNBQVM7QUFBQSxJQUN2QztBQUNBLFFBQUksTUFBTSxRQUFRO0FBQ2QsVUFBSSxTQUFTLEVBQUUsR0FBRyxNQUFNLE9BQU87QUFBQSxJQUNuQztBQUNBLFFBQUksTUFBTSxRQUFRLENBQUMsSUFBSSxNQUFNO0FBQ3pCLFVBQUksT0FBTyxNQUFNO0FBQUEsSUFDckI7QUFFQSxRQUFJLGVBQWU7QUFBQSxFQUN2QjtBQUVBLFFBQU07QUFDVjs7O0FDbERPLElBQU0sOEJBQThCO0FBQUEsRUFDdkMsV0FBVztBQUFBLEVBQ1gsUUFBUTtBQUFBLEVBQ1IsV0FBVztBQUFBLEVBQ1gsVUFBVTtBQUNkOzs7QUN6Sk8sSUFBTSxtQ0FBbUMsSUFBSSxPQUFPOzs7QUN4QzNELGFBQXdCO0FBSWpCLElBQU0scUNBQXFDLE1BQU07QUFDakQsSUFBTSx3Q0FBd0MsTUFBTTs7O0FDc0NwRCxJQUFNLCtCQUErQjtBQUVyQyxJQUFNLDhCQUE4QjtBQVdwQyxJQUFNLDZCQUE2QjtBQU9uQyxJQUFNLGdEQUFnRDtBQUV0RCxJQUFNLHFEQUNUO0FBRUcsSUFBTSwwQkFBMEI7QUFFaEMsSUFBTSxpQ0FBaUM7QUFFdkMsSUFBTSxxQ0FBcUM7QUFFM0MsSUFBTSxpQ0FBaUM7QUFJdkMsSUFBTSxpQ0FBaUM7QUFFdkMsSUFBTSx3Q0FBd0M7QUFFOUMsSUFBTSx5Q0FBeUM7QUFFL0MsSUFBTSwrQkFBK0I7QUFFckMsSUFBTSx3Q0FBd0M7QUFFOUMsSUFBTSxrQ0FBa0M7QUFFeEMsSUFBTSxrQ0FBa0M7QUFFeEMsSUFBTSw4QkFBOEI7QUFFcEMsSUFBTSxnQ0FBZ0M7QUFFdEMsSUFBTSwrQkFBK0I7QUFFckMsSUFBTSxpQ0FBaUM7QUFFdkMsSUFBTSwrQkFBK0I7QUFFckMsSUFBTSw4QkFBOEI7QUFNcEMsSUFBTSxvQ0FBb0M7OztBQ3ZDakQsSUFBTSw2QkFBNkIsSUFBSSxJQUF1QixPQUFPLE9BQU8sMkJBQTJCLENBQUM7OztBQ3lDakcsSUFBTSxlQUFlO0FBQUEsRUFDeEIsRUFBRSxLQUFLLGNBQWMsTUFBTSxTQUFTLFlBQVksS0FBSztBQUFBLEVBQ3JELEVBQUUsS0FBSyxhQUFhLE1BQU0sU0FBUyxZQUFZLEtBQUs7QUFBQSxFQUNwRCxFQUFFLEtBQUssU0FBUyxNQUFNLFNBQVMsWUFBWSxLQUFLO0FBQUEsRUFDaEQsRUFBRSxLQUFLLFdBQVcsTUFBTSxTQUFTLFlBQVksS0FBSztBQUFBLEVBQ2xELEVBQUUsS0FBSyxZQUFZLE1BQU0sU0FBUyxZQUFZLEtBQUs7QUFBQSxFQUNuRCxFQUFFLEtBQUssa0JBQWtCLE1BQU0sU0FBUyxZQUFZLEtBQUs7QUFBQSxFQUN6RCxFQUFFLEtBQUssMEJBQTBCLE1BQU0sU0FBUyxZQUFZLEtBQUs7QUFBQSxFQUNqRSxFQUFFLEtBQUssZUFBZSxNQUFNLFNBQVMsWUFBWSxLQUFLO0FBQUEsRUFDdEQsRUFBRSxLQUFLLGdCQUFnQixNQUFNLFNBQVMsWUFBWSxLQUFLO0FBQUEsRUFDdkQsRUFBRSxLQUFLLHVCQUF1QixNQUFNLFNBQVMsWUFBWSxLQUFLO0FBQUEsRUFDOUQsRUFBRSxLQUFLLGtCQUFrQixNQUFNLFNBQVMsWUFBWSxLQUFLO0FBQUEsRUFDekQsRUFBRSxLQUFLLGFBQWEsTUFBTSxTQUFTLFlBQVksTUFBTTtBQUFBLEVBQ3JELEVBQUUsS0FBSyxTQUFTLE1BQU0sU0FBUyxZQUFZLE1BQU07QUFBQSxFQUNqRCxFQUFFLEtBQUssZUFBZSxNQUFNLFNBQVMsWUFBWSxLQUFLO0FBQUEsRUFDdEQsRUFBRSxLQUFLLFdBQVcsTUFBTSxTQUFTLFlBQVksTUFBTTtBQUFBLEVBQ25ELEVBQUUsS0FBSyxtQkFBbUIsTUFBTSxTQUFTLFlBQVksTUFBTTtBQUFBLEVBQzNELEVBQUUsS0FBSyxnQkFBZ0IsTUFBTSxTQUFTLFlBQVksTUFBTTtBQUFBLEVBQ3hELEVBQUUsS0FBSyxVQUFVLE1BQU0sU0FBUyxZQUFZLEtBQUs7QUFBQSxFQUNqRCxFQUFFLEtBQUssd0JBQXdCLE1BQU0sU0FBUyxZQUFZLEtBQUs7QUFBQSxFQUMvRCxFQUFFLEtBQUsseUJBQXlCLE1BQU0sU0FBUyxZQUFZLEtBQUs7QUFBQSxFQUNoRSxFQUFFLEtBQUssdUJBQXVCLE1BQU0sU0FBUyxZQUFZLEtBQUs7QUFBQSxFQUM5RCxFQUFFLEtBQUssVUFBVSxNQUFNLFNBQVMsWUFBWSxLQUFLO0FBQUEsRUFDakQsRUFBRSxLQUFLLFVBQVUsTUFBTSxTQUFTLFlBQVksS0FBSztBQUFBLEVBQ2pELEVBQUUsS0FBSyxrQkFBa0IsTUFBTSxTQUFTLFlBQVksS0FBSztBQUFBLEVBQ3pELEVBQUUsS0FBSyxrQkFBa0IsTUFBTSxTQUFTLFlBQVksS0FBSztBQUFBLEVBQ3pELEVBQUUsS0FBSywrQkFBK0IsTUFBTSxTQUFTLFlBQVksS0FBSztBQUFBLEVBQ3RFLEVBQUUsS0FBSywyQkFBMkIsTUFBTSxTQUFTLFlBQVksS0FBSztBQUFBLEVBQ2xFLEVBQUUsS0FBSyxVQUFVLE1BQU0sU0FBUyxZQUFZLEtBQUs7QUFBQSxFQUNqRCxFQUFFLEtBQUssV0FBVyxNQUFNLGlCQUFpQixVQUFVLFVBQVUsWUFBWSxNQUFNO0FBQUEsRUFDL0UsRUFBRSxLQUFLLGlCQUFpQixNQUFNLGlCQUFpQixVQUFVLFVBQVUsWUFBWSxNQUFNO0FBQUEsRUFDckYsRUFBRSxLQUFLLHNCQUFzQixNQUFNLGlCQUFpQixVQUFVLFVBQVUsWUFBWSxNQUFNO0FBQUE7QUFBQSxFQUUxRixFQUFFLEtBQUssdUJBQXVCLE1BQU0sU0FBUyxZQUFZLEtBQUs7QUFBQSxFQUM5RCxFQUFFLEtBQUssa0JBQWtCLE1BQU0sWUFBWSxVQUFVLFFBQVEsWUFBWSxLQUFLO0FBQUEsRUFDOUUsRUFBRSxLQUFLLGlCQUFpQixNQUFNLFlBQVksVUFBVSxRQUFRLFlBQVksS0FBSztBQUFBLEVBQzdFLEVBQUUsS0FBSyxPQUFPLE1BQU0saUJBQWlCLFVBQVUsVUFBVSxZQUFZLEtBQUs7QUFBQSxFQUMxRSxFQUFFLEtBQUssZ0NBQWdDLE1BQU0sU0FBUyxZQUFZLEtBQUs7QUFDM0U7QUFtQk8sSUFBTSx3QkFBd0I7QUFBQSxFQUNqQztBQUFBLEVBQ0E7QUFBQSxFQUFjO0FBQUEsRUFBYztBQUFBLEVBQWU7QUFBQSxFQUFlO0FBQUEsRUFBYTtBQUFBLEVBQ3ZFO0FBQUEsRUFBdUI7QUFBQSxFQUN2QjtBQUFBLEVBQWlCO0FBQUEsRUFBYTtBQUFBLEVBQzlCO0FBQUEsRUFBdUI7QUFBQSxFQUFzQjtBQUFBLEVBQzdDO0FBQUEsRUFBaUI7QUFBQSxFQUFrQjtBQUFBLEVBQ25DO0FBQUEsRUFBMkI7QUFBQSxFQUF3QjtBQUFBLEVBQXlCO0FBQUEsRUFBaUM7QUFBQSxFQUEwQjtBQUFBLEVBQW1CO0FBQzlKO0FBZ0JPLFNBQVMsVUFBZ0QsVUFBZ0M7QUFDNUYsU0FBTyxFQUFFLFNBQVM7QUFDdEI7QUFvQk8sSUFBTSx1QkFBdUI7QUFBQSxFQUNoQyxnQ0FBOEIsR0FBRztBQUFBLElBQzdCLE1BQU0sVUFBMEMsNEJBQTRCO0FBQUEsSUFDNUUsS0FBSyxDQUFDLE1BQXNDLEVBQUUscUJBQ3hDO0FBQUEsTUFDRSxFQUFFO0FBQUEsTUFDRixFQUFFO0FBQUEsTUFDRixFQUFFO0FBQUEsTUFDRixFQUFFO0FBQUEsTUFDRixFQUFFO0FBQUEsTUFDRixFQUFFO0FBQUEsSUFDTixJQUNFLEVBQUUsZUFDRSxDQUFDLEVBQUUsTUFBTSxFQUFFLElBQUksRUFBRSxZQUFZLEVBQUUsZUFBZSxFQUFFLFlBQVksSUFDNUQsQ0FBQyxFQUFFLE1BQU0sRUFBRSxJQUFJLEVBQUUsWUFBWSxFQUFFLGFBQWE7QUFBQSxFQUMxRDtBQUFBLEVBQ0EsOEJBQTZCLEdBQUc7QUFBQSxJQUM1QixNQUFNLFVBQXlDLDJCQUEyQjtBQUFBLElBQzFFLEtBQUssQ0FBQyxNQUFxQyxDQUFDLEVBQUUsSUFBSTtBQUFBLEVBQ3REO0FBQUEsRUFDQSxnREFBc0MsR0FBRztBQUFBLElBQ3JDLE1BQU0sVUFBa0QscUNBQXFDO0FBQUEsSUFDN0YsS0FBSyxDQUFDLE1BQThDLENBQUMsQ0FBQztBQUFBLEVBQzFEO0FBQUEsRUFDQSxzQ0FBaUMsR0FBRztBQUFBLElBQ2hDLE1BQU0sVUFBNEMsK0JBQStCO0FBQUEsSUFDakYsS0FBSyxDQUFDLE9BQXlDLENBQUM7QUFBQSxFQUNwRDtBQUFBLEVBQ0Esd0JBQTBCLEdBQUc7QUFBQSxJQUN6QixNQUFNLFVBQXNDLHVCQUF1QjtBQUFBLElBQ25FLEtBQUssQ0FBQyxNQUFrQyxDQUFDLEVBQUUsSUFBSTtBQUFBLEVBQ25EO0FBQUEsRUFDQSxvQ0FBZ0MsR0FBRztBQUFBLElBQy9CLE1BQU0sVUFBNEMsOEJBQThCO0FBQUEsSUFDaEYsS0FBSyxDQUFDLE1BQXdDLENBQUMsRUFBRSxNQUFNO0FBQUEsRUFDM0Q7QUFBQSxFQUNBLDBDQUFtQyxHQUFHO0FBQUEsSUFDbEMsTUFBTSxVQUErQyxrQ0FBa0M7QUFBQSxJQUN2RixLQUFLLENBQUMsTUFBMkMsQ0FBQyxFQUFFLE1BQU07QUFBQSxFQUM5RDtBQUFBLEVBQ0Esc0NBQWlDLEdBQUc7QUFBQSxJQUNoQyxNQUFNLFVBQXlDLDBCQUEwQjtBQUFBLElBQ3pFLEtBQUssQ0FBQyxNQUFxQyxDQUFDLEVBQUUsVUFBVTtBQUFBLEVBQzVEO0FBQUEsRUFDQSxnRUFBOEMsR0FBRztBQUFBLElBQzdDLE1BQU07QUFBQSxNQUNGO0FBQUEsSUFDSjtBQUFBLElBQ0EsS0FBSyxDQUFDLE1BQXNELENBQUMsRUFBRSxjQUFjO0FBQUEsRUFDakY7QUFBQSxFQUNBLHdFQUFrRCxHQUFHO0FBQUEsSUFDakQsTUFBTTtBQUFBLE1BQ0Y7QUFBQSxJQUNKO0FBQUEsSUFDQSxLQUFLLENBQUMsTUFBMEQsQ0FBQyxFQUFFLFlBQVk7QUFBQSxFQUNuRjtBQUFBLEVBQ0Esb0NBQWdDLEdBQUc7QUFBQSxJQUMvQixNQUFNLFVBQTRDLDhCQUE4QjtBQUFBLElBQ2hGLEtBQUssQ0FBQyxPQUF5QyxDQUFDO0FBQUEsRUFDcEQ7QUFBQSxFQUNBLG9DQUFnQyxHQUFHO0FBQUEsSUFDL0IsTUFBTSxVQUFpRCw4QkFBOEI7QUFBQSxJQUNyRixLQUFLLENBQUMsTUFBNkMsQ0FBQyxFQUFFLFdBQVcsRUFBRSxXQUFXLE1BQU0sRUFBRSxLQUFLLENBQUM7QUFBQSxFQUNoRztBQUFBLEVBQ0EsZ0RBQXNDLEdBQUc7QUFBQSxJQUNyQyxNQUFNLFVBQXVELHFDQUFxQztBQUFBLElBQ2xHLEtBQUssQ0FBQyxNQUFtRCxDQUFDO0FBQUEsTUFDdEQsYUFBYSxFQUFFO0FBQUEsTUFDZixlQUFlLEVBQUU7QUFBQSxNQUNqQixHQUFJLEVBQUUsYUFBYSxFQUFFLFlBQVksRUFBRSxXQUFXLElBQUksQ0FBQztBQUFBLElBQ3ZELENBQUM7QUFBQSxFQUNMO0FBQUEsRUFDQSxrREFBdUMsR0FBRztBQUFBLElBQ3RDLE1BQU0sVUFBd0Qsc0NBQXNDO0FBQUEsSUFDcEcsS0FBSyxDQUFDLE1BQ0YsQ0FBQyxFQUFFLFdBQVcsRUFBRSxXQUFXLGVBQWUsRUFBRSxjQUFjLENBQUM7QUFBQSxFQUNuRTtBQUFBLEVBQ0Esc0NBQWlDLEdBQUc7QUFBQSxJQUNoQyxNQUFNLFVBQTZDLCtCQUErQjtBQUFBLElBQ2xGLEtBQUssQ0FBQyxNQUF5QyxDQUFDLENBQUM7QUFBQSxFQUNyRDtBQUFBLEVBQ0EsOEJBQTZCLEdBQUc7QUFBQSxJQUM1QixNQUFNLFVBQXlDLDJCQUEyQjtBQUFBLElBQzFFLEtBQUssQ0FBQyxNQUFxQyxDQUFDLENBQUM7QUFBQSxFQUNqRDtBQUFBLEVBQ0Esa0NBQStCLEdBQUc7QUFBQSxJQUM5QixNQUFNLFVBQTJDLDZCQUE2QjtBQUFBLElBQzlFLEtBQUssQ0FBQyxNQUF1QyxDQUFDLENBQUM7QUFBQSxFQUNuRDtBQUFBLEVBQ0EsZ0NBQThCLEdBQUc7QUFBQSxJQUM3QixNQUFNLFVBQTBDLDRCQUE0QjtBQUFBLElBQzVFLEtBQUssQ0FBQyxNQUFzQyxDQUFDLENBQUM7QUFBQSxFQUNsRDtBQUFBLEVBQ0Esb0NBQWdDLEdBQUc7QUFBQSxJQUMvQixNQUFNLFVBQStDLDhCQUE4QjtBQUFBLElBQ25GLEtBQUssQ0FBQyxNQUEyQyxDQUFDLENBQUM7QUFBQSxFQUN2RDtBQUFBLEVBQ0EsZ0NBQThCLEdBQUc7QUFBQSxJQUM3QixNQUFNLFVBQTBDLDRCQUE0QjtBQUFBLElBQzVFLEtBQUssQ0FBQyxNQUFzQyxDQUFDLENBQUM7QUFBQSxFQUNsRDtBQUFBLEVBQ0EsOEJBQTZCLEdBQUc7QUFBQSxJQUM1QixNQUFNLFVBQXlDLDJCQUEyQjtBQUFBLElBQzFFLEtBQUssQ0FBQyxNQUFxQyxDQUFDLENBQUM7QUFBQSxFQUNqRDtBQUNKO0FBR08sSUFBTSwwQkFBMEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQVd2QztBQXFCTyxJQUFNLHlCQUF5QjtBQUFBLEVBQ2xDLDBDQUFvQyxHQUFHO0FBQUEsSUFDbkMsTUFBTSxVQUE4QyxpQ0FBaUM7QUFBQSxJQUNyRixLQUFLLENBQUMsTUFBMEMsQ0FBQyxFQUFFLGdCQUFnQixFQUFFLEtBQUs7QUFBQSxFQUM5RTtBQUFBLEVBQ0Esa0NBQWdDLEdBQUc7QUFBQSxJQUMvQixNQUFNLFVBQTBDLDRCQUE0QjtBQUFBLElBQzVFLEtBQUssQ0FBQyxNQUFzQyxDQUFDLEVBQUUsZ0JBQWdCLEVBQUUsTUFBTSxFQUFFLEVBQUU7QUFBQSxFQUMvRTtBQUFBLEVBQ0EsZ0NBQStCLEdBQUc7QUFBQSxJQUM5QixNQUFNLFVBQXlDLDJCQUEyQjtBQUFBLElBQzFFLEtBQUssQ0FBQyxNQUFxQyxDQUFDLEVBQUUsZ0JBQWdCLEVBQUUsSUFBSTtBQUFBLEVBQ3hFO0FBQUEsRUFDQSxrQ0FBZ0MsR0FBRztBQUFBLElBQy9CLE1BQU0sVUFBNEMsNEJBQTRCO0FBQUEsSUFDOUUsS0FBSyxDQUFDLE1BQXdDLENBQUMsRUFBRSxjQUFjO0FBQUEsRUFDbkU7QUFBQSxFQUNBLHdDQUFtQyxHQUFHO0FBQUEsSUFDbEMsTUFBTSxVQUE0QywrQkFBK0I7QUFBQSxJQUNqRixLQUFLLENBQUMsTUFBd0MsQ0FBQyxFQUFFLGNBQWM7QUFBQSxFQUNuRTtBQUFBLEVBQ0Esd0JBQTJCLEdBQUc7QUFBQSxJQUMxQixNQUFNLFVBQXNDLHVCQUF1QjtBQUFBLElBQ25FLEtBQUssQ0FBQyxNQUFrQyxDQUFDLEVBQUUsZ0JBQWdCLEVBQUUsSUFBSTtBQUFBLEVBQ3JFO0FBQ0o7QUFHTyxJQUFNLDRCQUE0QjtBQUFBO0FBQUE7QUFHekM7OztBQzlRQSxJQUFNLHNCQUFnRTtBQUFBLEVBQ2xFLEdBQUcsYUFBYSxJQUFJLFVBQVEsS0FBSyxHQUFHLEVBQUUsT0FBTyxDQUFDLFFBQWlELFFBQVEsUUFBUTtBQUFBLEVBQy9HLEdBQUc7QUFDUDs7O0FDbkVPLElBQU0sb0NBQW9DO0FBQzFDLElBQU0sc0NBQXNDOzs7QUNPbkQsSUFBTSwyQkFBMkI7QUFFakMsU0FBUyxxQkFBNkI7QUFDbEMsTUFBSSxPQUFPLFlBQVksYUFBYTtBQUFFLFdBQU87QUFBQSxFQUEwQjtBQUN2RSxRQUFNLE1BQU0sUUFBUSxLQUFLO0FBQ3pCLE1BQUksUUFBUSxRQUFXO0FBQUUsV0FBTztBQUFBLEVBQTBCO0FBQzFELFFBQU0sU0FBUyxPQUFPLEdBQUc7QUFDekIsTUFBSSxDQUFDLE9BQU8sU0FBUyxNQUFNLEtBQUssU0FBUyxHQUFHO0FBQUUsV0FBTztBQUFBLEVBQTBCO0FBQy9FLFNBQU8sS0FBSyxNQUFNLE1BQU07QUFDNUI7QUFFQSxJQUFNLG1CQUFtQixtQkFBbUI7QUFTNUMsU0FBUyxrQkFBa0IsTUFBOEM7QUFDckUsTUFBSTtBQUNBLFdBQU8sS0FBSyxVQUFVLElBQUk7QUFBQSxFQUM5QixRQUFRO0FBR0osV0FBTztBQUFBLEVBQ1g7QUFDSjtBQWdCQSxTQUFTLHFCQUFxQixTQUE4RDtBQUN4RixRQUFNLFVBQVUsU0FBUyxZQUFZLFNBQVMsV0FDeEMsRUFBRSxVQUFVLFFBQVEsVUFBVSxNQUFNLFVBQW1CLFFBQVEsQ0FBQyxFQUFFLElBQ2xFO0FBQ04sTUFBSSxDQUFDLFNBQVM7QUFBRSxXQUFPO0FBQUEsRUFBVztBQUNsQyxTQUFPLEVBQUUsVUFBVSxRQUFRLFVBQVUsUUFBUTtBQUNqRDtBQTJDTyxTQUFTLGlCQUFpQixXQUFtQixRQUFrQixTQUF3QztBQUMxRyxTQUFPLE9BQU8sV0FBVyxRQUFRLHFCQUFxQixPQUFPLEdBQUcsU0FBUyxxQkFBcUIsS0FBSztBQUN2RztBQXVCTyxTQUFTLGNBQWMsUUFBa0IsU0FBcUM7QUFLakYsUUFBTSxNQUFNLE9BQU87QUFDbkIsTUFBSSxvQkFBb0I7QUFDeEIsUUFBTSxTQUFTLFNBQVM7QUFDeEIsUUFBTSxnQkFBZ0Isb0JBQUksSUFBZ0I7QUFDMUMsV0FBUyxtQkFBeUI7QUFDOUIsUUFBSSxRQUFRLFdBQVcscUJBQXFCLENBQUMsU0FBUyxXQUFXO0FBQUU7QUFBQSxJQUFRO0FBQzNFLHdCQUFvQjtBQUNwQixZQUFRLFVBQVUsQ0FBQyxPQUFPLFlBQVk7QUFBRSxVQUFJLENBQUMsUUFBUSxTQUFTO0FBQUUsWUFBSSxLQUFLLE9BQU8sT0FBTztBQUFBLE1BQUc7QUFBQSxJQUFFLENBQUM7QUFBQSxFQUNqRztBQUdBLFFBQU0sZ0JBQWdCLHFCQUFxQixPQUFPO0FBR2xELFFBQU0sZ0JBQWdCLG9CQUFJLElBQStCO0FBQ3pELFFBQU0sTUFBTSxDQUFDLE9BQWUsWUFBZ0M7QUFDeEQsUUFBSSxJQUFJLE9BQU8sT0FBTztBQUN0QixVQUFNLFdBQVcsY0FBYyxJQUFJLEtBQUs7QUFDeEMsUUFBSSxDQUFDLFVBQVUsT0FBTyxPQUFPLEtBQUssU0FBUyxPQUFPLEdBQUc7QUFBRTtBQUFBLElBQVE7QUFDL0Qsa0JBQWMsT0FBTyxLQUFLO0FBQzFCLFdBQU8scUNBQXFDLGVBQWUsS0FBSyxFQUFFLE1BQU0sTUFBTSxNQUFTO0FBQUEsRUFDM0Y7QUFDQSxRQUFNLEtBQUssQ0FBQyxPQUFlLFlBQXdDO0FBQy9ELHFCQUFpQjtBQUNqQixRQUFJLFFBQVEsU0FBUztBQUFFLGFBQU8sTUFBTTtBQUFBLElBQVc7QUFDL0MsUUFBSSxDQUFDLFNBQVMsV0FBVztBQUFFLGFBQU8sYUFBYSxJQUFJLEdBQUcsT0FBTyxPQUFPLENBQUM7QUFBQSxJQUFHO0FBQ3hFLFFBQUksR0FBRyxPQUFPLE9BQU87QUFDckIsUUFBSSxXQUFXLGNBQWMsSUFBSSxLQUFLO0FBQ3RDLFFBQUksQ0FBQyxVQUFVO0FBQ1gsaUJBQVcsb0JBQUksSUFBSTtBQUNuQixvQkFBYyxJQUFJLE9BQU8sUUFBUTtBQUNqQyxhQUFPLG1DQUFtQyxlQUFlLEtBQUssRUFBRSxNQUFNLE1BQU0sTUFBUztBQUFBLElBQ3pGO0FBQ0EsYUFBUyxJQUFJLE9BQU87QUFDcEIsV0FBTyxNQUFNLElBQUksT0FBTyxPQUFPO0FBQUEsRUFDbkM7QUFFQSxXQUFTLGFBQWEsU0FBaUM7QUFDbkQsVUFBTSxVQUFVLE1BQU07QUFDbEIsVUFBSSxDQUFDLGNBQWMsT0FBTyxPQUFPLEdBQUc7QUFBRTtBQUFBLE1BQVE7QUFDOUMsY0FBUTtBQUFBLElBQ1o7QUFDQSxrQkFBYyxJQUFJLE9BQU87QUFDekIsV0FBTztBQUFBLEVBQ1g7QUFDQSxVQUFRLGlCQUFpQixTQUFTLE1BQU07QUFDcEMsZUFBVyxDQUFDLE9BQU8sUUFBUSxLQUFLLGVBQWU7QUFDM0MsaUJBQVcsV0FBVyxVQUFVO0FBQUUsWUFBSSxPQUFPLE9BQU87QUFBQSxNQUFHO0FBQUEsSUFDM0Q7QUFDQSxlQUFXLFdBQVcsZUFBZTtBQUFFLGNBQVE7QUFBQSxJQUFHO0FBQUEsRUFDdEQsR0FBRyxFQUFFLE1BQU0sS0FBSyxDQUFDO0FBVWpCLFNBQU8sSUFBSSxNQUFNLENBQUMsR0FBOEI7QUFBQSxJQUM1QyxJQUFJLFNBQVMsTUFBTTtBQUNmLFVBQUksT0FBTyxTQUFTLFVBQVU7QUFBRSxlQUFPO0FBQUEsTUFBVztBQUVsRCxVQUFJLFNBQVMsVUFBVSxTQUFTLFVBQVU7QUFBRSxlQUFPO0FBQUEsTUFBVztBQUc5RCxVQUFJLFNBQVMsTUFBTTtBQUNmLGVBQU87QUFBQSxNQUNYO0FBQ0EsVUFBSSxTQUFTLE9BQU87QUFDaEIsZUFBTztBQUFBLE1BQ1g7QUFDQSxVQUFJLFNBQVMsU0FBUztBQUNsQix5QkFBaUI7QUFDakIsZUFBTyxDQUFDLFlBQTBCLFFBQVEsVUFDcEMsTUFBTSxTQUNOLGFBQWEsSUFBSSxNQUFNLE9BQU8sQ0FBQztBQUFBLE1BQ3pDO0FBTUEsVUFBSSxTQUFTLFVBQVU7QUFDbkIsZUFBTyxDQUFjLFlBQW9CLFNBQWdDLE9BQU8sU0FBUyxlQUFlLEdBQUcsSUFBSTtBQUFBLE1BQ25IO0FBRUEsVUFDSSxTQUFTLGNBQ04sT0FBTyxVQUFVLGVBQWUsS0FBSyxRQUFRLFlBQVksSUFBSSxHQUNsRTtBQUNFLGVBQU8sUUFBUSxXQUFXLElBQUk7QUFBQSxNQUNsQztBQUNBLGFBQU8saUJBQWlCLE1BQU0sUUFBUSxPQUFPO0FBQUEsSUFDakQ7QUFBQSxFQUNKLENBQUM7QUFDTDtBQUVBLFNBQVMsT0FBTyxNQUFjLFFBQWtCLFNBQW9DLGtCQUFnQztBQVFoSCxRQUFNLFdBQVcsb0JBQUksSUFBaUI7QUFLdEMsUUFBTSxZQUFZLG9CQUFJLElBQTRCO0FBQ2xELFFBQU0sUUFBYSxJQUFJLE1BQU0sTUFBTTtBQUFBLEVBQUMsR0FBRztBQUFBLElBQ25DLElBQUksU0FBUyxNQUFNO0FBQ2YsVUFBSSxTQUFTLFFBQVE7QUFBRSxlQUFPO0FBQUEsTUFBVztBQUN6QyxVQUFJLFNBQVMsVUFBVTtBQUFFLGVBQU87QUFBQSxNQUFXO0FBSzNDLFVBQUksT0FBTyxTQUFTLFVBQVU7QUFBRSxlQUFPO0FBQUEsTUFBVztBQWVsRCxVQUFJLFNBQVMsUUFBUTtBQUNqQixlQUFPLENBQUMsYUFBdUIsY0FDM0IsSUFBSSxhQUF3QixRQUFRLE1BQU0sT0FBTyxRQUFXLENBQUMsR0FBRyxXQUFXLEdBQUcsUUFBUSxDQUFDO0FBQUEsTUFDL0Y7QUFDQSxVQUFJLFNBQVMsUUFBUTtBQUNqQixlQUFPLENBQUMsYUFBdUIsU0FBb0IsUUFBUSxNQUFNLE9BQU8sUUFBVyxJQUFJO0FBQUEsTUFDM0Y7QUFDQSxVQUFJLFNBQVMsU0FBUztBQUNsQixlQUFPLENBQUMsVUFBb0IsU0FBcUIsUUFBUSxNQUFNLE9BQU8sUUFBVyxRQUFRLENBQUMsQ0FBQztBQUFBLE1BQy9GO0FBQ0EsWUFBTSxTQUFTLFNBQVMsSUFBSSxJQUFJO0FBQ2hDLFVBQUksV0FBVyxRQUFXO0FBQUUsZUFBTztBQUFBLE1BQVE7QUFDM0MsWUFBTSxRQUFRLE9BQU8sR0FBRyxJQUFJLElBQUksSUFBSSxJQUFJLFFBQVEsU0FBUyxnQkFBZ0I7QUFDekUsZUFBUyxJQUFJLE1BQU0sS0FBSztBQUN4QixhQUFPO0FBQUEsSUFDWDtBQUFBLElBQ0EsTUFBTSxTQUFTLFVBQVUsTUFBTTtBQUczQixZQUFNLFVBQVUsS0FBSyxZQUFZLEdBQUc7QUFDcEMsWUFBTSxVQUFVLE1BQU0sS0FBSyxNQUFNLEdBQUcsT0FBTyxDQUFDLElBQUksS0FBSyxNQUFNLFVBQVUsQ0FBQyxDQUFDO0FBZXZFLFlBQU0sYUFBYSxvQkFBb0IsbUJBQW1CLE1BQ2xELFNBQVMsVUFBVSxLQUFLLFNBQVMsT0FBTztBQUNoRCxVQUFJLFlBQVk7QUFDWixjQUFNLE1BQU0sa0JBQWtCLElBQUk7QUFDbEMsWUFBSSxRQUFRLFFBQVc7QUFDbkIsZ0JBQU0sU0FBUyxVQUFVLElBQUksR0FBRztBQUNoQyxjQUFJLFFBQVE7QUFDUixrQkFBTSxNQUFNLEtBQUssSUFBSTtBQUdyQixnQkFBSSxPQUFPLGdCQUFnQixRQUFXO0FBR2xDLHNCQUFRLElBQUksd0NBQXdDLE9BQU8sV0FBVyxJQUFJLE1BQU0sRUFBRTtBQUNsRixxQkFBTyxPQUFPO0FBQUEsWUFDbEI7QUFDQSxnQkFBSSxNQUFNLE9BQU8sY0FBYyxrQkFBa0I7QUFHN0Msc0JBQVEsSUFBSSxxQ0FBcUMsT0FBTyxVQUFVLE1BQU0sT0FBTyxXQUFXLFdBQVcsSUFBSSxNQUFNLEVBQUU7QUFDakgscUJBQU8sT0FBTztBQUFBLFlBQ2xCO0FBRUEsc0JBQVUsT0FBTyxHQUFHO0FBQUEsVUFDeEI7QUFHQSxrQkFBUSxJQUFJLGdDQUFnQyxPQUFPLFdBQVcsSUFBSSxNQUFNLEVBQUU7QUFDMUUsZ0JBQU0sVUFBVSxPQUFPLFNBQVMsU0FBUyxHQUFHLElBQUksRUFBRSxLQUFLLGlCQUFpQjtBQUN4RSxnQkFBTSxRQUF3QixFQUFFLFFBQVE7QUFDeEMsb0JBQVUsSUFBSSxLQUFLLEtBQUs7QUFDeEIsa0JBQVE7QUFBQSxZQUNKLE1BQU07QUFJRixrQkFBSSxVQUFVLElBQUksR0FBRyxNQUFNLE9BQU87QUFDOUIsc0JBQU0sY0FBYyxLQUFLLElBQUk7QUFFN0Isc0JBQU0sUUFBUSxXQUFXLE1BQU07QUFDM0Isc0JBQUksVUFBVSxJQUFJLEdBQUcsTUFBTSxPQUFPO0FBQzlCLDhCQUFVLE9BQU8sR0FBRztBQUFBLGtCQUN4QjtBQUFBLGdCQUNKLEdBQUcsZ0JBQWdCO0FBRW5CLGdCQUFDLE9BQTZDLFFBQVE7QUFBQSxjQUMxRDtBQUFBLFlBQ0o7QUFBQSxZQUNBLE1BQU07QUFFRixrQkFBSSxVQUFVLElBQUksR0FBRyxNQUFNLE9BQU87QUFDOUIsMEJBQVUsT0FBTyxHQUFHO0FBQUEsY0FDeEI7QUFHQSxzQkFBUSxJQUFJLGtDQUFrQyxPQUFPLFdBQVcsSUFBSSxNQUFNLEVBQUU7QUFBQSxZQUNoRjtBQUFBLFVBQ0o7QUFDQSxpQkFBTztBQUFBLFFBQ1g7QUFHQSxnQkFBUSxJQUFJLDRDQUE0QyxPQUFPLCtCQUErQjtBQUFBLE1BQ2xHO0FBRUEsYUFBTyxPQUFPLFNBQVMsU0FBUyxHQUFHLElBQUksRUFBRSxLQUFLLGlCQUFpQjtBQUFBLElBQ25FO0FBQUEsRUFDSixDQUFDO0FBQ0QsU0FBTztBQUNYOzs7QUM5WE8sSUFBTSxzQkFBc0IsQ0FBQyxhQUFhLFFBQVEsVUFBVTtBQVM1RCxJQUFNLGtCQUFrQjtBQUFBLEVBQzNCO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQ0o7QUFhTyxJQUFNLDBCQUEwQjtBQUFBLEVBQ25DO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQ0o7QUFXTyxJQUFNLG9CQUFvQjtBQUFBO0FBQUEsRUFFN0IsS0FBSztBQUFBO0FBQUEsRUFFTCxTQUFTLENBQUMsR0FBRyxpQkFBaUIsR0FBRyx1QkFBdUI7QUFDNUQ7QUEwQk8sSUFBTSxpQkFBaUIsQ0FBQyxHQUFHLGlCQUFpQixHQUFHLHlCQUF5QixHQUFHLG1CQUFtQjs7O0FDbklyRyxvQkFBbUI7OztBQ3FEbkIsU0FBUyxnQkFBZ0IsT0FBYyxVQUFrQztBQUNyRSxTQUFPLE9BQU8sT0FBTyxJQUFJLE1BQU0sTUFBTSxTQUFTLEVBQUUsT0FBTyxNQUFNLENBQUMsR0FBRztBQUFBLElBQzdELE1BQU07QUFBQSxJQUNOLE1BQU0sRUFBRSxTQUFTO0FBQUEsRUFDckIsQ0FBQztBQUNMO0FBTUEsU0FBUyxjQUFjLE1BQXdDO0FBQzNELFFBQU0sRUFBRSxXQUFXLE1BQU0sSUFBSTtBQUc3QixRQUFNLGtCQUFrQixvQkFBSSxJQUE0QjtBQWF4RCxNQUFJO0FBQ0osTUFBSTtBQUNKLE1BQUksaUJBQWlCO0FBQ3JCLFFBQU0sVUFBVSxvQkFBSSxJQUlqQjtBQUVILE1BQUk7QUFDSixNQUFJLG9CQUFvQjtBQUN4QixNQUFJLFNBQVMsTUFBWTtBQUN6QixNQUFJLGNBQWMsTUFBWTtBQUU5QixXQUFTLE1BQU0sUUFBUSxJQUFJLE1BQU0sSUFBSSxLQUFLLFlBQVksR0FBUztBQUMzRCxRQUFJLFFBQVE7QUFBRTtBQUFBLElBQVE7QUFDdEIsYUFBUztBQUNULFdBQU87QUFDUCxnQkFBWTtBQUNaLGVBQVcsV0FBVyxRQUFRLE9BQU8sR0FBRztBQUFFLGNBQVEsT0FBTyxnQkFBZ0IsT0FBTyxRQUFRLFFBQVEsQ0FBQztBQUFBLElBQUc7QUFDcEcsWUFBUSxNQUFNO0FBQ2Qsb0JBQWdCLE1BQU07QUFDdEIsaUJBQWE7QUFDYixtQkFBZTtBQUFBLEVBQ25CO0FBRUEsV0FBUyxLQUFLLFNBQStCO0FBQ3pDLFFBQUksUUFBUTtBQUFFO0FBQUEsSUFBUTtBQUN0QixRQUFJLENBQUMsS0FBSyxZQUFZLEdBQUc7QUFDckIscUJBQWUsSUFBSSxNQUFNLElBQUksS0FBSyxnQkFBZ0IsQ0FBQztBQUNuRDtBQUFBLElBQ0o7QUFDQSxRQUFJO0FBR0EsWUFBTSxVQUFVLFFBQVEsU0FBUyxvQkFBb0IsUUFBUSxZQUN2RCxRQUFRLElBQUksUUFBUSxTQUFTLElBQUk7QUFDdkMsVUFBSSxTQUFTO0FBQUUsZ0JBQVEsV0FBVztBQUFBLE1BQVc7QUFHN0MsV0FBSyxLQUFLLFNBQVMsV0FBUztBQUFFLFlBQUksT0FBTztBQUFFLHlCQUFlLEtBQUs7QUFBQSxRQUFHO0FBQUEsTUFBRSxDQUFDO0FBQUEsSUFDekUsU0FBUyxPQUFPO0FBSVosVUFBSTtBQUFFLGFBQUssVUFBVSxPQUFPO0FBQUEsTUFBRyxRQUFRO0FBQ25DLGNBQU0sSUFBSSxNQUFNLElBQUksS0FBSyx3Q0FBd0M7QUFBQSxNQUNyRTtBQUNBLHFCQUFlLGlCQUFpQixRQUFRLFFBQVEsSUFBSSxNQUFNLE9BQU8sS0FBSyxDQUFDLENBQUM7QUFBQSxJQUM1RTtBQUFBLEVBQ0o7QUFFQSxXQUFTLGVBQWUsT0FBb0I7QUFDeEMsVUFBTSxLQUFLO0FBR1gsUUFBSTtBQUFFLFdBQUssV0FBVztBQUFBLElBQUcsUUFBUTtBQUFBLElBQTBDO0FBQUEsRUFDL0U7QUFFQSxRQUFNLFdBQVcsT0FBTyxRQUFnQztBQUNwRCxRQUFJLFFBQVE7QUFBRTtBQUFBLElBQVE7QUFDdEIsUUFBSSxDQUFDLGNBQWMsR0FBRyxHQUFHO0FBQUM7QUFBQSxJQUFPO0FBQ2pDLFVBQU0sTUFBTTtBQUdaLFFBQUksSUFBSSxTQUFTLG9CQUFvQixJQUFJLFdBQVcsSUFBSSxXQUFXO0FBQy9ELFVBQUksQ0FBQyxtQkFBbUI7QUFDcEIsYUFBSztBQUFBLFVBQ0QsTUFBTTtBQUFBLFVBQW1CLFdBQVcsSUFBSTtBQUFBLFVBQ3hDLE9BQU8scUJBQXFCLElBQUksTUFBTSxJQUFJLEtBQUssaUJBQWlCLENBQUM7QUFBQSxRQUNyRSxDQUFDO0FBQ0Q7QUFBQSxNQUNKO0FBRUEsWUFBTSxvQkFBb0IsZ0JBQWdCLElBQUksSUFBSSxPQUFPO0FBQ3pELFVBQUksQ0FBQyxxQkFBcUIsQ0FBQyxZQUFZO0FBQ25DLGFBQUs7QUFBQSxVQUNELE1BQU07QUFBQSxVQUNOLFdBQVcsSUFBSTtBQUFBLFVBQ2YsT0FBTyxxQkFBcUIsSUFBSTtBQUFBLFlBQzVCLElBQUksS0FBSyw2QkFBNkIsSUFBSSxPQUFPO0FBQUEsVUFDckQsQ0FBQztBQUFBLFFBQ0wsQ0FBQztBQUNEO0FBQUEsTUFDSjtBQUNBLFVBQUk7QUFJQSxjQUFNLFVBQVUsSUFBSSxRQUFRLENBQUM7QUFDN0IsY0FBTSxDQUFDLFNBQVMsR0FBRyxRQUFRLElBQUk7QUFDL0IsY0FBTSxTQUFTLG9CQUNULE1BQU0sa0JBQWtCLFNBQXNDLEdBQUcsUUFBUSxJQUN6RSxNQUFNLFdBQVksSUFBSSxTQUFTLFNBQXNDLEdBQUcsUUFBUTtBQUN0RixhQUFLLEVBQUUsTUFBTSxtQkFBbUIsV0FBVyxJQUFJLFdBQVcsT0FBTyxDQUFDO0FBQUEsTUFDdEUsU0FBUyxLQUFLO0FBQ1YsYUFBSztBQUFBLFVBQ0QsTUFBTTtBQUFBLFVBQ04sV0FBVyxJQUFJO0FBQUEsVUFDZixPQUFPLHFCQUFxQixHQUFHO0FBQUEsUUFDbkMsQ0FBQztBQUFBLE1BQ0w7QUFDQTtBQUFBLElBQ0o7QUFHQSxRQUFJLElBQUksU0FBUyxxQkFBcUIsSUFBSSxXQUFXO0FBQ2pELFlBQU0sSUFBSSxRQUFRLElBQUksSUFBSSxTQUFTO0FBQ25DLFVBQUksQ0FBQyxHQUFHO0FBQUM7QUFBQSxNQUFPO0FBQ2hCLGNBQVEsT0FBTyxJQUFJLFNBQVM7QUFDNUIsVUFBSSxJQUFJLFVBQVUsUUFBVztBQUN6QixZQUFJO0FBQ0EsY0FBSSx3QkFBd0IsSUFBSSxLQUFLLEdBQUc7QUFDcEMsOEJBQWtCLElBQUksS0FBSztBQUFBLFVBQy9CLE9BQU87QUFDSCxrQkFBTSxJQUFJLE1BQU0sT0FBTyxJQUFJLEtBQUssQ0FBQztBQUFBLFVBQ3JDO0FBQUEsUUFDSixTQUFTLEtBQUs7QUFDVixZQUFFLE9BQU8sR0FBWTtBQUFBLFFBQ3pCO0FBQUEsTUFDSixPQUFPO0FBQ0gsVUFBRSxRQUFRLElBQUksTUFBTTtBQUFBLE1BQ3hCO0FBQ0E7QUFBQSxJQUNKO0FBR0EsUUFBSSxJQUFJLFNBQVMsV0FBVyxJQUFJLE9BQU87QUFDbkMscUJBQWUsSUFBSSxPQUFPLElBQUksT0FBTztBQUFBLElBQ3pDO0FBQUEsRUFDSjtBQUVBLFdBQVMsVUFBVSxRQUFRO0FBQzNCLGdCQUFjLEtBQUssUUFBUSxXQUFTLE1BQU0sU0FBUyxJQUFJLE1BQU0sSUFBSSxLQUFLLGdCQUFnQixDQUFDLENBQUM7QUFFeEYsV0FBUyxPQUFPLFNBQWlCLFlBQXVDLE1BQW1DO0FBQ3ZHLFFBQUksUUFBUTtBQUFFLGFBQU8sUUFBUSxPQUFPLGdCQUFnQixRQUFRLFVBQVUsQ0FBQztBQUFBLElBQUc7QUFDMUUsV0FBTyxJQUFJLFFBQVEsQ0FBQyxTQUFTLFdBQVc7QUFDcEMsWUFBTSxZQUFZLEdBQUcsS0FBSyxRQUFRLEVBQUUsY0FBYztBQUNsRCxjQUFRLElBQUksV0FBVyxFQUFFLFNBQVMsUUFBUSxVQUFVLFdBQVcsQ0FBQztBQUNoRSxVQUFJO0FBQ0EsYUFBSztBQUFBLFVBQ0QsTUFBTTtBQUFBLFVBQ047QUFBQSxVQUNBO0FBQUEsVUFDQSxNQUFNLENBQUMsU0FBUyxHQUFHLElBQUk7QUFBQSxRQUMzQixDQUFDO0FBQUEsTUFDTCxTQUFTLEtBQUs7QUFDVixnQkFBUSxPQUFPLFNBQVM7QUFDeEIsZUFBTyxlQUFlLFFBQVEsTUFBTSxJQUFJLE1BQU0sT0FBTyxHQUFHLENBQUMsQ0FBQztBQUFBLE1BQzlEO0FBQUEsSUFDSixDQUFDO0FBQUEsRUFDTDtBQUVBLFNBQU87QUFBQSxJQUNILHdCQUE4QjtBQUFFLDBCQUFvQjtBQUFBLElBQU87QUFBQSxJQUMzRCxPQUFPLFNBQWlCLFNBQStCO0FBQ25ELHNCQUFnQixJQUFJLFNBQVMsT0FBTztBQUFBLElBQ3hDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQU1BLFVBQVUsU0FBK0I7QUFDckMsbUJBQWE7QUFBQSxJQUNqQjtBQUFBLElBRUEsVUFBVSxPQUFlLFNBQXdCO0FBQzdDLFdBQUssRUFBRSxNQUFNLFNBQVMsT0FBTyxRQUFRLENBQUM7QUFBQSxJQUMxQztBQUFBLElBRUE7QUFBQSxJQUVBLEdBQUcsU0FBNkI7QUFDNUIscUJBQWU7QUFBQSxJQUNuQjtBQUFBLElBRUEsU0FBUztBQUFBLEVBQ2I7QUFDSjtBQWtFTyxTQUFTLCtCQUFpRDtBQUM3RCxTQUFPLGNBQWM7QUFBQSxJQUNqQixPQUFPO0FBQUEsSUFDUCxhQUFhLE1BQU0sQ0FBQyxDQUFDLFFBQVEsYUFBYSxDQUFDLENBQUMsUUFBUTtBQUFBLElBQ3BELE1BQU0sQ0FBQyxLQUFLLGFBQWE7QUFDckIsY0FBUSxLQUFNLEtBQUssUUFBUTtBQUFBLElBQy9CO0FBQUEsSUFDQSxZQUFZLE1BQU07QUFBRSxVQUFJLFFBQVEsV0FBVztBQUFFLGdCQUFRLGFBQWE7QUFBQSxNQUFHO0FBQUEsSUFBRTtBQUFBLElBQ3ZFLFNBQVMsY0FBWTtBQUNqQixjQUFRLEdBQUcsY0FBYyxRQUFRO0FBQ2pDLGFBQU8sTUFBTSxRQUFRLElBQUksY0FBYyxRQUFRO0FBQUEsSUFDbkQ7QUFBQSxJQUNBLFdBQVcsY0FBWTtBQUNuQixjQUFRLEdBQUcsV0FBVyxRQUFRO0FBQzlCLGFBQU8sTUFBTSxRQUFRLElBQUksV0FBVyxRQUFRO0FBQUEsSUFDaEQ7QUFBQSxFQUNKLENBQUM7QUFDTDtBQUlBLFNBQVMsY0FBYyxLQUFxQztBQUN4RCxTQUNJLFFBQVEsUUFDTCxPQUFPLFFBQVEsWUFDZixVQUFVLE9BQ1YsT0FBUSxJQUEwQixTQUFTO0FBRXREOzs7QUNsVU8sU0FBUyxtQkFBd0M7QUFDcEQsUUFBTSxZQUFZLDZCQUE2QjtBQUUvQyxRQUFNLGdCQUFtRCxDQUFDO0FBQzFELE1BQUksb0JBQW9CO0FBR3hCLFFBQU0sY0FBYyxZQUEyQjtBQUMzQyxRQUFJLG1CQUFtQjtBQUFFO0FBQUEsSUFBUTtBQUNqQyx3QkFBb0I7QUFJcEIsZUFBVyxNQUFNLGVBQWU7QUFDNUIsVUFBSTtBQUNBLGNBQU0sR0FBRztBQUFBLE1BQ2IsU0FBUyxLQUFLO0FBQ1YsZ0JBQVEsTUFBTSxxQ0FBcUMsR0FBRztBQUFBLE1BQzFEO0FBQUEsSUFDSjtBQUFBLEVBQ0o7QUFRQSxRQUFNLE9BQU8sTUFBWTtBQUFBLEVBQTRCO0FBQ3JELFVBQVEsR0FBRyxXQUFXLE1BQU07QUFBRSxnQkFBWSxFQUFFLEtBQUssTUFBTSxJQUFJO0FBQUEsRUFBRyxDQUFDO0FBSS9ELFVBQVEsS0FBSyxjQUFjLE1BQU07QUFBRSxnQkFBWSxFQUFFLEtBQUssTUFBTSxJQUFJO0FBQUEsRUFBRyxDQUFDO0FBRXBFLFFBQU0sY0FBYyxRQUFRLElBQUksbUJBQW1CO0FBQ25ELE1BQUksWUFBWTtBQUVoQixTQUFPO0FBQUEsSUFDSCxNQUFNO0FBQUEsSUFDTjtBQUFBLElBRUEsV0FBVyxJQUFJO0FBQ1gsb0JBQWMsS0FBSyxFQUFFO0FBQUEsSUFDekI7QUFBQSxJQUVBLGNBQWM7QUFDVixVQUFJLFdBQVc7QUFBRTtBQUFBLE1BQVE7QUFDekIsa0JBQVk7QUFlWixVQUFJLE9BQU8sUUFBUSxTQUFTLFlBQVk7QUFDcEMsWUFBSTtBQUNBLGtCQUFRLEtBQUs7QUFBQSxZQUNULE1BQU07QUFBQSxZQUNOO0FBQUEsWUFDQSxLQUFLLFFBQVE7QUFBQSxVQUNqQixDQUFDO0FBQUEsUUFDTCxTQUFTLEtBQUs7QUFDVixrQkFBUSxNQUFNLGNBQWMsV0FBVywrQkFBK0IsR0FBRztBQUFBLFFBQzdFO0FBQUEsTUFDSjtBQUFBLElBQ0o7QUFBQSxJQUVBLFlBQVk7QUFJUixjQUFRLEtBQUssQ0FBQztBQUFBLElBQ2xCO0FBQUEsRUFDSjtBQUNKOzs7QUM4RUEsZUFBc0IsYUFBYSxNQUlDO0FBQ2hDLFFBQU0sRUFBRSxhQUFhLEtBQUssU0FBUyxJQUFJO0FBQ3ZDLFFBQU0sRUFBRSxVQUFVLElBQUk7QUFpQnRCLFFBQU0sV0FBVyxVQUFVLFdBQVcsWUFBWTtBQUM5QyxVQUFNLElBQUksTUFBTSxjQUFjLFdBQVcsOEJBQThCO0FBQUEsRUFDM0U7QUFDQSxRQUFNLGNBQWMsVUFBVSxPQUFPLE1BQU07QUFBQSxFQUF1QztBQUNsRixRQUFNLEtBQUssY0FBYyxVQUFVO0FBQUEsSUFDL0IsV0FBVztBQUFBLEVBQ2YsQ0FBQztBQVNELE1BQUk7QUFDSixNQUFJLGtCQUFrQjtBQUV0QixRQUFNLGFBQWEsWUFBMkI7QUFDMUMsUUFBSSxpQkFBaUI7QUFBRTtBQUFBLElBQVE7QUFDL0Isc0JBQWtCO0FBQ2xCLFFBQUk7QUFDQSxZQUFNLGNBQWM7QUFBQSxJQUN4QixTQUFTLEtBQUs7QUFDVixjQUFRLE1BQU0sY0FBYyxXQUFXLG9CQUFvQixHQUFHO0FBQUEsSUFDbEU7QUFDQSxRQUFJO0FBQ0EsZ0JBQVUsVUFBVTtBQUFBLElBQ3hCLFNBQVMsS0FBSztBQUNWLGNBQVEsTUFBTSxjQUFjLFdBQVcsOEJBQThCLEdBQUc7QUFBQSxJQUM1RTtBQUNBLFFBQUk7QUFDQSxVQUFJLFVBQVU7QUFBQSxJQUNsQixTQUFTLEtBQUs7QUFDVixjQUFRLE1BQU0sY0FBYyxXQUFXLDBCQUEwQixHQUFHO0FBQUEsSUFDeEU7QUFBQSxFQUNKO0FBRUEsTUFBSSxXQUFXLFVBQVU7QUFHekIsTUFBSTtBQUNBLFVBQU0sU0FBUyxNQUFNLFNBQVMsRUFBRTtBQUNoQyxRQUFJLFVBQVUsT0FBTyxXQUFXLFVBQVU7QUFDdEMsWUFBTSxFQUFFLFNBQVMsUUFBUSxJQUFJO0FBQzdCLG9CQUFjO0FBRWQsVUFBSSxTQUFTO0FBS1QsbUJBQVcsV0FBVyxPQUFPLEtBQUssT0FBTyxHQUFHO0FBQ3hDLGdCQUFNLEtBQUssUUFBUSxPQUFPO0FBQzFCLG9CQUFVLE9BQU8sU0FBUyxVQUFVLFNBQW9CLEdBQUcsR0FBRyxJQUFJLENBQUM7QUFBQSxRQUN2RTtBQUNBLGdCQUFRO0FBQUEsVUFDSixjQUFjLFdBQVcsMEJBQTBCLE9BQU8sS0FBSyxPQUFPLEVBQUUsS0FBSyxJQUFJLENBQUM7QUFBQSxRQUN0RjtBQUFBLE1BQ0o7QUFBQSxJQUNKO0FBQUEsRUFDSixTQUFTLEtBQUs7QUFDVixZQUFRLE1BQU0sY0FBYyxXQUFXLHNCQUFzQixHQUFHO0FBTWhFLFFBQUk7QUFBRSxVQUFJLFVBQVU7QUFBQSxJQUFHLFFBQVE7QUFBQSxJQUFlO0FBQzlDLFVBQU07QUFBQSxFQUNWO0FBUUEsTUFBSTtBQUNBLFFBQUksWUFBWTtBQUFBLEVBQ3BCLFNBQVMsS0FBSztBQUdWLFlBQVEsTUFBTSxjQUFjLFdBQVcseUJBQXlCLEdBQUc7QUFBQSxFQUN2RTtBQUdBLFNBQU87QUFBQSxJQUNILFNBQVM7QUFBQSxFQUNiO0FBQ0o7OztBQ3RRQSxTQUFTLGdCQUFnQixLQUE2QztBQUNsRSxNQUFJLENBQUMsT0FBTyxPQUFPLFFBQVEsVUFBVTtBQUFFLFdBQU87QUFBQSxFQUFXO0FBQ3pELFFBQU0sSUFBSTtBQUdWLE1BQUksT0FBTyxFQUFFLGFBQWEsWUFBWTtBQUNsQyxXQUFPLEVBQUU7QUFBQSxFQUNiO0FBRUEsUUFBTSxNQUFNLEVBQUU7QUFDZCxNQUFJLE9BQU8sT0FBTyxRQUFRLFlBQVksT0FBUSxJQUFnQyxhQUFhLFlBQVk7QUFDbkcsV0FBUSxJQUFnQztBQUFBLEVBQzVDO0FBRUEsTUFBSSxPQUFPLFFBQVEsWUFBWTtBQUMzQixXQUFPO0FBQUEsRUFDWDtBQUNBLFNBQU87QUFDWDtBQUVBLGVBQWUsT0FBc0I7QUFDakMsUUFBTSxjQUFjLFFBQVEsSUFBSSxtQkFBbUI7QUFDbkQsUUFBTSxZQUFZLFFBQVEsS0FBSyxDQUFDO0FBRWhDLE1BQUksQ0FBQyxXQUFXO0FBQ1osWUFBUSxNQUFNLGlCQUFpQixXQUFXLHFDQUFxQztBQUMvRSxZQUFRLEtBQUssQ0FBQztBQUFBLEVBQ2xCO0FBaUJBLFFBQU0sYUFBYSxRQUFRLFNBQVM7QUFFcEMsUUFBTSxXQUFXLGdCQUFnQixVQUFVO0FBQzNDLE1BQUksQ0FBQyxVQUFVO0FBSVgsWUFBUTtBQUFBLE1BQ0osaUJBQWlCLFdBQVc7QUFBQSxJQUNoQztBQUNBO0FBQUEsRUFDSjtBQUdBLFFBQU0sTUFBTSxpQkFBaUI7QUFDN0IsUUFBTSxhQUFhLEVBQUUsYUFBYSxLQUFLLFNBQVMsQ0FBQztBQUNyRDtBQUVBLEtBQUssRUFBRSxNQUFNLENBQUMsUUFBaUI7QUFDM0IsVUFBUTtBQUFBLElBQ0osaUJBQWlCLFFBQVEsSUFBSSxtQkFBbUIsV0FBVztBQUFBLElBQzNELGVBQWUsUUFBUSxJQUFJLFNBQVMsSUFBSSxVQUFVO0FBQUEsRUFDdEQ7QUFDQSxVQUFRLEtBQUssQ0FBQztBQUNsQixDQUFDOyIsCiAgIm5hbWVzIjogWyJleHBvcnRzIiwgIm1vZHVsZSIsICJleHBvcnRzIiwgIm1vZHVsZSIsICJleHBvcnRzIiwgIm1vZHVsZSIsICJleHBvcnRzIiwgImV4cG9ydHMiLCAicmVxdWlyZV9jb21tb24iLCAiZXhwb3J0cyIsICJleHBvcnRzIiwgIm1vZHVsZSIsICJyZXF1aXJlX18iLCAiZXhwb3J0cyIsICJtb2R1bGUiLCAicmVxdWlyZV9fIiwgImV4cG9ydHMiLCAibW9kdWxlIiwgInJlcXVpcmVfXyIsICJleHBvcnRzIiwgIm1vZHVsZSIsICJyZXF1aXJlX18iLCAiZXhwb3J0cyIsICJtb2R1bGUiLCAiZXhwb3J0cyIsICJleHBvcnRzIiwgImV4cG9ydHMiLCAibW9kdWxlIiwgImV4cG9ydHMiLCAiZXhwb3J0cyIsICJtb2R1bGUiLCAiZXhwb3J0cyIsICJtb2R1bGUiLCAiZXhwb3J0cyIsICJtb2R1bGUiLCAiZXhwb3J0cyIsICJtb2R1bGUiLCAiZXhwb3J0cyIsICJtb2R1bGUiLCAiZXhwb3J0cyIsICJtb2R1bGUiLCAiZXhwb3J0cyIsICJtb2R1bGUiLCAiZXhwb3J0cyIsICJtb2R1bGUiLCAiZXhwb3J0cyIsICJtb2R1bGUiLCAiZXhwb3J0cyIsICJtb2R1bGUiLCAiZXhwb3J0cyIsICJtb2R1bGUiLCAiZXhwb3J0cyIsICJtb2R1bGUiLCAiZXhwb3J0cyIsICJtb2R1bGUiLCAiZXhwb3J0cyIsICJtb2R1bGUiLCAiZXhwb3J0cyIsICJtb2R1bGUiLCAiZXhwb3J0cyIsICJtb2R1bGUiLCAiZXhwb3J0cyIsICJtb2R1bGUiLCAiZXhwb3J0cyIsICJtb2R1bGUiLCAiZXhwb3J0cyIsICJtb2R1bGUiLCAiZXhwb3J0cyIsICJtb2R1bGUiLCAiZXhwb3J0cyIsICJtb2R1bGUiLCAiZXhwb3J0cyIsICJtb2R1bGUiLCAiZXhwb3J0cyIsICJtb2R1bGUiLCAiZXhwb3J0cyIsICJtb2R1bGUiLCAiZXhwb3J0cyIsICJtb2R1bGUiLCAiZXhwb3J0cyIsICJtb2R1bGUiLCAiZXhwb3J0cyIsICJtb2R1bGUiLCAiZXhwb3J0cyIsICJtb2R1bGUiLCAiZXhwb3J0cyIsICJtb2R1bGUiLCAiZXhwb3J0cyIsICJtb2R1bGUiLCAiZXhwb3J0cyIsICJtb2R1bGUiLCAiZXhwb3J0cyIsICJtb2R1bGUiLCAiZXhwb3J0cyIsICJtb2R1bGUiLCAiZXhwb3J0cyIsICJtb2R1bGUiLCAiZXhwb3J0cyIsICJtb2R1bGUiLCAiZXhwb3J0cyIsICJtb2R1bGUiLCAiZXhwb3J0cyIsICJtb2R1bGUiLCAiZXhwb3J0cyIsICJtb2R1bGUiLCAicmVxdWlyZV92YWxpZCIsICJleHBvcnRzIiwgIm1vZHVsZSIsICJleHBvcnRzIiwgIm1vZHVsZSIsICJleHBvcnRzIiwgIm1vZHVsZSIsICJleHBvcnRzIiwgIm1vZHVsZSIsICJleHBvcnRzIiwgIm1vZHVsZSIsICJleHBvcnRzIiwgIm1vZHVsZSIsICJleHBvcnRzIiwgIm1vZHVsZSIsICJyZXF1aXJlX3NlbXZlciIsICJleHBvcnRzIiwgIm1vZHVsZSJdCn0K
