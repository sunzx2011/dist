# Buddy App packages

Each subdirectory is an independently removable Buddy App package.

Required files:

- `app.json` — package manifest (`kind: "buddy-app"`)
- `home/categories.json` — homepage tabs, scenes and quick prompts
- `prompts/system.md` — app identity and boundaries
- `prompts/modes/*.md` — per-mode prompts
- `icon.png` or `icon.svg`

Optional capability files:

- `workflow/plan.schema.json`
- `workflow/evidence.schema.json`

The host scans this directory through the generic Buddy App registry. Core does
not contain app-id branches. Deleting a package directory removes the app from
the app switcher; its data under a target project's `.workmate/workflow/`
directory is intentionally left untouched.
