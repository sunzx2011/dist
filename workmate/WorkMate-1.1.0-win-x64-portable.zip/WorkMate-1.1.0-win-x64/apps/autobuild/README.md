# AutoBuild Buddy App

独立 Buddy App 插件包。Core 只通过 app.json、home/categories.json、workflow schema 和 team 配置读取本应用；删除本目录即可卸载应用。

**不依赖 Git**：任何可写目录都能运行。每个步骤完成时只记录 `targets` 下文件的 sha256/大小快照，不会自动执行 `git add/commit`。

## 配置入口

- `app.json → team.roles`：角色团队（planner / coder / verifier / reviewer）。
  - `model`：该角色使用的模型；`null` 表示跟随会话模型。
  - `tools`：工具白名单（引擎工具名）。
  - `readOnly: true`：Write/Edit 拒绝，Bash 只允许只读命令和验证命令。
  - `maxTurns`：单次派活的最大模型轮次。
  - `prompt`：角色提示词文件。
- `app.json → limits`：`maxPlanSteps` / `maxTurnsPerRequest` / `maxEvidencePerStep`，
  创建 run 时固化进 `.workmate/workflow/runs/<id>/run.json`。
- `workflow/plan.schema.json`：步骤的 `checks[].criterionIds` 决定一条命令关闭哪些判据；
  有 `checks` 的步骤由宿主 `WorkflowVerify(action=run_checks)` 执行并自动写真实证据。
- 主代理默认工具面只有 `WorkflowPlan` / `WorkflowVerify` / `WorkflowCompleteStep`；
  `WorkflowStateGet` 和 `ReviewStatus` 是角色白名单里的隐藏只读工具，主代理由宿主注入状态摘要。
- `prompts/system.md`：主代理的应用级提示词与计划预算。
- 评审一旦开始，`approve_plan` / `accept` 会检查宿主注入的 `review.converged`；未收敛不允许推进。
- `prompts/roles/*.md`：各角色提示词；可在设置界面直接编辑覆盖。

改团队、模型、工具白名单、预算都只改这里，不需要改 Rust 代码。

运行时也可以在 **设置 → 应用管理 → AutoBuild** 里改 `model / tools / maxTurns / readOnly / prompt`，
并在「运行预算」里改 `maxPlanSteps / maxTurnsPerRequest / maxEvidencePerStep`；
覆盖写入 `~/.workmate/buddy-apps-state.json`，不会修改安装目录里的 `app.json`。

## 提示词分层（改之前先看这里）

| 层 | 文件 | 何时注入 |
| --- | --- | --- |
| 应用级 | `prompts/system.md` | 每个 AutoBuild 会话的每一轮 |
| 工作流类型 | `home/categories.json → systemPromptAppend` | 建会话时选中的「需求实现 / 缺陷修复 / 重构优化 / 测试验收」 |
| 阶段提醒 + 状态摘要 | `src/workflow.rs::phase_prompt`（宿主） | 按 `draft / plan_review / execute / accept` 注入阶段、步骤、证据和评审摘要 |
| 角色 | `prompts/roles/*.md` | `Agent` 具名派活到 planner / coder / verifier / reviewer 时 |

`prompts/phases/*.md` 已删除：它从未被注入，和 `categories.json` 重复。
改工作流类型提示词请改 `home/categories.json`。
