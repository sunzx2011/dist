WorkMate 1.1.7 · Windows 免安装版（x64）
=====================================================

怎么用
------
1. 把整个文件夹解压到任意位置（不要只解出 WorkMate.exe，assets/ 与 apps/ 要跟着）。
2. 双击 WorkMate.exe 即可。不写注册表、不装服务、不建开始菜单项。
3. 卸载 = 直接删掉这个文件夹。

系统要求
--------
* Windows 10 1803+ / Windows 11（x64）
* WebView2 运行时：Windows 11 自带；Windows 10 一般随 Edge 已装。
  如果双击后提示缺少 WebView2，装一次微软官方 Evergreen Runtime 即可：
  https://developer.microsoft.com/microsoft-edge/webview2/
* 首次运行可能被 SmartScreen 拦（本包未做代码签名）：点「更多信息」→「仍要运行」。

数据放在哪
----------
默认 %USERPROFILE%\.workmate（会话、模型配置、专家、日志都在这里）。
想让它完全绿色（数据跟着程序走），启动前设一个环境变量：

    set WORKMATE_CONFIG_DIR=%CD%\data
    WorkMate.exe

（也可以只设 WORKBUDDY_CONFIG_DIR / CODEBUDDY_CONFIG_DIR，作用相同。）

Computer Use
------------
本包包含 Codex 官方 Windows x64 Computer Use 离线运行时（node.exe、
node_repl.exe 和 codex-computer-use.exe），不需要外网或单独安装 Codex。
首次开启时会解压到 %USERPROFILE%\.workmate\computer-use-runtime。

设置 → 智能体 → 电脑操控 → 开启 Codex Computer Use。
如果 Windows/目标应用弹出授权，按提示允许；首次解压会比普通启动稍慢。

开 App 前可先独立验证底层运行时（不会点击应用）：

    powershell -NoProfile -ExecutionPolicy Bypass -File .\check-computer-use.ps1 -RuntimeZip .\computer-use\runtime.zip

成功时会打印 Node 版本、NodeREPL、@oai/sky、应用列表数量和 Authenticode 状态。

如果这台机器连 exe 都不允许运行（AppLocker / WDAC / Smart App Control）
--------------------------------------------------------------------
那就不在这台机器上跑任何东西。在另一台你能控制的机器（Mac / 内网服务器）上：

    node scripts/workmate-web.mjs --host 0.0.0.0 --port 8787 --ui ui/dist

它会打印一个带 token 的地址（形如 http://192.168.1.20:8787/?token=XXXX），
在受限机器上用 Edge / Chrome 打开即可。注意：这个端口等于「远程执行 shell」的入口，
只在自己内网开。
