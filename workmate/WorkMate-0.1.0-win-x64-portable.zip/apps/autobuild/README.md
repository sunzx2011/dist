# AutoBuild Buddy App

独立 Buddy App 插件包。Core 只通过 app.json、home/categories.json 和 workflow schema 读取本应用；删除本目录即可卸载应用。
