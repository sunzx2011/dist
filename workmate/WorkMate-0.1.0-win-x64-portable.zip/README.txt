WorkMate 0.1.0 · Windows 免安装版（x64）
=====================================================

怎么用
------
1. 把整个文件夹解压到任意位置（不要只解出 WorkMate.exe，assets/ 和 apps/ 要跟着）。
2. 双击 WorkMate.exe 即可。不会写注册表、不装服务、不建开始菜单项。
3. 卸载 = 直接删掉这个文件夹。

系统要求
--------
* Windows 10 1803+ / Windows 11（x64）
* WebView2 运行时：Windows 11 自带；Windows 10 一般随 Edge 已装。
  如果双击后提示缺少 WebView2，装一次微软官方的 Evergreen Runtime（免费）即可：
  https://developer.microsoft.com/microsoft-edge/webview2/
* 首次运行可能被 SmartScreen 拦（本包未做代码签名）：点「更多信息」→「仍要运行」。

数据放在哪
----------
默认 %USERPROFILE%\.workmate（会话、模型配置、专家、日志都在这里）。
想让它完全绿色（数据跟着程序走），启动前设一个环境变量即可：

    set WORKMATE_CONFIG_DIR=%CD%\data
    WorkMate.exe

（也可以只设 WORKBUDDY_CONFIG_DIR / CODEBUDDY_CONFIG_DIR，作用相同。）

10 秒自检（不需要 WebView2，也不需要联网）
------------------------------------------
在解压出来的目录里开一个 cmd / PowerShell，依次跑：

    wb.exe --version        # 期望打印 wb 0.1.0
    wb.exe agents           # 期望列出 product.json 里的 agent 定义
    wb.exe tools list       # 期望列出工具（会顺带显示探测到的 shell）
    wb.exe sessions         # 期望打印会话列表（顺带证明 SQLite 能在这台机器建库）

上面四条都能正常输出 = 这套 Rust 核心（资源、工具表、shell 探测、SQLite）在
Windows 上确实跑起来了。GUI 若打不开，问题就只在 WebView2 那一层。

（没有 wb.exe 时说明打包时没编 CLI：cargo build --release -p workbuddy-rs --bin wb）
