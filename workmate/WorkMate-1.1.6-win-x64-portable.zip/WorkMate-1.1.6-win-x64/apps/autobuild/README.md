# AutoBuild Buddy App

独立 Buddy App 插件包。Core 只通过 app.json、home/categories.json、workflow schema 和 team 配置读取本应用；删除本目录即可卸载应用。

**不依赖 Git**：任何可写目录都能运行。每个步骤完成时只记录 `targets` 下文件的 sha256/大小快照，不会自动执行 `git add/commit`。

## 配置入口

- `app.json → team.roles`：**可选**角色团队（planner / builder / inspector / reviewer）。
  默认由主代理端到端完成；只有大步骤、并行工作或用户明确要求时才派子代理。
  - `model`：该角色使用的模型；`null` 表示跟随会话模型。
  - `tools`：工具白名单（引擎工具名）。
  - `readOnly: true`：Write/Edit 拒绝，Bash 只允许只读命令和验证命令。
  - `maxTurns`：单次派活的最大模型轮次；不配置时不限制。
  - `prompt`：角色提示词文件。
- `app.json → limits`：`maxPlanSteps` / `maxEvidencePerStep`；`maxTurnsPerRequest` 只在显式配置时生效，默认不限。
  创建 run 时固化进 `.workmate/workflow/runs/<id>/run.json`。
- `app.json → workflow.labels`：把宿主的稳定阶段/步骤 id 映射成 AutoBuild 文案；状态机本身不依赖这些中文名。
- `app.json → workflow.review`：声明独立评审角色（当前为 `reviewer`）和界面名称（当前为「对线」）。
  更换角色或名称不需要修改通用 review 宿主。
- `workflow/plan.schema.json`：步骤的 `checks[].criterionIds` 决定一条命令关闭哪些判据；
  有 `checks` 的步骤由宿主 `WorkflowVerify(action=run_checks)` 执行并自动写真实证据。
- 主代理默认工具面只有 `WorkflowPlan` / `WorkflowVerify` / `WorkflowCompleteStep`；
  评审模型只拿到 `ReviewSubmit` / `ReviewDisposition`，状态由宿主注入，不再暴露 `ReviewStatus`。
- `prompts/system.md`：主代理的应用级提示词与计划预算。
- 评审一旦开始，`approve_plan` / `accept` 会检查宿主注入的 `review.converged`；未收敛不允许推进。
- 对线是单轮可选能力：用户明确要求，或模型根据具体设计争议/风险主动开启；reviewer 最多提 3 个阻塞问题，主模型处置完立即结束。没有最终确认轮，也没有高风险第二轮。
- 计划评审只审需求、范围、决策级设计和覆盖关系。文件拆分、函数命名、内部结构、测试脚本、正则和证据不在计划阶段评审。
- `spec.executionMode=fast` 仅用于 1–3 步低风险任务，保存计划后自动批准；其余使用 `standard`。用户要求对线时必须使用 `standard`。
- 计划审批前由宿主检查每条验收标准至少被一个步骤覆盖；最终验收前由宿主重跑 `finalChecks` 或去重后的步骤检查。
- 对线入口：`需求实现 → 计划对线`，或用户明确写“开启对线 / 对抗评审”；最终验证阶段不再开启第二套对线。
- `prompts/roles/*.md`：各角色提示词；可在设置界面直接编辑覆盖。

改团队、模型、工具白名单、预算都只改这里，不需要改 Rust 代码。
插件与通用宿主的职责边界见 `docs/buddy-app-plugin-boundary.md`。

运行时也可以在 **设置 → 应用管理 → AutoBuild** 里改 `model / tools / maxTurns / readOnly / prompt`，
并在「运行预算」里改 `maxPlanSteps / maxTurnsPerRequest / maxEvidencePerStep`；
覆盖写入 `~/.workmate/buddy-apps-state.json`，不会修改安装目录里的 `app.json`。

## 提示词分层（改之前先看这里）

| 层 | 文件 | 何时注入 |
| --- | --- | --- |
| 应用级 | `prompts/system.md` | 每个 AutoBuild 会话的每一轮 |
| 工作流类型 | `home/categories.json → systemPromptAppend` | 建会话时选中的「需求实现 / 缺陷修复 / 重构优化 / 测试验收」 |
| 阶段提醒 + 状态摘要 | `src/workflow.rs::phase_prompt`（宿主） | 按 `draft / plan_review / execute / accept` 注入阶段、步骤、证据和评审摘要 |
| 角色 | `prompts/roles/*.md` | `Agent` 具名派活到 planner / builder / inspector / reviewer 时 |

`prompts/phases/*.md` 已删除：它从未被注入，和 `categories.json` 重复。
改工作流类型提示词请改 `home/categories.json`。
